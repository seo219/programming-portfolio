namespace ClassLibrary1
{
    class Car2
    {
        public string Bland { get; set; }
        public int Wheel_num { get; set; }
        public string Color { get; set; }
        public int Speed { get; set; }

        public Car2(string bland,int wheel_num,string color)
        {
            this.Bland = bland;
            this.Wheel_num = wheel_num;
            this.Color = color;
        }
        public void Speed_up(int speed)
        {
       
            if (speed + speed > 100)
                speed = 150;
            else 
                speed = speed + speed;

        }
        public void Speed_down(int speed)
        {
            if (speed - speed < 0)
                speed = 150;
            else
                speed = speed - speed;
        }
    }
    public class Class1
        {
       static void Main(string[] args)
       {
          Car2 car1 = new Car2("tico",4,"red");
          car1.Speed_up (150);



            Console.WriteLine(" 브랜드는 : {0}, 바퀴수는 : {1},  색깔은 : {2}, 속도는 {3}", car1.Bland, car1.Wheel_num, car1.Color, car1.Speed);
       }
    }
    
}

