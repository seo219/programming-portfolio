using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace kmj
{
    public class Class1
    {
    }
}
