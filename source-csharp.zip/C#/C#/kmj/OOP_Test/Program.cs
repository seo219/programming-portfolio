//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Runtime.CompilerServices;
//using System.Security.Cryptography;
//using System.Text;
//using System.Threading.Tasks;
//using System.Xml.Serialization;

//namespace OOP_Test
//{
//    class Car
//    {
//        private string brand;
//        private string color;
//        private int wheel_num;
//        private int speed = 0;

//        public string Brand { get; set; }
//        public int Wheel_num { get; set; }
//        public int Speed { get; set; }
//        public string Color { get; set; }

//        //private string  brand;

//        //public string  Brand
//        //{
//        //    get { return brand; }
//        //    set { brand = value; }
//        //}

//        //private string color;

//        //public string Color
//        //{
//        //    get { return color; }
//        //    set { color = value; }
//        //}

//        //private int wheel_num;

//        //public int Wheel_Num
//        //{
//        //    get { return wheel_num; }
//        //    set { wheel_num = value; }
//        //}

//        //private int speed;

//        //public int Speed
//        //{
//        //    get { return speed; }
//        //    set { speed = value; }
//        //}


//        public Car (string brand,string color,int wheel_num)
//        {
//            this.Brand = brand;
//            this.Color = color;
//            this.Wheel_num = wheel_num;

//            //this.brand = brand;
//            //this.color = color;
//            //this.wheel_num = wheel_num;
//        }
//        public void Speed_up(int value)
//        {
//            if (speed + value > 100)
//                speed = 100;
//            else 
//                speed = speed + value;                            
//        }
//        public void Speed_down(int value)
//        {
//            if (speed - value < 0)
//                speed = 0;
//            else
//                speed = speed - value;
//        }
//    }

//    internal class Program
//    { 
//        static void Main(string[] args)
//        {
//             Car car1 = new Car("tico","red",4);

//            car1.Speed = 100;

//            string t1 = car1.Brand;

//            Console.WriteLine("브랜드 = {0}, 색깔 = {1} 휠 갯수 = {2} 속도 = {3}", car1.Brand, car1.Color, car1.Wheel_num, car1.Speed);
            

//            Console.ReadKey();
//        }
//    }
//}
