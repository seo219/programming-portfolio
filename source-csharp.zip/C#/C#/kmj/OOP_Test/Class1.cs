using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Test
{
    class Car2
    {
        public string Bland { get; set; }
        public int Wheel_num { get; set; }
        public string Color { get; set; }
        public int Speed { get; set; }

        public Car2(string bland, int wheel_num, string color)
        {
            this.Bland = bland;
            this.Wheel_num = wheel_num;
            this.Color = color;
        }
        public void Speed_up(int speed)
        {

            if (speed + speed > 100)
                speed = 150;
            else
                speed = speed + speed;

        }
        public void Speed_down(int speed)
        {
            if (speed - speed < 0)
                speed = 150;
            else
                speed = speed - speed;
        }
    }
    public class Class1
    {
        static void Main(string[] args)
        {
            Car2 car1 = new Car2("tico", 4, "red");
            car1.Speed_up(100);



            Console.WriteLine($" 브랜드는 : {car1.Bland}, 바퀴수는 : {car1.Wheel_num},  색깔은 : {car1.Color}, 속도는 {car1.Speed}");
        }
    }

}


