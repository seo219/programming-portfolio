namespace Test01
{
    partial class DataUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TxtMat = new System.Windows.Forms.TextBox();
            this.TxtEng = new System.Windows.Forms.TextBox();
            this.TxtGra = new System.Windows.Forms.TextBox();
            this.TxtNam = new System.Windows.Forms.TextBox();
            this.ComPart = new System.Windows.Forms.ComboBox();
            this.ComDep = new System.Windows.Forms.ComboBox();
            this.BtnSave = new System.Windows.Forms.Button();
            this.BtnClean = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "부      서 : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "성      명 : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "학      력 : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "영      어 : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "수      학 : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "전형구분 : ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TxtMat);
            this.groupBox1.Controls.Add(this.TxtEng);
            this.groupBox1.Controls.Add(this.TxtGra);
            this.groupBox1.Controls.Add(this.TxtNam);
            this.groupBox1.Controls.Add(this.ComPart);
            this.groupBox1.Controls.Add(this.ComDep);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(268, 263);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "데이터 변경";
            // 
            // TxtMat
            // 
            this.TxtMat.Location = new System.Drawing.Point(77, 193);
            this.TxtMat.Name = "TxtMat";
            this.TxtMat.Size = new System.Drawing.Size(179, 21);
            this.TxtMat.TabIndex = 11;
            // 
            // TxtEng
            // 
            this.TxtEng.Location = new System.Drawing.Point(77, 146);
            this.TxtEng.Name = "TxtEng";
            this.TxtEng.Size = new System.Drawing.Size(179, 21);
            this.TxtEng.TabIndex = 10;
            // 
            // TxtGra
            // 
            this.TxtGra.Location = new System.Drawing.Point(77, 102);
            this.TxtGra.Name = "TxtGra";
            this.TxtGra.Size = new System.Drawing.Size(179, 21);
            this.TxtGra.TabIndex = 9;
            // 
            // TxtNam
            // 
            this.TxtNam.Location = new System.Drawing.Point(77, 58);
            this.TxtNam.Name = "TxtNam";
            this.TxtNam.Size = new System.Drawing.Size(179, 21);
            this.TxtNam.TabIndex = 8;
            // 
            // ComPart
            // 
            this.ComPart.FormattingEnabled = true;
            this.ComPart.Location = new System.Drawing.Point(77, 234);
            this.ComPart.Name = "ComPart";
            this.ComPart.Size = new System.Drawing.Size(179, 20);
            this.ComPart.TabIndex = 7;
            // 
            // ComDep
            // 
            this.ComDep.FormattingEnabled = true;
            this.ComDep.Location = new System.Drawing.Point(77, 14);
            this.ComDep.Name = "ComDep";
            this.ComDep.Size = new System.Drawing.Size(179, 20);
            this.ComDep.TabIndex = 6;
            // 
            // BtnSave
            // 
            this.BtnSave.Location = new System.Drawing.Point(8, 269);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(75, 23);
            this.BtnSave.TabIndex = 7;
            this.BtnSave.Text = "변경";
            this.BtnSave.UseVisualStyleBackColor = true;
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click_1);
            // 
            // BtnClean
            // 
            this.BtnClean.Location = new System.Drawing.Point(97, 269);
            this.BtnClean.Name = "BtnClean";
            this.BtnClean.Size = new System.Drawing.Size(75, 23);
            this.BtnClean.TabIndex = 8;
            this.BtnClean.Text = "초기화";
            this.BtnClean.UseVisualStyleBackColor = true;
            this.BtnClean.Click += new System.EventHandler(this.BtnClean_Click_1);
            // 
            // BtnClose
            // 
            this.BtnClose.Location = new System.Drawing.Point(186, 269);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(75, 23);
            this.BtnClose.TabIndex = 9;
            this.BtnClose.Text = "종료";
            this.BtnClose.UseVisualStyleBackColor = true;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click_1);
            // 
            // DataUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(268, 298);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnClean);
            this.Controls.Add(this.BtnSave);
            this.Controls.Add(this.groupBox1);
            this.Name = "DataUpdate";
            this.Text = "데이터 입력";
            this.Load += new System.EventHandler(this.DataUpdate_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TxtMat;
        private System.Windows.Forms.TextBox TxtEng;
        private System.Windows.Forms.TextBox TxtGra;
        private System.Windows.Forms.TextBox TxtNam;
        private System.Windows.Forms.ComboBox ComPart;
        private System.Windows.Forms.ComboBox ComDep;
        private System.Windows.Forms.Button BtnSave;
        private System.Windows.Forms.Button BtnClean;
        private System.Windows.Forms.Button BtnClose;
    }
}