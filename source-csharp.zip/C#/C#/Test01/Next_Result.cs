using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test01
{
    public partial class Next_Result : Form
    {
        static string StrConn = @"Data Source=CONFIGURE_LOCALLY;Initial Catalog=sis;User ID=CONFIGURE_LOCALLY;Password=CONFIGURE_LOCALLY;TrustServerCertificate=True;";
        DataTable Dt;

        public Next_Result()
        {
            InitializeComponent();
        }

        private async Task LoadDbAsync()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(StrConn))
                {
                    await conn.OpenAsync();

                    string sql = "select * from exam;";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    using (SqlDataReader dr = await cmd.ExecuteReaderAsync())
                    {
                        Dt = new DataTable();
                        Dt.Load(dr);
                    }
                }

                dataGridView1.DataSource = Dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외발생 : " + ex.Message);
            }

            listView1.Items.Clear();

            try
            {
                using (SqlConnection conn = new SqlConnection(StrConn))
                {
                    await conn.OpenAsync();

                    string sql = "select 수험번호, 부서, 성명, 주민등록번호, 우편번호, 주소 from exam_emp order by 수험번호 asc;";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    using (SqlDataReader dr = await cmd.ExecuteReaderAsync())
                    {
                        while (await dr.ReadAsync())
                        {
                            var item = new ListViewItem(dr.GetValue(0).ToString());
                            item.SubItems.Add(dr.GetValue(1).ToString());
                            item.SubItems.Add(dr.GetValue(2).ToString());
                            item.SubItems.Add(dr.GetValue(3).ToString());
                            item.SubItems.Add(dr.GetValue(4).ToString());
                            item.SubItems.Add(dr.GetValue(5).ToString());
                            listView1.Items.Add(item);
                        }
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외발생 : " + ex.Message);
            }

            CombDepart.Items.Clear();
            CombDepart.DropDownStyle = ComboBoxStyle.DropDownList;

            using (SqlConnection conn = new SqlConnection(StrConn))
            {
                await conn.OpenAsync();

                string sql = "select distinct 부서 from exam_emp order by 부서";
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                using (SqlDataReader dr = await cmd.ExecuteReaderAsync())
                {
                    while (await dr.ReadAsync())
                    {
                        if (!dr.IsDBNull(0))
                            CombDepart.Items.Add(dr.GetString(0).Trim());
                    }
                }
            }

        }

        private async Task ExecuteSPAsync(string spName, int num, string name, string address)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(StrConn))
                {
                    await conn.OpenAsync();

                    using (SqlCommand cmd = new SqlCommand(spName, conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        SqlParameter pInput1 = new SqlParameter("@num", SqlDbType.Int)
                        {
                            Direction = ParameterDirection.Input,
                            Value = num
                        };
                        cmd.Parameters.Add(pInput1);

                        SqlParameter pInput2 = new SqlParameter("@name", SqlDbType.NChar, 3) // 길이는 SP에 맞게
                        {
                            Direction = ParameterDirection.Input,
                            Value = name
                        };
                        cmd.Parameters.Add(pInput2);

                        SqlParameter pInput3 = new SqlParameter("@address", SqlDbType.NVarChar, 30) // 길이도 적당히
                        {
                            Direction = ParameterDirection.Input,
                            Value = address
                        };
                        cmd.Parameters.Add(pInput3);

                        int rowEffect = await cmd.ExecuteNonQueryAsync();
                        // 필요하면 MessageBox.Show("결과 : " + rowEffect);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외발생 : " + ex.Message);
            }
        }

        private void BtnExit_Click(object sender, EventArgs e) //
        {
            Application.Exit();
        }

        private async void BtnLoad_Click(object sender, EventArgs e) //
        {
            await LoadDbAsync();
        }


        private async void Next_Result_Load(object sender, EventArgs e) //
        {
            await LoadDbAsync();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e) //
        {
            if (listView1.SelectedItems.Count == 0) return;

            ListViewItem item = listView1.SelectedItems[0];

            TxtName.Text = item.SubItems[2].Text;
            CombDepart.Text = item.SubItems[1].Text;
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {

        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {

        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {

        }

    }
}
