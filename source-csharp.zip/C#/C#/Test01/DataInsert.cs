using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Test01
{
    public partial class DataInsert : Form
    {
        static string StrConn = @"Data Source=CONFIGURE_LOCALLY;Initial Catalog=sis;User ID=CONFIGURE_LOCALLY;Password=CONFIGURE_LOCALLY;TrustServerCertificate=True;";

        public DataInsert()
        {
            InitializeComponent();
        }

        private async Task LoadDbAsync()
        {
            ComDep.Items.Clear();
            ComDep.DropDownStyle = ComboBoxStyle.DropDownList;

            using (SqlConnection conn = new SqlConnection(StrConn))
            {
                await conn.OpenAsync();

                string sql = "select distinct 부서 from exam_emp order by 부서";
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                using (SqlDataReader dr = await cmd.ExecuteReaderAsync())
                {
                    while (await dr.ReadAsync())
                    {
                        if (!dr.IsDBNull(0))
                            ComDep.Items.Add(dr.GetString(0).Trim());
                    }
                }
            }

            ComPart.Items.Clear();
            ComPart.DropDownStyle = ComboBoxStyle.DropDownList;

            using (SqlConnection conn = new SqlConnection(StrConn))
            {
                await conn.OpenAsync();

                string sql = "select distinct 전형구분 from exam_emp order by 전형구분";
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                using (SqlDataReader dr = await cmd.ExecuteReaderAsync())
                {
                    while (await dr.ReadAsync())
                    {
                        if (!dr.IsDBNull(0))
                            ComPart.Items.Add(dr.GetString(0).Trim());
                    }
                }
            }

        }
        
        private async Task ExecuteSPAsync(string spName, string depart, string name, string grade, int eng, int math, string part)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(StrConn))
                {
                    await conn.OpenAsync();

                    using (SqlCommand cmd = new SqlCommand(spName, conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        SqlParameter pInput1 = new SqlParameter("@depart", SqlDbType.NChar, 4)
                        {
                            Direction = ParameterDirection.Input,
                            Value = depart
                        };
                        cmd.Parameters.Add(pInput1);

                        SqlParameter pInput2 = new SqlParameter("@name", SqlDbType.NChar, 3)
                        {
                            Direction = ParameterDirection.Input,
                            Value = name
                        };
                        cmd.Parameters.Add(pInput2);
                        
                        SqlParameter pInput3 = new SqlParameter("@grade", SqlDbType.NVarChar, 4)
                        {
                            Direction = ParameterDirection.Input,
                            Value = grade
                        };
                        cmd.Parameters.Add(pInput3);

                        SqlParameter pInput4 = new SqlParameter("@eng", SqlDbType.Int)
                        {
                            Direction = ParameterDirection.Input,
                            Value = eng
                        };
                        cmd.Parameters.Add(pInput4);

                        SqlParameter pInput5 = new SqlParameter("@math", SqlDbType.Int)
                        {
                            Direction = ParameterDirection.Input,
                            Value = math
                        };
                        cmd.Parameters.Add(pInput5);

                        SqlParameter pInput6 = new SqlParameter("@part", SqlDbType.NChar, 2)
                        {
                            Direction = ParameterDirection.Input,
                            Value = part
                        };
                        cmd.Parameters.Add(pInput6);

                        int rowEffect = await cmd.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외발생 : " + ex.Message);
            }
        }

        private async void DataInsert_Load(object sender, EventArgs e)
        {
            await LoadDbAsync();
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnClean_Click(object sender, EventArgs e)
        {
            ComDep.SelectedIndex = 0;
            TxtNam.Text = string.Empty;
            TxtGra.Text = string.Empty;
            TxtEng.Text = string.Empty;
            TxtMat.Text = string.Empty;
            ComPart.SelectedIndex = 0;
        }

        private async void BtnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ComPart.Text) ||
                string.IsNullOrWhiteSpace(ComDep.Text) ||
                string.IsNullOrWhiteSpace(TxtNam.Text) ||
                string.IsNullOrWhiteSpace(TxtGra.Text) ||
                string.IsNullOrWhiteSpace(TxtEng.Text) ||
                string.IsNullOrWhiteSpace(TxtMat.Text))
            {
                MessageBox.Show("모든 값을 입력하세요.");
                return;
            }

            await ExecuteSPAsync("InsertExam", ComDep.Text, TxtNam.Text, TxtGra.Text, int.Parse(TxtEng.Text), int.Parse(TxtMat.Text), ComPart.Text);

        }
    }
}
