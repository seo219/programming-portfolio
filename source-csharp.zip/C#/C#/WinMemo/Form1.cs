using System;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Printing;
using System.Threading;

namespace WinMemo
{
    public delegate void ShowTime();

    public partial class MemoConfig : Form
    {
        // 상태 및 설정 관련 필드
        private float defaultFontSize;
        private float zoomFactor = 1.0f;
        private string currentFileName = "";
        private DateTime lastSaveTime;
        private bool ThreadGo = true;

        // 폼 초기화
        public MemoConfig()
        {
            InitializeComponent();
            defaultFontSize = textBox1.Font.Size;
        }

        // 새로 만들기 (본문 초기화)
        private void 새로만들기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        // 새 창 열기 (메모장 추가 실행)
        private void 새창ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new MemoConfig().Show();
        }

        // 파일 열기 (텍스트 파일 불러오기)
        private void 열기SToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "텍스트 문서(*.txt)|*.txt|모든 파일|*.*";
            openFileDialog1.FilterIndex = 1;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = File.ReadAllText(openFileDialog1.FileName);
                currentFileName = openFileDialog1.FileName;
            }
            toolStripStatusLabelFile.Text = currentFileName;
        }

        // 저장 (현재 파일에 덮어쓰기)
        private void 저장SToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(currentFileName))
            {
                saveFileDialog1.Filter = "텍스트 문서(*.txt)|*.txt|모든 파일|*.*";
                saveFileDialog1.FilterIndex = 1;
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    currentFileName = saveFileDialog1.FileName;
                    File.WriteAllText(currentFileName, textBox1.Text);
                }
            }
            else
            {
                File.WriteAllText(currentFileName, textBox1.Text);
            }
            toolStripStatusLabelStatus.Text = "저장됨";
            toolStripStatusLabelFile.Text = currentFileName;
            lastSaveTime = DateTime.Now;
            toolStripStatusLabelSaveTime.Text = $"마지막 저장: {lastSaveTime:yyyy-MM-dd HH:mm:ss}";
        }

        // 다른 이름으로 저장
        private void 다른이름으로저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "텍스트 문서(*.txt)|*.txt|모든 파일|*.*";
            saveFileDialog1.FilterIndex = 1;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                currentFileName = saveFileDialog1.FileName;
                File.WriteAllText(currentFileName, textBox1.Text);
            }
            toolStripStatusLabelStatus.Text = "저장됨";
            toolStripStatusLabelFile.Text = currentFileName;
            lastSaveTime = DateTime.Now;
            toolStripStatusLabelSaveTime.Text = $"마지막 저장: {lastSaveTime:yyyy-MM-dd HH:mm:ss}";
        }

        // 인쇄 (프린터 출력)
        private void 인쇄ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            PrintDocument printDoc = new PrintDocument();
            printDialog.Document = printDoc;
            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                printDoc.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);
                printDoc.Print();
            }
        }

        // 인쇄 페이지 설정
        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Font font = new Font("Arial", 12);
            e.Graphics.DrawString(textBox1.Text, font, Brushes.Black, 10, 10);
        }

        // 프로그램 종료
        private void 끝내기XToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // 편집 메뉴 (실행 취소, 잘라내기, 복사, 붙여넣기, 삭제, 전체 선택)
        private void 실행취소UToolStripMenuItem_Click(object sender, EventArgs e) => textBox1.Undo();
        private void 잘라내기ToolStripMenuItem_Click(object sender, EventArgs e) => textBox1.Cut();
        private void 복사CToolStripMenuItem_Click(object sender, EventArgs e) => textBox1.Copy();
        private void 붙여넣기PToolStripMenuItem_Click(object sender, EventArgs e) => textBox1.Paste();
        private void 삭제LToolStripMenuItem_Click(object sender, EventArgs e) => textBox1.SelectedText = "";
        private void 모두선택ToolStripMenuItem_Click(object sender, EventArgs e) => textBox1.SelectAll();

        // 시간/날짜 삽입
        private void 시간날짜DToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.AppendText(DateTime.Now.ToString());
        }

        // 글꼴 변경
        private void 글꼴FToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (FontDialog dlg = new FontDialog())
            {
                dlg.Font = textBox1.Font;
                if (dlg.ShowDialog() == DialogResult.OK)
                    textBox1.Font = dlg.Font;
            }
        }

        // 확대
        private void 확대ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            zoomFactor += 0.1f;
            float newSize = defaultFontSize * zoomFactor;
            textBox1.Font = new Font(textBox1.Font.FontFamily, newSize);
        }

        // 축소
        private void 축소OToolStripMenuItem_Click(object sender, EventArgs e)
        {
            zoomFactor = Math.Max(0.1f, zoomFactor - 0.1f);
            float newSize = defaultFontSize * zoomFactor;
            textBox1.Font = new Font(textBox1.Font.FontFamily, newSize);
        }

        // 글꼴 크기 기본값 복원
        private void 기본값복원ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            zoomFactor = 1.0f;
            textBox1.Font = new Font(textBox1.Font.FontFamily, defaultFontSize);
        }

        // 상태표시줄 표시/숨김
        private void 상태표시줄ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            statusStrip1.Visible = !statusStrip1.Visible;
        }

        // 폼 로드 시 상태표시줄의 시계 스레드 시작
        private void MemoConfig_Load(object sender, EventArgs e)
        {
            Thread t = new Thread(new ThreadStart(Form_Thread));
            t.IsBackground = true;
            t.Start();
        }

        // 상태표시줄의 시계 표시 (1초마다 갱신)
        public void Form_Thread()
        {
            while (ThreadGo)
            {
                if (statusStrip1.InvokeRequired)
                {
                    statusStrip1.Invoke(new MethodInvoker(delegate
                    {
                        toolStripStatusLabelTime.Text = DateTime.Now.ToLongTimeString();
                    }));
                }
                else
                {
                    toolStripStatusLabelTime.Text = DateTime.Now.ToLongTimeString();
                }
                Thread.Sleep(1000);
            }
        }

        // 폼 닫을 때 시계 스레드 종료
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            ThreadGo = false;
            base.OnFormClosing(e);
        }

        // 텍스트 변경 시 글자수/상태/커서 위치 갱신
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            toolStripStatusLabelText.Text = $"글자수: {textBox1.Text.Length}";
            toolStripStatusLabelStatus.Text = "수정됨";
            UpdateCursorLineCol();
        }

        // 마우스 업/키 업/키 다운에서 커서 위치 갱신
        private void textBox1_MouseUp(object sender, MouseEventArgs e)
        {
            UpdateCursorLineCol();
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            UpdateCursorLineCol();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            UpdateCursorLineCol();
        }

        // 줄, 열 위치 갱신(상태표시줄)
        private void UpdateCursorLineCol()
        {
            int selectionStart = textBox1.SelectionStart;
            int line, col;
            if (selectionStart == textBox1.Text.Length && textBox1.Text.Length > 0)
            {
                line = textBox1.GetLineFromCharIndex(selectionStart - 1) + 1;
                col = selectionStart - textBox1.GetFirstCharIndexOfCurrentLine() + 1;
            }
            else
            {
                line = textBox1.GetLineFromCharIndex(selectionStart) + 1;
                col = selectionStart - textBox1.GetFirstCharIndexOfCurrentLine() + 1;
            }
            if (col < 1) col = 1;
            toolStripStatusLabelLineCol.Text = $"Ln {line}, Col {col}";
        }
    }
}
