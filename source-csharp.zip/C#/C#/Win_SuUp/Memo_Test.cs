using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    public partial class Memo_Test : Form
    {
        public Memo_Test()
        {
            InitializeComponent();
        }

        private void Memo_Test_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }

        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Btn_Cut_Click(object sender, EventArgs e)
        {
            if(TextBox_Memo.SelectionLength > 0)
            {
                TextBox_Memo.Cut();
                Label_Message.Text = "선택 영역이 클립 보드에 저장되었습니다.";
            }
        }

        private void Btn_Copy_Click(object sender, EventArgs e)
        {
            if (TextBox_Memo.SelectionLength > 0)
            {
                TextBox_Memo.Copy();
                Label_Message.Text = "선택 영역이 클립 보드에 저장되었습니다.";
            }
        }

        private void Btn_Paste_Click(object sender, EventArgs e)
        {
            if(TextBox_Memo.SelectionLength > 0)
            {
                if(MessageBox.Show("선택된 내용이 지워집니다. 계속 하시겠습니까?", "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }

            }
                TextBox_Memo.Paste();
                Label_Message.Text = "클립 보드의 내용을 붙여 넣었습니다.";
        }

        private void Btn_Undo_Click(object sender, EventArgs e)
        {
            TextBox_Memo.Undo();
            Label_Message.Text = "이전 작업이 취소 되었습니다.";
        }
    }
}
