using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    public partial class Test_Validate : Form
    {
        public Test_Validate()
        {
            InitializeComponent();
        }

        private void Text_Name_Validating(object sender, CancelEventArgs e)
        {
            if(Text_Name.Text.Length == 0)
            {
                Lbl_Message.Text = "이름을 입력하세요.";
                e.Cancel = true;
            }
        }

        private void Text_Name_Validated(object sender, EventArgs e)
        {
            Lbl_Message.Text = "";
        }

        private void Text_Mail_Validating(object sender, CancelEventArgs e)
        {
            if(Text_Mail.Text.Length == 0)
            {
                Lbl_Message.Text = "메일 주소를 입력하세요.";
                e.Cancel = true;
            }
            else if(Text_Mail.Text.IndexOf(".") == -1 || Text_Mail.Text.IndexOf("@") == -1)
            {
                Lbl_Message.Text = "정확한 메일 주소를 입력하세요.";
                e.Cancel = true;
            }
        }

        private void Text_Mail_Validated(object sender, EventArgs e)
        {
            Lbl_Message.Text = "";
        }

        private void Text_Tell_Validating(object sender, CancelEventArgs e)
        {
            bool result = Int32.TryParse(Text_Tell.Text, out int value);

            if (Text_Tell.Text.Length == 0)
            {
                Lbl_Message.Text = "집 전화번호를 입력하세요.";
                e.Cancel = true;
            }
            else if (!result)
            {
                Lbl_Message.Text = "정확한 집 전화번호를 입력하세요.";
                e.Cancel = true;
            }
        }

        private void Text_Tell_Validated(object sender, EventArgs e)
        {
            Lbl_Message.Text = "";
        }

        private void Test_Validate_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }

        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Text_Ph_Validating(object sender, CancelEventArgs e)
        {
            bool result = Int32.TryParse(Text_Ph.Text, out int value);

            if (Text_Ph.Text.Length == 0)
            {
                Lbl_Message.Text = "핸드폰 번호를 입력하세요.";
                e.Cancel = true;
            }
            else if (!result)
            {
                Lbl_Message.Text = "정확한 핸드폰 번호를 입력하세요.";
                e.Cancel = true;
            }
        }

        private void Text_Ph_Validated(object sender, EventArgs e)
        {
            Lbl_Message.Text = "";
        }
    }
}
