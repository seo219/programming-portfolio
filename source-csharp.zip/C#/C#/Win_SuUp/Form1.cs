using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Btn_Ok_Click(object sender, EventArgs e)
        {
            if (textBox_ID.Text.Length == 0 || textBox_PW.Text.Length == 0)
            {
                this.DialogResult = DialogResult.Retry;
            }
            else if (textBox_ID.Text.Length > 0 && textBox_PW.Text.Length > 0)
            {
                MessageBox.Show(textBox_ID.Text + "님 반갑습니다.", "확인");
            }
            this.Close();
        }

        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            //Application.Exit();
            this.Close();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
            this.ActiveControl = textBox_ID;
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (DialogResult == DialogResult.Retry)
            {
                MessageBox.Show("ID와 Password를 입력하세요.", "확인");
                e.Cancel = true;
            }
            
        }
    }
}
