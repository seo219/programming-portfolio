namespace Win_SuUp
{
    partial class Form_Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Child = new System.Windows.Forms.Button();
            this.Btn_Own = new System.Windows.Forms.Button();
            this.Btn_Center = new System.Windows.Forms.Button();
            this.Btn_Close = new System.Windows.Forms.Button();
            this.Parent_Text = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Btn_Child
            // 
            this.Btn_Child.Location = new System.Drawing.Point(57, 37);
            this.Btn_Child.Name = "Btn_Child";
            this.Btn_Child.Size = new System.Drawing.Size(272, 21);
            this.Btn_Child.TabIndex = 0;
            this.Btn_Child.Text = "자식폼 보기";
            this.Btn_Child.UseVisualStyleBackColor = true;
            this.Btn_Child.Click += new System.EventHandler(this.Btn_Child_Click);
            // 
            // Btn_Own
            // 
            this.Btn_Own.Location = new System.Drawing.Point(57, 66);
            this.Btn_Own.Name = "Btn_Own";
            this.Btn_Own.Size = new System.Drawing.Size(272, 21);
            this.Btn_Own.TabIndex = 1;
            this.Btn_Own.Text = "소유폼 표시";
            this.Btn_Own.UseVisualStyleBackColor = true;
            this.Btn_Own.Click += new System.EventHandler(this.Btn_Own_Click);
            // 
            // Btn_Center
            // 
            this.Btn_Center.Location = new System.Drawing.Point(57, 95);
            this.Btn_Center.Name = "Btn_Center";
            this.Btn_Center.Size = new System.Drawing.Size(272, 21);
            this.Btn_Center.TabIndex = 2;
            this.Btn_Center.Text = "화면 중앙으로";
            this.Btn_Center.UseVisualStyleBackColor = true;
            // 
            // Btn_Close
            // 
            this.Btn_Close.Location = new System.Drawing.Point(57, 124);
            this.Btn_Close.Name = "Btn_Close";
            this.Btn_Close.Size = new System.Drawing.Size(272, 21);
            this.Btn_Close.TabIndex = 3;
            this.Btn_Close.Text = "닫기";
            this.Btn_Close.UseVisualStyleBackColor = true;
            this.Btn_Close.Click += new System.EventHandler(this.Btn_Close_Click);
            // 
            // Parent_Text
            // 
            this.Parent_Text.Location = new System.Drawing.Point(57, 153);
            this.Parent_Text.Name = "Parent_Text";
            this.Parent_Text.Size = new System.Drawing.Size(272, 21);
            this.Parent_Text.TabIndex = 4;
            // 
            // Form_Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 211);
            this.Controls.Add(this.Parent_Text);
            this.Controls.Add(this.Btn_Close);
            this.Controls.Add(this.Btn_Center);
            this.Controls.Add(this.Btn_Own);
            this.Controls.Add(this.Btn_Child);
            this.Name = "Form_Test";
            this.Text = "Form_Test";
            this.Load += new System.EventHandler(this.Form_Test_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_Child;
        private System.Windows.Forms.Button Btn_Own;
        private System.Windows.Forms.Button Btn_Center;
        private System.Windows.Forms.Button Btn_Close;
        private System.Windows.Forms.TextBox Parent_Text;
    }
}