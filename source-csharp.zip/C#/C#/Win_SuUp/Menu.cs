using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    public delegate void ShowTime();

    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void exitEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void openOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "텍스트 문서(*.txt)|*.txt|모든 파일|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.InitialDirectory = @"F:\C#\Win_SuUp";
            openFileDialog1.Title = "텍스트 파일 열기";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string File_Name = openFileDialog1.FileName;
                StreamReader str = new StreamReader(File_Name, Encoding.Default);
                TextBox_Memo.Text = str.ReadToEnd();

                str.Close();
            }
        }

        private void saveSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "텍스트 문서(*.txt)|*.txt|모든 파일|*.*";
            saveFileDialog1.InitialDirectory = @"F:\C#\Win_SuUp";
            saveFileDialog1.Title = "텍스트 파일 저장";
            saveFileDialog1.OverwritePrompt = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string File_Name = saveFileDialog1.FileName;

                StreamWriter str_w = new StreamWriter(File_Name, false, Encoding.Default);

                str_w.Write(TextBox_Memo.Text);

                str_w.Flush();
                str_w.Close();
            }
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            Sta_Message.Text = "안녕하세요.";
            Thread t = new Thread(new ThreadStart(Form_Thread));
            t.Start();
        }

        bool ThreadGo = true;

        public void Form_Thread()
        {
            if (InvokeRequired)
            {
                while (ThreadGo)
                {
                    ShowTime del = new ShowTime(Form_Thread);
                    Sta_Time.Text = DateTime.Now.ToLongTimeString();
                    Invoke(del);
                    Thread.Sleep(1000);
                }

            }

        }
    }
}
