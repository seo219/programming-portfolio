using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    public partial class Key_Test : Form
    {
        public Key_Test()
        {
            InitializeComponent();
        }

        private void Label_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                Label.Text = "마우스 오른쪽 버튼이 클릭 되었습니다.";
            }
            else if (e.Button == MouseButtons.Left)
            {
                Label.Text = "마우스 왼쪽 버튼이 클릭 되었습니다.";
            } 
        }

        private void Btn_Ok_MouseHover(object sender, EventArgs e)
        {
            Btn_Ok.Cursor = Cursors.Hand;
        }

        private void Btn_Close_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Key_Test_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }

        private void TextBox_Memo_KeyPress(object sender, KeyPressEventArgs e)
        {
            Label.Text = Char.GetUnicodeCategory(e.KeyChar).ToString(); // 키의 카테고라
            // Label.Text = (e.KeyChar).ToString();
        }

        private void TextBox_Memo_KeyDown(object sender, KeyEventArgs e)
        {
            //if ((e.KeyCode == Keys.F1 && e.Shift) == true)
            //{
            //    MessageBox.Show("F1 Key와 Shift Key가 동시에 눌렸습니다.");
            //}

            if (e.KeyCode == Keys.F1 && e.Shift)
            {
                MessageBox.Show("텍스트 박스에서 F1 Key와 Shift Key가 동시에 눌렸습니다.");
            }
        }

        private void Key_Test_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.F1 && e.Shift) == true)
            {
                MessageBox.Show("폼에서 F1 Key와 Shift Key가 동시에 눌렸습니다.");
                e.Handled = true;
            }
        }
    }
}
