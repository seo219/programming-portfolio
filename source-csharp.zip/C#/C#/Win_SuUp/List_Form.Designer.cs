namespace Win_SuUp
{
    partial class List_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.List_Source = new System.Windows.Forms.ListBox();
            this.List_Dest = new System.Windows.Forms.ListBox();
            this.Btn_Move = new System.Windows.Forms.Button();
            this.Btn_Reject = new System.Windows.Forms.Button();
            this.BTN_Search = new System.Windows.Forms.Button();
            this.Btn_Ok = new System.Windows.Forms.Button();
            this.Btn_Cancel = new System.Windows.Forms.Button();
            this.Btn_Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // List_Source
            // 
            this.List_Source.FormattingEnabled = true;
            this.List_Source.ItemHeight = 12;
            this.List_Source.Location = new System.Drawing.Point(12, 12);
            this.List_Source.Name = "List_Source";
            this.List_Source.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.List_Source.Size = new System.Drawing.Size(151, 304);
            this.List_Source.TabIndex = 0;
            // 
            // List_Dest
            // 
            this.List_Dest.FormattingEnabled = true;
            this.List_Dest.ItemHeight = 12;
            this.List_Dest.Location = new System.Drawing.Point(307, 12);
            this.List_Dest.Name = "List_Dest";
            this.List_Dest.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.List_Dest.Size = new System.Drawing.Size(151, 304);
            this.List_Dest.TabIndex = 1;
            // 
            // Btn_Move
            // 
            this.Btn_Move.Location = new System.Drawing.Point(179, 90);
            this.Btn_Move.Name = "Btn_Move";
            this.Btn_Move.Size = new System.Drawing.Size(112, 29);
            this.Btn_Move.TabIndex = 2;
            this.Btn_Move.Text = "▶▶▶▶▶▶";
            this.Btn_Move.UseVisualStyleBackColor = true;
            this.Btn_Move.Click += new System.EventHandler(this.Btn_Move_Click);
            // 
            // Btn_Reject
            // 
            this.Btn_Reject.Location = new System.Drawing.Point(179, 152);
            this.Btn_Reject.Name = "Btn_Reject";
            this.Btn_Reject.Size = new System.Drawing.Size(112, 29);
            this.Btn_Reject.TabIndex = 3;
            this.Btn_Reject.Text = "◀◀◀◀◀◀";
            this.Btn_Reject.UseVisualStyleBackColor = true;
            this.Btn_Reject.Click += new System.EventHandler(this.Btn_Reject_Click);
            // 
            // BTN_Search
            // 
            this.BTN_Search.Location = new System.Drawing.Point(179, 214);
            this.BTN_Search.Name = "BTN_Search";
            this.BTN_Search.Size = new System.Drawing.Size(112, 29);
            this.BTN_Search.TabIndex = 4;
            this.BTN_Search.Text = "검색";
            this.BTN_Search.UseVisualStyleBackColor = true;
            this.BTN_Search.Click += new System.EventHandler(this.BTN_Search_Click);
            // 
            // Btn_Ok
            // 
            this.Btn_Ok.Location = new System.Drawing.Point(31, 322);
            this.Btn_Ok.Name = "Btn_Ok";
            this.Btn_Ok.Size = new System.Drawing.Size(112, 29);
            this.Btn_Ok.TabIndex = 5;
            this.Btn_Ok.Text = "확인";
            this.Btn_Ok.UseVisualStyleBackColor = true;
            this.Btn_Ok.Click += new System.EventHandler(this.Btn_Ok_Click);
            // 
            // Btn_Cancel
            // 
            this.Btn_Cancel.Location = new System.Drawing.Point(179, 322);
            this.Btn_Cancel.Name = "Btn_Cancel";
            this.Btn_Cancel.Size = new System.Drawing.Size(112, 29);
            this.Btn_Cancel.TabIndex = 6;
            this.Btn_Cancel.Text = "초기화";
            this.Btn_Cancel.UseVisualStyleBackColor = true;
            this.Btn_Cancel.Click += new System.EventHandler(this.Btn_Cancel_Click);
            // 
            // Btn_Exit
            // 
            this.Btn_Exit.Location = new System.Drawing.Point(326, 322);
            this.Btn_Exit.Name = "Btn_Exit";
            this.Btn_Exit.Size = new System.Drawing.Size(112, 29);
            this.Btn_Exit.TabIndex = 7;
            this.Btn_Exit.Text = "종료";
            this.Btn_Exit.UseVisualStyleBackColor = true;
            this.Btn_Exit.Click += new System.EventHandler(this.Btn_Exit_Click);
            // 
            // List_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 359);
            this.Controls.Add(this.List_Dest);
            this.Controls.Add(this.List_Source);
            this.Controls.Add(this.Btn_Exit);
            this.Controls.Add(this.Btn_Cancel);
            this.Controls.Add(this.Btn_Ok);
            this.Controls.Add(this.BTN_Search);
            this.Controls.Add(this.Btn_Reject);
            this.Controls.Add(this.Btn_Move);
            this.Name = "List_Form";
            this.Text = "List_Form";
            this.Load += new System.EventHandler(this.List_Form_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox List_Source;
        private System.Windows.Forms.ListBox List_Dest;
        private System.Windows.Forms.Button Btn_Move;
        private System.Windows.Forms.Button Btn_Reject;
        private System.Windows.Forms.Button BTN_Search;
        private System.Windows.Forms.Button Btn_Ok;
        private System.Windows.Forms.Button Btn_Cancel;
        private System.Windows.Forms.Button Btn_Exit;
    }
}