namespace Win_SuUp
{
    partial class Search_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Text_Item = new System.Windows.Forms.TextBox();
            this.Btn_Ok = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Text_Item
            // 
            this.Text_Item.Location = new System.Drawing.Point(12, 14);
            this.Text_Item.Name = "Text_Item";
            this.Text_Item.Size = new System.Drawing.Size(283, 21);
            this.Text_Item.TabIndex = 0;
            // 
            // Btn_Ok
            // 
            this.Btn_Ok.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Btn_Ok.Location = new System.Drawing.Point(302, 14);
            this.Btn_Ok.Name = "Btn_Ok";
            this.Btn_Ok.Size = new System.Drawing.Size(75, 21);
            this.Btn_Ok.TabIndex = 1;
            this.Btn_Ok.Text = "확인";
            this.Btn_Ok.UseVisualStyleBackColor = true;
            // 
            // Search_Form
            // 
            this.AcceptButton = this.Btn_Ok;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 49);
            this.Controls.Add(this.Btn_Ok);
            this.Controls.Add(this.Text_Item);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Search_Form";
            this.Text = "Search_Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Btn_Ok;
        public System.Windows.Forms.TextBox Text_Item;
    }
}