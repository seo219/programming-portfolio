using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    public partial class Dlg_Test1 : Form
    {
        public Dlg_Test1()
        {
            InitializeComponent();
        }
        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "텍스트 문서(*.txt)|*.txt|모든 파일|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.InitialDirectory = @"F:\C#\Win_SuUp";
            openFileDialog1.Title = "텍스트 파일 열기";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string File_Name = openFileDialog1.FileName;
                StreamReader str = new StreamReader(File_Name, Encoding.Default);
                textBox_Memo.Text = str.ReadToEnd();

                str.Close();
            }
        }

        private void Btn_Save_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "텍스트 문서(*.txt)|*.txt|모든 파일|*.*";
            saveFileDialog1.InitialDirectory = @"F:\C#\Win_SuUp";
            saveFileDialog1.Title = "텍스트 파일 저장";
            saveFileDialog1.OverwritePrompt = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string File_Name = saveFileDialog1.FileName;

                StreamWriter str_w = new StreamWriter(File_Name, false, Encoding.Default);

                str_w.Write(textBox_Memo.Text);
                
                str_w.Flush();
                str_w.Close();
            }
        }
    }
}
