using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    public partial class Form_Test : Form
    {
        public Form_Test()
        {
            InitializeComponent();
        }

        private void Btn_Close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form_Test_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }

        private void Btn_Child_Click(object sender, EventArgs e)
        {
            Mini_Form Child = new Mini_Form(Parent_Text.Text);
            Child.TopLevel = false;
            Child.Parent = this;
            Child.BringToFront();
            Child.Show();
        }

        private void Btn_Own_Click(object sender, EventArgs e)
        {
            Mini_Form Owned = new Mini_Form(Parent_Text.Text);
            this.AddOwnedForm(Owned);
            Owned.Show();
        }
    }
}
