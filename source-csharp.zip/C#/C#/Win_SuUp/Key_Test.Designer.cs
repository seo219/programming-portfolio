namespace Win_SuUp
{
    partial class Key_Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label = new System.Windows.Forms.Label();
            this.TextBox_Memo = new System.Windows.Forms.TextBox();
            this.Btn_Close = new System.Windows.Forms.Button();
            this.Btn_Ok = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label
            // 
            this.Label.Dock = System.Windows.Forms.DockStyle.Top;
            this.Label.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label.Location = new System.Drawing.Point(0, 0);
            this.Label.Name = "Label";
            this.Label.Size = new System.Drawing.Size(434, 55);
            this.Label.TabIndex = 0;
            this.Label.Text = "...";
            this.Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Label_MouseDown);
            // 
            // TextBox_Memo
            // 
            this.TextBox_Memo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBox_Memo.Location = new System.Drawing.Point(0, 55);
            this.TextBox_Memo.Multiline = true;
            this.TextBox_Memo.Name = "TextBox_Memo";
            this.TextBox_Memo.Size = new System.Drawing.Size(434, 356);
            this.TextBox_Memo.TabIndex = 1;
            this.TextBox_Memo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBox_Memo_KeyDown);
            this.TextBox_Memo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_Memo_KeyPress);
            // 
            // Btn_Close
            // 
            this.Btn_Close.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Btn_Close.Location = new System.Drawing.Point(0, 375);
            this.Btn_Close.Name = "Btn_Close";
            this.Btn_Close.Size = new System.Drawing.Size(434, 36);
            this.Btn_Close.TabIndex = 3;
            this.Btn_Close.Text = "종료";
            this.Btn_Close.UseVisualStyleBackColor = true;
            this.Btn_Close.Click += new System.EventHandler(this.Btn_Close_Click);
            // 
            // Btn_Ok
            // 
            this.Btn_Ok.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Btn_Ok.Location = new System.Drawing.Point(0, 339);
            this.Btn_Ok.Name = "Btn_Ok";
            this.Btn_Ok.Size = new System.Drawing.Size(434, 36);
            this.Btn_Ok.TabIndex = 2;
            this.Btn_Ok.Text = "확인";
            this.Btn_Ok.UseVisualStyleBackColor = true;
            this.Btn_Ok.MouseHover += new System.EventHandler(this.Btn_Ok_MouseHover);
            // 
            // Key_Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 411);
            this.Controls.Add(this.Btn_Ok);
            this.Controls.Add(this.Btn_Close);
            this.Controls.Add(this.TextBox_Memo);
            this.Controls.Add(this.Label);
            this.KeyPreview = true;
            this.Name = "Key_Test";
            this.Text = "Key_Test";
            this.Load += new System.EventHandler(this.Key_Test_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Key_Test_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label;
        private System.Windows.Forms.TextBox TextBox_Memo;
        private System.Windows.Forms.Button Btn_Close;
        private System.Windows.Forms.Button Btn_Ok;
    }
}