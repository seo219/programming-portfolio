using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    public partial class Tab_Test : Form
    {
        public Tab_Test()
        {
            InitializeComponent();
        }

        private void Tab_Test_Load(object sender, EventArgs e)
        {
            foreach(FontFamily FontName in FontFamily.Families)
            {
                Cmb_Font.Items.Add(FontName.Name);
            }
            Cmb_Font.Text = Cmb_Font.Items[0].ToString();

            for(int i = 6; i<= 48;  i++)
            {
                Cmb_Size.Items.Add(i.ToString());
            }
            Cmb_Size.Text = Cmb_Size.Items[0].ToString();

            Cmb_Style.Items.Add(FontStyle.Bold);
            Cmb_Style.Items.Add(FontStyle.Italic);
            Cmb_Style.Items.Add(FontStyle.Underline);
            Cmb_Style.Items.Add(FontStyle.Strikeout);
            Cmb_Style.Items.Add(FontStyle.Regular);

            Cmb_Style.Text = Cmb_Style.Items[0].ToString();

            Cmb_Color.Items.Add(Color.Black.Name);
            Cmb_Color.Items.Add(Color.Red.Name);
            Cmb_Color.Items.Add(Color.Orange.Name);
            Cmb_Color.Items.Add(Color.Yellow.Name);
            Cmb_Color.Items.Add(Color.Green.Name);
            Cmb_Color.Items.Add(Color.Blue.Name);
            Cmb_Color.Items.Add(Color.Indigo.Name);
            Cmb_Color.Items.Add(Color.Violet.Name);
            Cmb_Color.Items.Add(Color.Brown.Name);
            Cmb_Color.Items.Add(Color.Gray.Name);

            Cmb_Color.Text = Cmb_Color.Items[0].ToString();
        }


        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Btn_Ok_Click(object sender, EventArgs e)
        {
            string Font_Name = Cmb_Font.SelectedItem.ToString();
            int Font_Size = Int32.Parse(Cmb_Size.SelectedItem.ToString());
            FontStyle Font_Style = (FontStyle)Cmb_Style.SelectedItem;

            Label_Text.Font = new Font(Font_Name, Font_Size, Font_Style);

        }

        private void Btn_Ok1_Click(object sender, EventArgs e)
        {
            Label_Text.ForeColor = Color.FromName(Cmb_Color.Text);
            tabControl1.SelectedTab = tabPage1;
        }

        private void Btn_Cancel1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }
    }
}
