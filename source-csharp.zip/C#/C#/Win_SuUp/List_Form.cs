using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    public partial class List_Form : Form
    {
        public List_Form()
        {
            InitializeComponent();
        }

        private void Btn_Ok_Click(object sender, EventArgs e)
        {

        }

        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void List_Form_Load(object sender, EventArgs e)
        {
            List_Source.Items.AddRange(new string[] {"모니터", "키보드", "마우스", "그래픽 카드", "메인 보드", "프린터", "하드 디스크", "USB 메모리", "HDMI Cable"});
        }

        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            List_Source.Items.Clear();
            List_Dest.Items.Clear();

            List_Source.Items.AddRange(new string[] { "모니터", "키보드", "마우스", "그래픽 카드", "메인 보드", "프린터", "하드 디스크", "USB 메모리", "HDMI Cable" });
        }

        private void Btn_Move_Click(object sender, EventArgs e)
        {
            if(List_Source.Items.Count > 0)
            {
                foreach(string MyItem in List_Source.SelectedItems)
                {
                    List_Dest.Items.Add(MyItem);
                }
            }

            for (int MyItemIndex = List_Source.SelectedItems.Count - 1; MyItemIndex >= 0; MyItemIndex--)
            {
                List_Source.Items.RemoveAt(List_Source.SelectedIndices[MyItemIndex]);
            }

        }

        private void Btn_Reject_Click(object sender, EventArgs e)
        {
            if(List_Dest.Items.Count > 0)
            {
                foreach(string MovedItem in List_Dest.SelectedItems)
                {
                    List_Source.Items.Add(MovedItem);
                }

                for (int Index = List_Dest.SelectedItems.Count - 1; Index >= 0; Index--)
                {
                    List_Dest.Items.RemoveAt(List_Dest.SelectedIndices[Index]);
                }
            }
        }

        private void BTN_Search_Click(object sender, EventArgs e)
        {
            string SearchItem;
            int Idx;

            Search_Form SF = new Search_Form();
            if(SF.ShowDialog() == DialogResult.OK)
            {
                SearchItem = SF.Text_Item.Text;
                Idx = List_Source.Items.IndexOf(SearchItem);

                List_Source.ClearSelected();

                if(Idx > -1)
                {
                    List_Source.SetSelected(Idx, true);
                }
                else
                {
                    MessageBox.Show("입력하신 상품은 없습니다.", "찾기 실패");
                }
            }
        }
    }
}
