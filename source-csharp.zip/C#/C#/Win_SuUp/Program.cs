using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    internal static class Program
    {
        /// <summary>
        /// 해당 애플리케이션의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Login());
            //Application.Run(new Modal_Modaless());
            //Application.Run(new Form_Test());
            //Application.Run(new Test_Validate());
            //Application.Run(new List_Form());
            //Application.Run(new Tab_Test());
            //Application.Run(new Key_Test());
            //Application.Run(new Memo_Test());
            //Application.Run(new Dig_Test());
            //Application.Run(new Dlg_Test1());
            Application.Run(new Menu());
        }
    }
}
