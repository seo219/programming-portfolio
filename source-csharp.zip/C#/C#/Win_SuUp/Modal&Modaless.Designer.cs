namespace Win_SuUp
{
    partial class Modal_Modaless
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Modal = new System.Windows.Forms.Button();
            this.Modaless = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Modal
            // 
            this.Modal.Location = new System.Drawing.Point(197, 46);
            this.Modal.Name = "Modal";
            this.Modal.Size = new System.Drawing.Size(164, 38);
            this.Modal.TabIndex = 0;
            this.Modal.Text = "모달";
            this.Modal.UseVisualStyleBackColor = true;
            this.Modal.Click += new System.EventHandler(this.Modal_Click);
            // 
            // Modaless
            // 
            this.Modaless.Location = new System.Drawing.Point(197, 113);
            this.Modaless.Name = "Modaless";
            this.Modaless.Size = new System.Drawing.Size(164, 38);
            this.Modaless.TabIndex = 1;
            this.Modaless.Text = "모달리스";
            this.Modaless.UseVisualStyleBackColor = true;
            this.Modaless.Click += new System.EventHandler(this.Modaless_Click);
            // 
            // Modal_Modaless
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(559, 197);
            this.Controls.Add(this.Modaless);
            this.Controls.Add(this.Modal);
            this.Name = "Modal_Modaless";
            this.Text = "Modal_Modaless";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Modal;
        private System.Windows.Forms.Button Modaless;
    }
}