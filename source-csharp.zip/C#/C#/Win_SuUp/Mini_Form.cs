using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    public partial class Mini_Form : Form
    {
        public Mini_Form()
        {
            InitializeComponent();
        }

        public Mini_Form(string str)
        {
            InitializeComponent();
            this.textBox1.Text = str;
        }

        private void Btn_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
