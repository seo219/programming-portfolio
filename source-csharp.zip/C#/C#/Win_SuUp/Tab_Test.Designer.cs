namespace Win_SuUp
{
    partial class Tab_Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Btn_Cancel = new System.Windows.Forms.Button();
            this.Btn_Ok = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Cmb_Style = new System.Windows.Forms.ComboBox();
            this.Cmb_Size = new System.Windows.Forms.ComboBox();
            this.Cmb_Font = new System.Windows.Forms.ComboBox();
            this.Label_Text = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.Cmb_Color = new System.Windows.Forms.ComboBox();
            this.Btn_Ok1 = new System.Windows.Forms.Button();
            this.Btn_Cancel1 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(388, 250);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.Btn_Cancel);
            this.tabPage1.Controls.Add(this.Btn_Ok);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.Cmb_Style);
            this.tabPage1.Controls.Add(this.Cmb_Size);
            this.tabPage1.Controls.Add(this.Cmb_Font);
            this.tabPage1.Controls.Add(this.Label_Text);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(380, 224);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "글꼴";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // Btn_Cancel
            // 
            this.Btn_Cancel.Location = new System.Drawing.Point(245, 154);
            this.Btn_Cancel.Name = "Btn_Cancel";
            this.Btn_Cancel.Size = new System.Drawing.Size(113, 29);
            this.Btn_Cancel.TabIndex = 8;
            this.Btn_Cancel.Text = "종료";
            this.Btn_Cancel.UseVisualStyleBackColor = true;
            this.Btn_Cancel.Click += new System.EventHandler(this.Btn_Cancel_Click);
            // 
            // Btn_Ok
            // 
            this.Btn_Ok.Location = new System.Drawing.Point(88, 154);
            this.Btn_Ok.Name = "Btn_Ok";
            this.Btn_Ok.Size = new System.Drawing.Size(113, 29);
            this.Btn_Ok.TabIndex = 7;
            this.Btn_Ok.Text = "확인";
            this.Btn_Ok.UseVisualStyleBackColor = true;
            this.Btn_Ok.Click += new System.EventHandler(this.Btn_Ok_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "스타일";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "크기";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "글꼴";
            // 
            // Cmb_Style
            // 
            this.Cmb_Style.FormattingEnabled = true;
            this.Cmb_Style.Location = new System.Drawing.Point(88, 108);
            this.Cmb_Style.Name = "Cmb_Style";
            this.Cmb_Style.Size = new System.Drawing.Size(270, 20);
            this.Cmb_Style.TabIndex = 3;
            // 
            // Cmb_Size
            // 
            this.Cmb_Size.FormattingEnabled = true;
            this.Cmb_Size.Location = new System.Drawing.Point(88, 64);
            this.Cmb_Size.Name = "Cmb_Size";
            this.Cmb_Size.Size = new System.Drawing.Size(270, 20);
            this.Cmb_Size.TabIndex = 2;
            // 
            // Cmb_Font
            // 
            this.Cmb_Font.FormattingEnabled = true;
            this.Cmb_Font.Location = new System.Drawing.Point(88, 20);
            this.Cmb_Font.Name = "Cmb_Font";
            this.Cmb_Font.Size = new System.Drawing.Size(270, 20);
            this.Cmb_Font.TabIndex = 1;
            // 
            // Label_Text
            // 
            this.Label_Text.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Label_Text.Font = new System.Drawing.Font("Agency FB", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Text.Location = new System.Drawing.Point(3, 199);
            this.Label_Text.Name = "Label_Text";
            this.Label_Text.Size = new System.Drawing.Size(374, 22);
            this.Label_Text.TabIndex = 0;
            this.Label_Text.Text = "소프트웨어융합과";
            this.Label_Text.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.Btn_Cancel1);
            this.tabPage2.Controls.Add(this.Btn_Ok1);
            this.tabPage2.Controls.Add(this.Cmb_Color);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(380, 224);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "색상";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "색상 :";
            // 
            // Cmb_Color
            // 
            this.Cmb_Color.FormattingEnabled = true;
            this.Cmb_Color.Location = new System.Drawing.Point(77, 76);
            this.Cmb_Color.Name = "Cmb_Color";
            this.Cmb_Color.Size = new System.Drawing.Size(270, 20);
            this.Cmb_Color.TabIndex = 1;
            // 
            // Btn_Ok1
            // 
            this.Btn_Ok1.Location = new System.Drawing.Point(77, 119);
            this.Btn_Ok1.Name = "Btn_Ok1";
            this.Btn_Ok1.Size = new System.Drawing.Size(113, 29);
            this.Btn_Ok1.TabIndex = 2;
            this.Btn_Ok1.Text = "확인";
            this.Btn_Ok1.UseVisualStyleBackColor = true;
            this.Btn_Ok1.Click += new System.EventHandler(this.Btn_Ok1_Click);
            // 
            // Btn_Cancel1
            // 
            this.Btn_Cancel1.Location = new System.Drawing.Point(234, 119);
            this.Btn_Cancel1.Name = "Btn_Cancel1";
            this.Btn_Cancel1.Size = new System.Drawing.Size(113, 29);
            this.Btn_Cancel1.TabIndex = 3;
            this.Btn_Cancel1.Text = "취소";
            this.Btn_Cancel1.UseVisualStyleBackColor = true;
            this.Btn_Cancel1.Click += new System.EventHandler(this.Btn_Cancel1_Click);
            // 
            // Tab_Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(388, 250);
            this.Controls.Add(this.tabControl1);
            this.Name = "Tab_Test";
            this.Text = "Tab_Test";
            this.Load += new System.EventHandler(this.Tab_Test_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox Cmb_Style;
        private System.Windows.Forms.ComboBox Cmb_Size;
        private System.Windows.Forms.ComboBox Cmb_Font;
        private System.Windows.Forms.Label Label_Text;
        private System.Windows.Forms.Button Btn_Cancel;
        private System.Windows.Forms.Button Btn_Ok;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Btn_Cancel1;
        private System.Windows.Forms.Button Btn_Ok1;
        private System.Windows.Forms.ComboBox Cmb_Color;
        private System.Windows.Forms.Label label4;
    }
}