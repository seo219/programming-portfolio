using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_SuUp
{
    public partial class Modal_Modaless : Form
    {
        public Modal_Modaless()
        {
            InitializeComponent();
        }

        private void Modal_Click(object sender, EventArgs e)
        {
            Dialog dlg = new Dialog();
            dlg.Text = "모달";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show(dlg.textBox_Name.Text + "님 반갑습니다.");
            }
        }

        private void Modaless_Click(object sender, EventArgs e)
        {
            Dialog dlg = new Dialog();
            dlg.Text = "모달리스";
            dlg.Show();
        }
    }
}
