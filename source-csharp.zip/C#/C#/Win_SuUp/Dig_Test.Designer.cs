namespace Win_SuUp
{
    partial class Dig_Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TextBox_Memo = new System.Windows.Forms.TextBox();
            this.Btn_Font = new System.Windows.Forms.Button();
            this.Btn_Color = new System.Windows.Forms.Button();
            this.Btn_Exit = new System.Windows.Forms.Button();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // TextBox_Memo
            // 
            this.TextBox_Memo.Dock = System.Windows.Forms.DockStyle.Left;
            this.TextBox_Memo.Location = new System.Drawing.Point(0, 0);
            this.TextBox_Memo.Multiline = true;
            this.TextBox_Memo.Name = "TextBox_Memo";
            this.TextBox_Memo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TextBox_Memo.Size = new System.Drawing.Size(210, 409);
            this.TextBox_Memo.TabIndex = 0;
            // 
            // Btn_Font
            // 
            this.Btn_Font.Location = new System.Drawing.Point(235, 12);
            this.Btn_Font.Name = "Btn_Font";
            this.Btn_Font.Size = new System.Drawing.Size(107, 44);
            this.Btn_Font.TabIndex = 1;
            this.Btn_Font.Text = "글꼴";
            this.Btn_Font.UseVisualStyleBackColor = true;
            this.Btn_Font.Click += new System.EventHandler(this.Btn_Font_Click);
            // 
            // Btn_Color
            // 
            this.Btn_Color.Location = new System.Drawing.Point(235, 88);
            this.Btn_Color.Name = "Btn_Color";
            this.Btn_Color.Size = new System.Drawing.Size(107, 44);
            this.Btn_Color.TabIndex = 2;
            this.Btn_Color.Text = "색상";
            this.Btn_Color.UseVisualStyleBackColor = true;
            this.Btn_Color.Click += new System.EventHandler(this.Btn_Color_Click);
            // 
            // Btn_Exit
            // 
            this.Btn_Exit.Location = new System.Drawing.Point(235, 164);
            this.Btn_Exit.Name = "Btn_Exit";
            this.Btn_Exit.Size = new System.Drawing.Size(107, 44);
            this.Btn_Exit.TabIndex = 3;
            this.Btn_Exit.Text = "종료";
            this.Btn_Exit.UseVisualStyleBackColor = true;
            this.Btn_Exit.Click += new System.EventHandler(this.Btn_Exit_Click);
            // 
            // Dig_Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 409);
            this.Controls.Add(this.Btn_Exit);
            this.Controls.Add(this.Btn_Color);
            this.Controls.Add(this.Btn_Font);
            this.Controls.Add(this.TextBox_Memo);
            this.Name = "Dig_Test";
            this.Text = "Dig_Test";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TextBox_Memo;
        private System.Windows.Forms.Button Btn_Font;
        private System.Windows.Forms.Button Btn_Color;
        private System.Windows.Forms.Button Btn_Exit;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Timer timer1;
    }
}