namespace Win_SuUp
{
    partial class Test_Validate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Lbl_Message = new System.Windows.Forms.Label();
            this.Text_Name = new System.Windows.Forms.TextBox();
            this.Text_Mail = new System.Windows.Forms.TextBox();
            this.Text_Tell = new System.Windows.Forms.TextBox();
            this.Text_Ph = new System.Windows.Forms.TextBox();
            this.Btn_OK = new System.Windows.Forms.Button();
            this.Btn_Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "이름(&N)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "E-Mail 주소(&E)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "집전화(&T)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "핸드폰(&H)";
            // 
            // Lbl_Message
            // 
            this.Lbl_Message.BackColor = System.Drawing.SystemColors.Control;
            this.Lbl_Message.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Lbl_Message.Font = new System.Drawing.Font("굴림", 9F);
            this.Lbl_Message.Location = new System.Drawing.Point(0, 170);
            this.Lbl_Message.Name = "Lbl_Message";
            this.Lbl_Message.Size = new System.Drawing.Size(489, 25);
            this.Lbl_Message.TabIndex = 10;
            this.Lbl_Message.Text = "   ";
            this.Lbl_Message.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Text_Name
            // 
            this.Text_Name.Location = new System.Drawing.Point(117, 26);
            this.Text_Name.Name = "Text_Name";
            this.Text_Name.Size = new System.Drawing.Size(347, 21);
            this.Text_Name.TabIndex = 1;
            this.Text_Name.Validating += new System.ComponentModel.CancelEventHandler(this.Text_Name_Validating);
            this.Text_Name.Validated += new System.EventHandler(this.Text_Name_Validated);
            // 
            // Text_Mail
            // 
            this.Text_Mail.Location = new System.Drawing.Point(117, 55);
            this.Text_Mail.Name = "Text_Mail";
            this.Text_Mail.Size = new System.Drawing.Size(347, 21);
            this.Text_Mail.TabIndex = 3;
            this.Text_Mail.Validating += new System.ComponentModel.CancelEventHandler(this.Text_Mail_Validating);
            this.Text_Mail.Validated += new System.EventHandler(this.Text_Mail_Validated);
            // 
            // Text_Tell
            // 
            this.Text_Tell.Location = new System.Drawing.Point(117, 84);
            this.Text_Tell.Name = "Text_Tell";
            this.Text_Tell.Size = new System.Drawing.Size(347, 21);
            this.Text_Tell.TabIndex = 5;
            this.Text_Tell.Validating += new System.ComponentModel.CancelEventHandler(this.Text_Tell_Validating);
            this.Text_Tell.Validated += new System.EventHandler(this.Text_Tell_Validated);
            // 
            // Text_Ph
            // 
            this.Text_Ph.Location = new System.Drawing.Point(117, 113);
            this.Text_Ph.Name = "Text_Ph";
            this.Text_Ph.Size = new System.Drawing.Size(347, 21);
            this.Text_Ph.TabIndex = 7;
            this.Text_Ph.Validating += new System.ComponentModel.CancelEventHandler(this.Text_Ph_Validating);
            this.Text_Ph.Validated += new System.EventHandler(this.Text_Ph_Validated);
            // 
            // Btn_OK
            // 
            this.Btn_OK.Location = new System.Drawing.Point(172, 142);
            this.Btn_OK.Name = "Btn_OK";
            this.Btn_OK.Size = new System.Drawing.Size(101, 25);
            this.Btn_OK.TabIndex = 8;
            this.Btn_OK.Text = "확인";
            this.Btn_OK.UseVisualStyleBackColor = true;
            // 
            // Btn_Cancel
            // 
            this.Btn_Cancel.CausesValidation = false;
            this.Btn_Cancel.Location = new System.Drawing.Point(293, 142);
            this.Btn_Cancel.Name = "Btn_Cancel";
            this.Btn_Cancel.Size = new System.Drawing.Size(101, 25);
            this.Btn_Cancel.TabIndex = 9;
            this.Btn_Cancel.Text = "취소";
            this.Btn_Cancel.UseVisualStyleBackColor = true;
            this.Btn_Cancel.Click += new System.EventHandler(this.Btn_Cancel_Click);
            // 
            // Test_Validate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 195);
            this.Controls.Add(this.Btn_Cancel);
            this.Controls.Add(this.Btn_OK);
            this.Controls.Add(this.Text_Ph);
            this.Controls.Add(this.Text_Tell);
            this.Controls.Add(this.Text_Mail);
            this.Controls.Add(this.Text_Name);
            this.Controls.Add(this.Lbl_Message);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Test_Validate";
            this.Text = "Test_Validate";
            this.Load += new System.EventHandler(this.Test_Validate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Lbl_Message;
        private System.Windows.Forms.TextBox Text_Name;
        private System.Windows.Forms.TextBox Text_Mail;
        private System.Windows.Forms.TextBox Text_Tell;
        private System.Windows.Forms.TextBox Text_Ph;
        private System.Windows.Forms.Button Btn_OK;
        private System.Windows.Forms.Button Btn_Cancel;
    }
}