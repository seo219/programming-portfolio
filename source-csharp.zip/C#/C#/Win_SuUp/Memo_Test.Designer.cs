namespace Win_SuUp
{
    partial class Memo_Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_Message = new System.Windows.Forms.Label();
            this.TextBox_Memo = new System.Windows.Forms.TextBox();
            this.Btn_Undo = new System.Windows.Forms.Button();
            this.Btn_Copy = new System.Windows.Forms.Button();
            this.Btn_Cut = new System.Windows.Forms.Button();
            this.Btn_Paste = new System.Windows.Forms.Button();
            this.Btn_Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label_Message
            // 
            this.Label_Message.Dock = System.Windows.Forms.DockStyle.Top;
            this.Label_Message.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Label_Message.Location = new System.Drawing.Point(0, 0);
            this.Label_Message.Name = "Label_Message";
            this.Label_Message.Size = new System.Drawing.Size(406, 31);
            this.Label_Message.TabIndex = 0;
            this.Label_Message.Text = "...";
            this.Label_Message.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TextBox_Memo
            // 
            this.TextBox_Memo.Location = new System.Drawing.Point(3, 34);
            this.TextBox_Memo.Multiline = true;
            this.TextBox_Memo.Name = "TextBox_Memo";
            this.TextBox_Memo.Size = new System.Drawing.Size(266, 372);
            this.TextBox_Memo.TabIndex = 1;
            // 
            // Btn_Undo
            // 
            this.Btn_Undo.Location = new System.Drawing.Point(275, 34);
            this.Btn_Undo.Name = "Btn_Undo";
            this.Btn_Undo.Size = new System.Drawing.Size(124, 36);
            this.Btn_Undo.TabIndex = 2;
            this.Btn_Undo.Text = "실행취소";
            this.Btn_Undo.UseVisualStyleBackColor = true;
            this.Btn_Undo.Click += new System.EventHandler(this.Btn_Undo_Click);
            // 
            // Btn_Copy
            // 
            this.Btn_Copy.Cursor = System.Windows.Forms.Cursors.Default;
            this.Btn_Copy.Location = new System.Drawing.Point(275, 118);
            this.Btn_Copy.Name = "Btn_Copy";
            this.Btn_Copy.Size = new System.Drawing.Size(124, 36);
            this.Btn_Copy.TabIndex = 3;
            this.Btn_Copy.Text = "복사하기";
            this.Btn_Copy.UseVisualStyleBackColor = true;
            this.Btn_Copy.Click += new System.EventHandler(this.Btn_Copy_Click);
            // 
            // Btn_Cut
            // 
            this.Btn_Cut.Location = new System.Drawing.Point(275, 202);
            this.Btn_Cut.Name = "Btn_Cut";
            this.Btn_Cut.Size = new System.Drawing.Size(124, 36);
            this.Btn_Cut.TabIndex = 4;
            this.Btn_Cut.Text = "잘라내기";
            this.Btn_Cut.UseVisualStyleBackColor = true;
            this.Btn_Cut.Click += new System.EventHandler(this.Btn_Cut_Click);
            // 
            // Btn_Paste
            // 
            this.Btn_Paste.Location = new System.Drawing.Point(275, 286);
            this.Btn_Paste.Name = "Btn_Paste";
            this.Btn_Paste.Size = new System.Drawing.Size(124, 36);
            this.Btn_Paste.TabIndex = 5;
            this.Btn_Paste.Text = "붙여넣기";
            this.Btn_Paste.UseVisualStyleBackColor = true;
            this.Btn_Paste.Click += new System.EventHandler(this.Btn_Paste_Click);
            // 
            // Btn_Exit
            // 
            this.Btn_Exit.Location = new System.Drawing.Point(275, 370);
            this.Btn_Exit.Name = "Btn_Exit";
            this.Btn_Exit.Size = new System.Drawing.Size(124, 36);
            this.Btn_Exit.TabIndex = 6;
            this.Btn_Exit.Text = "종료";
            this.Btn_Exit.UseVisualStyleBackColor = true;
            this.Btn_Exit.Click += new System.EventHandler(this.Btn_Exit_Click);
            // 
            // Memo_Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 412);
            this.Controls.Add(this.Btn_Exit);
            this.Controls.Add(this.Btn_Paste);
            this.Controls.Add(this.Btn_Cut);
            this.Controls.Add(this.Btn_Copy);
            this.Controls.Add(this.Btn_Undo);
            this.Controls.Add(this.TextBox_Memo);
            this.Controls.Add(this.Label_Message);
            this.Name = "Memo_Test";
            this.Text = "Memo_Test";
            this.Load += new System.EventHandler(this.Memo_Test_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_Message;
        private System.Windows.Forms.TextBox TextBox_Memo;
        private System.Windows.Forms.Button Btn_Undo;
        private System.Windows.Forms.Button Btn_Copy;
        private System.Windows.Forms.Button Btn_Cut;
        private System.Windows.Forms.Button Btn_Paste;
        private System.Windows.Forms.Button Btn_Exit;
    }
}