using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    internal static class Program
    {
        /// <summary>
        /// 해당 애플리케이션의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Del_Pub());
            //Application.Run(new Del_Sub());
            //Application.Run(new Del_Sub1());
            //Application.Run(new Arg_FormEvent_Pub());
            //Application.Run(new DBConn());
            //Application.Run(new ExecuteScalar());
            //Application.Run(new ExecuteNonQuery());
            //Application.Run(new ListVeiw_Test());
            Application.Run(new List_Apply());
        }
    }
}
