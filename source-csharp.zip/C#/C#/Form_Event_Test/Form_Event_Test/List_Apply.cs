using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Form_Event_Test
{
    public partial class List_Apply : Form
    {
        static string StrConn = @"Data Source=CONFIGURE_LOCALLY;Initial Catalog=sis;User ID=CONFIGURE_LOCALLY;Password=CONFIGURE_LOCALLY;TrustServerCertificate=True;";
        DataTable Dt;

        public List_Apply()
        {
            InitializeComponent();
        }

        private async Task LoadDbAsync()
        {
            listView1.Items.Clear();

            try
            {
                using (SqlConnection conn = new SqlConnection(StrConn))
                {
                    await conn.OpenAsync();

                    // string sql = "WAITFOR DELAY '00:00:05'; select 수험번호, 성명, 주소 from ListViewTest order by 수험번호 asc;"; // WAITFOR DELAY '00:00:05';는 비동기 작동 확인용 쿼리
                    string sql = "select 수험번호, 성명, 주소 from ListViewTest order by 수험번호 asc;";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    using (SqlDataReader dr = await cmd.ExecuteReaderAsync())
                    {
                        while (await dr.ReadAsync())
                        {
                            var item = new ListViewItem(dr.GetValue(0).ToString());
                            item.SubItems.Add(dr.GetValue(1).ToString());
                            item.SubItems.Add(dr.GetValue(2).ToString());
                            listView1.Items.Add(item);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외발생 : " + ex.Message);
            }
        }


        private async Task ExecuteSPAsync(string spName, int num, string name, string address)
{
    try
    {
        using (SqlConnection conn = new SqlConnection(StrConn))
        {
            await conn.OpenAsync();

            using (SqlCommand cmd = new SqlCommand(spName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter pInput1 = new SqlParameter("@num", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Input,
                    Value = num
                };
                cmd.Parameters.Add(pInput1);

                SqlParameter pInput2 = new SqlParameter("@name", SqlDbType.NChar, 3) // 길이는 SP에 맞게
                {
                    Direction = ParameterDirection.Input,
                    Value = name
                };
                cmd.Parameters.Add(pInput2);

                SqlParameter pInput3 = new SqlParameter("@address", SqlDbType.NVarChar, 30) // 길이도 적당히
                {
                    Direction = ParameterDirection.Input,
                    Value = address
                };
                cmd.Parameters.Add(pInput3);

                int rowEffect = await cmd.ExecuteNonQueryAsync();
                // 필요하면 MessageBox.Show("결과 : " + rowEffect);
            }
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show("예외발생 : " + ex.Message);
    }
}


        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private async void Btn_Add_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Txt_Num.Text) ||
                string.IsNullOrWhiteSpace(Txt_Name.Text) ||
                string.IsNullOrWhiteSpace(Txt_Add.Text))
            {
                MessageBox.Show("모든 값을 입력하세요.");
                return;
            }

            await ExecuteSPAsync("InsertListView",
                                 int.Parse(Txt_Num.Text),
                                 Txt_Name.Text,
                                 Txt_Add.Text);

            await LoadDbAsync();
        }

        private async void Btn_Update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Txt_Num.Text))
            {
                MessageBox.Show("수정할 수험번호를 입력(또는 선택)하세요.");
                return;
            }

            await ExecuteSPAsync("UpdateListView",
                                 int.Parse(Txt_Num.Text),
                                 Txt_Name.Text,
                                 Txt_Add.Text);

            await LoadDbAsync();
        }

        private async void Btn_Delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Txt_Num.Text))
            {
                MessageBox.Show("삭제할 수험번호를 입력(또는 선택)하세요.");
                return;
            }

            await ExecuteSPAsync("DeleteListView",
                                 int.Parse(Txt_Num.Text),
                                 Txt_Name.Text,
                                 Txt_Add.Text);

            await LoadDbAsync();
        }


        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0) return;

            ListViewItem item = listView1.SelectedItems[0];

            Txt_Num.Text = item.SubItems[0].Text;
            Txt_Name.Text = item.SubItems[1].Text;
            Txt_Add.Text = item.SubItems[2].Text;
        }

        private async void List_Apply_Load(object sender, EventArgs e)
        {
            await LoadDbAsync();
        }


        private void Btn_Insert_Click(object sender, EventArgs e)
        {

        }
    }
}
