using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class Event_Sb : Form
    {
        public Event_Sb()
        {
            InitializeComponent();
        }
        public void Displayer(object sender, EventArgs e)
        {
            Event_Pb event_numgen = sender as Event_Pb;

        }
    }
}
