using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class Del_Sub : Form
    {
        public Del_Sub()
        {
            InitializeComponent();
        }

        private void Del_Sub_Load(object sender, EventArgs e)
        {
            Del_Pub dp = new Del_Pub();
            dp.Show();
            dp.Event_TextBox += Dp_Event_TextBox;
        }

        private void Dp_Event_TextBox(string name)
        {
            this.BeginInvoke(new Action(() =>
            {
                Sub_TextBox.Text = name;

            }));
        }
    }
}
