using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class DataGridTest : Form
    {
        static string StrConn = @"Data Source=CONFIGURE_LOCALLY;Initial Catalog=sis;User ID=CONFIGURE_LOCALLY;Password=CONFIGURE_LOCALLY;TrustServerCertificate=True;";

        public DataGridTest()
        {
            InitializeComponent();
        }
    }
}
