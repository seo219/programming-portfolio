using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class Arg_FormEvent_Pub : Form
    {
        public class ValueTimeEventArg : EventArgs
        {
            public int Value {  get; set; }
            public string Time { get; set; }

            public ValueTimeEventArg(int value, string time)
            {
                Value = value;
                Time = time;
            }
        }

        public event EventHandler<ValueTimeEventArg> ValueReset;


        public Arg_FormEvent_Pub()
        {
            InitializeComponent();
        }

        private void Arg_FormEvent_Pub_Load(object sender, EventArgs e)
        {

        }

        private void EventBtn_Click(object sender, EventArgs e)
        {
            var now = DateTime.Now.ToString("yyyy-MM-dd tt h:mm:ss");
            ValueReset?.Invoke(this, new ValueTimeEventArg(0, now));
        }
    }
}
