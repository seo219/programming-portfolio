namespace Form_Event_Test
{
    partial class ExecuteNonQuery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Txt_Name = new System.Windows.Forms.TextBox();
            this.Txt_ID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Btn_Exit = new System.Windows.Forms.Button();
            this.Btn_TableDrop = new System.Windows.Forms.Button();
            this.Btn_Insert = new System.Windows.Forms.Button();
            this.Btn_Create = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Txt_Name
            // 
            this.Txt_Name.Location = new System.Drawing.Point(118, 172);
            this.Txt_Name.Name = "Txt_Name";
            this.Txt_Name.Size = new System.Drawing.Size(100, 21);
            this.Txt_Name.TabIndex = 1;
            // 
            // Txt_ID
            // 
            this.Txt_ID.Location = new System.Drawing.Point(118, 140);
            this.Txt_ID.Name = "Txt_ID";
            this.Txt_ID.Size = new System.Drawing.Size(100, 21);
            this.Txt_ID.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(55, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Name : ";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(80, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "ID : ";
            // 
            // Btn_Exit
            // 
            this.Btn_Exit.Location = new System.Drawing.Point(57, 305);
            this.Btn_Exit.Name = "Btn_Exit";
            this.Btn_Exit.Size = new System.Drawing.Size(161, 32);
            this.Btn_Exit.TabIndex = 5;
            this.Btn_Exit.Text = "종료";
            this.Btn_Exit.UseVisualStyleBackColor = true;
            this.Btn_Exit.Click += new System.EventHandler(this.Btn_Exit_Click);
            // 
            // Btn_TableDrop
            // 
            this.Btn_TableDrop.Location = new System.Drawing.Point(57, 257);
            this.Btn_TableDrop.Name = "Btn_TableDrop";
            this.Btn_TableDrop.Size = new System.Drawing.Size(161, 32);
            this.Btn_TableDrop.TabIndex = 6;
            this.Btn_TableDrop.Text = "테이블 삭제";
            this.Btn_TableDrop.UseVisualStyleBackColor = true;
            this.Btn_TableDrop.Click += new System.EventHandler(this.Btn_TableDrop_Click);
            // 
            // Btn_Insert
            // 
            this.Btn_Insert.Location = new System.Drawing.Point(57, 209);
            this.Btn_Insert.Name = "Btn_Insert";
            this.Btn_Insert.Size = new System.Drawing.Size(161, 32);
            this.Btn_Insert.TabIndex = 7;
            this.Btn_Insert.Text = "데이터 삽입";
            this.Btn_Insert.UseVisualStyleBackColor = true;
            this.Btn_Insert.Click += new System.EventHandler(this.Btn_Insert_Click);
            // 
            // Btn_Create
            // 
            this.Btn_Create.Location = new System.Drawing.Point(57, 92);
            this.Btn_Create.Name = "Btn_Create";
            this.Btn_Create.Size = new System.Drawing.Size(161, 32);
            this.Btn_Create.TabIndex = 8;
            this.Btn_Create.Text = "테이블 생성";
            this.Btn_Create.UseVisualStyleBackColor = true;
            this.Btn_Create.Click += new System.EventHandler(this.Btn_Create_Click);
            // 
            // ExecuteNonQuery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(272, 418);
            this.Controls.Add(this.Txt_Name);
            this.Controls.Add(this.Txt_ID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Btn_Exit);
            this.Controls.Add(this.Btn_TableDrop);
            this.Controls.Add(this.Btn_Insert);
            this.Controls.Add(this.Btn_Create);
            this.Name = "ExecuteNonQuery";
            this.Text = "ExecuteNonQuery";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Txt_Name;
        private System.Windows.Forms.TextBox Txt_ID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Btn_Exit;
        private System.Windows.Forms.Button Btn_TableDrop;
        private System.Windows.Forms.Button Btn_Insert;
        private System.Windows.Forms.Button Btn_Create;
    }
}