namespace Form_Event_Test
{
    partial class DBConn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Connection = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Btn_Connection
            // 
            this.Btn_Connection.Location = new System.Drawing.Point(12, 12);
            this.Btn_Connection.Name = "Btn_Connection";
            this.Btn_Connection.Size = new System.Drawing.Size(75, 23);
            this.Btn_Connection.TabIndex = 0;
            this.Btn_Connection.Text = "DB 연결";
            this.Btn_Connection.UseVisualStyleBackColor = true;
            this.Btn_Connection.Click += new System.EventHandler(this.Btn_Connection_Click);
            // 
            // DBConn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 197);
            this.Controls.Add(this.Btn_Connection);
            this.Name = "DBConn";
            this.Text = "DBConn";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Btn_Connection;
    }
}