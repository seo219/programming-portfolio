using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class Arg_FormEvent_Sub : Form
    {
        public Arg_FormEvent_Sub()
        {
            InitializeComponent();
        }

        private void Arg_FormEvent_Sub_Load(object sender, EventArgs e)
        {
            Arg_FormEvent_Pub pub = new Arg_FormEvent_Pub();
            pub.ValueReset += Pub_ValueReset;
            pub.Show();
        }

        private void Pub_ValueReset(object sender, Arg_FormEvent_Pub.ValueTimeEventArg e)
        {

        }
    }
}
