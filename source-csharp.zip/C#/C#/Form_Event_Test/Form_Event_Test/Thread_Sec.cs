using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class Thread_Sec : Form
    {

        public Thread_Sec()
        {
            InitializeComponent();
        }

        private void Thread_Sec_Load(object sender, EventArgs e)
        {
            Thread_Event thevent = new Thread_Event();
            thevent.CounterChanged += Thevent_CounterChanged;
            thevent.Show();
        }

        private void Thevent_CounterChanged(object sender, Thread_Event.CounterEventArgs e)
        {

        }
    }
}
