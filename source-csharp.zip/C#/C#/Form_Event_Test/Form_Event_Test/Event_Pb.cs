using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{

    public partial class Event_Pb : Form
    {
        public event EventHandler<int?> Event_NumGen;

        public Event_Pb()
        {
            InitializeComponent();
        }

        private void Event_Pb_Load(object sender, EventArgs e)
        {
            Event_Sb es = new Event_Sb();
            //this.Event_NumGen
            es.Show();

            //th = new Thread(new ThreadStart(Thread_Test));
            //th.IsBackground = true;
            //th.Start();
        }

        private void EventBtn_Click(object sender, EventArgs e)
        {
            //num = 0;
            //Event_NumGen(this, num); // 이벤트 발생
        }
        
        private void Thread_Test()
        {

        }
    }
}
