using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class ListVeiw_Test : Form
    {
        static string StrConn = @"Data Source=CONFIGURE_LOCALLY;Initial Catalog=sis;User ID=CONFIGURE_LOCALLY;Password=CONFIGURE_LOCALLY;TrustServerCertificate=True;";
        SqlConnection Conn = new SqlConnection(StrConn);

        public ListVeiw_Test()
        {
            InitializeComponent();
        }

        private void Btn_Read_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();

            try
            {
                Conn.Open();

                SqlCommand cmd = new SqlCommand("select 성명, 영어, 수학 from exam", Conn);
                SqlDataReader Dr = cmd.ExecuteReader();

                while (Dr.Read())
                {
                    ListViewItem item;
                    item = new ListViewItem(Dr.GetValue(0).ToString());
                    item.SubItems.Add(Dr.GetValue(1).ToString());
                    item.SubItems.Add(Dr.GetValue(2).ToString());
                    listView1.Items.Add(item);
                }
                Dr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외발생 : " + ex.Message);
            }
            finally
            {
                Conn?.Close();
            }
        }

        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
