using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class Del_Pub1 : Form
    {
        public class StrEventArgs : EventArgs
        {
            public string Msg1 {  get; set; }
            public string Msg2 { get; set; }

            public StrEventArgs(string msg1, string msg2)
            {
                Msg1 = msg1;
                Msg2 = msg2;
            }
        }

        public event EventHandler<StrEventArgs> Event_Name;

        public Del_Pub1()
        {
            InitializeComponent();
        }

        private void Pub_TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Event_Name(this, new StrEventArgs(Pub_TextBox.Text.Trim(), "Melong"));
            }
        }
    }
}
