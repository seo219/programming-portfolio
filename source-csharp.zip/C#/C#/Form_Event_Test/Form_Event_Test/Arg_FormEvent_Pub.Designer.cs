namespace Form_Event_Test
{
    partial class Arg_FormEvent_Pub
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.EventBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(131, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 50);
            this.label1.TabIndex = 2;
            this.label1.Text = "Event 발생자";
            // 
            // EventBtn
            // 
            this.EventBtn.Location = new System.Drawing.Point(35, 167);
            this.EventBtn.Name = "EventBtn";
            this.EventBtn.Size = new System.Drawing.Size(435, 58);
            this.EventBtn.TabIndex = 3;
            this.EventBtn.Text = "Event 발생";
            this.EventBtn.UseVisualStyleBackColor = true;
            this.EventBtn.Click += new System.EventHandler(this.EventBtn_Click);
            // 
            // Arg_FormEvent_Pub
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 308);
            this.Controls.Add(this.EventBtn);
            this.Controls.Add(this.label1);
            this.Name = "Arg_FormEvent_Pub";
            this.Text = "Arg_FormEvent_Pub";
            this.Load += new System.EventHandler(this.Arg_FormEvent_Pub_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button EventBtn;
    }
}