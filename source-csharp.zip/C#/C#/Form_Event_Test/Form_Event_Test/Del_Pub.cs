using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class Del_Pub : Form
    {
        public delegate void Dele_TextBox(string name);
        public event Dele_TextBox Event_TextBox;
        public Del_Pub()
        {
            InitializeComponent();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Event_TextBox(Pub_TextBox.Text.Trim());
            }
        }
    }
}
