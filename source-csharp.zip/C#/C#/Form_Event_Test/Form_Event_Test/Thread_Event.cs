using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class Thread_Event : Form
    {
        public class CounterEventArgs : EventArgs
        {
            public int Value { get; set; }

            public CounterEventArgs(int value)
            {
                Value = value;
            }
        }

        public event EventHandler<CounterEventArgs> CounterChanged;

        public Thread_Event()
        {
            InitializeComponent();
        }

        private void EventBtn_Click(object sender, EventArgs e)
        {

        }
    }
}
