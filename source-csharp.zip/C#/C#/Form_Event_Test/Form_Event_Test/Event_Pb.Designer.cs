namespace Form_Event_Test
{
    partial class Event_Pb
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EventBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // EventBtn
            // 
            this.EventBtn.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.EventBtn.Location = new System.Drawing.Point(40, 75);
            this.EventBtn.Name = "EventBtn";
            this.EventBtn.Size = new System.Drawing.Size(226, 57);
            this.EventBtn.TabIndex = 2;
            this.EventBtn.Text = "Event 발생";
            this.EventBtn.UseVisualStyleBackColor = true;
            this.EventBtn.Click += new System.EventHandler(this.EventBtn_Click);
            // 
            // Event_Pb
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 207);
            this.Controls.Add(this.EventBtn);
            this.Name = "Event_Pb";
            this.Text = "Event_Pb";
            this.Load += new System.EventHandler(this.Event_Pb_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button EventBtn;
    }
}