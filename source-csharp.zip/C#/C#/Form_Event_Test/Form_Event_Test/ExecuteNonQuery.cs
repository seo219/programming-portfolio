using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class ExecuteNonQuery : Form
    {
        static string StrConn = @"Data Source=CONFIGURE_LOCALLY;Initial Catalog=sis;User ID=CONFIGURE_LOCALLY;Password=CONFIGURE_LOCALLY;TrustServerCertificate=True;";
        SqlConnection Conn = new SqlConnection(StrConn);

        public ExecuteNonQuery()
        {
            InitializeComponent();
        }

        private void ExecuteSP(String SPName)
        {
            try // 실행 되면
            {
                Conn.Open();
                SqlCommand Cmd = new SqlCommand(SPName, Conn);
                Cmd.CommandType = CommandType.StoredProcedure;

                int RowEffect = Cmd.ExecuteNonQuery();
                MessageBox.Show("결과 : " + RowEffect.ToString());
            }
            catch (Exception ex) // 안된다면
            {
                MessageBox.Show("예외발생 : " + ex.Message);
            }
            finally // 되던 안되던
            {
                Conn?.Close();
            }
        }

        private void ExecuteSP(String SPName, int Id, string Name)
        {
            try
            {
                Conn.Open();
                SqlCommand Cmd = new SqlCommand(SPName, Conn);
                Cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter pInPut1 = new SqlParameter("@id", SqlDbType.Int);
                pInPut1.Direction = ParameterDirection.Input;
                pInPut1.Value = Id;
                Cmd.Parameters.Add(pInPut1);

                SqlParameter pInPut2 = new SqlParameter("@name", SqlDbType.NChar);
                pInPut2.Direction = ParameterDirection.Input;
                pInPut2.Value = Name;
                Cmd.Parameters.Add(pInPut2);

                int RowEffect = Cmd.ExecuteNonQuery();
                MessageBox.Show("결과 : " + RowEffect.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외발생 : " + ex.Message);
            }
            finally
            {
                Conn.Close();
            }
        }

        private void Btn_Create_Click(object sender, EventArgs e)
        {
            ExecuteSP("CreateMyTable");
        }

        private void Btn_Insert_Click(object sender, EventArgs e)
        {
            ExecuteSP("InsertTestTable", Int32.Parse(Txt_ID.Text), Txt_Name.Text);
        }

        private void Btn_TableDrop_Click(object sender, EventArgs e)
        {
            ExecuteSP("DropTestTable");
        }

        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
