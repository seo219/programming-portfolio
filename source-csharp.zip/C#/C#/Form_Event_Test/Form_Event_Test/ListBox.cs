using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class ListBox : Form
    {
        static string StrConn = @"Data Source=CONFIGURE_LOCALLY;Initial Catalog=sis;User ID=CONFIGURE_LOCALLY;Password=CONFIGURE_LOCALLY;TrustServerCertificate=True;";
        SqlConnection Conn = new SqlConnection(StrConn);

        public ListBox()
        {
            InitializeComponent();
        }

        private void Btn_Read_Click(object sender, EventArgs e)
        {
            try
            {
                listBox1.Items.Clear();

                Conn.Open();
                SqlCommand cmd = new SqlCommand("select * from exam_emp", Conn);

                SqlDataReader Dr;
                Dr = cmd.ExecuteReader();

                while (Dr.Read())
                {
                    string Rec = string.Format("부서 : {0}, 성명={1}, 학력={2}, 영어={3}, 수학={4}, 전형구분={5}, 수험번호={6}",
                        Dr["부서"], Dr["성명"], Dr["학력"], Dr["영어"], Dr["수학"], Dr["전형구분"], Dr["수험번호"]);

                    listBox1.Items.Add(Rec);
                }

                Dr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외발생 : " + ex.Message);
            }
            finally
            {
                Conn?.Close();
            }
        }

        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
