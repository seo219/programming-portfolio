using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class DBConn : Form
    {
        public DBConn()
        {
            InitializeComponent();
        }

        SqlConnection Conn = new SqlConnection();

        private void Btn_Connection_Click(object sender, EventArgs e)
        {
            try
            {
                Conn.ConnectionString = @"Data Source=CONFIGURE_LOCALLY;Initial Catalog=sis;User ID=CONFIGURE_LOCALLY;Password=CONFIGURE_LOCALLY;TrustServerCertificate=True;";

                Conn.Open();
                MessageBox.Show("연결성공");
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외발생 : " + ex.Message);
            }
        }

    }
}
