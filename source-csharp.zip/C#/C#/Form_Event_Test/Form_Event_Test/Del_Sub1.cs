using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class Del_Sub1 : Form
    {
        public Del_Sub1()
        {
            InitializeComponent();
        }

        private void Del_Sub1_Load(object sender, EventArgs e)
        {
            Del_Pub1 dp1 = new Del_Pub1();
            dp1.Event_Name += Dp1_Event_Name;
            dp1.Show();
        }

        private void Dp1_Event_Name(object sender, Del_Pub1.StrEventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}
