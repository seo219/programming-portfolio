using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Event_Test
{
    public partial class ExecuteScalar : Form
    {
        public ExecuteScalar()
        {
            InitializeComponent();
        }
        
        SqlConnection Conn = new SqlConnection();

        private void ExecuteScalar_Load(object sender, EventArgs e)
        {
            try
            {
                Conn.ConnectionString = @"Data Source=CONFIGURE_LOCALLY;Initial Catalog=sis;User ID=CONFIGURE_LOCALLY;Password=CONFIGURE_LOCALLY;TrustServerCertificate=True;";

                Conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외발생 : " + ex.Message);
            }
        }

        private void Btn_Search_Click(object sender, EventArgs e)
        {
            String StrSQL = "select 성명 from exam_emp where 수험번호=@txt_no";
            SqlCommand Cmd = new SqlCommand(StrSQL, Conn);
            Cmd.CommandType = CommandType.Text;

            SqlParameter p1 = new SqlParameter("@txt_no", SqlDbType.Int);
            p1.Value = Int32.Parse(Txt_No.Text);
            Cmd.Parameters.Add(p1);
            object scalarvalue = Cmd.ExecuteScalar();
            MessageBox.Show("성명 : " + scalarvalue);
        }

        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            Conn?.Close();
            Application.Exit();
        }
    }
}
