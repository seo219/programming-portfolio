using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class Test3
    {
        //static void Main(string[] args)
        //{
        //    int num, kor, eng, mat, sum;
        //    double avg;
        //    string name, result;

        //    Console.Write("학번을 입력 : ");
        //    num = Int32.Parse(Console.ReadLine());

        //    while (num != 9999)
        //    {
        //        Console.Write("이름을 입력 : ");
        //        name = Console.ReadLine();
        //        Console.Write("국어 점수를 입력 : ");
        //        kor = Int32.Parse(Console.ReadLine());
        //        Console.Write("영어 점수를 입력 : ");
        //        eng = Int32.Parse(Console.ReadLine());
        //        Console.Write("수학 점수를 입력 : ");
        //        mat = Int32.Parse(Console.ReadLine());

        //        sum = kor + eng + mat;
        //        avg = (double)sum / 3;

        //        if (kor >= 40 && eng >= 40 && mat >= 40 && avg >= 60)
        //        {
        //            result = "합격";
        //        } else
        //        {
        //            result = "불합격";
        //        }

        //        Console.WriteLine("이름 : {0}, 학번 : {1}, 국어 : {2}, 영어 : {3}, 수학 : {4}, 총점 : {5}, 평균 : {6}, 결과 : {7} \n", name, num, kor, eng, mat, sum, avg, result);

        //        Console.Write("학번을 입력 : ");
        //        num = Int32.Parse(Console.ReadLine());
        //    }
        //}
    }
}
