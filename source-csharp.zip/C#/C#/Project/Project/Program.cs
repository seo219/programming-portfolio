using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class Program
    {
        //static void Main(string[] args)
        //{
        //    int h;
        //    int w;
        //    int a;

        //    Console.Write("높이 입력 : ");
        //    h = Int32.Parse(Console.ReadLine());
        //    Console.Write("가로 입력 : ");
        //    w = Int32.Parse(Console.ReadLine());

        //    a = h * w;
        //    Console.WriteLine("높이 : {0}, 가로 : {1}, 넓이 : {2}", h, w, a);
        //}
    }
}
