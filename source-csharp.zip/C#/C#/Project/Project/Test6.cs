//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Project
//{
//    internal class Test6
//    {

//        static void BubbleSort(int[] arr)
//        {
//            for (int i = 0; i < arr.Length; i++)
//            {
//                Console.Write("{0}번째 정수를 입력 : ", i + 1);
//                arr[i] = Int32.Parse(Console.ReadLine());
//            }

//            int temp;
//            for (int i = 0; i < arr.Length - 1; i++)
//            {
//                for (int j = 0; j < arr.Length - i - 1; j++)
//                {
//                    if (arr[j] > arr[j + 1])
//                    {
//                        temp = arr[j];
//                        arr[j] = arr[j + 1];
//                        arr[j + 1] = temp;
//                    }
//                }
//            }
//        }

//        static void Main(string[] args)
//        {
//            int[] numbers = new int[5];

//            BubbleSort(numbers);

//            Console.Write("\n정렬된 정수 : ");
//            for (int i = 0; i < numbers.Length; i++)
//            {
//                Console.Write(numbers[i] + " ");
//            }
//            Console.Write("\n");
//        }
//    }
//}
