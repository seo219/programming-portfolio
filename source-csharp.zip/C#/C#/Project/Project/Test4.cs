using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class Test4
    {
        static void Swap(ref int x, ref int y)
        {
            int temp;
            temp = x;
            x = y;
            y = temp;

            Console.WriteLine("x = {0}, y = {1}", x, y);
        }
        //static void Main(string[] args)
        //{
        //    int x, y;
        //    x = 10;
        //    y = 20;

        //    Console.WriteLine("x = {0}, y = {1}\n", x, y);
        //    Swap(ref x, ref y);
        //}
    }
}
