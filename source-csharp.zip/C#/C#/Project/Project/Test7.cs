//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Project
//{
//    internal class Test7
//    {
//        static void SelectionSort(int[] arr)
//        {
//            for (int i = 0; i < arr.Length; i++)
//            {
//                Console.Write("{0}번째 정수를 입력 : ", i + 1);
//                arr[i] = Int32.Parse(Console.ReadLine());
//            }

//            int minIndex, temp;
//            for (int i = 0; i < arr.Length - 1; i++)
//            {
//                minIndex = i;

//                for (int j = i + 1; j < arr.Length; j++)
//                {
//                    if (arr[j] < arr[minIndex])
//                    {
//                        minIndex = j;
//                    }
//                }

//                temp = arr[i];
//                arr[i] = arr[minIndex];
//                arr[minIndex] = temp;
//            }
//        }

//        static void Main()
//        {
//            int[] numbers = new int[5];

//            SelectionSort(numbers);

//            Console.Write("\n정렬된 정수 : ");
//            for (int i = 0; i < numbers.Length; i++)
//            {
//                Console.Write(numbers[i] + " ");
//            }
//            Console.Write("\n");
//        }
//    }
//}
