using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class Test5
    {
        static void Input_Data(int[] num)
        {
            for (int i = 0; i < num.Length; i++)
            {
                do
                {
                    Console.Write("{0}번째 점수를 입력 : ", i + 1);
                    num[i] = Int32.Parse(Console.ReadLine());
                } while (num[i] < 0 || num[i] > 10);
            }
        }

        static int Max_Score(int[] num)
        {
            int max = num[0];
            for (int i = 0; i < num.Length; i++)
            {
                if (num[i] > max)
                {
                    max = num[i];
                }
            }
            return max;
        }

        static int Min_Score(int[] num)
        {
            int min = num[0];
            for (int i = 0; i < num.Length; i++)
            {
                if (num[i] < min)
                {
                    min = num[i];
                }
            }
            return min;
        }

        static int Sum_Score(int[] num)
        {
            int sum = 0;

            for (int i = 0; i < num.Length; i++)
            {
                sum += num[i];
            }

            return sum;
        }

        //static void Main(string[] args)
        //{
        //    int[] num = new int[8];
        //    int score;

        //    Input_Data(num);
        //    score = Sum_Score(num) - (Min_Score(num) + Max_Score(num));

        //    Console.WriteLine("최종 점수 : {0}", score);
        //}
    }
}
