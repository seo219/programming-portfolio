using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class Test2
    {
        //static void Main(string[] args)
        //{
        //    int result;
        //    for (int i = 2; i < 10; i++)
        //    {
        //        Console.WriteLine("==== {0}단 ====", i);
        //        for (int j = 1; j < 10; j++)
        //        {
        //            result = i * j;
        //            if (result >= 60)
        //            {
        //                break;
        //            }
        //            else if (result >= 30)
        //            {
        //                continue;
        //            }
        //            else
        //            {
        //                Console.WriteLine("{0} * {1} = {2}", i, j, i * j);
        //            }
        //        }
        //            Console.WriteLine();
        //    }
        //}
    }
}
