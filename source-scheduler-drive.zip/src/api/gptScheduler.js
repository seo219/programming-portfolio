// src/api/gptScheduler.js

import { OpenAI } from 'openai';

/**
 * ⚠️ 현재는 브라우저에서 호출(과제 용). 배포 전에는 서버로 옮기세요.
 */
const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  // 배포용이면 dangerouslyAllowBrowser 제거하고 서버 사이드에서 호출
  dangerouslyAllowBrowser: true,
});

// ===================== 공용 유틸 =====================

const MODEL = 'gpt-4o-mini';

const TYPE_COLORS = {
  sleep: '#F0E6FF',
  meal: '#E0FBFC',
  fixed: '#E3F9E5',
  todo: '#FFF5E5',
  holiday: '#FFEFD5',
};

// 시간 유틸(정규화)
const toMin = (hhmm) => {
  const [h, m] = String(hhmm || '00:00').split(':').map(x => parseInt(x, 10));
  return (Number.isFinite(h) ? h : 0) * 60 + (Number.isFinite(m) ? m : 0);
};
const toHHMM = (min) => {
  const h = Math.floor(min / 60);
  const m = min % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
};
const padHHMM = (s) => toHHMM(toMin(s));

const clamp = (t, min, max) => Math.max(min, Math.min(max, t));
const overlaps = (a, b) => Math.max(toMin(a.start), toMin(b.start)) < Math.min(toMin(a.end), toMin(b.end));

/** generatedTasks 표준화 */
function normalizeTask(t) {
  const type = t.type || (t.task === '수면' ? 'sleep' : t.type) || 'fixed';
  const task = t.task || t.activity || (type === 'sleep' ? '수면' : '');
  const activity = t.activity || task;
  return {
    start: padHHMM(t.start),
    end: padHHMM(t.end),
    type,
    task,
    activity,                 // ReschedulePage 미리보기 호환
    color: t.color || TYPE_COLORS[type] || undefined,
  };
}

function normalizeFixedData(fixedData = {}) {
  const sleepTime = fixedData.sleepTime || { wakeUp: '06:00', bedTime: '22:00' };
  const meals = (fixedData.meals || []).map(m => ({
    start: padHHMM(m.start), end: padHHMM(m.end), type: 'meal', task: '식사', activity: '식사', color: TYPE_COLORS.meal,
  }));
  const schedules = (fixedData.schedules || []).map(s => ({
    start: padHHMM(s.start), end: padHHMM(s.end), type: 'fixed', task: s.task || '고정 일정', activity: s.task || '고정 일정', color: s.color || TYPE_COLORS.fixed,
  }));

  const wake = padHHMM(sleepTime.wakeUp || '06:00');
  const bed = padHHMM(sleepTime.bedTime || '22:00');

  // 수면 블록은 렌더 시 특수 처리하는 경우가 많지만, 일관성을 위해 명시 추가 가능
  const sleep = [{
    start: bed, end: wake, type: 'sleep', task: '수면', activity: '수면', color: TYPE_COLORS.sleep,
  }];

  return { sleepTime: { wakeUp: wake, bedTime: bed }, meals, schedules, sleep };
}

/** [start, end) 구간에서 고정 블록 제외 후 빈 구간 반환 */
function computeFreeWindows(dayStart, dayEnd, blocks) {
  const fixed = [...blocks]
    .map(normalizeTask)
    .map(b => ({ ...b, s: toMin(b.start), e: toMin(b.end) }))
    .filter(b => b.s < b.e)
    .sort((a, b) => a.s - b.s);

  let cursor = dayStart;
  const free = [];
  for (const b of fixed) {
    const s = clamp(b.s, dayStart, dayEnd);
    const e = clamp(b.e, dayStart, dayEnd);
    if (e <= dayStart || s >= dayEnd) continue;
    if (s > cursor) free.push({ start: toHHMM(cursor), end: toHHMM(s) });
    cursor = Math.max(cursor, e);
  }
  if (cursor < dayEnd) free.push({ start: toHHMM(cursor), end: toHHMM(dayEnd) });
  return free;
}

// 고정/홀리데이 블록을 시간 순으로 정렬해 겹치지 않게 패킹하고,
// 중간 틈이 10분 이상이면 '휴식' 블록도 넣는다.
function packAndFill(tasks, dayStart, dayEnd) {
  const sorted = tasks.slice().sort((a, b) => toMin(a.start) - toMin(b.start));
  const out = [];
  let cursor = dayStart;

  for (const t of sorted) {
    let s = Math.max(toMin(t.start), cursor);
    let e = Math.max(s, toMin(t.end));
    if (e <= s) continue;

    // 틈이 10분 이상이면 휴식 블록 삽입
    const gap = s - cursor;
    if (gap >= 10) {
      out.push({
        start: toHHMM(cursor),
        end: toHHMM(s),
        type: 'holiday',
        task: '휴식',
        activity: '휴식',
        color: '#F6F6F6',
      });
    }

    out.push({ ...t, start: toHHMM(s), end: toHHMM(e) });
    cursor = e;
    if (cursor >= dayEnd) break;
  }

  // 끝에 남은 시간도 여유 시간으로 표시
  if (cursor < dayEnd) {
    out.push({
      start: toHHMM(cursor),
      end: toHHMM(dayEnd),
      type: 'holiday',
      task: '여유 시간',
      activity: '여유 시간',
      color: '#F6F6F6',
    });
  }
  return out;
}

/** 간단 폴백 스케줄러(네트워크/파싱 실패 시 사용). dueDate 오름차순, 60분 단위로 끼워넣기 */
function localFallbackSchedule(fixedData, todoData) {
  const { sleepTime, meals, schedules } = normalizeFixedData(fixedData);
  const dayStart = toMin(sleepTime.wakeUp);
  const dayEnd = toMin(sleepTime.bedTime);

  const fixedBlocks = [...meals, ...schedules];
  const free = computeFreeWindows(dayStart, dayEnd, fixedBlocks);

  const todos = [...(todoData || [])].sort((a, b) => {
    const ad = a.dueDate || '9999-12-31';
       const bd = b.dueDate || '9999-12-31';
    return ad.localeCompare(bd);
  });

  const out = [];
  let i = 0;
  for (const win of free) {
    let c = toMin(win.start);
    const end = toMin(win.end);
    while (c + 60 <= end && i < todos.length) {
      const t = todos[i++];
      const start = toHHMM(c);
      const stop = toHHMM(c + 60);
      out.push(normalizeTask({
        start, end: stop, type: 'todo',
        task: t.text || t.task || '할 일',
        activity: t.text || t.task || '할 일',
        color: TYPE_COLORS.todo,
      }));
      c += 60;
    }
    if (i >= todos.length) break;
  }

  // 고정(식사/수면/고정일정) + 투두
  return [...meals.map(normalizeTask), ...schedules.map(normalizeTask), ...out];
}

// ===================== OpenAI 호출 =====================

function buildPrompt({ fixedData, todoData }) {
  const { sleepTime, meals, schedules } = normalizeFixedData(fixedData);

  const lines = [];
  lines.push('다음 조건으로 일일 일정을 JSON으로 생성하라.');
  lines.push('');
  lines.push('### 하루 시간 범위');
  lines.push(`- 기상: ${sleepTime.wakeUp}, 취침: ${sleepTime.bedTime}`);
  lines.push('');
  lines.push('### 고정 블록 (겹치면 안 됨, 그대로 유지)');
  if (meals.length === 0 && schedules.length === 0) {
    lines.push('- (없음)');
  } else {
    [...meals, ...schedules].forEach(b => lines.push(`- ${b.start}~${b.end} ${b.activity} (${b.type})`));
  }
  lines.push('');
  lines.push('### 할 일 목록 (마감일 우선 배치)');
  if (!todoData || todoData.length === 0) {
    lines.push('- (없음)');
  } else {
    // 간단 요약
    const sorted = [...todoData].sort((a, b) => (a.dueDate || '9999-12-31').localeCompare(b.dueDate || '9999-12-31'));
    sorted.forEach((t, i) => {
      lines.push(`- ${i + 1}. ${t.text || t.task || '할 일'} | 마감일: ${t.dueDate || '없음'}`);
    });
  }
  lines.push('');
  lines.push('### 생성 규칙');
  lines.push('- 출력은 **오직 JSON** 객체 한 개만 반환한다. 코드블록( ``` )을 사용하지 말 것.');
  lines.push('- 키 스키마: { "tasks": [{ "start":"HH:MM", "end":"HH:MM", "type":"sleep|meal|fixed|todo", "task":"문자열", "activity":"문자열", "color":"#RRGGBB" }] }');
  lines.push('- 모든 시간은 HH:MM 형식, 겹치지 않게 배치.');
  lines.push('- 고정 블록(식사/고정일정)은 유지, 빈 시간에 todo를 넣는다.');
  lines.push('- todo는 **마감일이 빠른 순**으로 우선 배치. 한 할 일의 기본 소요시간은 60분으로 가정하되, 필요하면 30~90분 사이로 조절 가능.');
  lines.push('- 기상 이전/취침 이후에는 배치 금지.');
  lines.push('- type별 권장 색상: sleep=#F0E6FF, meal=#E0FBFC, fixed=#E3F9E5, todo=#FFF5E5. 색상 키를 반드시 채운다.');
  lines.push('- 수면 블록은 별도 생성하지 않는다(이미 범위로 주어짐). 단, 기존 고정 블록은 그대로 유지.');
  lines.push('- 불가피하게 전부 못 넣으면 남은 todo는 제외해도 된다(오버랩 금지).');

  return lines.join('\n');
}

/** OpenAI 응답에서 JSON만 안전하게 추출 */
function extractJson(text) {
  if (!text) return null;
  let s = String(text).trim();

  const stripFence = (x) =>
    x.replace(/^```[a-zA-Z-]*\n?/, '').replace(/```$/, '').trim();

  const tryParse = (x) => {
    try { return JSON.parse(x); }
    catch { return null; }
  };

  // 1) 코드펜스 제거 후 바로 파싱 시도
  if (s.startsWith('```')) {
    const noFence = stripFence(s);
    const direct = tryParse(noFence);
    if (direct) return direct;
    s = noFence; // 이후 단계에서도 사용
  }

  // 2) 가장 바깥 { ... } 덩어리 파싱
  const first = s.indexOf('{');
  const last  = s.lastIndexOf('}');
  if (first !== -1 && last !== -1 && last > first) {
    const mid = s.slice(first, last + 1);
    const obj = tryParse(mid);
    if (obj) return obj;
  }

  // 3) 본문 속 코드펜스 블록들 개별 파싱
  const fenceRegex = /```[\s\S]*?```/g;
  const fences = s.match(fenceRegex) || [];
  for (const f of fences) {
    const obj = tryParse(stripFence(f));
    if (obj) return obj;
  }

  // 4) 마지막 시도: 전체 문자열 파싱
  return tryParse(s);
}


// ===================== 공개 API =====================

/**
 * 빈 슬롯 시작시간 리스트(옵션): 이전 호환용.
 * 지금은 로컬에서 계산해서 반환(모델 낭비 방지).
 */
export async function generateSlotTimes({ fixedData = {} } = {}) {
  const { sleepTime, meals, schedules } = normalizeFixedData(fixedData);
  const dayStart = toMin(sleepTime.wakeUp);
  const dayEnd = toMin(sleepTime.bedTime);
  const free = computeFreeWindows(dayStart, dayEnd, [...meals, ...schedules]);
  // 60분 단위 시작점만
  const starts = [];
  free.forEach(win => {
    let c = toMin(win.start);
    const e = toMin(win.end);
    while (c + 60 <= e) {
      starts.push(toHHMM(c));
      c += 60;
    }
  });
  return starts;
}

/**
 * 메인: 고정데이터 + 투두로 하루 스케줄 생성
 * - 기본적으로 OpenAI 사용
 * - 실패 시 로컬 폴백
 */
export async function generateSchedule({ fixedData = {}, todoData = [] }) {
  const prompt = buildPrompt({ fixedData, todoData });

  try {
    const res = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.2,
      max_tokens: 900,
    });

    const raw = res?.choices?.[0]?.message?.content || '';
    const json = extractJson(raw);

    if (!json || !Array.isArray(json.tasks)) {
      // 파싱 실패 → 폴백
      return localFallbackSchedule(fixedData, todoData).map(normalizeTask);
    }

    // JSON → 표준화 + 겹침/시간 범위 보정
    const { sleepTime, meals, schedules } = normalizeFixedData(fixedData);
    const dayStart = toMin(sleepTime.wakeUp);
    const dayEnd = toMin(sleepTime.bedTime);

    const fixedBlocks = [...meals, ...schedules];
    const fixedR = fixedBlocks.map(b => ({ ...b, s: toMin(b.start), e: toMin(b.end) }));

    const tasks = json.tasks
      .map(normalizeTask)
      // 하루 범위로 클램프
      .map(t => {
        const s = clamp(toMin(t.start), dayStart, dayEnd);
        const e = clamp(toMin(t.end), dayStart, dayEnd);
        return e > s ? { ...t, start: toHHMM(s), end: toHHMM(e) } : null;
      })
      .filter(Boolean)
      // 고정 블록과 겹치면 제거
      .filter(t => !fixedR.some(f => overlaps(f, t)))
      // 정렬
      .sort((a, b) => toMin(a.start) - toMin(b.start));

    // 자기들끼리 겹치는 것 제거(앞선 항목 우선)
    const packed = [];
    for (const t of tasks) {
      if (!packed.some(p => overlaps(p, t))) packed.push(t);
    }

    // 최종: (식사/고정) + (AI 투두)
    return [...fixedBlocks.map(normalizeTask), ...packed.map(normalizeTask)];
  } catch (e) {
    console.error('[generateSchedule] OpenAI call failed:', e);
    // 네트워크/쿼터/기타 오류 → 폴백
    return localFallbackSchedule(fixedData, todoData).map(normalizeTask);
  }
}

/**
 * 아주 단순한 텍스트 타임라인이 필요한 경우(과거 호환)
 */
export async function generateSimpleSchedule({ fixedData = {}, todoData = [] }) {
  const tasks = await generateSchedule({ fixedData, todoData });
  // "HH:MM - 제목" 형식
  const lines = tasks
    .slice()
    .sort((a, b) => toMin(a.start) - toMin(b.start))
    .map(t => `${t.start} - ${t.task}`);
  return lines.join('\n');
}

// ===================== Holiday: Generate without sampling =====================

/**
 * 관심사/컨디션/고정시간을 바탕으로 "holiday" 일정만 생성한다.
 * - 샘플링 없이 OpenAI가 활동 종류·이름·시간을 모두 구성
 * - 반환: normalize된 holiday tasks 배열
 */
export async function generateHolidaySchedule({ interest, energy, fixedData = {} }) {
  // 컨디션별 권장 세션 길이/가이드
  const ENERGY_CONFIG = {
    '피곤함':       { wakeUp: '10:00', bedTime: '21:30', duration: 45,  notes: '짧은 세션, 휴식 자주, 강도 낮게' },
    '보통':         { wakeUp: '09:00', bedTime: '22:00', duration: 60,  notes: '표준 세션, 균형 잡힌 활동' },
    '에너지 충만': { wakeUp: '08:00', bedTime: '23:00', duration: 90,  notes: '긴 세션, 집중도 높은 활동' },
  };

  // 고정 블록(식사 등) 포함한 하루 범위 정규화
  const base = normalizeFixedData({
    ...fixedData,
    sleepTime: fixedData?.sleepTime ?? ENERGY_CONFIG[energy]?.sleepTime ?? undefined,
  });

  const { sleepTime, meals, schedules } = base;
  const dayStart = toMin(sleepTime.wakeUp);
  const dayEnd   = toMin(sleepTime.bedTime);

  const prompt = [
    '다음 입력을 바탕으로 휴일 일정을 JSON으로 생성하라.',
    '',
    '## 오늘 정보',
    `- 관심사: ${interest}`,
    `- 컨디션: ${energy} (${ENERGY_CONFIG[energy]?.notes || ''})`,
    '',
    '## 하루 시간',
    `- 기상: ${sleepTime.wakeUp} (이전 시간에 활동 배치 금지)`,
    `- 취침: ${sleepTime.bedTime} (이후 시간에 활동 배치 금지)`,
    '',
    '## 고정 블록(유지, 겹치기 금지)',
    ...(meals.length + schedules.length === 0
      ? ['- (없음)']
      : [...meals, ...schedules].map(b => `- ${b.start}~${b.end} ${b.activity || b.task} (${b.type})`)),
    '',
    '## 생성 규칙',
    '- 출력은 오직 하나의 JSON 객체: { "tasks":[{...}] } 형태. 코드블록(```), 설명 문장 금지.',
    '- tasks 배열 원소 스키마:',
    '  { "start":"HH:MM", "end":"HH:MM", "type":"holiday", "task":"문자열", "activity":"문자열", "color":"#RRGGBB" }',
    `- type은 항상 "holiday". color는 "#FFEFD5" 사용.`,
    `- 컨디션에 맞춰 세션 길이를 ${ENERGY_CONFIG[energy]?.duration || 60}분 전후로 구성.`,
    '- 동일 활동명을 과도하게 반복하지 말 것(다양성).',
    '- 고정 블록, 다른 생성된 활동과 시간이 겹치지 않게 배치.',
    '- 활동명은 관심사와 자연스럽게 연결된, 구체적이고 실행 가능한 이름으로.',
    '- 기상~취침 범위를 벗어나지 말 것.',
    '- 필요 시 중간에 10~15분 휴식 활동(스트레칭/간식/물 마시기 등)도 적절히 포함 가능.',
    '',
    '## 예시(형식 참고, 실제 내용 아님)',
    '{ "tasks": [',
    '  { "start":"09:00","end":"09:45","type":"holiday","task":"요가 기초","activity":"요가 기초","color":"#FFEFD5" },',
    '  { "start":"10:00","end":"10:45","type":"holiday","task":"스트레칭 루틴","activity":"스트레칭 루틴","color":"#FFEFD5" }',
    '] }',
  ].join('\n');

  try {
    const res = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.35,
      max_tokens: 900,
    });

    const raw = res?.choices?.[0]?.message?.content || '';
    const json = extractJson(raw);
    let tasks = Array.isArray(json?.tasks) ? json.tasks : [];

    // 스키마 정규화 + 범위/겹침 보정 + 정렬
    tasks = tasks
      .map(t => ({
        start: padHHMM(t.start),
        end:   padHHMM(t.end),
        type:  'holiday',
        task:  t.task || t.activity || '휴일 활동',
        activity: t.activity || t.task || '휴일 활동',
        color: '#FFEFD5',
      }))
      .map(t => {
        const s = clamp(toMin(t.start), dayStart, dayEnd);
        const e = clamp(toMin(t.end),   dayStart, dayEnd);
        return e > s ? { ...t, start: toHHMM(s), end: toHHMM(e) } : null;
      })
      .filter(Boolean)
      .sort((a, b) => toMin(a.start) - toMin(b.start));

    // 상호 겹침 제거(앞선 항목 우선)
    const packed = [];
    for (const t of tasks) {
      if (!packed.some(p => overlaps(p, t))) packed.push(t);
    }
    // 틈 메우기 + 휴식 자동 삽입
    const filled = packAndFill(packed, dayStart, dayEnd);
    return filled.map(normalizeTask);
  } catch (e) {
    console.error('[generateHolidaySchedule] OpenAI failed:', e);
    // 폴백: 컨디션에 맞춘 길이로 빈 창에 2~4개 정도 배치
    const duration = ENERGY_CONFIG[energy]?.duration || 60;
    const baseStarts = [dayStart, dayStart + duration + 20, dayStart + duration*2 + 40];
    const safe = baseStarts
      .map((s,i)=>({
        start: toHHMM(s),
        end:   toHHMM(Math.min(s + duration, dayEnd)),
        type:  'holiday',
        task:  `${interest} 활동 ${i+1}`,
        activity: `${interest} 활동 ${i+1}`,
        color: '#FFEFD5',
      }))
      .filter(t => toMin(t.end) > toMin(t.start));
    return safe.map(normalizeTask);
  }
}
