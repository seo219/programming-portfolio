// src/pages/CalendarPage.jsx
import React, { useState, useEffect } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebaseConfig';
import { doc, getDoc, deleteDoc } from 'firebase/firestore';
import './CalendarPage.css';

export default function CalendarPage() {
  const [value, setValue] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const [viewMode, setViewMode] = useState('none');
  const [scheduleData, setScheduleData] = useState([]);
  const [showFullSchedule, setShowFullSchedule] = useState(false);
  const navigate = useNavigate();

  const typeColors = {
    sleep: '#F0E6FF',
    meal: '#E0FBFC',
    fixed: '#E3F9E5',
    todo: '#FFF5E5',
    holiday: '#FFEFD5',
  };

  const localFormat = date => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  };

  const onClickDay = day => {
    setValue(day);
    setSelectedDate(day);
    setViewMode('loading');
    setShowFullSchedule(false);
  };

  useEffect(() => {
    if (!selectedDate) return;
    const key = localFormat(selectedDate);
    const user = auth.currentUser;
    if (!user) return;
    (async () => {
      const ref = doc(db, 'users', user.uid, 'dailySchedules', key);
      const snap = await getDoc(ref);
      if (!snap.exists()) {
        setScheduleData([]);
        setViewMode('none');
      } else {
        const data = snap.data();
        setScheduleData(data.generatedTasks || []);
        setViewMode(data.isHoliday ? 'holiday' : 'plan');
      }
    })();
  }, [selectedDate]);

  const handleCancelHoliday = async () => {
    if (!selectedDate) return;
    const user = auth.currentUser;
    if (!user) return;
    const key = localFormat(selectedDate);
    const ref = doc(db, 'users', user.uid, 'dailySchedules', key);
    await deleteDoc(ref);
    setScheduleData([]);
    setViewMode('none');
  };

  const renderFullSchedule = () => {
    if (!selectedDate) return null;
    const sleepItem = scheduleData.find(it => it.task === '수면');
    if (!sleepItem) return null;

    const [bedH, bedM] = sleepItem.start.split(':').map(Number);
    const [wakeH, wakeM] = sleepItem.end.split(':').map(Number);

    const wakeDate = new Date(selectedDate);
    wakeDate.setHours(wakeH, wakeM, 0, 0);
    let bedDate = new Date(selectedDate);
    bedDate.setHours(bedH, bedM, 0, 0);
    if (bedDate <= wakeDate) bedDate.setDate(bedDate.getDate() + 1);

    const wakeStr = `${String(wakeH).padStart(2, '0')}:${String(wakeM).padStart(2, '0')}`;
    const bedStr = `${String(bedH).padStart(2, '0')}:${String(bedM).padStart(2, '0')}`;

    const slotMap = {};
    scheduleData
      .filter(it => it.task !== '수면')
      .forEach(({ start, end, task, type, color }) => {
        if (!start || !end) return;
        const [h1, m1] = start.split(':').map(Number);
        const [h2, m2] = end.split(':').map(Number);
        const s = new Date(wakeDate); s.setHours(h1, m1, 0, 0);
        let e = new Date(wakeDate); e.setHours(h2, m2, 0, 0);
        if (e <= s) e.setDate(e.getDate() + 1);
        const startSlot = s < wakeDate ? wakeDate : s;
        const endSlot = e > bedDate ? bedDate : e;
        const bg = type === 'fixed'
          ? (color || typeColors.fixed)
          : (typeColors[type] || typeColors.todo);
        let cur = new Date(startSlot);
        while (cur < endSlot) {
          slotMap[cur.toTimeString().slice(0, 5)] = { task, color: bg };
          cur.setMinutes(cur.getMinutes() + 10);
        }
      });

    return (
      <table className="full-schedule">
        <thead>
          <tr><th>시간</th><th>활동</th></tr>
        </thead>
        <tbody>
          <tr style={{ backgroundColor: typeColors.sleep }}>
            <td>{wakeStr}</td><td>기상</td>
          </tr>
          {(() => {
            const rows = [];
            for (let cur = new Date(wakeDate); cur < bedDate; cur.setMinutes(cur.getMinutes() + 10)) {
              const ts = cur.toTimeString().slice(0, 5);
              const cell = slotMap[ts];
              rows.push(
                <tr key={ts} style={{ backgroundColor: cell?.color || 'transparent' }}>
                  <td>{ts}</td><td>{cell?.task || ''}</td>
                </tr>
              );
            }
            return rows;
          })()}
          <tr style={{ backgroundColor: typeColors.sleep }}>
            <td>{bedStr}</td><td>취침</td>
          </tr>
        </tbody>
      </table>
    );
  };

  const renderSummary = () => {
    if (!selectedDate) return null;
    let events = [];
    scheduleData.forEach(({ start, end, task, type, color }) => {
      if (type === 'holiday') {
        events.push({ time: start, label: task, color, key: `s${start}` });
        events.push({ time: end, label: `${task} 종료`, color, key: `e${end}` });
      } else if (task === '수면') {
        events.push({ time: end, label: '기상', color: typeColors.sleep, key: 'wake' });
        events.push({ time: start, label: '취침', color: typeColors.sleep, key: 'bed' });
      } else if (start && end) {
        const bg = type === 'fixed'
          ? (color || typeColors.fixed)
          : (typeColors[type] || typeColors.todo);
        events.push({ time: start, label: task, color: bg, key: `s${start}` });
        events.push({ time: end, label: `${task} 종료`, color: bg, key: `e${end}` });
      }
    });
    events.sort((a, b) => a.time.localeCompare(b.time));
    const wakeIdx = events.findIndex(e => e.label === '기상');
    if (wakeIdx > 0) {
      events = [...events.slice(wakeIdx), ...events.slice(0, wakeIdx)];
    }
    return (
      <table className="summary-table">
        <tbody>
          {events.map(ev => (
            <tr key={ev.key} style={{ backgroundColor: ev.color }}>
              <td style={{ fontWeight: 'bold', width: '40%' }}>{ev.time}</td>
              <td>{ev.label}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <div className="calendar-page">
      <h1>📅 달력</h1>
      <div className="calendar-wrapper">
        <Calendar onClickDay={onClickDay} value={value} />
      </div>

      <div className="schedule-panel">
        {!selectedDate && <p>날짜를 선택해주세요</p>}
        {viewMode === 'loading' && <p>로딩 중…</p>}
        {selectedDate && viewMode !== 'loading' && (
          <>
            <h2>{selectedDate.toLocaleDateString('ko-KR')} 일정</h2>

            {(viewMode === 'plan' || viewMode === 'holiday') && (
              <button className="toggle-full" onClick={() => setShowFullSchedule(v => !v)}>
                {showFullSchedule ? '요약 보기' : '전체 일정표 보기'}
              </button>
            )}

            {viewMode !== 'none' && (showFullSchedule ? renderFullSchedule() : renderSummary())}

            {viewMode === 'plan' && (
              <div className="btn-group">
                <button
                  onClick={() =>
                    navigate(`/plan/${localFormat(selectedDate)}/edit`, { state: { scheduleData } })
                  }
                >
                  계획표 수정하기
                </button>
                <button
                  onClick={() =>
                    navigate(`/reschedule/${localFormat(selectedDate)}`)
                  }
                >
                  AI 스케줄링 받기
                </button>
              </div>
            )}

            {viewMode === 'holiday' && (
              <div className="btn-group">
                <button
                  onClick={() =>
                    navigate(`/holiday/schedule/${localFormat(selectedDate)}`)
                  }
                >
                  다시 추천 받기
                </button>
                <button onClick={handleCancelHoliday}>
                  휴일 해제하기
                </button>
              </div>
            )}

            {viewMode === 'none' && (
              <div className="btn-group">
                <button
                  onClick={() =>
                    navigate(`/plan/${localFormat(selectedDate)}`)
                  }
                >
                  계획표 만들기
                </button>
                <button
                  onClick={() =>
                    navigate(`/holiday/schedule/${localFormat(selectedDate)}`)
                  }
                >
                  휴일 지정
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
