// src/pages/HolidaySchedulePage.jsx
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { generateHolidaySchedule } from '../api/gptScheduler';
import { auth, db } from '../firebaseConfig';
import { doc, setDoc } from 'firebase/firestore';
import './HolidaySchedulePage.css';

const TYPE_COLORS = { holiday: '#FFEFD5' };

export default function HolidaySchedulePage() {
  const { dateKey } = useParams(); // YYYY-MM-DD
  const navigate = useNavigate();

  const [interest, setInterest] = useState('운동');
  const [energy, setEnergy] = useState('보통');
  const [generated, setGenerated] = useState([]);       // [{start,end,activity}]
  const [tasksForSave, setTasksForSave] = useState([]); // Firestore 저장용
  const [loading, setLoading] = useState(false);

  const interestOptions = ['운동', '음악', '미술', '영화/드라마', '독서'];
  const energyOptions = ['피곤함', '보통', '에너지 충만'];

  const handleRecommend = async () => {
    try {
      setLoading(true);
      // 사용자가 고른 관심사/컨디션만 넘겨서 OpenAI가 holiday tasks를 '바로' 생성
      const tasks = await generateHolidaySchedule({
        interest,
        energy,
        fixedData: {
          // 필요 시 휴일에 유지할 고정 블록(예: 식사)만 지정
          meals: [
            { start: '12:00', end: '12:40' },
            { start: '18:00', end: '18:40' },
          ],
          // schedules: [] // (있으면 추가)
        },
      });

      setTasksForSave(tasks);
      setGenerated(
        tasks.map(t => ({ start: t.start, end: t.end, activity: t.activity || t.task }))
      );
    } catch (err) {
      console.error('[HolidaySchedulePage] recommend error:', err);
      alert('추천 생성 중 문제가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      const user = auth.currentUser;
      if (!user) {
        alert('로그인 후 이용해주세요.');
        return;
      }
      const ref = doc(db, 'users', user.uid, 'dailySchedules', dateKey);
      await setDoc(
        ref,
        {
          isHoliday: true,
          generatedTasks: tasksForSave, // 이미 type: 'holiday'
        },
        { merge: true }
      );
      navigate('/calendar');
    } catch (err) {
      console.error('[HolidaySchedulePage] save error:', err);
      alert('저장 중 문제가 발생했습니다.');
    }
  };

  return (
    <div className="holiday-schedule-page">
      <h2>{dateKey?.replace(/-/g, '. ')} 휴일 일정 추천</h2>

      <div className="controls">
        <label>
          관심사&nbsp;
          <select value={interest} onChange={(e) => setInterest(e.target.value)}>
            {interestOptions.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
          </select>
        </label>

        <label style={{ marginLeft: 12 }}>
          컨디션&nbsp;
          <select value={energy} onChange={(e) => setEnergy(e.target.value)}>
            {energyOptions.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
          </select>
        </label>

        <button onClick={handleRecommend} disabled={loading} style={{ marginLeft: 12 }}>
          {loading ? '추천 생성 중…' : '추천받기'}
        </button>
      </div>

      {generated.length > 0 && (
        <>
          <table className="holiday-table">
            <thead>
              <tr>
                <th>시작</th>
                <th>종료</th>
                <th>활동</th>
              </tr>
            </thead>
            <tbody>
              {generated.map((it, i) => (
                <tr key={i} style={{ backgroundColor: TYPE_COLORS.holiday }}>
                  <td>{it.start}</td>
                  <td>{it.end}</td>
                  <td>{it.activity}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="btns">
            <button onClick={handleSave}>휴일 일정으로 저장</button>
            <button onClick={() => navigate(-1)}>취소</button>
          </div>
        </>
      )}
    </div>
  );
}
