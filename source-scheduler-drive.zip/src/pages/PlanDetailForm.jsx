// src/pages/PlanDetailForm.jsx
import React, { useEffect, useState, useMemo } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import FixedSchedule from '../components/FixedSchedule';
import { auth, db } from '../firebaseConfig';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { loadTemplate, saveTemplate } from '../services/templateService';
import './PlanDetailForm.css';

export default function PlanDetailForm() {
  // 1) URL 파라미터에서 date(YYYY-MM-DD) 읽기
  const { date } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  // 2) 쿼리 파라미터(template)와 state(scheduleData) 안전하게 읽기
  const templateId = new URLSearchParams(location.search).get('template');
  const passed = useMemo(
    () => location.state?.scheduleData || [],
    [location.state?.scheduleData]
  );

  // 3) 로컬 폼 상태
  const [name, setName] = useState('');
  const [fixedData, setFixedData] = useState({
    sleepTime: { wakeUp: '', bedTime: '' },
    meals: [],
    schedules: []
  });

  // 4) ReschedulePage에서 넘겨준 데이터가 있을 때 fixedData 동기화
  useEffect(() => {
    if (!passed.length) return;
    const sleep = passed.find(it => it.task === '수면');
    const sleepTime = sleep
      ? { wakeUp: sleep.end, bedTime: sleep.start }
      : { wakeUp: '', bedTime: '' };
    const meals = passed
      .filter(it => it.type === 'meal')
      .map(it => ({ start: it.start, end: it.end }));
    const schedules = passed
      .filter(it => it.type === 'fixed')
      .map(it => ({
        task: it.task,
        start: it.start,
        end: it.end,
        color: it.color || '#F3FFF3'
      }));
    setFixedData({ sleepTime, meals, schedules });
  }, [passed]);

  // 5) 템플릿 편집 or 기존 플랜 로드
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    if (templateId) {
      // 템플릿 로드
      loadTemplate(user.uid, templateId).then(tpl => {
        if (!tpl) return;
        setName(tpl.name);
        setFixedData({
          sleepTime: tpl.sleepTime,
          meals: tpl.meals,
          schedules: tpl.schedules
        });
      });
    } else if (!passed.length) {
      // Firestore에서 기존 플랜 로드
      (async () => {
        const ref = doc(db, 'users', user.uid, 'dailySchedules', date);
        const snap = await getDoc(ref);
        if (!snap.exists()) return;
        const data = snap.data();
        setName(data.name || '');
        const tasks = data.generatedTasks || [];
        const sleep = tasks.find(it => it.task === '수면');
        const sleepTime = sleep
          ? { wakeUp: sleep.end, bedTime: sleep.start }
          : { wakeUp: '', bedTime: '' };
        const meals = tasks
          .filter(it => it.type === 'meal')
          .map(it => ({ start: it.start, end: it.end }));
        const schedules = tasks
          .filter(it => it.type === 'fixed')
          .map(it => ({
            task: it.task,
            start: it.start,
            end: it.end,
            color: it.color || '#F3FFF3'
          }));
        setFixedData({ sleepTime, meals, schedules });
      })();
    }
  }, [templateId, passed, date]);

  // 6) 일정 저장 핸들러
  const handleSaveSchedule = async () => {
    const user = auth.currentUser;
    if (!user) return alert('로그인 후 이용해주세요.');
    const tasks = [];

    // 수면
    const { wakeUp, bedTime } = fixedData.sleepTime;
    if (wakeUp && bedTime) {
      tasks.push({
        task: '수면',
        start: bedTime,
        end: wakeUp,
        type: 'sleep',
        color: '#E3D1FF'
      });
    }
    // 식사
    fixedData.meals.forEach(({ start, end }) => {
      if (start && end) {
        tasks.push({
          task: '식사',
          start,
          end,
          type: 'meal',
          color: '#C3F4FE'
        });
      }
    });
    // 고정 일정
    fixedData.schedules.forEach(({ task, start, end, color }) => {
      if (task && start && end) {
        tasks.push({ task, start, end, type: 'fixed', color });
      }
    });

    try {
      const ref = doc(db, 'users', user.uid, 'dailySchedules', date);
      await setDoc(ref, { generatedTasks: tasks, isHoliday: false }, { merge: true });
      alert('일정이 저장되었습니다.');
      navigate('/calendar');
    } catch (err) {
      alert('저장 중 오류: ' + err.message);
    }
  };

  // 7) 템플릿 저장 핸들러
  const handleSaveTemplate = async () => {
    const user = auth.currentUser;
    if (!user) return alert('로그인 후 이용해주세요.');
    if (!name.trim()) return alert('템플릿 이름을 입력해주세요.');
    await saveTemplate(user.uid, { name: name.trim(), ...fixedData }, templateId);
    alert('템플릿이 저장되었습니다.');
  };

  // 8) 휴일 지정 & 템플릿 불러오기 경로 수정
  const handleSetHoliday = () => {
    navigate(`/holiday/schedule/${date}`);
  };
  const handleLoadTemplate = () => {
    navigate(`/templates/select/${date}`);
  };

  return (
    <div className="plan-detail-form">
      <h1>📝 {date} 계획표 작성</h1>

      <button className="btn-holiday" onClick={handleSetHoliday}>
        휴일 지정
      </button>
      <button className="btn-template" onClick={handleLoadTemplate}>
        템플릿 불러오기
      </button>

      <div className="field">
        <label>계획표 이름</label>
        <input
          type="text"
          placeholder="이름을 입력하세요"
          value={name}
          onChange={e => setName(e.target.value)}
        />
      </div>

      <FixedSchedule fixedData={fixedData} setFixedData={setFixedData} />

      <div className="buttons">
        <button onClick={handleSaveTemplate}>템플릿 저장하기</button>
        <button onClick={handleSaveSchedule}>일정으로 저장</button>
      </div>
    </div>
  );
}
