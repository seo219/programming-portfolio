// src/components/NavBar.jsx
import React from 'react';
import { NavLink } from 'react-router-dom';
import { Calendar, FileText, CheckSquare, Settings } from 'lucide-react';
import './NavBar.css';

const items = [
    { to: '/calendar', Icon: Calendar },
    { to: '/templates', Icon: FileText },
    { to: '/todos', Icon: CheckSquare },
    { to: '/settings', Icon: Settings },
];

export default function NavBar() {
    return (
        <nav className="nav-bar">
            {items.map(item => {
                const Icon = item.Icon;  // eslint는 이 방식을 더 확실히 잡아줍니다
                return (
                    <NavLink
                        key={item.to}
                        to={item.to}
                        className={({ isActive }) =>
                            isActive ? 'nav-item active' : 'nav-item'
                        }
                    >
                        <Icon />
                    </NavLink>
                );
            })}

        </nav>
    );
}
