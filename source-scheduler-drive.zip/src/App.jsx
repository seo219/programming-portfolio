import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import RequireAuth from './components/RequireAuth';
import Layout       from './components/Layout';

import LoginPage            from './pages/LoginPage';
import RegisterPage         from './pages/RegisterPage';
import CalendarPage         from './pages/CalendarPage';
// 플랜 상세 보기 페이지 대신 바로 Form으로 진입
import PlanDetailForm       from './pages/PlanDetailForm';
import ReschedulePage       from './pages/ReschedulePage';

import PlanTemplatesPage    from './pages/PlanTemplatesPage';
import TemplateForm         from './pages/TemplateForm';
import TemplateSelectPage   from './pages/TemplateSelectPage';

import TodoListsPage        from './pages/TodoListsPage';
import TodoForm             from './pages/TodoForm';

import HolidayPage          from './pages/HolidayPage';
import HolidaySchedulePage  from './pages/HolidaySchedulePage';
import HolidayScheduleForm  from './pages/HolidayScheduleForm';

import SettingsPage         from './pages/SettingsPage';

function App() {
  return (
    <Router>
      <Routes>
        {/* Public */}
        <Route path="/login"    element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        {/* Protected */}
        <Route element={<RequireAuth />}>
          <Route element={<Layout />}>
            <Route index element={<Navigate to="/calendar" replace />} />

            {/* Calendar & Plans */}
            <Route path="calendar"        element={<CalendarPage />} />
            {/* ⬇️ PlanDetailPage 대신 Form으로 바로 진입 */}
            <Route path="plan/:date"      element={<PlanDetailForm />} />
            <Route path="plan/:date/edit" element={<PlanDetailForm isEdit />} />
            <Route path="reschedule/:date" element={<ReschedulePage />} />

            {/* Holiday */}
            <Route path="holiday"                element={<HolidayPage />} />
            <Route path="holiday/schedule/:date" element={<HolidaySchedulePage />} />
            <Route path="holiday/form"           element={<HolidayScheduleForm />} />

            {/* Templates */}
            <Route path="templates"              element={<PlanTemplatesPage />} />
            <Route path="templates/new"          element={<TemplateForm />} />
            <Route path="templates/:id/edit"     element={<TemplateForm isEdit />} />
            <Route path="templates/select/:date" element={<TemplateSelectPage />} />

            {/* Todos */}
            <Route path="todos"       element={<TodoListsPage />} />
            <Route path="todos/new"   element={<TodoForm />} />
            <Route path="todos/:id/edit" element={<TodoForm isEdit />} />

            {/* Settings */}
            <Route path="settings" element={<SettingsPage />} />

            {/* Catch-all */}
            <Route path="*" element={<Navigate to="/calendar" replace />} />
          </Route>
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
