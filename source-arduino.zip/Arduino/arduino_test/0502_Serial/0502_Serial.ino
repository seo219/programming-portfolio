#include <SoftwareSerial.h>

SoftwareSerial btSerial(2, 3);

void setup() {
  pinMode(13, OUTPUT);    // 내장 LED 핀 설정
  Serial.begin(9600);     // 디버깅을 위한 시리얼 모니터
  btSerial.begin(9600);   // Bluetooth 모듈 통신 시작
}

void loop() {
  if (btSerial.available()) {
    char data = btSerial.read();
    Serial.print("Received data: ");
    Serial.println(data);  // 받은 데이터 확인

    if (data == '1') {
      Serial.println("Turning on LED");
      digitalWrite(13, HIGH);  // LED 켜기
    } else if (data == '0') {
      Serial.println("Turning off LED");
      digitalWrite(13, LOW);   // LED 끄기
    }
  }
}
