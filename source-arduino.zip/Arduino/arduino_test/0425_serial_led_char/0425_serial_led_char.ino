void setup() {
  pinMode(13, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if (Serial.available()) {
    String input;
    input = Serial.readString();

    if (input == "on" || input == "ON") {
      digitalWrite(13, HIGH);
      Serial.println("LED ON");
      
    } else if (input == "off" || input == "OFF") {
      digitalWrite(13, LOW);
      Serial.println("LED OFF");
      
    } else {
      Serial.println("ERROR");
      
    }
  }
}

// line ending
// new line ending
// \n : 줄 바꿈
// 캐리지 리턴
// \r : 커서를 앞으로 땡김
// no line ending : 위의 것을 안함
