void setup() {
  pinMode(13, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  if(Serial.available()){
    char data = Serial.read();
    if(data == '1'){
      digitalWrite(13, HIGH);
      Serial.println("LED ON");
    } else if(data == '0'){
      digitalWrite(13, LOW);
      Serial.println("LED OFF");
    }
  }
}
