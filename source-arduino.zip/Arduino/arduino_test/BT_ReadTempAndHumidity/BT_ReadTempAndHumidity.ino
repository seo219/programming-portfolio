#include <DHT11.h>
#include <SoftwareSerial.h>

SoftwareSerial btSerial(2,3);
DHT11 dht11(8);

void setup() {
    Serial.begin(9600);
    btSerial.begin(9600);
}

void loop() {
    int temperature = 0;
    int humidity = 0;
    int result = dht11.readTemperatureHumidity(temperature, humidity);

    if (result == 0) {
        Serial.print("Temperature: ");
        Serial.print(temperature);
        Serial.print(" °C\tHumidity: ");
        Serial.print(humidity);
        Serial.println(" %");

        btSerial.print("Tempe: ");
        btSerial.print(temperature, 1);
        btSerial.print(" °C                 ");
        btSerial.print("Humi: ");
        btSerial.print(humidity);
        btSerial.println(" %");

        delay(1000);
    } else {
        Serial.println(DHT11::getErrorString(result));
        btSerial.println(DHT11::getErrorString(result));

    }
}
