//PWM 3, 5, 6, 9, 10, 11 => analogwrite

int red = 9;
int green = 10;
int blue = 11;

void setup() {
  // put your setup code here, to run once:
  pinMode(red, OUTPUT);
  pinMode(green, OUTPUT);
  pinMode(blue, OUTPUT);

}

void loop() {
  // put your main code here, to run repeatedly:
    int redValue = 255;
    int greenValue = 255;
    int blueValue = 255;

  for (int i = 0; i < 256; i++){
    analogWrite(red, 255 - i);
    analogWrite(blue, 255 - i);
    delay(10);
  }
  delay(1000);

}
