const int btnPin = 8;
const int ledPin = 13;
bool btnState;

void setup() {
  pinMode(btnPin,INPUT);
  pinMode(ledPin,OUTPUT);
}

void loop() {
  btnState = digitalRead(btnPin);
  if (btnState == LOW){
    digitalWrite(ledPin,LOW);
  }
  else {
    digitalWrite(ledPin,HIGH);
  }
  
}
