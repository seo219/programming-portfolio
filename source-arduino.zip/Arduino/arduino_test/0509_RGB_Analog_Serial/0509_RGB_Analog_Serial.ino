void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);

  pinMode(9, OUTPUT);
  pinMode(10, OUTPUT);
  pinMode(11, OUTPUT);

}

// parseInt() => 공백, comma, tab, newline을 구분자로 자동으로 인식하고 정수만 읽는 함수
// "255 100 50\n" => red = 255, green = 100, blue = 50으로 인식하게 만들기.
// "255,100,50\n"도 가능.

void loop() {
  // put your main code here, to run repeatedly:
  if (Serial.available()){
    int red = Serial.parseInt();
    int green = Serial.parseInt();
    int blue = Serial.parseInt();

    String temp = Serial.readStringUntil('\n');

    Serial.print("red : ");
    Serial.println(red);
    Serial.print("green : ");
    Serial.println(green);
    Serial.print("blue : ");
    Serial.println(blue);

    analogWrite(9,red);
    analogWrite(10,green);
    analogWrite(11,blue);
  }
}
