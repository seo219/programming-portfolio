int INA=5;
int INB=6;

void setup(){
    pinMode(INA,OUTPUT);  // 5번 핀을 출력핀으로 설정함.
    pinMode(INB,OUTPUT);  // 6번 핀을 출력핀으로 설정함.
}

void loop(){
    digitalWrite(INA,HIGH);  // 모터가 A 방향으로 회전 (5번 핀 High)
    digitalWrite(INB,LOW);   // 6번 핀은 Low
    
    // digitalWrite(INA,LOW);
    // digitalWrite(INB,HIGH);  // 주석 해제하면 모터가 B 방향으로 회전

    // analogWrite(INA, 30);
    // analogWrite(INB, 0);

}

