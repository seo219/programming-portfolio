void setup() {
  Serial.begin(9600);
}

void loop() {
  while (Serial.available() > 0) {
    int red = Serial.parseInt();
    int green = Serial.parseInt();
    int blue = Serial.parseInt();
    String temp = Serial.readStringUntil('\n'); // 시리얼 버퍼를 비워서 받은값이 0으로 초기화되지 않도록 한다.
    Serial.print("red: "); Serial.println(red);
    Serial.print("green: "); Serial.println(green);
    Serial.print("blue: "); Serial.println(blue);
  }
}
