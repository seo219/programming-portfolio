void setup() {
  Serial.begin(9600);      
  Serial.println(78);            // "78"을 스트링 형태로 출력한다.
  Serial.println(1.23456);       // 스트링 형태로 출력하되, 소수점 옵션이 없는 소수의 경우 소수점 2자리 "1.23"까지 출력한다.
  Serial.println('N');           // 문자 "N" 출력한다.
  Serial.println("Hello world"); // 문자열 "Hello world." 출력한다.
  Serial.println(78, BIN);       // 2진수를 사람들이 인지하기 편하도록 스트링 형태 "1001110"으로 출력한다.
  Serial.println(78, OCT);       // 8진수값을 스트링 형태 "116"으로 출력한다.
  Serial.println(78, DEC);       // ASCII 숫자 "78"
  Serial.println(78, HEX);       // 16진수 "4E"
  Serial.println(1.23456, 0);    // (실수, 소수점 자리 옵션), 소수점 자리가 없으므로 "1"을 출력한다.
  Serial.println(1.23456, 4);    // (실수, 소수점 자리 옵션), 소수점 자리 4까지 반올림하여 "1.2346"을 출력한다. 
}

void loop() {   // print labels
}
