int ledPin = 13;
int dcPi1n1 = 9;
int dcPi1n2 = 10;

String rxData = "";
boolean start = false;


void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(dcPi1n1, OUTPUT);
  pinMode(dcPi1n2, OUTPUT);

  digitalWrite(dcPi1n2, LOW);

  Serial.begin(9600);
}

void loop() {
  if(Serial.available()){
    char data = Serial.read();
    if(start){
      if(data == '@'){
        parseData(rxData);
        rxData = "";
        start = false;
      }else{
        rxData += data;
      }

    }else{
      if(data == '#') start = true;
    }

  }

}

void parseData(String rxStr){
  String cmd = rxStr.substring(0, rxStr.indexOf(','));
  String data = rxStr.substring(rxStr.indexOf(',') + 1);

  if(cmd == "LED" || cmd == "led"){
    if(data == "ON" || data == "on"){
      digitalWrite(ledPin, HIGH);
      Serial.println("LED ON");
    }else if(data == "OFF" || data == "off"){
      digitalWrite(ledPin, LOW);
      Serial.println("LED OFF");
    }else {
      Serial.println("잘못된 데이터 값");
      digitalWrite(ledPin, LOW);
    }
}else if(cmd == "MOTOR" || cmd == "motor"){
  bool isNumeric = true;
  for (int i = 0; i < data.length(); i++) {
    if (!isDigit(data[i])) {
      isNumeric = false;
      break;
    }
  }

  if (isNumeric) {
    int speed = data.toInt();
    if (speed >= 0 && speed <= 255) {
      analogWrite(dcPi1n1, speed);
      digitalWrite(dcPi1n2, LOW);
      Serial.println("MOTOR SPEED: " + String(speed));
    } else {
      Serial.println("잘못된 데이터 값");
      analogWrite(dcPi1n1, 0);
    }
  } else {
    Serial.println("잘못된 데이터 값");
    analogWrite(dcPi1n1, 0);
  }
}
else {
    Serial.println("잘못된 명령어");
  }

}
