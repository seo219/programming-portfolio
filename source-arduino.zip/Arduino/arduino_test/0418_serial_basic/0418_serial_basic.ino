void setup() {
  Serial.begin(9600);
  
}

void loop() {
  // int a = 66;
  // Serial.println(a);
  // Serial.write(a); // 아스키코드 66 -> B
  // delay(1000);

  // Serial.println(Serial.available());
  // Serial.println((char)Serial.read()); // reaad = 아스키코드 B -> 66
  // delay(1000);



}
