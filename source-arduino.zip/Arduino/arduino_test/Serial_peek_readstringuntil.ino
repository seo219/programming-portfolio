void setup(){
   Serial.begin(9600);
 }

void loop(){
  if(Serial.available()){
    char temp_peek = Serial.peek();
    Serial.print(temp_peek);
    char temp_read = Serial.read();
    Serial.println(temp_read);  // 읽어온 데이터는 buffer에서 삭제
    String temp_string = Serial.readStringUntil('\n');
    Serial.println(temp_string);
  }
}
