void setup(){
   Serial.begin(9600);
 }

void loop(){
  char temp[20];  
  if(Serial.available()){  // 시리얼에 입력된 값이 있으면
    byte leng = Serial.readBytes(temp, 20); // (버퍼, 길이) - 길이 초과시 나누어 실행
    Serial.print("Input data Lenght : ");
    Serial.println(leng);  
    for(int i = 0; i < leng; i++) Serial.print(temp[i]);  
    Serial.println();
  }    
}
