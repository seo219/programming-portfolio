void setup(){
  Serial.begin(9600);     // opens serial port, sets data rate to 9600 bps
}

void loop(){
  if (Serial.available() > 0) {        // send data only when you receive data:  
    byte value = Serial.read();                // read the incoming byte:
    Serial.write(value);
    Serial.print(", ");
    Serial.println(value);                // say what you got:
  }
}
