void setup(){
   Serial.begin(9600);
 }

void loop(){
  while(Serial.available()){  // 시리얼 버퍼에 데이터 있으면
    if(Serial.find("123")){  // 시리얼 버퍼에 스트링 "123"이 있으면, 조건이 스트링: 관련 변수 스트링 기준
      String temp = Serial.readString(); // "123" 이후 들어온 스트링 저장
      Serial.print("Temp Value = "); Serial.println(temp);
    } 
  }
}
