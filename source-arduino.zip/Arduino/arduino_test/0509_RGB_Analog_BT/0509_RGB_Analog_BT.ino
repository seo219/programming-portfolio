#include <SoftwareSerial.h>

SoftwareSerial BTSerial(2,3);

void setup() {
  Serial.begin(9600);
  BTSerial.begin(9600);

  pinMode(9, OUTPUT);
  pinMode(10, OUTPUT);
  pinMode(11, OUTPUT);

}

void loop() {
  if (BTSerial.available()){
    int red = BTSerial.parseInt();
    int green = BTSerial.parseInt();
    int blue = BTSerial.parseInt();
    String temp = BTSerial.readStringUntil('\n');

    analogWrite(9,red);
    analogWrite(10,green);
    analogWrite(11,blue);

    Serial.print("Red : ");
    Serial.println(red);
    Serial.print("Green : ");
    Serial.println(green);
    Serial.print("Blue : ");
    Serial.println(blue);
  }

}
