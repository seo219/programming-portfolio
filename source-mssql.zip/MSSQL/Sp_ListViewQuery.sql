Create proc InsertListView
    @num int,
    @name nchar(3),
	@address nvarchar(30)
as
begin
	insert into ListViewTest(수험번호, 성명, 주소)
	values (@num, @name, @address)
end
---------------------------------------------------------------
Create proc DeleteListView
    @num int,
    @name nchar(3),
	@address nvarchar(30)
as
begin
	delete from ListViewTest
	where 수험번호 = @num
end
---------------------------------------------------------------
Create proc UpdateListView
    @num int,
    @name nchar(3),
	@address nvarchar(30)
as
begin
    update ListViewTest
    set 성명 = @name,
        주소 = @address
    where 수험번호 = @num;
end