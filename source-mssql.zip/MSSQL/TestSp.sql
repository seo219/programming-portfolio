select 수험번호, 부서, 성명, 주민등록번호, 우편번호, 주소 from exam_emp
select 전형구분 from exam_emp
select * from exam_emp
select 부서, 성명, 학력, 영어, 수학, 전형구분 from exam_emp
select 부서, 성명, 학력, 영어, 수학 from exam

Create proc InsertExam
	@depart nchar(4),
    @name nchar(3),
	@grade nvarchar(4),
	@eng int,
	@math int,
	@part nchar(2)
as
begin
	insert into exam_emp(부서, 성명, 학력, 영어, 수학, 전형구분)
	values (@depart,@name,@grade,@eng,@math,@part)
end

Create proc updateExam
	@depart nchar(4),
    @name nchar(3),
	@grade nvarchar(4),
	@eng int,
	@math int,
	@part nchar(2)
as
begin
    update exam_emp
    set 부서 = @depart,
		학력 = @grade,
		영어 = @eng,
		수학 = @math,
		전형구분 = @part
    where 성명 = @name;
end

Create proc deleteExam
    @num int,
	@depart nchar(4),
    @name nchar(3),
	@priNum int,
	@mailNum int,
	@address nvarchar(30)
as
begin
	delete from exam_emp
	where 수험번호 = @num
end

select distinct 전형구분 from exam_emp