Create proc CreateMyTable
as
begin
	if exists (select 1 from sys.tables
				where name = 'TestTable')
	begin
		drop table TestTable
		create table TestTable
		(
			id int primary key,
			name nvarchar(3)
		)
		print 'TestTable을 삭제하고, TestTable을 생성했습니다.'
	end

	else
	begin
		create table TestTable
		(
			id int primary key,
			name nvarchar(3)
		)
		print 'TestTable을 생성했습니다.'
	end
end


Create proc InsertTestTable
    @id   int,
    @name nvarchar(3)
as
begin
	if exists (select 1 from sys.tables
				where name = 'TestTable')
	begin
		insert into TestTable (id, name)
		values (@id, @name)

		print 'TestTable에 추가했습니다.'
	end

	else
	begin
		print 'TestTable이 존재하지 않습니다.'
	end
end

Create proc DropTestTable
as
begin
	if exists (select 1 from sys.tables
				where name = 'TestTable')
	begin
		drop table TestTable
		print 'TestTable을 삭제했습니다.'
	end

	else
	begin
		print 'TestTable이 존재하지 않습니다.'
	end
end

select * from TestTable
