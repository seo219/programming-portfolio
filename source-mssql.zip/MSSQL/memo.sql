-- select 
-- update delete insert 실제 데이터 값을 변형하기에 조심해야함.

-- begin tran 데이터 변형 시작

-- @@trancount 실행중인 데이터 변형 수

-- rollback 데이터 변형 취소 (원상복구)
-- commit 데이터 변형 완 (더는 돌릴 수 없음.)