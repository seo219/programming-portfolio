use sis

sp_help ListViewTest

select max(len(수험번호)) from exam_emp
select min(len(수험번호)) from exam_emp

alter table exam
alter column 성명 nchar(3)

alter table exam_emp
alter column 수험번호 int

select * from exam

--exam_emp도 바꿔두기.

select 수험번호, count(*) from exam
group by 수험번호
having count(*)>1

delete exam
where 수험번호 in (select 수험번호 from exam
group by 수험번호
having COUNT(*)>1)

delete exam
where 성명 in (select 성명 from exam_emp
group by 성명
having COUNT(*)>1)