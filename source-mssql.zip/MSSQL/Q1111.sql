sp_help exam_emp

alter table ListViewTest
add 수험번호 int

update exam
set 전형구분 = (select 전형구분 from exam_emp where exam.성명 = 성명)

select * from exam
select * from exam_emp

SELECT *
FROM   exam
WHERE  부서 IS NULL

DELETE FROM exam
WHERE  부서 IS NULL

select 성명, 영어, 수학 from exam

create table ListViewTest
		(
			수험번호 int primary key,
			성명 nchar(3),
			주소 nvarchar(30)
		)

select * from ListViewTest
select * from exam

INSERT INTO ListViewTest (수험번호, 성명, 주소)
SELECT 수험번호, 성명, 주소
FROM exam

drop table ListViewTest