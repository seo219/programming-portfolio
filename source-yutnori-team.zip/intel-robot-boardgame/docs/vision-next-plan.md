# 비전 다음 진행 계획

컴퓨터를 껐다 켠 뒤 바로 이어서 작업하기 위한 문서입니다. 상세 근거는 `docs/vision-yut-progress.md`와 `docs/interfaces.md`의 "윷 인식" 소절에 있습니다.

## 1. 지금 상태 한눈에

- 윷 인식(`read_yut`, 모델 연결, 시험 도구)은 완료되어 develop에 병합됐습니다 (PR #18).
- 이 브랜치(`feature/KAN-2-vision-board-state`)에서 board_state 준비 S1~S5를 마쳤습니다.
- 커밋: `d5a1293`, `e918131`, `bc59f53`, `cd5270a`, `cea3be3`, `9f8075d`, `401e3bd`.
- `pytest` 372 passed (`.venv` 기준).
- 2026-11-04 진행: 아래 3절 가의 ①②③④⑤를 마쳤습니다 (결과는 표의 "상태" 열).
- `board_state()`는 실카메라가 아니라 저장된 사진(`data/board/horse_4~6`, 11/4 10:14)으로만 확인했습니다 (말 9개 모두 정답).
- 실제 `config/board_cells.json`은 있습니다. 11/4 10:14 카메라 위치 기준이며, 카메라나 판이 움직이면 다시 맞춥니다 (마커 4개 이동량으로 호모그래피 보정).

## 2. 다시 시작하는 방법 (컴퓨터 재시작 후)

```powershell
cd C:\Users\LOCAL_USER\Intel_prj\intel-robot-boardgame
git status --short --branch
.venv\Scripts\activate                      # 활성화 안 하면 .venv\Scripts\python.exe 로 실행
python -m pytest tests -q
python scripts/try_read_yut.py --camera 0   # 윷 읽기 시험
```

- `try_read_yut.py` 키: 스페이스=읽기, c=정지 보정, o/x=정답 표시, q=종료. 기록은 `data/yut_logs/`.
- **시스템 python(3.14)은 쓰지 않습니다.** openvino, pygame이 없습니다.

| 로컬에만 있는 것 | 비고 |
|---|---|
| `data/` | 촬영 사진, `data/yut_logs/`, `data/board/` |
| `models/yut/` | 윷 모델 3종. 기본은 `7bc45355-openvino-int8` |
| 로컬 브랜치 `feature/KAN-2-vision-board-state-handoff` | 검토 문서 `docs/vision-board-state-review.md` (`dd6be9b`, `70b63ea`). **아직 push 안 함** |

- `.omc/`는 커밋하지 않습니다.

## 3. 다음 할 일

### 가. 사람이 할 일

| 번호 | 항목 | 선행 | 완료 기준 | 상태 (11/4) |
|---|---|---|---|---|
| ① | 트레이 설치, 판 고정 카메라 위치 확정, 노출·화이트밸런스 고정 | 없음 | 카메라 위치가 고정됨 (움직이면 이후 측정을 다시 해야 함) | 완료. 트레이 자동 노출은 껐으나 타임아웃은 그대로 |
| ② | 트레이 ROI 측정 `python scripts/select_roi.py --only tray` | ① | `config/slots.json`의 `tray`에 실측값만 들어감 | 완료 `[42, 25, 1805, 964]` |
| ③ | 트레이 상태로 `try_read_yut.py` 30~50회 시험 (o/x 표시, 던진 직후와 멎은 뒤 섞기, 정지 보정 c 재측정) | ①, ② | `data/yut_logs/`에 기록과 요약이 남음 | 완료 (30회 + 20회). 아래 "나. 비전 코드" 참고 |
| ④ | 말 없는 기준 사진 촬영 후 `python scripts/make_board_cells.py --draft <초안> --out config/board_cells.json` | ① | 실제 `config/board_cells.json` 생성 | 완료. 기존 초안이 맞았고, 판이 약 48px 움직여 마커로 보정함 |
| ⑤ | 말 색 범위를 시연장 조명에서 재측정 (`src/vision/board_pieces.py`의 `PIECE_COLORS`) | ① | 두 색 모두 시연장 조명에서 구분됨 | 완료. 범위는 그대로 (빨강 S 하한 130에 여유 10~20) |
| ⑥ | USB 카메라 2대(트레이·판) 동시 연결 시험 | ① | 두 카메라가 동시에 프레임을 줌 | 다음 차례 (판 카메라 번호 미확인) |
| ⑦ | 실카메라에서 `board_state()` 확인 (`BOARD_FLUSH_FRAMES=5`가 충분한지) | ④, ⑤, ⑥ | 놓은 말과 결과가 일치 |
| ⑧ | 시연 PC에서 추론 속도·메모리 측정, `setup_env.ps1 -Robot`, `check_env.py --demo --robot` | 없음 | 수치와 통과 여부 기록 |

- ④의 초안 `config/slots_draft_v2.json`은 카메라 위치 확정 전 값입니다. 확정 후 기준 사진으로 다시 만듭니다.
- ④에서 기존 파일을 덮어쓰려면 `--force`를 붙입니다.
- ⑧의 로봇 경로(`-Robot`)는 미확인입니다.

### 나. 비전 코드 (시험 결과가 나온 뒤)

- [ ] 정지 대기 지연 원인 분석: 11/4 시험 결과 타임아웃 4/30(13%), 노출 고정과 ROI 적용 뒤 5/20(25%)로 줄지 않음. 윷이 멎은 뒤에도 프레임 차이(diff)가 0.3~1.2를 약 0.5초 주기로 오르내려 기준 0.7을 넘음. 원인(밝기 진동·손 그림자·윷 미세 움직임)은 미확인. 보류 상태이며, 이어서 하려면 변화픽셀 비율(25단계 초과 픽셀 %)을 프레임마다 `wait.csv`에 함께 기록한 뒤 10회 재시험해 어느 지표가 조용한지 보고 정지 판정 지표를 정함. 읽은 결과는 맞았고(confidence만 절반으로 깎임), 게임은 confidence를 아직 쓰지 않음.
- [x] 트레이 ROI 적용: 정지 판정(`_wait_until_still`)에만 적용함. 윷 검출은 모델이 전체 프레임으로 학습돼 전체 프레임 유지.
- [ ] 윷이 벽에 기대거나 겹쳐 못 찾는 경우(실패 9회 중 대부분)는 코드가 아니라 트레이·규칙 문제. 트레이 벽 개선 또는 재던지기·`ask_help` 정책을 팀(김동현)과 정함.
- [ ] `main.py`의 `build_vision`에 판 카메라 번호 연결 (D3 결정 후).
- [ ] D1 결정 후 `board_state()` 한 곳 수정 (판독 불가 방식).
- [ ] 새 사진(학습 미사용)으로 정확도 재검증. 현재 98%는 학습 사진과 겹칠 수 있음.
- [ ] 모델 재학습이 필요하면 틀린 사진을 모아 사용자에게 전달 (Geti 재학습은 사람이 함).

### 다. 팀 결정 대기

| 코드 | 내용 | 관련 |
|---|---|---|
| C1 | 비전 예외가 게임을 죽임. `DeviceWrapper`에서 잡아 `ask_help`로 넘김. 임시로 `verify_moves=False` 가능 | 김동현 |
| C2 | 비전이 말을 놓치면 재이동이 대기 칸의 두 번째 말을 집을 수 있음 | 신이서, 김동현 |
| D1 | 판독 불가 규약 (예외로 알릴지) | 팀 |
| D3 | 카메라 번호 설정 위치 | 팀 |
| 대기·완주 칸 | 비전이 읽을지 (현재는 판 위 29칸만) | 게임 담당 |
| 칸 이름 | 비전은 게임 이름 `cell_0~19`, `diag_*`, `center` 채택. 팀 최종 확인 필요 | 팀 |

- 상세 근거는 로컬 브랜치의 `docs/vision-board-state-review.md`에 있습니다.

## 4. PR·정리 순서

- [ ] ① 이 브랜치 push 후 PR 초안 작성. develop과 최신 상태를 먼저 맞춥니다.
  - 변경 요약, 새 의존성 없음, 인터페이스 변경 없음, `interfaces.md` 소절 추가, 미확인 목록 포함.
- [ ] ② 검토 문서 브랜치 처리 결정: 별도 PR로 팀에 전달하거나 이 브랜치에 cherry-pick.
- [ ] ③ Jira KAN-2 댓글(ID 10005)에 board_state 준비 결과와 "PR #18 병합 완료" 반영.
- [ ] ④ 병합된 브랜치 정리. 원격 삭제는 사용자가 `git push origin --delete`로 직접 합니다.
- [ ] ⑤ PR 병합은 팀 리뷰 후 사용자가 직접 합니다.

## 5. 알려진 위험과 주의

- 카메라가 움직이면 ROI, 칸 좌표, 정지 보정을 다시 측정해야 합니다.
- 현재 정확도 98%는 학습 사진과 겹칠 수 있는 수치입니다.
- 정지 기준(`STILL_*`)은 표본 1회로 정했습니다.
- 한 카메라를 두 모듈이 동시에 열 수 없습니다.
- 실제 로봇·카메라 코드(`src/robot`, `src/vision`)는 사람이 실행합니다.
- `config/slots.json`, `config/board_cells.json`, `config/poses.json`에는 실측값만 넣습니다.
- 인터페이스를 바꿀 때는 `interfaces.py`, `docs/interfaces.md`, `mock.py`, 호출부를 함께 고치고 PR 설명에 적습니다.
- 다른 담당자 폴더(`game/`, `robot/`) 수정은 먼저 사람에게 확인합니다.

## 6. 미확인 목록

- [ ] 프레임 버퍼 지연 (`BOARD_FLUSH_FRAMES=5`가 충분한지)
- [ ] USB 카메라 2대 동시 연결
- [ ] 실제 로봇에서 C2의 결과
- [ ] 시연 PC 추론 속도·메모리
- [ ] 로봇 환경 설치 경로 (`setup_env.ps1 -Robot`)
- [ ] 실카메라 `board_state()` 동작
