# 모듈 간 인터페이스

모듈끼리는 아래 함수만으로 주고받습니다. 칸은 `"cell_1"`처럼 **슬롯 이름**으로 부르며, 픽셀 좌표나 로봇 좌표는 각 모듈 안에서만 씁니다. 실제 정의는 `src/common/interfaces.py`, 가짜 구현은 `src/common/mock.py`에 있습니다.

> **10/30 회의 결정:** 게임이 **윷놀이**로 바뀌었습니다 (차선책: 돌 vs 인간, Day 6 판단). 아래 1절은 지금 코드에 들어 있는 **윷놀이 인터페이스**(Day 1 회의에서 바뀌면 함께 고침)이고, 2절은 차선책용 **주사위 게임 인터페이스**입니다. 주사위 게임 골격은 차선책(돌 vs 인간)으로 전환할 때 씁니다.
> 확정되면 김동현(C1)이 `interfaces.py`, `mock.py`, 호출하는 곳을 함께 고칩니다 (AGENTS.md "인터페이스를 바꿀 때").

## 1. 윷놀이 인터페이스 (코드 반영 11/02, Day 1 회의에서 바뀌면 함께 고침)

| 모듈 | 함수 | 반환 | 담당 | 바뀐 점 |
|---|---|---|---|---|
| vision | `read_yut()` | `YutResult(flats, value, confidence)` · 4개가 안 보이거나 애매하면 `value=None` | 정성욱 | `read_dice()` 대신. 가락이 멈춘 뒤 8장 다수결로 읽음 (아래 "윷 인식") |
| vision | `piece_at(cell)` | 그 칸에 있는 말의 편 `"robot"` / `"human"` / `None` | 정성욱 | 칸 이름이 29칸 + 대기 칸으로 늘어남 |
| vision | `board_state()` | 판 위 칸 전체의 편 `{"cell_3": "robot", ...}` · 빈 칸은 `None`(빠져도 됨) | 정성욱 | **새로 추가 (11/03)**. 로봇이 말을 옮기고 `home()`한 뒤 게임이 판 전체를 기대 상태와 비교 |
| robot | `home()` | 없음 · HOME 자세로 복귀 | 신이서 | 같음 |
| robot | `move(src, dst)` | `bool` 성공 여부 · 업힌 말도 같은 함수로 옮김 | 신이서 | **사람 말·잡힌 말도 로봇이 옮김** |
| game | `choose_move(game, player, pending)` | `Move(piece, value, reason)` · 로봇이 움직일 말과 적용할 결과 (`game/strategy.py`) | 김동현 | 새로 추가 (전략) |
| llm | `narrate(event, context=None)` | 중계 문장 `str` | 김관영 | 이벤트 종류가 늘어남. **`context` 추가 (11/04)**: 판 상태로 판세·위기를 덧붙임 (아래 "중계") |
| db | `save(event)` | 없음 | 김관영 | 같음 |
| ui | `update(state, message)` / `ask_help(msg)` | 없음 | 김민범 | 윷판·모아 둔 결과 표시 |
| ui | `ask_choice(options)` | 고른 번호 `int` · 사람이 움직일 말 선택 | 김민범 | 새로 추가 |
| ui | `show_throw(flats, name)` | 없음 · AI 턴 윷 던지기 장면 (앞 개수 0~4, 빽도 -1, "윷" 같은 이름) | 김민범 | 새로 추가 |

### 데이터 형식

```python
@dataclass
class YutResult:
    flats: Optional[int]   # 평평한 면이 위인 윷가락 수 0~4, 표시한 가락 하나만 앞이면 -1(빽도), 인식 실패면 None
    value: Optional[int]   # 이동 칸 수: 빽도-1 도1 개2 걸3 윷4 모5
    confidence: float

@dataclass
class Move:
    piece: int             # 말 번호 0부터 (pieces_per_side-1까지)
    value: int             # 적용할 결과 칸 수 (pending 중 하나)
    reason: str = ""       # capture | stack | advance | enter | back | human

@dataclass
class YutState:            # 주사위 골격의 GameState와 구분하려고 이름을 바꿈
    pieces: dict           # {"robot": ["wait_robot", "cell_7"], "human": ["cell_4", "cell_4"]}  편마다 말 2개, 업힘 = 같은 칸
    current: str = "human"
    turn: int = 1
    pending: list = field(default_factory=list)  # 모아 둔 결과, 예: [4, 5, 1]
    winner: Optional[str] = None
```

- **진행 방식 (11/02 결정):** 사람 턴은 사람이 실제 윷을 던지고 비전(`read_yut`)이 읽습니다. AI 턴은 로봇이 던지지 않고, 게임이 `config/yut_board.json`의 `ai_throw.flat_prob`로 결과를 정해 UI `show_throw()`가 장면을 보여 줍니다. 말은 사람 말·로봇 말·잡힌 말·완주 모두 로봇팔이 `move()`로 옮기고, 사람은 `ask_choice()`로 말만 고릅니다. `throw_yut()`는 쓰지 않습니다.
- 게임은 `YutResult.flats`만 봅니다 (`None`이면 인식 실패로 다시 던짐). `value`는 화면·로그용입니다.
- **빽도 (11/03 결정):** 윷가락 하나에 표시하고, 그 가락 하나만 앞이면 비전은 `flats=-1`을 돌려줍니다. 필드는 그대로이고 값 범위만 늘었습니다. 판 위에 말이 없으면 게임이 무효로 처리합니다.
- 오케스트레이터는 비전·로봇을 `game/wrapper.py`의 `DeviceWrapper`로만 부릅니다. 로봇 동작마다 `home()`을 부르고, 팔이 HOME 밖이면 비전 호출을 막습니다. 실제 모듈을 붙이는 방법은 그 파일 맨 위 주석을 봐 주세요.
- 턴 순서: `game/state_machine.py`의 `YutTurnMachine` (던지기 → 읽기 → 고르기 → 이동 → 확인 → 정리). 흐름 테스트는 `tests/test_yut_turn.py`입니다.
- **윷 인식 (11/03 구현, 인터페이스는 바뀐 것 없음):** `read_yut()`의 시그니처와 반환 형식은 그대로이고 내부 동작만 채웠습니다. 실제 실행(`--mock` 아님)의 윷놀이에서만 윷 모델을 불러오고, `--game dice`는 모델 없이 뜹니다.
  - 가락이 멈출 때까지 기다린 뒤(최대 3초, 못 멈추면 confidence를 절반으로) 8장을 읽어 75% 이상 일치하는 결과를 씁니다.
  - 모델 클래스는 `down`(배) / `backdo`(표시한 배) / `upper`(등)입니다. 가락이 4개가 아니면 `None`, 배 개수는 `down + backdo`, 표시한 배만 1개 앞이면 `flats=-1`(빽도)입니다.
  - 모델은 `models/yut/<이름>/model.xml`에 둡니다 (git 제외, 기본 `7bc45355-openvino-int8`). 없으면 안내를 출력하고 종료합니다.
  - 로봇이 움직인 뒤에는 `home()`을 부르고 나서 `read_yut()`을 호출합니다 (`DeviceWrapper`가 지킴).
- 실행: `python src/main.py --mock` (윷놀이), `--game dice` (주사위 골격).
- 로봇 없이 실물 시험: `python src/main.py --no-robot [--ui]`. 비전·상태 머신·중계·DB·화면은 실제 모듈이고, 로봇 대신 `common/mock.py`의 `HandRobot`이 "말을 옮기고 확인" 안내를 띄웁니다. 사람이 옮긴 뒤 `board_state()`로 판 전체를 확인합니다. 기록은 `data/games.db`에 남습니다. 카메라 번호는 `--tray-cam N --board-cam N`으로 지정합니다 (판 카메라를 생략하면 트레이와 같은 카메라).
- **board_state 구현 (11/03, 인터페이스는 바뀐 것 없음):** `board_state()`·`piece_at(cell)`의 시그니처와 반환 형식은 그대로입니다.
  - 반환 형식: `{게임 칸 이름: "robot" | "human" | None}`. 판 위 29칸 키를 모두 포함하고 빈 칸은 `None`입니다.
  - **칸 이름 (비전 쪽 채택, 팀 최종 확인 필요):** 게임 칸 이름(`cell_0`~`cell_19`, `diag_r1`~`diag_r4`, `diag_l1`~`diag_l4`, `center`)을 키로 씁니다. `load_board_cells`(`src/vision/board_cells.py`)가 29칸 이름을 `config/yut_board.json`에서 읽어 검증하며, `cell_20`~`cell_28`이 섞이면 오류입니다. `scripts/make_board_cells.py`가 비전 초안의 `cell_20`~`cell_28`을 게임 이름으로 바꿉니다. 변환표는 비전 코드 안에 두고 `robot.slots.SLOT_ALIASES`와 일치하는지 테스트로 확인합니다 (비전은 로봇 모듈을 import하지 않음, 설계 규칙 2).
  - 판 카메라에서 처음 5프레임을 버리고(버퍼에 남은 옛 화면 제거) 8프레임을 읽어 칸별로 다수결을 냅니다. 75% 이상 일치해야 인정합니다.
  - 애매한 칸은 `None`으로 돌려주고, 이유는 `VisionDetector.last_board_issues`에 남깁니다. 판독 불가를 예외로 알리는 규약은 팀 결정 대기입니다.
  - 칸 좌표는 `config/board_cells.json`(게임 칸 이름 29개)입니다. `scripts/make_board_cells.py`로 기준 사진 초안에서 만들며, **카메라 위치 확정 후 다시 만들어야 합니다.** 파일이 없으면 `FileNotFoundError`입니다.
  - `home()` 뒤에만 호출합니다. `piece_at(cell)`은 `board_state()` 결과에서 그 칸을 꺼냅니다.
  - 판 칸 좌표는 `config/board_cells.json`(`{"x", "y", "roi_r"}`)에 두고 `config/slots.json`에는 트레이 `tray`만 남습니다. 실제 `board_cells.json`은 카메라 최종 위치 확정 후 사람이 기준 사진에서 만들며 아직 저장소에 없습니다 (측정값만 넣고 임의 값은 넣지 않음).
  - **미정:** 비전이 대기 칸·완주 칸도 읽어야 하는지 게임 담당과 확인이 필요합니다. 현재 구현은 판 위 29칸만 읽습니다.

슬롯 이름: `cell_0`~`cell_19`, `diag_r1`~`diag_r4`, `diag_l1`~`diag_l4`, `center`, `wait_human`, `wait_robot`, `goal_human`, `goal_robot`, `yut_tray`. 연결 관계는 `docs/rules.md` 윷판 그림을 따릅니다.

### 이벤트 형식 (제안, C1·C2 Day 1 합의)

`Event(turn, player, kind, detail)`은 그대로 두고 `kind`와 `detail`만 늘립니다.

| kind | 언제 | detail 예 |
|---|---|---|
| `throw` | 윷 결과가 확정될 때 | `{"yut": "윷", "value": 4, "again": true}` |
| `move` | 말 하나(또는 업힌 말)를 옮길 때 | `{"piece": 1, "yut": "걸", "from": "cell_3", "to": "cell_6", "stacked": 1}` |
| `capture` | 상대 말을 잡았을 때 | `{"cell": "cell_4", "captured": 2, "again": true}` |
| `stack` | 내 말을 업었을 때 | `{"cell": "cell_4", "stacked": 2}` |
| `finish` | 말이 완주했을 때 | `{"pieces": 2, "left": 0}` (함께 완주한 말 수, 남은 말 수) |
| `win` | 승리 | `{"turns": 18}` |
| `help` | 사람 도움 요청 | `{"message": "윷 인식 실패"}` |
| `decision` | (확장) 로봇이 말을 고른 이유 | `{"piece": 2, "reason": "capture"}` |

- `board_state()`의 키는 게임 칸 이름(`cell_0`~`cell_19`, `diag_r1`~`diag_r4`, `diag_l1`~`diag_l4`, `center`)입니다. 비전 초안의 `cell_20`~`cell_28`은 `robot/slots.py`의 `SLOT_ALIASES` 대응대로 바꿔서 돌려줍니다. 대기·완주 칸은 읽지 않습니다 (개수는 게임 로직이 기록). 소유자만 돌려주고 업힌 말 수는 게임이 압니다.
- 이동 확인: 기대와 다른 칸이 옮긴 도착 칸이면 최대 2회 다시 옮기고, 그래도 다르거나 다른 칸이 다르면 어느 칸이 다른지 `ask_help()`로 알립니다. `piece_at(cell)`은 단독 확인용으로 남겨 둡니다.
- `move`의 `stacked`는 함께 움직인 말 수입니다 (혼자면 1, 업힌 말이면 2). `to`가 `"goal"`이면 완주입니다.
- `reason`: `capture` | `stack` | `advance` | `enter` (규칙서 MVP 우선순위 순서). 로봇 전략은 `game/strategy.py`의 `choose_move` 하나이며 시뮬레이션(`simulate()`)도 같은 함수를 씁니다.
- 중계: 이벤트 하나는 `narrate(event, context)`로 하고, 한 턴 전체를 LLM 한 번으로 중계하려면 `narrate_turn(events, context)`를 씁니다. 실패하면 가장 중요한 이벤트 하나를 템플릿 문장으로 냅니다.
- 중계 `context` (선택, 11/04): 오케스트레이터가 이동 이벤트를 중계할 때 `{"pieces": {"human": ["wait", "cell_3"], "robot": [...]}, "reason": "capture"}`를 넘깁니다. `pieces`는 규칙 엔진 위치(`wait`·`goal`, 편 구분 없는 이름)의 **복사본**이고, `reason`은 로봇 이동에만 있습니다. 중계기(`llm/situation.py`)는 이것으로 역전·위기(상대가 어떤 윷을 던지면 잡히는지)·로봇의 생각·판세 중 하나를 골라 덧붙입니다. 계산은 코드가 하고 LLM은 말로만 바꿉니다. `context`가 없으면(주사위 게임 등) 지금처럼 장면만 중계합니다.
- 이벤트는 `src/game/yut_reference.py`의 `move_events()`가 만들고, 오케스트레이터와 `simulate()`(가짜 한 판)가 함께 씁니다. 윷판 그래프는 `config/yut_board.json`에 있습니다.

## 2. 주사위 게임 인터페이스 (현재 코드, 차선책 전환 시 사용)

| 모듈 | 함수 | 반환 | 담당 |
|---|---|---|---|
| vision | `read_dice()` | `DiceResult(value, confidence)` · 애매하면 `value=None` | 정성욱 |
| vision | `piece_at(cell)` | 그 칸에 있는 말 `"robot"` / `"human"` / `None` | 정성욱 |
| robot | `home()` | 없음 · HOME 자세로 복귀 | 신이서 |
| robot | `roll_dice()` | `bool` 성공 여부 | 신이서 |
| robot | `move(src, dst)` | `bool` 성공 여부 | 신이서 |
| llm | `narrate(event)` | 중계 문장 `str` | 김관영 |
| db | `save(event)` | 없음 | 김관영 |
| ui | `update(state)` / `ask_help(msg)` | 없음 | 김민범 |

돌 vs 인간에서는 `read_dice()` 결과를 돌의 답(0·1·2)으로 바꿔 쓰고, 문제 출제·채점은 `llm/quiz.py`(`QuizMaster.ask()`, `grade()`)를 씁니다. 문제 은행 형식은 `{"question", "answer": 0|1|2, "explain"}`로 바꿀 예정입니다 (현재는 보기형).

## 순서 규칙 (두 게임 공통)

1. 로봇이 움직인 뒤에는 반드시 `home()`을 부른 다음 비전을 호출합니다 (팔이 화면을 가림).
2. `narrate()`는 로봇이 멈춰 있을 때만 호출합니다 (시연 PC 자원).
3. 인식·이동 실패는 최대 2회 재시도하고, 그래도 실패하면 `ui.ask_help()`로 사람에게 요청합니다.
