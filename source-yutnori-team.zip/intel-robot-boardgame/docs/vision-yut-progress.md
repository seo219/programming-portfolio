# 윷 인식 진행 현황과 수정 사항

- 작성일: 2026-11-03
- 작성 주체: 비전 담당 작업 기록
- 기준 커밋: `caf10f5` (브랜치 `feature/KAN-2-vision-detector-roi`). 9절(board_state 준비)은 브랜치 `feature/KAN-2-vision-board-state` 기준
- 관련 문서: 설계·변경 배경은 [vision-yut-handoff.md](vision-yut-handoff.md), 인터페이스는 [interfaces.md](interfaces.md)의 "윷 인식" 항목
- 표기: 시험 값은 개발 환경(조명 고정 없음) 기준이며, 코드·git으로 확인되지 않은 항목은 "미확인"으로 적었습니다.

## 1. 한눈에 보기

- `read_yut()`이 동작합니다. 가락이 멈추길 기다린 뒤 8프레임을 읽어 다수결로 도·개·걸·윷·모·빽도를 돌려줍니다.
- 실제 실행(`--mock` 아님)의 윷놀이는 `main.py`의 `build_vision()`으로 Geti 윷 모델(`7bc45355-openvino-int8`)을 불러옵니다.
- 실제 카메라 검증은 `scripts/try_read_yut.py`로 10회 읽은 것이 전부입니다 (맞음 8, 틀림 0, 실패 2).
- 실패 2건은 가락이 카메라 시야 가장자리·밖에 있어 4개가 안 보인 경우입니다.
- `board_state()`·`piece_at()`도 구현했습니다 (9절). 칸 좌표 파일 `config/board_cells.json`은 카메라 위치 확정 후 만들어야 하므로 아직 없고, 실카메라 시험은 못 했습니다.
- 안 되는 것: 트레이 ROI 적용, 노출·화이트밸런스 고정.
- `python src/main.py` 전체를 실제 카메라·로봇·Ollama로 돌린 적은 없습니다.

## 2. 완성한 기능

| 기능 | 파일 | 커밋 |
|---|---|---|
| 판정 규칙 (검출 목록 → 배 개수 → `YutResult`) | `src/vision/yut_logic.py` | `ecf5b79` |
| `read_yut()` 다수결 | `src/vision/detector.py` | `b72ba3b` |
| 정지 대기 (`_wait_until_still`) | `src/vision/detector.py` | `6d8d67f` |
| 모델 분류기 (`ModelApiYutClassifier`) | `src/vision/yut_model.py` | `d802a51` |
| 모델 평가 스크립트 | `scripts/eval_yut.py` | `bff2a2e` |
| `main.py` 연결 (`build_vision`) | `src/main.py` | `cb17138` |
| 카메라 시험 스크립트 | `scripts/try_read_yut.py` | `60d008d` |
| 정지 대기 진단 기록 (`StillInfo`) | `src/vision/detector.py`, `scripts/try_read_yut.py` | `caf10f5` |

### 동작 규칙 요약

| 항목 | 규칙 |
|---|---|
| 모델 클래스 | `down` = 배, `backdo` = 표시된 배, `upper` = 등 |
| 가락 수 | 점수 0.5 이상 검출이 4개가 아니면 `None` |
| 배 개수 | `down` + `backdo` |
| 빽도 | 표시된 배(`backdo`)가 있고 배 개수가 1이면 `flats=-1` |
| 다수결 | 8프레임 중 75% 이상 일치해야 인정, 아니면 `value=None` |
| 정지 대기 | 최대 3초. 못 멈추면 읽긴 읽되 `confidence`를 절반으로 |
| 정지 판정 | 직전 프레임과 그레이 평균 차이 0.7 미만이 연속 10프레임 |
| 모델 위치 | `models/yut/<이름>/model.xml` (git 제외). 없으면 안내 후 종료 |

## 3. 수정한 점

| 무엇을 | 왜 | 이전 → 이후 | 커밋 |
|---|---|---|---|
| develop 머지 | 윷놀이 코드·인터페이스를 가져오려고 | 주사위 기준 브랜치 → 윷놀이 코드·인터페이스 포함. 주사위 `read_dice` detector는 차선책으로 유지 | `4d8be57` |
| `openvino-model-api==0.4.7` 의존성 추가 | Geti 모델을 불러오려고 | 없음 → `requirements.txt`에 추가, lock 2개 재생성. 기존 패키지 버전 변경 없이 추가만 (model-api, pillow, opencv-python-headless) | `641cbb7` |
| `scripts/setup_env.ps1` 일반 설치 경로 | model-api가 headless OpenCV를 깔아 `imshow`가 막혀서 | GUI 빌드 복구 단계 추가 | `641cbb7` |
| 윷 모델 선택 | 3종 비교 | `7bc45355-openvino-int8`을 기본으로 (4절 가) | `d802a51` |
| 미리보기 한글 | `cv2.putText`가 한글을 `???`로 그림 | Pillow로 그리기 (맑은 고딕 등 후보 폰트). 폰트가 없으면 영어 문구로 대체 | `7fd6aa9` |
| 정지 판정 기준 | 실측 근거 (4절 나) | `STILL_DIFF_THRESH` 1.0 → 0.7, `STILL_FRAMES` 3 → 10 | `2696d4b` |
| 정지 보정 (c 모드) | 굴림과 가만히를 더 잘 가르려고 | 평균 차이 1지표 → 평균 차이 + 변화 픽셀 비율 2지표, 가만히/굴림 2구간 비교, 중복 프레임 제외. 판정에는 평균 차이 유지 (구분력이 더 높았음) | `1920b72`, `4a488b6` |
| 시험 기록 위치 | 파일이 흩어짐 | 보정 csv/txt, 읽기 시험 csv/txt/사진/대기 차이값을 `data/yut_logs/` 아래로 모음 | `f6486fd` |
| 읽기 시험 기록 | 정답률을 바로 보려고 | CSV·사진·요약 파일 저장, o/x 정답 표시와 정답률 요약 추가 | `b3d5e33` |
| 정지 대기 진단 | 대기 지연 원인을 가리려고 | 대기 시간·프레임 수·차이값을 시험 기록에 추가 | `caf10f5` |
| 인터페이스 문서 | 구현 반영 | 시그니처 변경 없음. `docs/interfaces.md`에 "윷 인식" 항목 추가. `interfaces.py`, `mock.py`는 변경하지 않음 | `cb17138` |

### 팀 알림이 필요한 점

- 의존성 추가는 팀 절차(`docs/versions.md`)상 팀에 알려야 합니다.
- `scripts/setup_env.ps1` 변경은 2026-11-03 이 PC(Windows, Python 3.12.14 `.venv`)에서 돌려 확인했습니다: lock 28개 패키지 일치, `imshow` 가능, 테스트와 `--mock` 한 판 정상. 로봇 설치 경로(`-Robot`)는 확인하지 못했습니다.
- **재설치가 필요한 경우:** 실제 윷 모델을 돌리는 사람(`python src/main.py` 실제 모드, `try_read_yut.py`, `eval_yut.py`)만 `uv pip sync requirements.lock` 또는 `setup_env.ps1`로 패키지를 맞추면 됩니다. `model_api`는 모델을 만들 때만 불러오므로 `pytest`와 `--mock`은 재설치 없이 동작합니다. `check_env.py`는 lock과 비교하므로 재설치하지 않으면 경고합니다.

## 4. 시험 결과

### 가. 모델 평가

- 조건: `data/yukk_1` 188장, `scripts/eval_yut.py`, 이 PC CPU.
- **학습 데이터와 겹칠 수 있어 낙관적입니다.** `data/yukk_2`는 비어 있어 새 사진 검증은 못 했습니다.

| 모델 | 정답 | 정확도 | 평균 추론 시간 |
|---|---|---|---|
| `47a430b5-fp16` | 180/188 | 95.7% | 235ms |
| `7bc45355-fp16` | 184/188 | 97.9% | 68ms |
| `7bc45355-int8` | 185/188 | 98.4% | 76ms |

- 오답은 전부 가락 하나를 놓쳐 `None`이 된 경우입니다. 엉뚱한 값은 없었습니다.

### 나. 정지 보정 실측

- 조건: 2026-11-03, 카메라 0, 1920x1080, 약 30fps. 기록은 `data/yut_logs/yut_calib_20261103_154410`.
- 처음 측정은 굴림 최대가 0.82라 구분되지 않았습니다. 윷을 충분히 굴리지 않은 것으로 보입니다 (추정).
- 다시 측정한 값:

| 구간 | 평균 차이 |
|---|---|
| 가만히 | 최대 0.62, 95% 0.44, 평균 0.28 |
| 굴림 | 최대 7.34, 중앙값 1.40, 평균 1.76 |

- 굴림 중 "가만히 최대"를 넘은 프레임 비율: 평균 차이 77.5%, 변화 픽셀 67.5%.
- 기준 0.7에서 연속 프레임: 굴리는 도중 잠잠한 구간 최대 7, 멎은 뒤 21.
- 결정: 기준 0.7, 연속 10프레임. 표본이 1회라 다른 조명·위치에서 다시 측정해야 합니다.

### 다. 실카메라 읽기 시험

- 조건: `data/yut_logs/yut_try_20261103_155533`, 정지 기준 0.7/10, 모델 `7bc45355-int8`, 10회.
- 결과: 맞음(o) 8, 틀림(x) 0, 실패 2. 정답률 100%는 o/(o+x)이며 표본 10회라 낙관적일 수 있습니다.

| 이름 | 횟수 |
|---|---|
| 개 | 3 |
| 도 | 1 |
| 모 | 2 |
| 빽도 | 2 |
| 실패 | 2 |

- confidence 평균 0.65, 평균 걸린 시간 2.35초.
- 걸린 시간은 약 1.1~1.5초(5건)와 약 3.5초(4건)로 갈렸습니다. 3건은 타임아웃(confidence 0.5)이었으나 결과는 맞았습니다.
- 실패 2건(#7, #8)의 원인은 **카메라 시야**입니다. 가락이 화면 가장자리에 걸치거나 화면 밖으로 나가 4개가 안 보였고, 모델 오류가 아닙니다.
- 약 3.5초 걸린 이유는 미확인입니다 (진단 기록으로 확인 예정).

## 5. 도구 사용법

실행 환경은 프로젝트 `.venv`입니다. 시스템 python 3.14에는 openvino가 없습니다.

### `scripts/eval_yut.py`

```bash
python scripts/eval_yut.py --model models/yut/7bc45355-openvino-int8 data/yukk_1
```

- 데이터 폴더 아래에 `backdo/do/gae/gurl/yukk/mo` 하위 폴더가 있어야 합니다.
- 전체 정답 수, 인식 실패(None) 수, 이름별 정답, 평균 추론 시간, 오답 목록을 출력합니다.
- `--min-score`로 낮은 점수 검출을 버릴 수 있습니다.

### `scripts/try_read_yut.py`

```bash
python scripts/try_read_yut.py --camera 0
python scripts/try_read_yut.py --image data/yukk_1/gae/xxx.jpg   # 사진 한 장, 창 없음
```

| 키 | 동작 |
|---|---|
| 스페이스 | `read_yut()` 실행, 결과 출력·기록 |
| `o` / `x` | 직전 결과를 맞음 / 틀림으로 표시 |
| `c` | 정지 보정 (가만히 4초 → 굴림 4초, 각 구간 앞에 준비 1초). 판정 로직은 바꾸지 않는 진단용 |
| `q` / Esc | 종료 (요약 저장) |

| 출력 파일 (`data/yut_logs/`) | 내용 |
|---|---|
| `yut_try_<시각>.csv` | 읽기 시험 줄별 기록 (즉시 저장) |
| `yut_try_<시각>.txt` | 종료 시 요약 (정답률 등) |
| `yut_try_<시각>/NNN_<이름>.jpg` | 박스를 그린 원본 해상도 사진 |
| `yut_try_<시각>/NNN_wait.csv` | 정지 대기 프레임별 차이값 |
| `yut_calib_<시각>.csv`, `.txt` | 정지 보정 기록과 구간별 요약 |

- CSV 열: `seq, time, flats, value, name, confidence, elapsed_sec, detections, verdict, image`, 정지 대기 진단 `wait_sec, still_ok, wait_frames, wait_max_diff, wait_last_diff`.
- 시험 순서: (1) `c`로 보정해 기준값 확인 (2) 윷을 던지고 멎은 뒤 스페이스 (3) `o`/`x` 표시 (4) 종료 후 요약 확인.
- `data/` 아래라 기록 파일은 git에 올라가지 않습니다.

## 6. 남은 일과 위험

| 항목 | 담당 | 상태 |
|---|---|---|
| 트레이 설치, 카메라 고정, 노출·화이트밸런스 고정 | 사람 | 미착수 |
| 트레이 ROI 측정 `select_roi.py --only tray` (`slots.json` 값은 실측만 넣음) | 사람 | 미착수 |
| 트레이 상태에서 30~50회 시험 | 사람 + 비전 | 미착수 |
| 정지 대기 지연 원인 진단 (진단 기록으로 확인) | 비전 | 기록 기능은 완료, 분석 전 |
| 트레이 ROI 적용 코드 | 비전 | 미착수 |
| 5단계 말 위치 읽기 | 비전 | 구현 완료, 남은 일은 9절 |
| 시연 PC 속도·메모리 측정 | 사람 + 비전 | 미착수 (이 PC 값만 있음) |
| 새 사진으로 정확도 재검증 (`data/yukk_2` 비어 있음) | 비전 | 미착수 |
| develop 재동기화, PR 정리 (의존성 커밋 `641cbb7` 분리 또는 김관영에게 알림) | 비전 | 미착수 |
| 구 `read_dice` 주사위 코드 | 비전 | 차선책으로 유지 |

## 7. 결정이 필요한 것

| 항목 | 내용 | 상태 |
|---|---|---|
| 칸 이름 | 비전은 게임 칸 이름(`cell_0`~`cell_19`, `diag_r1`~`diag_r4`, `diag_l1`~`diag_l4`, `center`)을 키로 채택. 비전 초안의 `cell_20`~`cell_28`은 `make_board_cells.py`가 변환하고 `load_board_cells`는 `cell_20`~`cell_28`이 섞이면 오류. 게임 쪽 윷판 설정과 같은 이름 | 비전 쪽 채택, 팀 최종 확인 필요 |
| 대기·완주 칸 | 비전이 대기 칸·완주 칸도 읽어야 하는지. 현재 구현은 판 위 29칸만 읽음 | 게임 담당과 확인 필요 (미정) |
| 의존성 알림·PR 분리 | 의존성 추가를 팀에 알리는 방식, PR에서 `641cbb7`을 분리할지 | 결정 필요 |
| 트레이 사용 | 트레이를 사용 | 결정됨 |

## 8. 검증 현황

| 항목 | 결과 |
|---|---|
| 전체 pytest (프로젝트 `.venv`, 3.12.14, lock 설치) | 372 passed (11/03, board_state 준비 이후) |
| 전체 pytest (`model_api`가 없는 환경) | 이 값은 372 이전에 잰 것이라 미확인 |
| skip 6건 | `model_api`가 없는 환경에서 건너뛰는 실모델 통합 테스트. `.venv`에서는 실제로 실행되어 통과 |
| `scripts/setup_env.ps1` (공통 경로) | lock 28개 일치, `imshow` 가능, `--mock` 한 판 정상, `check_env` 필수 항목 통과 (Ollama 버전·서버 경고는 윷 인식과 무관) |
| `python src/main.py --mock` | 윷놀이·주사위 한 판 정상 |
| `try_read_yut.py` 카메라 모드 | 사람이 실행해 확인 (4절 다) |
| `python src/main.py` 실제 카메라·로봇·Ollama 전체 실행 | **한 적 없음** |

## 9. board_state 준비 (S1~S4)

`board_state()`와 `piece_at(cell)`을 구현했습니다. 시그니처는 그대로입니다 (`docs/interfaces.md` "윷 인식" 항목 참고).

### 새 파일

| 파일 | 내용 |
|---|---|
| `src/vision/board_cells.py` | `config/board_cells.json`(게임 칸 이름 → 좌표) 읽기. 파일이 없으면 `FileNotFoundError` |
| `src/vision/board_pieces.py` | 색 덩어리 → 가장 가까운 칸 배정 (카메라·로봇을 import하지 않는 순수 함수) |
| `scripts/make_board_cells.py` | 비전 초안(`slots_draft_v2.json`)을 `board_cells.json`으로 변환. 이미 있으면 `--force` 없이 덮어쓰지 않음 |

### 커밋

| 커밋 | 내용 |
|---|---|
| `d5a1293` | 판 칸 좌표 로더와 초안 변환 스크립트 추가 |
| `e918131` | 말 판별을 `src/vision`으로 이전해 단일화 |
| `bc59f53` | 트레이·판 카메라를 번호별 캡처로 분리, 카메라 실패 시 재열기 |
| `cd5270a` | `board_state()` 구현 (프레임 비우기·칸별 다수결, `piece_at` 통합) |
| `cea3be3` | 시험 스크립트 정리 (카메라 안내, `eval_yut.py`가 `yut_logic` 판정 재사용) |
| (다음 두 커밋) | 문서 갱신(board_state 구현 내용, 칸 이름 결정), `slots.json`의 0값 판 칸 자리표시 제거. 해시는 `git log`로 확인 |

### 수정한 점

| 무엇을 | 이전 → 이후 |
|---|---|
| 말 판별 | 두 벌(scripts와 detector) → `board_pieces.py` 하나로 단일화. 충돌(한 칸에 덩어리 둘) 처리 방식도 이때 바뀜 |
| 칸 간격 | 칸 간격을 중앙값 하나로 단순화 |
| 카메라 | 한 카메라 → 트레이·판 카메라를 번호별로 캡처, 읽기 실패 시 재열기 |
| `piece_at` | 옛 ROI 색 비율 방식 → `board_state()` 결과에서 꺼냄. `slots.json`의 판 칸 ROI는 더 이상 아무 코드도 읽지 않음 |
| `select_roi.py` | 기본 대상을 `tray`만으로 (판 칸 좌표는 `make_board_cells.py`) |

- 테스트는 325개에서 372개로 늘었습니다 (`.venv`에서 `pytest tests -q`, 372 passed).
- 판 칸 좌표는 `config/board_cells.json`(게임 이름 29칸, `{"x","y","roi_r"}`)에 두고 `config/slots.json`에는 `tray`만 남습니다.
- `main.py`의 `build_vision`은 아직 판 카메라 번호를 받지 않습니다. 지금은 `VisionDetector`의 기본값을 씁니다.

### 남은 일

| 항목 | 담당 | 상태 |
|---|---|---|
| 실제 `config/board_cells.json` 생성 (카메라 위치 확정 후 `make_board_cells.py` 실행) | 사람 | 미착수 |
| 말 색 범위(HSV) 시연장 조명에서 재측정 | 사람 + 비전 | 미착수 |
| 프레임 버퍼 지연(5프레임 버리기가 충분한지) | 사람 + 비전 | 미확인 |
| USB 카메라 2대 동시 연결 | 사람 | 미확인 |
| 대기·완주 칸을 비전이 읽을지 (읽는다면 칸 이름과 좌표 실측) | 팀 + 비전 | 미정 |
| 카메라 번호 설정 위치 (D3) | 팀 | 결정 대기 |
| 판독 불가 규약, 예외로 알릴지 (D1) | 팀 | 결정 대기 |
| 예외 처리 (C1) | 팀 | 결정 대기 |
| 재이동 (C2) | 팀 | 결정 대기 |
