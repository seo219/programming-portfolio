# 로봇 제어·학습 도구 조사 (LeRobot vs Physical AI Studio)

- 작성일: 2026-11-03 (KAN-3)
- 목적: 칸 위치 이동 + 모방학습(ACT 집기)을 결합할 때 어떤 도구를 쓸지 정하기 위한 조사 기록
- 표시: **[코드]** 이 PC에 설치된 LeRobot 0.6.1 소스를 직접 읽어 확인 · **[문서]** 공식 문서·소스 설명으로 확인(실행은 안 해 봄) · **[미확인]** 확인하지 못함

## 0. 결정 (2026-11-03): Physical AI Studio 우선, LeRobot은 차선책

| 구분 | 주 도구 | 차선책 |
|---|---|---|
| 모방학습(ACT) 녹화·학습·내보내기 | **Intel Physical AI Studio** | LeRobot (`lerobot-record`, `lerobot-train`) |
| 정책 실행 (게임 코드 안) | Studio에서 OpenVINO로 내보낸 모델을 `InferenceModel`로 실행 | LeRobot 정책 실행 |
| 로봇 드라이버 (`Backend`) | `physicalai-so101-plugin`의 `SO101` (3.2절) | 현재 구현 `src/robot/backend_lerobot.py` |
| 보정 파일 | LeRobot 보정 JSON 형식 그대로 (플러그인이 읽음, 4절 질문 2) | 같음 |

- **이유**
  - 비전(Geti + OpenVINO)과 같은 Intel 흐름입니다.
  - 정책을 OpenVINO로 내보내 CPU에서 실행하면 시연 PC의 RTX 3050 6GB를 중계 LLM(약 3GB)과 나눠 쓰지 않아도 됩니다.
  - 녹화·학습을 화면에서 관리할 수 있습니다.
  - 데이터셋을 LeRobot v3 형식으로 내보내고 가져올 수 있어, 녹화는 시연 PC에서 하고 학습은 다른 PC(5060 Ti)에서 할 수 있습니다.
- **차선책(LeRobot)으로 바꾸는 조건:** 6절 확인 항목 중 하나라도 막히면 바꿉니다.
  - 3번: Studio 정책을 게임 코드에서 실행할 수 없음
  - 5번: Windows에서 Studio를 쓸 수 없음(Docker + USB 전달)
  - 1·2번: 보정 값이 맞지 않음
- **차선책을 대비해 지킬 것**
  - 녹화한 데이터셋은 **LeRobot v3 형식으로 내보내 Hugging Face Hub에 백업**합니다. 그러면 LeRobot으로 바꿔도 다시 녹화하지 않아도 됩니다.
  - `backend_lerobot.py`와 `scripts\setup_env.ps1 -Robot`(LeRobot 설치)은 지우지 않고 차선책 경로로 남깁니다.
- **코드 영향:** 하드웨어 접근이 `Backend` 인터페이스 뒤에 있어서 Studio 플러그인 백엔드를 추가하면 됩니다(5절 표의 1~3단계는 "구현만 교체"). 게임 코드(`move()` 호출 쪽)는 바뀌지 않습니다.
- 아래 1~8절은 결정 전 조사 기록이며 그대로 둡니다.

## 1. 결론 요약

1. 칸 이동(좌표 접근)은 모방학습과 **계층으로 나눈다**: 칸 위 접근은 측정한 관절 자세, 집기는 모방학습(ACT), 놓기는 스크립트. 자세한 구조는 `docs/waiting-goal-slots.md`.
2. **보정(calibration)은 두 도구가 같은 JSON 형식을 읽을 수 있다** [문서]. 그래서 "보정 때문에 도구를 하나로 통일해야 한다"는 이유는 약해졌다. 단위(degree)가 숫자까지 같은지는 [미확인].
3. 4~5단계(스크립트 집기, 게임 연결)는 어느 도구든 그대로 진행할 수 있다. **도구를 정해야 하는 시점은 6단계(ACT 녹화·학습·실행) 직전**이다.
4. 현재 코드(1~4단계)는 LeRobot 기준으로 작성했고, 하드웨어 접근은 `Backend` 인터페이스(`src/robot/backend.py`) 뒤에 있어 Studio 드라이버로 바꿀 수 있다.

## 2. LeRobot 0.6.1 (설치된 소스에서 확인) [코드]

- SO-101: `from lerobot.robots.so_follower import SO101Follower, SO101FollowerConfig`, 리더는 `lerobot.teleoperators.so_leader`의 `SO101Leader`.
- `send_action(action)`은 목표를 보내기만 하고 **도착을 기다리지 않는다**. `max_relative_target`을 주면 한 번에 움직이는 각도가 제한된다. 그래서 `backend_lerobot.py`가 보간하며 보내고 도착을 확인한다.
- 단위: 팔 관절은 도(degree, `use_degrees=True` 기본), 그리퍼는 0~100.
- `connect()`는 보정이 안 맞으면 `input()`으로 멈춘다. 게임 중 멈추지 않도록 `connect(calibrate=False)`로 연결하고 `is_calibrated`를 직접 확인한다.
- 보정 파일: `calibration_dir/<id>.json`. `calibration_dir`을 주지 않으면 `~/.cache/huggingface/lerobot/calibration/robots/so_follower/<id>.json` (환경변수 `HF_LEROBOT_CALIBRATION`으로 바꿀 수 있음). 항목은 관절마다 `id`, `drive_mode`, `homing_offset`, `range_min`, `range_max`.
- 카메라는 로봇 설정(`cameras`)에 등록해 `get_observation()`에 함께 들어온다.
- CLI(설치된 `.venv\Scripts`에서 확인): `lerobot-find-port`, `lerobot-find-cameras`, `lerobot-calibrate`, `lerobot-teleoperate`, `lerobot-record`, `lerobot-replay`, `lerobot-train`, `lerobot-eval`, `lerobot-rollout`, `lerobot-find-joint-limits` 등. 실행해 본 것은 아니다.

## 3. Physical AI Studio

### 3.1 무엇인가 [문서]

- Intel의 오픈소스(Apache-2.0) 프레임워크: 시연 데이터로 로봇 정책을 학습·평가·배포. 웹 화면(`localhost:7860`)과 파이썬 라이브러리(`physicalai-train`), CLI(`physicalai`)가 있다.
- 정책: ACT, Pi0.5, SmolVLA 등. 학습한 모델은 OpenVINO·ONNX로 내보낼 수 있고, 내보낸 모델은 `InferenceModel("./exports/act")`로 불러 실행한다.
- 설치: Docker를 권장한다. **Windows 설치 문서는 찾지 못했다** [미확인]. Docker에서 USB 시리얼·카메라를 넘기는 방법도 [미확인].
- LeRobot 형식 데이터셋을 읽는 `LeRobotDataModule`이 있다 [문서]. 즉 LeRobot으로 녹화한 데이터를 Studio에서 학습하는 조합이 가능해 보인다 (실제 시험은 안 함).

### 3.2 SO-101 드라이버 (`physicalai-so101-plugin` 0.2.0, Apache-2.0) [문서]

- 별도 패키지이며 Studio의 로봇 목록에 SO-101 팔로워·리더를 등록한다. 저장소: `openvinotoolkit/physicalai`.
- `SO101(port, calibration=<경로 또는 객체>, role="follower"|"leader", unit="normalized"|"degrees"|"ticks")`.
  - `calibration`에 **"LeRobot 보정 JSON 파일의 경로"** 를 줄 수 있다고 소스에 적혀 있다.
  - 보정 JSON 항목이 LeRobot과 같다: 관절마다 `id`, `drive_mode`, `homing_offset`, `range_min`, `range_max`.
- `get_observation()` / `send_action(np.ndarray 6개)`의 단순한 동기 인터페이스. **카메라는 없다**(`images`가 항상 `None`).
- 단위 `"degrees"`는 "보정 범위 중간 기준 각도"라고 설명되어 LeRobot의 도(degree)와 같아 보이지만, 숫자 일치는 [미확인].
- `physicalai run --config runtime.yaml` 명령으로 런타임을 실행한다. 문서의 예시는 양팔 텔레오퍼레이션 하나뿐이고, 일반 정책을 로봇에서 돌리는 완전한 예시는 찾지 못했다 [미확인].
- SO-101 URDF도 포함되어 있다(`get_urdf_path()`). 이 레포의 `config/urdf/so101/`는 공식 `SO-ARM100` 저장소(`a758567`)에서 따로 받은 것이다.

## 4. 질문별 답

### 질문 1. Studio로 학습한 정책을 파이썬 게임 코드에서 실행할 수 있는가 → **아마 가능, 완전한 예시는 없음**

- 가능한 이유: `SO101` 드라이버가 단순한 `get_observation`/`send_action`이라 우리 프로세스가 포트를 직접 열고 쓸 수 있다(포트 충돌 없음). 정책은 `InferenceModel`로 불러 실행한다.
- 우리가 직접 만들어야 하는 것: (a) 손목 카메라를 OpenCV로 읽기, (b) ACT 정책이 요구하는 입력 형식(이름, 정규화)으로 관측값 만들기, (c) 정책의 행동을 `Backend`로 보내기. 이 글루 코드는 `ActGrasper`에 들어간다.
- 확인 못 한 것: ACT 정책의 입력 형식, 추론 속도(시연 PC RTX 3050 6GB, 중계 LLM과 동시 사용).

### 질문 2. 보정이 LeRobot과 호환되는가 → **호환될 가능성이 높음**

- 플러그인이 LeRobot 보정 JSON을 직접 읽는다고 소스에 적혀 있고, 항목이 설치된 LeRobot의 `MotorCalibration`과 같다 [코드+문서].
- 따라서 한 도구로 보정한 파일을 `calibration_dir`에 두고 다른 도구가 읽게 할 수 있다.
- 남은 확인: 같은 자세에서 두 드라이버가 읽은 각도가 같은지, Studio 화면에서 만든 보정 파일이 이 JSON 형식인지.

## 5. 선택지와 영향

| 단계 | LeRobot만 | Studio 병행 | 영향 |
|---|---|---|---|
| 1~3 설정·슬롯·백엔드 | 이미 작성됨 | `Backend` 구현만 교체 | 작음 |
| 4 자세 측정·스크립트 집기 | `record_poses.py` | 보정 파일 공유 필요 | 보정 일치만 |
| 5 게임 연결 | 인터페이스로 연결 | 같음 | 없음 |
| 6 ACT | `lerobot-record`/`train`, LeRobot에서 실행 | 학습은 Studio, 실행은 `InferenceModel` + 글루 코드 | **큼** |

- **LeRobot만**: 보정·녹화·학습·실행이 한 도구. 이 레포 문서와 설치 스크립트가 이미 이 기준.
- **Studio 병행**: 화면에서 데이터를 보고 학습을 관리할 수 있고 OpenVINO로 내보낼 수 있다. 대신 손목 카메라와 정책 입력 형식을 우리가 직접 이어야 한다.

## 6. 6단계 전에 확인할 것 (미확인 항목)

1. 같은 자세에서 LeRobot과 플러그인 `SO101(unit="degrees")`가 읽은 값 비교.
2. Studio에서 만든 보정 파일이 LeRobot에서 `is_calibrated`가 되는지 (또는 반대).
3. Studio에서 내보낸 ACT 정책이 요구하는 관측 형식으로 우리 코드에서 추론 1회 실행.
4. 시연 PC(RTX 3050 6GB)에서 ACT 추론이 중계 모델과 함께 돌아가는지 (`docs/prep-notes.md`에 VRAM 경고 있음).
5. Windows에서 Studio를 쓸 수 있는지 (Docker + USB 장치 전달).

## 7. 기타 확인한 사실

- **FFmpeg**: LeRobot의 `torchcodec`이 동영상 녹화·학습 데이터 읽기에 FFmpeg DLL을 쓴다. 칸 이동(3~5단계)에는 필요 없고 ACT 녹화·학습(6단계)에 필요하다. 이 PC에는 FFmpeg 7.1이 설치되어 있다 [코드: `scripts\setup_env.ps1 -Robot` 점검 결과].
- **카메라 소유**: 손목 카메라는 로봇, 판 고정·트레이 카메라는 비전이 연다 (한 카메라는 한 프로그램만 열 수 있음). `docs/vision-yut-handoff.md` 2.2장.
- **URDF**: 칸 자세를 계산(IK)으로 구하고 싶을 때만 필요. 현재는 관절값 직접 측정 방식(`scripts/record_poses.py`)이라 쓰지 않는다. `config/urdf/so101/README.md` 참고.

## 8. 출처

- Physical AI Studio 저장소: https://github.com/open-edge-platform/physical-ai-studio
- physicalai-so101-plugin (PyPI): https://pypi.org/project/physicalai-so101-plugin/
- 플러그인 소스: https://github.com/openvinotoolkit/physicalai/tree/main/packages/physicalai-so101-plugin (`calibration.py`, `so101.py`)
- Intel Physical AI Studio 소개: https://lablab.ai/tech/intel/intel-physical-ai-studio
- LeRobot SO-101 문서: https://huggingface.co/docs/lerobot/en/so101
- SO-ARM100 (URDF 출처): https://github.com/TheRobotStudio/SO-ARM100
