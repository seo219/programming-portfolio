"""main.build_vision: 윷놀이만 윷 모델을 비전에 연결하는지 (카메라·모델 없이 확인)."""
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import main  # noqa: E402
import vision.yut_model as yut_model  # noqa: E402


def test_윷놀이는_분류기를_비전에_넘김(monkeypatch):
    class 가짜분류기:
        pass

    monkeypatch.setattr(yut_model, "ModelApiYutClassifier", 가짜분류기)
    vision = main.build_vision(yut=True)
    assert isinstance(vision.yut_classifier, 가짜분류기)


def test_주사위_골격은_모델을_불러오지_않음(monkeypatch):
    def 호출되면_안_됨():
        raise AssertionError("주사위 골격에서 윷 모델을 불러왔습니다")

    monkeypatch.setattr(yut_model, "ModelApiYutClassifier", 호출되면_안_됨)
    assert main.build_vision(yut=False).yut_classifier is None


def test_모델_폴더가_없으면_안내_후_종료(monkeypatch):
    def 없음():
        raise FileNotFoundError("윷 모델이 없습니다: x/model.xml")

    monkeypatch.setattr(yut_model, "ModelApiYutClassifier", 없음)
    with pytest.raises(SystemExit) as e:
        main.build_vision(yut=True)
    assert "models/yut" in str(e.value)
