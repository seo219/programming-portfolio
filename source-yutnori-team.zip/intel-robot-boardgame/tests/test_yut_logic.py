import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from common.interfaces import YutResult  # noqa: E402
from common.mock import yut_result  # noqa: E402
from vision.yut_logic import Detection, flats_from_detections, to_yut_result  # noqa: E402

BOARD = ROOT / "config" / "yut_board.json"
BOX = (0.0, 0.0, 10.0, 10.0)


def dets(*labels, score=0.9):
    return [Detection(label, score, BOX) for label in labels]


@pytest.mark.parametrize(
    "labels, expected",
    [
        (["down", "upper", "upper", "upper"], 1),  # 도
        (["down", "down", "upper", "upper"], 2),  # 개
        (["down", "down", "down", "upper"], 3),  # 걸
        (["down", "down", "down", "down"], 4),  # 윷
        (["upper", "upper", "upper", "upper"], 0),  # 모
        (["backdo", "upper", "upper", "upper"], -1),  # 빽도
    ],
)
def test_배_개수(labels, expected):
    assert flats_from_detections(dets(*labels)) == expected


def test_가락_수가_4개가_아니면_None():
    assert flats_from_detections(dets("down", "upper", "upper")) is None
    assert flats_from_detections(dets("down", "upper", "upper", "upper", "upper")) is None


def test_점수_낮은_검출이_빠져_3개가_되면_None():
    items = dets("down", "upper", "upper") + dets("upper", score=0.3)
    assert flats_from_detections(items) is None


def test_빽도_가락이_있어도_배가_2개_이상이면_개수():
    assert flats_from_detections(dets("down", "backdo", "upper", "upper")) == 2


def test_알_수_없는_label은_ValueError():
    with pytest.raises(ValueError):
        flats_from_detections(dets("down", "upper", "upper", "foo"))


@pytest.mark.parametrize("flats", [-1, 0, 1, 2, 3, 4])
def test_to_yut_result는_mock과_같다(flats):
    assert to_yut_result(flats, 1.0, BOARD) == yut_result(flats, 1.0)


def test_flats_None이면_인식_실패():
    assert to_yut_result(None, 0.4, BOARD) == YutResult(None, None, 0.4)


def test_표에_없는_flats는_ValueError():
    with pytest.raises(ValueError):
        to_yut_result(7, 1.0, BOARD)
