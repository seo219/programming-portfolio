"""scripts/try_read_yut.py의 정지 보정 지표 계산(frame_metrics) 시험. 카메라·모델은 쓰지 않는다."""
import sys
from pathlib import Path

import pytest

np = pytest.importorskip("numpy")
pytest.importorskip("cv2")  # 스크립트가 cv2를 import하므로 없으면 건너뜀

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

from try_read_yut import frame_metrics  # noqa: E402

BASE = np.zeros((360, 640), dtype=np.uint8)


def test_같은_프레임은_둘_다_0():
    assert frame_metrics(BASE, BASE.copy()) == (0.0, 0.0)


def test_작은_영역만_크게_바뀌면_평균차는_작고_변화비율은_기대값():
    cur = BASE.copy()
    cur[100:160, 100:200] = 200  # 100x60 영역(10배수 정렬)을 0 -> 200
    mean_diff, changed = frame_metrics(BASE, cur)
    # 64x36 축소: 10x6=60칸이 200 -> 200*60/2304
    assert mean_diff == pytest.approx(200 * 60 / 2304, abs=0.01)
    # 320x180 축소: 50x30=1500칸 / 57600칸
    assert changed == pytest.approx(1500 / 57600 * 100, abs=0.01)


def test_잡음_수준_변화는_변화비율_0():
    base = np.full((360, 640), 100, dtype=np.uint8)
    noisy = base + np.where(np.indices(base.shape).sum(axis=0) % 2 == 0, 10, 0).astype(np.uint8)
    mean_diff, changed = frame_metrics(base, noisy)
    assert changed == 0.0
    assert mean_diff == pytest.approx(5.0, abs=0.1)


def test_요약_문자열에_핵심_숫자가_들어감():
    from try_read_yut import build_summary
    # (평균차, 변화 %, 중복): 가만히 유효 0.2,0.4 / 굴림 유효 0.2,1.0,3.0 + 중복 1개
    rows = {"가만히": [(0.2, 0.1, False), (0.4, 0.3, False), (0.0, 0.0, True)],
            "굴림": [(0.2, 0.5, False), (1.0, 2.0, False), (3.0, 4.0, False)]}
    text = build_summary(rows, ["카메라 번호: 0"])
    assert "[가만히] 프레임 3개 (중복 1개 제외)" in text
    assert "최소 0.20 / 평균 0.30 / 최대 0.40" in text  # 가만히 평균차
    # 평균차: 가만히 최대 0.40, 굴림 최대 3.00, 중앙값 1.00, 0.4 초과 2/3 = 66.7%
    assert "평균차: 가만히 최대 0.40 vs 굴림 최대 3.00, 굴림 중앙값 1.00, 굴림 중 가만히 최대 초과 66.7%" in text
    # 변화픽셀: 가만히 최대 0.30%, 굴림 최대 4.00%, 중앙값 2.00%, 0.3 초과 3/3 = 100%
    assert "변화픽셀: 가만히 최대 0.30% vs 굴림 최대 4.00%, 굴림 중앙값 2.00%, 굴림 중 가만히 최대 초과 100.0%" in text
    assert "카메라 번호: 0" in text


def test_폰트가_없으면_ASCII_대체_문구():
    from try_read_yut import choose_text, find_font_path
    assert find_font_path(["/없는/폰트.ttf", "/없는/폰트2.ttf"]) is None
    assert choose_text("가만히 두세요", "Hold still", has_font=False) == "Hold still"
    # 대체 문구가 없으면 ASCII 글자만 남김
    assert choose_text("a 가", None, has_font=False) == "a"
    assert choose_text("가나다", None, has_font=False) == "-"
    assert choose_text("가만히", "Hold still", has_font=True) == "가만히"


def test_한글_문구가_실제로_그려짐():
    from try_read_yut import draw_texts, find_font_path
    if find_font_path() is None:
        pytest.skip("폰트 없음")
    image = np.zeros((100, 400, 3), dtype=np.uint8)
    draw_texts(image, [("가만히 두세요", "Hold still", 0, (0, 255, 255))])
    assert (image != 0).any()
    assert not (image[:, :, 0] != 0).any()  # BGR 노랑(0,255,255): 파랑 채널은 비어 있어야 함


def test_시험_요약_정답률과_평균():
    from try_read_yut import build_trial_summary
    def row(name, flats, conf, el, verdict):
        return {"name": name, "flats": flats, "confidence": conf, "elapsed_sec": el, "verdict": verdict}
    rows = [row("개", 2, "0.9", "1.0", "ok"), row("개", 2, "0.6", "2.0", "wrong"),
            row("걸", 3, "0.5", "3.0", ""), row("실패", "", "0.0", "2.0", "")]
    text = build_trial_summary(rows, ["카메라 번호: 0"])
    assert "총 시도 4회 / 맞음(o) 1 / 틀림(x) 1 / 미표시 2" in text
    assert "정답률 50.0%" in text  # 1/(1+1)
    assert "이름별 횟수: 개 2, 걸 1, 실패 1" in text
    assert "confidence 평균 0.50 / 최소 0.00" in text  # (0.9+0.6+0.5+0)/4
    assert "평균 걸린 시간 2.00초" in text  # (1+2+3+2)/4
    assert "인식 실패(None) 1회" in text
    assert "카메라 번호: 0" in text


def test_시험_요약_표시_없으면_정답률_대시():
    from try_read_yut import build_trial_summary
    text = build_trial_summary([{"name": "도", "flats": 1, "confidence": "1.0", "elapsed_sec": "0.5", "verdict": ""}], [])
    assert "정답률 - (o/x 표시 없음)" in text


def test_기록은_LOG_DIR_아래에_폴더_자동_생성(tmp_path, monkeypatch):
    import cv2
    import try_read_yut as t
    log_dir = tmp_path / "data" / "yut_logs"  # 아직 없는 폴더
    monkeypatch.setattr(t, "LOG_DIR", log_dir)
    monkeypatch.setattr(t, "CALIB_PHASE_SECONDS", 0.05)
    monkeypatch.setattr(t, "CALIB_READY_SECONDS", 0.0)
    monkeypatch.setattr(cv2, "imshow", lambda *a: None)
    monkeypatch.setattr(cv2, "waitKey", lambda *a: 0)

    class FakeDetector:
        camera_index = 0

        def _grab(self):
            return np.zeros((360, 640, 3), dtype=np.uint8)

    t.calibrate(FakeDetector())
    assert log_dir.is_dir()
    assert len(list(log_dir.glob("yut_calib_*.csv"))) == 1
    assert len(list(log_dir.glob("yut_calib_*.txt"))) == 1


def test_시험_요약에_정지_대기_통계():
    from try_read_yut import build_trial_summary
    def row(wait, ok, mx):
        return {"name": "도", "flats": 1, "confidence": "1.0", "elapsed_sec": "1.0", "verdict": "",
                "wait_sec": wait, "still_ok": ok, "wait_max_diff": mx}
    rows = [row("0.500", 1, "0.60"), row("3.000", 0, "5.00"), row("2.500", 0, "3.00"), row("0.000", 1, "0.00")]
    text = build_trial_summary(rows, [])
    assert "정지 대기 평균 1.50초 / 타임아웃 2회 (50%)" in text  # (0.5+3+2.5+0)/4, 2/4
    assert "대기 중 최대 diff 평균 2.15 / 최대 5.00" in text  # (0.6+5+3+0)/4


def test_record_trial이_대기_진단_열과_wait_csv를_씀(tmp_path):
    import csv
    from types import SimpleNamespace
    import try_read_yut as t

    class Cls:
        def detect(self, frame):
            return []

    class Det:
        yut_classifier = Cls()
        last_still_info = SimpleNamespace(waited_sec=2.4, still=False, frames=3, max_diff=5.0, last_diff=0.9,
                                          diffs=[5.0, 3.0, 0.9])

        def read_yut(self):
            return SimpleNamespace(flats=2, value=2, confidence=0.5)

        def _grab(self):
            return np.zeros((36, 64, 3), dtype=np.uint8)

    rows, session = [], tmp_path / "yut_try_x"
    t.record_trial(Det(), rows, session, tmp_path / "yut_try_x.csv")
    with (tmp_path / "yut_try_x.csv").open(encoding="utf-8") as f:
        r = next(csv.DictReader(f))
    assert (r["wait_sec"], r["still_ok"], r["wait_frames"], r["wait_max_diff"], r["wait_last_diff"]) == \
        ("2.400", "0", "3", "5.000", "0.900")
    with (session / "001_wait.csv").open(encoding="utf-8") as f:
        assert list(csv.reader(f)) == [["idx", "diff"], ["0", "5.0"], ["1", "3.0"], ["2", "0.9"]]
