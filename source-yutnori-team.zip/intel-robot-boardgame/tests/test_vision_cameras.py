"""트레이·판 카메라 번호별 캡처 관리 테스트 (가짜 VideoCapture, 실제 카메라 사용 안 함)."""
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vision import detector as det  # noqa: E402
from vision.detector import VisionDetector, open_camera  # noqa: E402

SLOTS = ROOT / "config" / "slots.json"


class FakeCap:
    instances: list = []
    opened_ok = True
    fail_reads = 0  # 앞으로 read()가 실패할 횟수 (클래스 전체 공유)

    def __init__(self, index):
        self.index = index
        self.released = 0
        self.sets = []
        FakeCap.instances.append(self)

    def isOpened(self):
        return FakeCap.opened_ok

    def set(self, prop, value):
        self.sets.append((prop, value))

    def read(self):
        if FakeCap.fail_reads > 0:
            FakeCap.fail_reads -= 1
            return False, None
        return True, np.full((2, 2, 3), self.index, dtype=np.uint8)

    def release(self):
        self.released += 1


@pytest.fixture(autouse=True)
def fake_cv(monkeypatch):
    FakeCap.instances = []
    FakeCap.opened_ok = True
    FakeCap.fail_reads = 0
    monkeypatch.setattr(det.cv2, "VideoCapture", FakeCap)
    monkeypatch.setattr(det, "WARMUP_FRAMES", 0)


def opened():
    return [c.index for c in FakeCap.instances]


def value(frame):
    return int(frame[0, 0, 0])


def test_다른_번호면_번호별로_캡처를_연다():
    d = VisionDetector(SLOTS, camera_index=1, board_camera_index=2)
    assert opened() == []
    assert value(d._grab("tray")) == 1
    assert value(d._grab()) == 1
    assert opened() == [1]  # 트레이만 쓰면 판 카메라는 열지 않음
    assert value(d._grab("board")) == 2
    assert value(d._grab("board")) == 2
    assert opened() == [1, 2]


@pytest.mark.parametrize("board_index", [None, 1])
def test_판_번호가_없거나_같으면_캡처를_공유한다(board_index):
    d = VisionDetector(SLOTS, camera_index=1, board_camera_index=board_index)
    assert value(d._grab("tray")) == 1
    assert value(d._grab("board")) == 1
    assert opened() == [1]


def test_판_프레임_소스가_우선이고_트레이_소스와_독립():
    tray, board = np.zeros((2, 2, 3), np.uint8), np.ones((2, 2, 3), np.uint8)
    d = VisionDetector(SLOTS, frame_source=lambda: tray, board_frame_source=lambda: board)
    assert d._grab("tray") is tray
    assert d._grab("board") is board
    assert opened() == []


def test_판_소스가_없고_단일_구성이면_frame_source_공유():
    tray = np.zeros((2, 2, 3), np.uint8)
    d = VisionDetector(SLOTS, frame_source=lambda: tray)
    assert d._grab("board") is tray
    assert opened() == []


def test_판_소스만_있어도_트레이는_카메라를_쓴다():
    board = np.ones((2, 2, 3), np.uint8)
    d = VisionDetector(SLOTS, camera_index=3, board_frame_source=lambda: board)
    assert d._grab("board") is board
    assert opened() == []
    assert value(d._grab("tray")) == 3
    assert opened() == [3]


def test_다른_번호_구성에서_트레이_소스는_판에_쓰이지_않는다():
    tray = np.zeros((2, 2, 3), np.uint8)
    d = VisionDetector(SLOTS, camera_index=1, board_camera_index=2, frame_source=lambda: tray)
    assert d._grab("tray") is tray
    assert value(d._grab("board")) == 2
    assert opened() == [2]


def test_close는_모두_release하고_두_번_불러도_안전하며_다시_연다():
    d = VisionDetector(SLOTS, camera_index=1, board_camera_index=2)
    d._grab("tray")
    d._grab("board")
    d.close()
    d.close()
    assert [c.released for c in FakeCap.instances] == [1, 1]
    d._grab("tray")
    assert opened() == [1, 2, 1]


def test_read_실패시_예외와_release_후_다음_호출에서_재오픈():
    d = VisionDetector(SLOTS, camera_index=1, board_camera_index=2)
    d._grab("board")
    FakeCap.fail_reads = 1
    with pytest.raises(RuntimeError, match="2번"):
        d._grab("board")
    assert FakeCap.instances[0].released == 1
    assert value(d._grab("board")) == 2
    assert opened() == [2, 2]


def test_열지_못하면_한국어_예외와_release():
    FakeCap.opened_ok = False
    with pytest.raises(RuntimeError, match="카메라 5번을 열지 못했습니다"):
        open_camera(5)
    assert FakeCap.instances[0].released == 1
    d = VisionDetector(SLOTS, camera_index=7)
    with pytest.raises(RuntimeError, match="7번"):
        d._grab()
    assert d._caps == {}


def test_잘못된_camera_이름():
    d = VisionDetector(SLOTS, frame_source=lambda: np.zeros((2, 2, 3), np.uint8))
    with pytest.raises(ValueError):
        d._grab("side")


def test_기존_시그니처_호환():
    d = VisionDetector(SLOTS)
    assert d.camera_index == 0 and d.board_camera_index is None
    assert value(d._grab()) == 0
    classifier = object()
    d2 = VisionDetector(SLOTS, 4, lambda: np.zeros((2, 2, 3), np.uint8), classifier, ROOT / "config" / "yut_board.json")
    assert d2.camera_index == 4 and d2.yut_classifier is classifier
