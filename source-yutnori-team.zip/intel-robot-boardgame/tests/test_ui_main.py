"""main.py --ui 연결 확인 (헤드리스). --ui가 없으면 기존 ConsoleScreen 그대로입니다."""
import os
import sys
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import pytest  # noqa: E402

import main  # noqa: E402
from common.interfaces import YutState  # noqa: E402
from common.mock import ConsoleScreen  # noqa: E402


def test_build_screen_default_is_console():
    assert isinstance(main.build_screen(False), ConsoleScreen)
    assert isinstance(main.build_yut(True).screen, ConsoleScreen)


def test_build_screen_ui_is_game_screen():
    from ui.screen import GameScreen

    screen = main.build_screen(True)
    try:
        assert isinstance(screen, GameScreen)
        screen.update(YutState(pieces={"robot": ["wait_robot"] * 2, "human": ["wait_human"] * 2}), "시작")
    finally:
        screen.close()


def test_ui_without_display_gives_readable_error(monkeypatch):
    import pygame
    import ui.screen as ui_screen

    def boom(*a, **k):
        raise pygame.error("no display")

    monkeypatch.setattr(pygame.display, "set_mode", boom)
    with pytest.raises(SystemExit) as e:
        main.build_screen(True)
    assert "--ui 실행 실패" in str(e.value)
    assert ui_screen.UiError.__name__ == "UiError"
