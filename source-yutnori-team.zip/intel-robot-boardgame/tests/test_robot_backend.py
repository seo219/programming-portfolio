"""LeRobot 백엔드(도착 대기 루프)와 poses.json 저장 테스트. 가짜 로봇을 써서 lerobot·하드웨어 없이 실행합니다."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from robot.backend import BackendError  # noqa: E402
from robot.backend_lerobot import ARM, LeRobotBackend  # noqa: E402
from robot.config import load_poses, update_pose_file  # noqa: E402


class FakeRobot:
    """목표를 받으면 그대로 따라가는 가짜 SO101. stuck이면 움직이지 않음."""

    def __init__(self, start=(0.0,) * 5, stuck=False, fail_send=False):
        self.pos = dict(zip(ARM, start))
        self.pos["gripper"] = 50.0
        self.stuck, self.fail_send = stuck, fail_send
        self.sent = []
        self.disconnected = False

    def get_observation(self):
        return {f"{k}.pos": v for k, v in self.pos.items()}

    def send_action(self, action):
        if self.fail_send:
            raise RuntimeError("통신 끊김")
        self.sent.append(dict(action))
        if not self.stuck:
            for k, v in action.items():
                self.pos[k.removesuffix(".pos")] = v

    def disconnect(self):
        self.disconnected = True


class Clock:
    def __init__(self):
        self.t = 0.0

    def sleep(self, s):
        self.t += s

    def now(self):
        return self.t


def backend(robot, **kw):
    c = Clock()
    return LeRobotBackend(robot, sleep=c.sleep, clock=c.now, **kw), c


def test_move_to_reaches_goal_with_speed_limited_steps():
    r = FakeRobot()
    b, clock = backend(r, rate_hz=10.0)
    b.move_to((30.0, 0.0, 0.0, 0.0, 0.0), speed=10.0)  # 30도를 10도/초 → 3초 = 30스텝
    assert abs(r.pos["shoulder_pan"] - 30.0) < 1e-6
    assert len(r.sent) >= 30
    deltas = [r.sent[i]["shoulder_pan.pos"] - (r.sent[i - 1]["shoulder_pan.pos"] if i else 0.0) for i in range(30)]
    assert max(deltas) <= 1.0 + 1e-6  # 스텝마다 10도/초 / 10Hz = 1도 이하
    assert 2.9 <= clock.t <= 3.5


def test_move_to_times_out_when_robot_stuck():
    r = FakeRobot(stuck=True)
    b, _ = backend(r, timeout_s=1.0)
    with pytest.raises(BackendError, match="도달하지 못했습니다"):
        b.move_to((20.0, 0.0, 0.0, 0.0, 0.0))


def test_communication_error_becomes_backend_error():
    b, _ = backend(FakeRobot(fail_send=True))
    with pytest.raises(BackendError):
        b.move_to((10.0, 0.0, 0.0, 0.0, 0.0))
    with pytest.raises(BackendError):
        b.set_gripper(10.0)


def test_gripper_sent_without_waiting_for_arrival():
    r = FakeRobot(stuck=True)  # 말을 잡아서 안 닫히는 상황
    b, clock = backend(r, gripper_settle_s=0.5)
    b.set_gripper(10.0)
    assert r.sent == [{"gripper.pos": 10.0}] and clock.t == pytest.approx(0.5)


@pytest.mark.parametrize("bad", [-1.0, 101.0])
def test_gripper_range_checked(bad):
    b, _ = backend(FakeRobot())
    with pytest.raises(ValueError):
        b.set_gripper(bad)


def test_move_to_needs_five_joints():
    b, _ = backend(FakeRobot())
    with pytest.raises(ValueError):
        b.move_to((1.0, 2.0, 3.0))


def test_disconnect():
    r = FakeRobot()
    backend(r)[0].disconnect()
    assert r.disconnected


# ---- update_pose_file ----

J = [1.5, 2.5, 3.5, 4.5, 5.5, 6.5]


def poses_file(tmp_path):
    p = tmp_path / "poses.json"
    p.write_text(json.dumps({"_comment": "설명", "home": None, "cell_0": None, "cell_1": None}), encoding="utf-8")
    return p


def test_update_pose_file_saves_above_then_grasp(tmp_path):
    p = poses_file(tmp_path)
    update_pose_file(p, "cell_0", "above", J, {"follower_id": "f"})
    update_pose_file(p, "cell_0", "grasp", [9, 8, 7, 6, 5, 4])
    raw = json.loads(p.read_text(encoding="utf-8"))
    assert raw["_comment"] == "설명" and raw["_calibration"] == {"follower_id": "f"}
    assert raw["cell_0"] == {"above": J, "grasp": [9, 8, 7, 6, 5, 4]}
    assert raw["cell_1"] is None
    poses = load_poses(p)
    assert poses["cell_0"].above == tuple(J) and poses["cell_0"].grasp == (9.0, 8.0, 7.0, 6.0, 5.0, 4.0)


def test_update_pose_file_home_is_plain_list(tmp_path):
    p = poses_file(tmp_path)
    update_pose_file(p, "home", "above", J)
    assert json.loads(p.read_text(encoding="utf-8"))["home"] == J
    with pytest.raises(ValueError):
        update_pose_file(p, "home", "grasp", J)


def test_update_pose_file_rejects_bad_input(tmp_path):
    p = poses_file(tmp_path)
    before = p.read_text(encoding="utf-8")
    for args in [("cell_0", "above", [0] * 6), ("cell_0", "above", [1, 2]), ("cell_0", "middle", J)]:
        with pytest.raises(ValueError):
            update_pose_file(p, *args)
    with pytest.raises(KeyError):
        update_pose_file(p, "cell_99", "above", J)
    assert p.read_text(encoding="utf-8") == before  # 실패하면 파일은 그대로
