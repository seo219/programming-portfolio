"""중계 상황(판세·위기·로봇의 생각·역전) 테스트. Ollama 없이 가짜 클라이언트로 확인합니다."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from common.interfaces import Event  # noqa: E402
from common.mock import ConsoleScreen, MockNarrator, MockStore, ScriptedRobot, ScriptedVision  # noqa: E402
from game.wrapper import DeviceWrapper  # noqa: E402
from game.yut_orchestrator import YutOrchestrator  # noqa: E402
from game.yut_reference import YutBoard  # noqa: E402
from llm.narrator import OllamaNarrator  # noqa: E402
from llm.situation import Situation, danger, standing  # noqa: E402

BOARD = YutBoard(ROOT / "config" / "yut_board.json")
HUMAN_MOVE = Event(5, "human", "move", {"piece": 1, "yut": "걸", "from": "wait", "to": "cell_3", "stacked": 1})
ROBOT_MOVE = Event(6, "robot", "move", {"piece": 1, "yut": "도", "from": "cell_9", "to": "cell_10", "stacked": 1})
HUMAN_FINISH = Event(9, "human", "finish", {"pieces": 1, "left": 1})


class RecordingClient:
    def __init__(self, reply: str = "", fail: bool = False):
        self.reply, self.fail = reply, fail
        self.prompts: list[str] = []

    def generate(self, **kwargs):
        return {}

    def chat(self, **kwargs):
        self.prompts.append(kwargs["messages"][-1]["content"])
        if self.fail:
            raise ConnectionError("ollama 꺼짐")
        return {"message": {"content": self.reply}}


def narrator(reply: str = "", fail: bool = False) -> tuple[OllamaNarrator, RecordingClient]:
    client = RecordingClient(reply, fail)
    return OllamaNarrator(client=client, warmup=False, board=BOARD), client


# ---- 계산 ----

def test_standing_counts_finished_and_remaining():
    s = standing(BOARD, {"human": ["goal", "wait"], "robot": ["cell_1", "wait"]})
    assert s["human"]["finished"] == 1 and s["robot"]["finished"] == 0
    assert s["human"]["remaining"] == BOARD.distance("wait")
    assert s["robot"]["remaining"] == BOARD.distance("cell_1") + BOARD.distance("wait")


def test_danger_lists_yut_that_captures():
    # 사람 말 cell_3: 로봇은 cell_1에서 개, 대기에서 걸이면 잡음
    pieces = {"human": ["cell_3", "wait"], "robot": ["cell_1", "wait"]}
    assert danger(BOARD, pieces, "human") == ["개", "걸"]


def test_danger_does_not_change_pieces():
    pieces = {"human": ["cell_3", "wait"], "robot": ["cell_1", "wait"]}
    danger(BOARD, pieces, "human")
    assert pieces == {"human": ["cell_3", "wait"], "robot": ["cell_1", "wait"]}


def test_no_danger_when_out_of_reach():
    assert danger(BOARD, {"human": ["wait", "wait"], "robot": ["cell_10", "wait"]}, "robot") == []


# ---- 상황 고르기 ----

def test_robot_reason_when_safe():
    note = Situation(BOARD).note(ROBOT_MOVE, {"pieces": {"human": ["wait", "wait"], "robot": ["cell_10", "wait"]},
                                              "reason": "advance"})
    assert note.kind == "reason" and "완주에 가장 가까운 말이라서" in note.text


def test_danger_comes_before_reason():
    s = Situation(BOARD)
    note = s.note(HUMAN_MOVE, {"pieces": {"human": ["cell_3", "wait"], "robot": ["cell_1", "wait"]}})
    assert note.kind == "danger" and "'개'·'걸'" in note.facts


def test_danger_with_one_yut_reads_naturally():
    note = Situation(BOARD).note(HUMAN_MOVE, {"pieces": {"human": ["cell_3", "wait"], "robot": ["cell_2", "goal"]}})
    assert note.kind == "danger" and "'도'만 던져도" in note.facts and "중 하나" not in note.facts


def test_same_kind_not_repeated_in_a_row():
    s = Situation(BOARD)
    ctx = {"pieces": {"human": ["cell_3", "wait"], "robot": ["cell_1", "wait"]}}
    assert s.note(HUMAN_MOVE, ctx).kind == "danger"
    assert s.note(HUMAN_MOVE, ctx) is None  # 바로 다음에는 같은 위기를 다시 말하지 않음
    assert s.note(HUMAN_MOVE, ctx).kind == "danger"


def test_lead_change_after_big_gap():
    s = Situation(BOARD)
    s.note(ROBOT_MOVE, {"pieces": {"human": ["wait", "wait"], "robot": ["cell_10", "wait"]}, "reason": "advance"})
    after = {"human": ["cell_17", "wait"], "robot": ["cell_10", "wait"]}
    st = standing(BOARD, after)
    gap = st["robot"]["remaining"] - st["human"]["remaining"]
    assert gap > 0  # 사람이 앞섬
    note = s.note(Event(7, "human", "move", {}), {"pieces": after})
    assert note.kind == "lead_change" and f"{gap}칸" in note.text


def test_small_swing_is_not_lead_change():
    s = Situation(BOARD)
    s.note(ROBOT_MOVE, {"pieces": {"human": ["wait", "wait"], "robot": ["cell_1", "wait"]}})  # 로봇 1칸 앞
    note = s.note(Event(7, "human", "move", {}), {"pieces": {"human": ["cell_2", "wait"], "robot": ["cell_1", "wait"]}})
    assert note is None or note.kind != "lead_change"


def test_no_note_without_context_or_for_win():
    s = Situation(BOARD)
    assert s.note(HUMAN_MOVE, None) is None
    win = Event(20, "human", "win", {"turns": 20})
    assert s.note(win, {"pieces": {"human": ["goal", "goal"], "robot": ["cell_1", "wait"]}}) is None


# ---- 중계기 ----

def test_prompt_includes_situation():
    n, client = narrator("걸! 그런데 로봇이 개만 나와도 잡혀요!")
    n.narrate(HUMAN_MOVE, {"pieces": {"human": ["cell_3", "wait"], "robot": ["cell_1", "wait"]}})
    assert "[상황] 위기" in client.prompts[-1] and n.last_source == "llm"


def test_template_fallback_appends_situation():
    n, _ = narrator(fail=True)
    text = n.narrate(HUMAN_MOVE, {"pieces": {"human": ["cell_3", "wait"], "robot": ["cell_1", "wait"]}})
    assert n.last_source == "template" and text.endswith("그런데 로봇이 개만 나와도 사람 말이 잡혀요!")


def test_situation_numbers_are_allowed():
    pieces = {"human": ["goal", "wait"], "robot": ["cell_10", "wait"]}
    st = standing(BOARD, pieces)
    gap = abs(st["robot"]["remaining"] - st["human"]["remaining"])
    reply = f"사람 말 완주! 이제 {gap}칸 차이입니다!"
    n, _ = narrator(reply)
    assert n.narrate(HUMAN_FINISH, {"pieces": pieces}) == reply  # 판세 숫자는 상황에서 왔으므로 통과
    n2, _ = narrator(reply)
    assert n2.narrate(HUMAN_FINISH) != reply  # context가 없으면 지어낸 숫자로 보고 템플릿 사용


def test_narrate_without_context_still_works():
    n, client = narrator("사람, 걸로 3번 칸에 섭니다!")
    assert n.narrate(HUMAN_MOVE) == "사람, 걸로 3번 칸에 섭니다!"
    assert "[상황]" not in client.prompts[-1]


SAFE_ROBOT = {"pieces": {"human": ["wait", "wait"], "robot": ["cell_10", "wait"]}, "reason": "advance"}


def test_robot_thought_is_appended_by_code():
    n, client = narrator("도! 로봇이 10번 칸에 섭니다! 이제 달립니다!")
    text = n.narrate(ROBOT_MOVE, SAFE_ROBOT)
    assert n.last_source == "llm"
    assert text == "도! 로봇이 10번 칸에 섭니다! 이제 달립니다! 로봇: 저는 완주에 가장 가까운 말이라서 이 말을 골랐어요!"
    assert "속마음" not in client.prompts[-1]  # LLM은 장면만


def test_first_person_from_llm_falls_back():
    n, _ = narrator("사람이 2턴 만에 승리! 저는 이 순간을 기다렸어요.")
    n.narrate(Event(2, "human", "win", {"turns": 2}), {"pieces": {"human": ["goal", "goal"], "robot": ["wait", "wait"]}})
    assert n.last_source == "template"  # 속마음을 주지 않았는데 '저는'이면 누구 말인지 모호


def test_warmup_uses_longer_timeout(monkeypatch):
    import llm.narrator as mod
    made = []
    monkeypatch.setattr(mod, "_make_client", lambda host, timeout: made.append(timeout) or RecordingClient())
    OllamaNarrator(warmup=False, board=BOARD)
    assert made == [mod.TIMEOUT, mod.WARMUP_TIMEOUT]  # 중계는 8초, 모델 올리기는 더 기다림


# ---- 오케스트레이터 연결 ----

def test_orchestrator_passes_pieces_copy_and_robot_reason():
    log: list[str] = []
    screen = ConsoleScreen(choices=[], quiet=True)
    dev = DeviceWrapper(ScriptedVision([], log=log), ScriptedRobot(log=log), screen, ask_flats=lambda: 1)
    narr = MockNarrator()
    ai = [2, 1]  # 개로 잡고, 한 번 더 던져 도
    orch = YutOrchestrator(BOARD, dev, narr, MockStore(), screen, ai_throw=lambda: ai.pop(0) if ai else 1,
                           verify_moves=False)
    orch.game.pieces["robot"][0] = "cell_2"
    orch.game.pieces["human"][0] = "cell_4"
    orch.state.current = "robot"
    orch.play_turn()

    contexts = [c for c in narr.contexts if c]
    assert contexts[0]["reason"] == "capture"
    assert contexts[0]["pieces"]["human"][0] == "wait"  # 잡힌 뒤의 판
    contexts[0]["pieces"]["robot"][0] = "goal"
    assert orch.game.pieces["robot"][0] != "goal"  # 복사본이라 게임 상태는 그대로
