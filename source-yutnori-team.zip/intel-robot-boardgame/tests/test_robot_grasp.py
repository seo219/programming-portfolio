"""집기 확인(허공 잡기 방지), 팩토리, 슬롯 이름 대응 테스트. 하드웨어 없이 FakeBackend로 실행합니다."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from robot.backend import BackendError  # noqa: E402
from robot.backend_lerobot import LeRobotBackend  # noqa: E402
from robot.config import ConfigNotSet, RobotSettings, SlotPose, load_poses, load_settings  # noqa: E402
from robot.controller import RobotController  # noqa: E402
from robot.factory import build_controller  # noqa: E402
from robot.fake_backend import FakeBackend  # noqa: E402
from robot.grasp import ScriptGrasper  # noqa: E402
from robot.slots import SLOT_ALIASES, SlotTracker, canonical_slot  # noqa: E402

POSE = SlotPose(above=(0, 10, 0, 0, 0, 0), grasp=(0, 30, 0, 0, 0, 0))
# 0 닫힘 ~ 100 열림. 말 폭에서 멈추는 값 40, 기준 holding_min 30, 닫으라는 값 10
S = RobotSettings(gripper_open=100.0, gripper_close=10.0, gripper_holding_min=30.0, approach=0.5)


def pick(backend, settings=S):
    ScriptGrasper(settings).pick(backend, POSE, 0, 1.0)


# ---- 집기 확인 ----

def test_pick_ok_when_piece_holds_gripper_open():
    b = FakeBackend(holding_at=40.0)  # 말 폭에서 멈춤 → 40 >= 30
    pick(b)
    assert b.calls[-1][0] == "move_to"  # 확인을 통과해 들어올림까지 감


def test_pick_fails_when_gripper_closes_fully_on_air():
    b = FakeBackend()  # 허공: 10까지 닫힘 → 10 < 30
    with pytest.raises(BackendError, match="말을 잡지 못했습니다"):
        pick(b)
    assert not any(c[0] == "move_to" and c[1] == (0, 10, 0, 0, 0) for c in b.calls)  # 들어올리지 않음


@pytest.mark.parametrize("reading,ok", [(30.0, True), (29.9, False)])
def test_direction_larger_is_more_open_and_boundary(reading, ok):
    """값이 클수록 열림: holding_min과 같으면 잡은 것, 그보다 작으면 허공."""
    b = FakeBackend(holding_at=reading)
    b.set_gripper = lambda v, _b=b: setattr(_b, "_gripper", reading)  # 읽는 값을 정확히 고정
    if ok:
        pick(b)
    else:
        with pytest.raises(BackendError):
            pick(b)


def test_check_skipped_when_holding_min_is_none():
    pick(FakeBackend(), RobotSettings(gripper_open=100.0, gripper_close=10.0))  # 허공이어도 확인 안 함


def test_check_skipped_when_backend_has_no_gripper_position():
    class Plain:
        def move_to(self, joints, speed=None): pass
        def set_gripper(self, value): pass

    pick(Plain())  # gripper_position이 없으면 건너뜀 (예외 없음)


def test_controller_move_returns_false_on_air_grasp_and_keeps_counts(tmp_path):
    poses = tmp_path / "poses.json"
    poses.write_text(json.dumps({"home": [1] * 6, "cell_3": {"above": [1, 10, 0, 0, 0, 0], "grasp": [1, 30, 0, 0, 0, 0]},
                                 "cell_5": {"above": [2, 10, 0, 0, 0, 0], "grasp": [2, 30, 0, 0, 0, 0]}}), encoding="utf-8")
    t = SlotTracker({"cell_3": 1})
    c = RobotController(poses, FakeBackend(), S, t)  # 허공
    assert c.move("cell_3", "cell_5") is False
    assert t.snapshot() == {"cell_3": 1}
    c = RobotController(poses, FakeBackend(holding_at=40.0), S, t)
    assert c.move("cell_3", "cell_5") is True and t.snapshot() == {"cell_5": 1}


def test_lerobot_backend_gripper_position():
    class R:
        def get_observation(self):
            return {"gripper.pos": 42.5}

    assert LeRobotBackend(R()).gripper_position() == 42.5

    class Broken:
        def get_observation(self):
            raise RuntimeError("끊김")

    with pytest.raises(BackendError):
        LeRobotBackend(Broken()).gripper_position()


def test_load_settings_holding_min(tmp_path):
    def cfg(**g):
        p = tmp_path / "robot.json"
        p.write_text(json.dumps({"gripper": g}), encoding="utf-8")
        return load_settings(p)

    assert cfg(open=100, close=10, holding_min=30).gripper_holding_min == 30
    assert cfg().gripper_holding_min is None
    with pytest.raises(ValueError):
        cfg(open=100, close=10, holding_min=10)  # close 이하
    with pytest.raises(ValueError):
        cfg(open=100, close=10, holding_min=100)  # open 이상


def test_repo_robot_json_has_holding_min_null():
    assert load_settings(ROOT / "config" / "robot.json").gripper_holding_min is None


# ---- 팩토리 ----

def test_factory_builds_controller_with_injected_backend():
    seen = {}
    fake = FakeBackend()

    def make(cfg):
        seen["cfg"] = cfg
        return fake

    ctl = build_controller(ROOT, backend_factory=make)
    assert ctl.backend is fake and "follower" in seen["cfg"]
    assert ctl.settings == load_settings(ROOT / "config" / "robot.json")


def test_factory_without_port_raises_config_not_set_before_importing_lerobot():
    with pytest.raises(ConfigNotSet, match="follower.port"):
        build_controller(ROOT)  # robot.json의 port가 null


# ---- 슬롯 이름 대응 ----

def test_alias_table_matches_game_and_poses():
    """게임 칸 이름(yut_board.json layout)이 모두 poses.json에 있는 이름으로 바뀌는지."""
    layout = {k for k in json.loads((ROOT / "config" / "yut_board.json").read_text(encoding="utf-8"))["layout"] if not k.startswith("_")}
    raw = json.loads((ROOT / "config" / "poses.json").read_text(encoding="utf-8"))
    assert {canonical_slot(k) for k in layout} <= set(raw)
    assert len({canonical_slot(k) for k in layout}) == len(layout) == 29  # 일대일
    assert set(SLOT_ALIASES) <= layout


def test_tracker_treats_game_and_pose_names_alike():
    t = SlotTracker({"diag_r1": 1})
    assert t.count("cell_20") == 1 and t.snapshot() == {"cell_20": 1}
    t.apply("cell_20", "center", 1)
    assert t.snapshot() == {"cell_22": 1}
    t.sync({"diag_l3": 1, "cell_27": 1})
    assert t.snapshot() == {"cell_27": 2}
