"""board_state() 테스트: 합성 프레임(칸 29개 격자 + 색 원)으로 프레임 비우기·칸별 다수결·region을 확인한다."""
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from vision.board_cells import board_cell_names  # noqa: E402
from vision.board_pieces import MIN_BLOB_AREA  # noqa: E402
from vision.detector import BOARD_FLUSH_FRAMES, FRAMES, VisionDetector  # noqa: E402

RED = (0, 0, 220)    # BGR
BLUE = (220, 0, 0)
R = 28               # 말 반지름: 면적 약 2463px > MIN_BLOB_AREA
assert np.pi * R * R > MIN_BLOB_AREA

NAMES = board_cell_names()
# 8열 격자, 간격 110px. 프레임은 1280x720
POS = {n: (100 + 110 * (i % 8), 100 + 110 * (i // 8)) for i, n in enumerate(NAMES)}
OUTSIDE = (1150, 600)  # 판 바깥


def write_cells(tmp_path: Path) -> Path:
    path = tmp_path / "board_cells.json"
    cells = {n: {"x": x, "y": y, "roi_r": 40} for n, (x, y) in POS.items()}
    path.write_text(json.dumps({"cells": cells}), encoding="utf-8")
    return path


def frame(pieces=None, extra=()):
    """pieces: {칸 이름: 색}. extra: [(x, y, 색)] 임의 위치 원."""
    img = np.full((720, 1280, 3), 128, np.uint8)
    for name, color in (pieces or {}).items():
        cv2.circle(img, POS[name], R, color, -1)
    for x, y, color in extra:
        cv2.circle(img, (x, y), R, color, -1)
    return img


def sequence(frames):
    it = iter(frames)
    return lambda: next(it)


def detector(tmp_path, source, **kw):
    slots = tmp_path / "slots.json"
    slots.write_text(json.dumps({"tray": [0, 0, 10, 10]}), encoding="utf-8")
    return VisionDetector(slots, board_frame_source=source, board_cells_path=write_cells(tmp_path), **kw)


def expected(pieces):
    return {n: pieces.get(n) for n in NAMES}


def test_빈_판은_29키_모두_None(tmp_path):
    state = detector(tmp_path, lambda: frame()).board_state()
    assert len(state) == 29
    assert state == expected({})


def test_말이_정확한_칸에_배정된다(tmp_path):
    f = frame({"diag_r1": RED, "cell_7": BLUE})
    d = detector(tmp_path, lambda: f)
    assert d.board_state() == expected({"diag_r1": "robot", "cell_7": "human"})
    assert d.last_board_issues == []


def test_오래된_프레임은_버리고_새_프레임만_읽는다(tmp_path):
    old, new = frame({"cell_3": RED}), frame({"cell_5": RED})
    # flush가 없으면 앞쪽 옛 프레임이 다수결에 섞여 cell_3이 남는 구성 (FRAMES장 중 옛 프레임이 다수)
    d = detector(tmp_path, sequence([old] * BOARD_FLUSH_FRAMES + [new] * FRAMES))
    assert d.board_state() == expected({"cell_5": "robot"})


def test_한_프레임에만_나타난_가짜_덩어리는_무시한다(tmp_path):
    clean = frame({"cell_2": BLUE})
    noisy = frame({"cell_2": BLUE}, extra=[(*POS["cell_9"], RED)])
    d = detector(tmp_path, sequence([clean] * BOARD_FLUSH_FRAMES + [noisy] + [clean] * (FRAMES - 1)))
    assert d.board_state() == expected({"cell_2": "human"})
    assert d.last_board_issues == []


def test_반반_흔들리는_칸은_None과_불안정_기록(tmp_path):
    a, b = frame({"cell_4": RED}), frame()
    d = detector(tmp_path, sequence([b] * BOARD_FLUSH_FRAMES + [a, b] * (FRAMES // 2)))
    assert d.board_state() == expected({})
    assert any(i.startswith("불안정: cell_4") for i in d.last_board_issues)


def test_같은_칸에_빨강_파랑이_겹치면_None과_충돌_기록(tmp_path):
    x, y = POS["cell_6"]
    f = frame(extra=[(x - 30, y, RED), (x + 30, y, BLUE)])  # 겹치지 않는 두 덩어리, 둘 다 cell_6에 가장 가까움
    d = detector(tmp_path, lambda: f)
    assert d.board_state()["cell_6"] is None
    assert any("충돌: cell_6" in i for i in d.last_board_issues)


def test_판_바깥의_빨간_물체는_무시한다(tmp_path):
    f = frame({"cell_1": BLUE}, extra=[(*OUTSIDE, RED)])
    d = detector(tmp_path, lambda: f)
    assert d.board_state() == expected({"cell_1": "human"})
    assert d.last_board_issues == []


def test_board_cells_json이_없으면_FileNotFoundError(tmp_path):
    slots = tmp_path / "slots.json"
    slots.write_text("{}", encoding="utf-8")
    d = VisionDetector(slots, board_frame_source=lambda: frame(), board_cells_path=tmp_path / "없음.json")
    with pytest.raises(FileNotFoundError):
        d.board_state()


def test_piece_at은_board_state와_같고_모르는_칸은_ValueError(tmp_path):
    f = frame({"center": RED, "cell_0": BLUE})
    d = detector(tmp_path, lambda: f)
    state = d.board_state()
    assert d.piece_at("center") == state["center"] == "robot"
    assert d.piece_at("cell_0") == "human"
    assert d.piece_at("cell_10") is None
    with pytest.raises(ValueError, match="cell_0"):
        d.piece_at("cell_99")


def test_트레이_카메라와_다른_구성에서는_판_소스만_읽는다(tmp_path):
    def tray_source():
        raise AssertionError("트레이 frame_source를 쓰면 안 됨")
    f = frame({"cell_8": RED})
    d = detector(tmp_path, lambda: f, camera_index=1, board_camera_index=2, frame_source=tray_source)
    assert d.board_state() == expected({"cell_8": "robot"})


def test_반환_키는_board_cell_names와_같다(tmp_path):
    assert set(detector(tmp_path, lambda: frame()).board_state()) == set(board_cell_names())


def test_기존_생성_방식으로도_read_dice_read_yut이_동작한다(tmp_path):
    slots = tmp_path / "slots.json"
    slots.write_text(json.dumps({"tray": [0, 0, 200, 200]}), encoding="utf-8")
    img = np.full((200, 300, 3), 90, np.uint8)
    cv2.rectangle(img, (50, 50), (150, 150), (240, 240, 240), -1)
    cv2.circle(img, (100, 100), 12, (20, 20, 20), -1)
    d = VisionDetector(slots, frame_source=lambda: img)
    assert d.read_dice().value == 1
    with pytest.raises(RuntimeError, match="윷 모델"):
        d.read_yut()


# --- 실제 사진 (있을 때만) ---
DATA = ROOT / "data" / "board"
REF = DATA / "WIN_20261103_10_50_51_Pro.jpg"
PHOTOS = {  # test_board_pieces.py의 정답을 게임 칸 이름으로 바꾼 것 (cell_21->diag_r2, cell_23->diag_r3, cell_25->diag_l1)
    "horse_1.jpg": {"cell_2": "human", "cell_8": "robot", "cell_14": "robot"},
    "horse_2.jpg": {"cell_1": "robot", "cell_6": "human", "diag_r3": "robot"},
    "horse_3.jpg": {"cell_9": "human", "cell_17": "human", "diag_r2": "robot", "diag_l1": "robot"},
}


@pytest.mark.parametrize("name", sorted(PHOTOS))
def test_실제_사진이_S2_배정과_같은_소유자(tmp_path, name):
    if not REF.exists() or not (DATA / name).exists():
        pytest.skip("data/board 사진 없음")
    from make_board_cells import convert
    draft = json.loads((ROOT / "config" / "slots_draft_v2.json").read_text(encoding="utf-8"))
    cells_path = tmp_path / "board_cells.json"
    cells_path.write_text(json.dumps(convert(draft)), encoding="utf-8")
    img = cv2.imread(str(DATA / name))
    slots = tmp_path / "slots.json"
    slots.write_text("{}", encoding="utf-8")
    d = VisionDetector(slots, board_frame_source=lambda: img, board_cells_path=cells_path)
    state = d.board_state()
    assert {k: v for k, v in state.items() if v} == PHOTOS[name]
    assert d.last_board_issues == []


CURRENT_PHOTOS = {  # 2026-11-04 10:14 판 카메라 사진 (horse_1~3과 달리 현재 카메라 위치). 정답은 사진에서 눈으로 확인
    "horse_4.jpg": {"diag_r1": "human", "diag_l1": "human", "diag_l3": "robot"},
    "horse_5.jpg": {"cell_12": "human", "diag_r1": "human", "diag_r4": "robot"},
    "horse_6.jpg": {"cell_2": "human", "cell_8": "robot", "cell_16": "human"},
}


@pytest.mark.parametrize("name", sorted(CURRENT_PHOTOS))
def test_실제_설정으로_현재_카메라_사진을_읽는다(tmp_path, name):
    """config/board_cells.json 그대로 읽는다. 배정 결과와 함께, 말이 배정된 칸의 원(roi_r) 안에 있는지도 본다.

    배정은 이웃 칸 간격의 60%까지 너그러워서 좌표가 수십 픽셀 어긋나도 결과가 맞는다. 원 안 검사가 어긋남을 잡는다.
    """
    if not (DATA / name).exists():
        pytest.skip("data/board 사진 없음")
    img = cv2.imread(str(DATA / name))
    slots = tmp_path / "slots.json"
    slots.write_text("{}", encoding="utf-8")
    d = VisionDetector(slots, board_frame_source=lambda: img, board_cells_path=ROOT / "config" / "board_cells.json")
    state = d.board_state()
    assert {k: v for k, v in state.items() if v} == CURRENT_PHOTOS[name]
    assert d.last_board_issues == []
    from vision.board_cells import load_board_cells
    from vision.board_pieces import find_piece_blobs
    cells = load_board_cells(ROOT / "config" / "board_cells.json")
    for blob in find_piece_blobs(img):
        if blob.cx < 700:  # 판 밖(왼쪽 책상의 마우스패드 등)
            continue
        nearest = min(cells.values(), key=lambda c: (c.x - blob.cx) ** 2 + (c.y - blob.cy) ** 2)
        assert ((nearest.x - blob.cx) ** 2 + (nearest.y - blob.cy) ** 2) ** 0.5 <= nearest.roi_r
