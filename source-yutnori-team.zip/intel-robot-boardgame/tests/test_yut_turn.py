"""윷놀이 턴 흐름 테스트: 래퍼(DeviceWrapper) + 상태 머신 + 오케스트레이터.

진행 방식 (11/02 결정): 사람 턴은 실제 윷을 비전이 읽고, AI 턴은 UI가 윷을 시뮬레이션하며,
말은 양쪽 모두 로봇팔이 옮깁니다. 하드웨어 대신 common/mock.py의 ScriptedVision·ScriptedRobot을 씁니다.
vision·robot 담당은 실제 모듈을 같은 자리에 넣어 흐름을 확인할 수 있습니다.
"""
import random
import sys
from pathlib import Path

import pytest
from transitions import MachineError

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from common.interfaces import Move  # noqa: E402
from common.mock import ConsoleScreen, MockNarrator, MockStore, ScriptedRobot, ScriptedVision  # noqa: E402
from game.state_machine import YutTurnMachine  # noqa: E402
from game.strategy import choose_move  # noqa: E402
from game.wrapper import DeviceWrapper  # noqa: E402
from game.yut_orchestrator import YutOrchestrator, ai_thrower, slot  # noqa: E402
from game.yut_reference import GOAL, WAIT, YutBoard, YutGame, throw_sticks  # noqa: E402

board = YutBoard(ROOT / "config" / "yut_board.json")
DO, GAE, GEOL, YUT, MO = 1, 2, 3, 4, 5  # 칸 수
F_DO, F_GAE, F_GEOL, F_YUT, F_MO, F_BACK = 1, 2, 3, 4, 0, -1  # 앞 개수 (빽도 -1)


def make(flats=(), ai=(), choices=(), robot_kw=None, verify=False, manual=1):
    """flats: 사람 턴에 비전이 읽을 앞 개수, ai: AI 턴에 UI가 시뮬레이션할 앞 개수."""
    log: list[str] = []
    vision = ScriptedVision(list(flats), log=log)
    robot = ScriptedRobot(log=log, **(robot_kw or {}))
    screen = ConsoleScreen(choices=list(choices), quiet=True)
    dev = DeviceWrapper(vision, robot, screen, ask_flats=lambda: manual)
    store = MockStore()
    ai = list(ai)
    orch = YutOrchestrator(board, dev, MockNarrator(), store, screen,
                           ai_throw=lambda: ai.pop(0) if ai else F_DO, verify_moves=verify)
    return orch, vision, robot, screen, store, log


# ---- 상태 머신 ----

def test_machine_full_turn_path():
    sm = YutTurnMachine()
    for trigger in ("throw", "read", "throw", "read", "choose", "move", "check", "retry", "check",
                    "resolve", "choose", "move", "check", "resolve", "throw", "read", "choose", "move",
                    "check", "resolve", "next_turn"):
        getattr(sm, trigger)()
    assert sm.state == "idle"


def test_machine_rejects_wrong_order():
    sm = YutTurnMachine()
    with pytest.raises(MachineError):
        sm.move()  # 던지기 전에 이동 불가
    sm.throw()
    with pytest.raises(MachineError):
        sm.choose()  # 읽기 전에 고르기 불가


# ---- 래퍼 ----

def test_wrapper_homes_after_move_and_blocks_vision_while_arm_out():
    orch, vision, robot, screen, store, log = make([F_DO])
    dev = orch.dev
    dev.move("wait_human", "cell_1")
    assert log == ["robot.move wait_human cell_1", "robot.home"] and not dev.arm_out
    assert dev.read() == F_DO
    dev.arm_out = True
    with pytest.raises(RuntimeError):
        dev.read()


def test_wrapper_retries_robot_failure():
    orch, vision, robot, screen, store, log = make(robot_kw={"move_fails": 2})
    assert orch.dev.move("wait_robot", "cell_1")
    assert log.count("robot.move wait_robot cell_1") == 3 and log[-1] == "robot.home"


def test_wrapper_gives_up_after_max_retry():
    orch, vision, robot, screen, store, log = make(robot_kw={"move_fails": 9})
    assert not orch.dev.move("wait_robot", "cell_1")
    assert log.count("robot.move wait_robot cell_1") == 3


# ---- 한 턴 ----

def test_human_throws_real_yut_and_robot_moves_human_piece():
    orch, vision, robot, screen, store, log = make([F_DO])
    orch.play_turn()
    assert log == ["vision.read_yut", "robot.move wait_human cell_1", "robot.home"]
    assert orch.state.pieces["human"][0] == "cell_1" and not screen.throws
    assert orch.state.current == "robot" and orch.state.turn == 2 and orch.sm.state == "idle"
    assert [e.kind for e in store.events] == ["throw", "move"]


def test_ai_throw_is_simulated_on_screen_not_read_by_vision():
    orch, vision, robot, screen, store, log = make(ai=[F_GAE])
    orch.state.current = "robot"
    orch.play_turn()
    assert screen.throws == [(F_GAE, "개")]
    assert log == ["robot.move wait_robot cell_2", "robot.home"]  # 비전 읽기·로봇 던지기 없음


def test_yut_mo_do_collects_three_results():
    # rules.md 13: 윷 → 모 → 도, 결과 [4, 5, 1]을 모아 하나씩 적용
    orch, *_, store, log = make([F_YUT, F_MO, F_DO], choices=[0, 0, 0])
    orch.play_turn()
    throws = [e.detail["value"] for e in store.events if e.kind == "throw"]
    moves = [e.detail["yut"] for e in store.events if e.kind == "move"]
    assert throws == [YUT, MO, DO] and moves == ["윷", "모", "도"]


def test_ai_yut_then_geol_collects_two_results():
    orch, vision, robot, screen, store, log = make(ai=[F_YUT, F_GEOL])
    orch.state.current = "robot"
    orch.play_turn()
    assert [n for _, n in screen.throws] == ["윷", "걸"]
    assert [e.detail["yut"] for e in store.events if e.kind == "move"] == ["윷", "걸"]


def test_read_failure_rethrows_then_asks_human():
    orch, vision, robot, screen, store, log = make([None, None, None], manual=F_GEOL)
    orch.play_turn()
    assert log.count("vision.read_yut") == 3
    assert screen.helps and orch.state.pieces["human"][0] == "cell_3"


def test_read_failure_once_then_ok():
    orch, vision, robot, screen, store, log = make([None, F_DO])
    orch.play_turn()
    assert not screen.helps and orch.state.pieces["human"][0] == "cell_1"


def test_robot_capture_clears_human_piece_first_and_throws_again():
    # rules.md 10: 로봇 cell_2, 사람 cell_4, 개 → 사람 말 대기로, 로봇 한 번 더
    orch, *_, store, log = make(ai=[F_GAE, F_DO])
    orch.game.pieces["robot"][0] = "cell_2"
    orch.game.pieces["human"][0] = "cell_4"
    orch.state.current = "robot"
    orch.play_turn()
    moves = [s for s in log if s.startswith("robot.move")]
    assert moves[:2] == ["robot.move cell_4 wait_human", "robot.move cell_2 cell_4"]
    assert orch.game.pieces["human"][0] == WAIT
    assert [e.kind for e in store.events].count("throw") == 2


def test_human_capture_robot_arm_clears_robot_pieces():
    # 사람이 잡아도 로봇팔이 로봇 말을 wait_robot으로 치우고 사람 말을 옮김
    orch, *_, store, log = make([F_GAE, F_DO], choices=[0, 0])
    orch.game.pieces["human"][0] = "cell_2"
    orch.game.pieces["robot"][:2] = ["cell_4", "cell_4"]
    orch.play_turn()
    moves = [s for s in log if s.startswith("robot.move")]
    assert moves[:2] == ["robot.move cell_4 wait_robot", "robot.move cell_2 cell_4"]
    assert orch.state.pieces["robot"][:2] == ["wait_robot", "wait_robot"]


def test_verify_retries_move_then_asks_help():
    orch, vision, robot, screen, store, log = make([F_DO], verify=True)
    orch.play_turn()  # 비전 판이 비어 있어 확인 실패
    assert log.count("robot.move wait_human cell_1") == 3
    assert any("cell_1" in h for h in screen.helps)


def test_verify_passes_when_vision_sees_piece():
    orch, vision, robot, screen, store, log = make(ai=[F_DO], verify=True)
    vision.board["cell_1"] = "robot"
    orch.state.current = "robot"
    orch.play_turn()
    assert log.count("robot.move wait_robot cell_1") == 1 and not screen.helps


def test_verify_other_cell_mismatch_asks_help_without_retry():
    orch, vision, robot, screen, store, log = make(ai=[F_DO], verify=True)
    vision.board.update({"cell_1": "robot", "cell_7": "human"})  # 옮긴 칸은 맞고, 기대하지 않은 말이 cell_7에
    orch.state.current = "robot"
    orch.play_turn()
    assert log.count("robot.move wait_robot cell_1") == 1  # 다시 옮기지 않음
    assert len(screen.helps) == 1 and "cell_7" in screen.helps[0] and "human" in screen.helps[0]


def test_board_diff_compares_board_cells_only():
    orch, vision, robot, screen, store, log = make()
    orch.game.pieces["robot"] = ["cell_2", "cell_2"]  # 업힌 말도 칸 하나, 편 하나
    orch.game.pieces["human"] = [WAIT, GOAL]  # 대기·완주는 비전이 읽지 않음
    vision.board.update({"cell_2": "robot", "cell_9": None, "wait_human": "human"})
    assert orch._board_diff() == {}
    vision.board["cell_5"] = "human"  # 잡혀서 치웠어야 할 말이 남은 경우
    del vision.board["cell_2"]
    assert orch._board_diff() == {"cell_2": ("robot", None), "cell_5": (None, "human")}


def test_move_failure_asks_help_once_without_verify_retry():
    orch, vision, robot, screen, store, log = make([F_DO], robot_kw={"move_fails": 9}, verify=True)
    orch.play_turn()  # 로봇 이동이 끝내 실패 → 사람이 옮김, 비전 확인·재이동은 하지 않음
    assert log.count("robot.move wait_human cell_1") == 3
    assert len(screen.helps) == 1 and "vision.board_state" not in log


def test_finish_and_win():
    # rules.md 14: 업힌 말 전부 완주 → 승리 (말 수는 config를 따름)
    orch, *_, store, log = make(ai=[F_GEOL])
    orch.game.pieces["robot"] = ["cell_19"] * orch.game.board.pieces
    orch.state.current = "robot"
    orch.play_turn()
    assert orch.state.winner == "robot" and orch.sm.state == "end"
    assert "robot.move cell_19 goal_robot" in log
    assert [e.kind for e in store.events][-3:] == ["move", "finish", "win"]


def test_slot_names():
    assert slot("robot", WAIT) == "wait_robot" and slot("human", GOAL) == "goal_human"
    assert slot("human", "cell_3") == "cell_3"


def test_ai_thrower_reads_config():
    throw = ai_thrower(ROOT / "config" / "yut_board.json", random.Random(0))
    results = [throw() for _ in range(16000)]
    assert set(results) == {F_BACK, F_MO, F_DO, F_GAE, F_GEOL, F_YUT}
    assert abs(results.count(F_BACK) / len(results) - 1 / 16) < 0.01  # 빽도 6.25%
    assert abs(results.count(F_DO) / len(results) - 3 / 16) < 0.015  # 도 18.75%


# ---- 빽도 ----

def test_backdo_void_when_no_piece_on_board():
    orch, vision, robot, screen, store, log = make([F_BACK])
    orch.play_turn()
    assert log == ["vision.read_yut"]  # 로봇이 움직이지 않음
    assert orch.state.pieces["human"] == ["wait_human"] * board.pieces
    assert orch.state.current == "robot" and orch.sm.state == "idle"
    assert [e.kind for e in store.events] == ["throw"]


def test_backdo_moves_piece_back():
    orch, vision, robot, screen, store, log = make([F_BACK])
    orch.game.pieces["human"] = ["cell_3", WAIT]
    orch.play_turn()
    assert "robot.move cell_3 cell_2" in log and orch.game.pieces["human"][0] == "cell_2"


def test_backdo_choices_skip_waiting_pieces():
    # 윷 다음 빽도: 빽도는 판 위 말에만 보기로 나옴
    orch, vision, robot, screen, store, log = make([F_YUT, F_BACK], choices=[2, 0])
    orch.game.pieces["human"] = ["cell_3", WAIT]
    orch.play_turn()  # 보기: 말1에 윷, 말2에 윷, 말1에 빽도 → 빽도 먼저, 다음 말1에 윷
    assert orch.game.pieces["human"] == ["cell_6", WAIT]


def test_ai_backdo_shown_on_screen():
    orch, vision, robot, screen, store, log = make(ai=[F_BACK])
    orch.state.current = "robot"
    orch.game.pieces["robot"] = ["cell_5", WAIT]
    orch.play_turn()
    assert screen.throws == [(F_BACK, "빽도")]
    assert log == ["robot.move cell_5 cell_4", "robot.home"]


# ---- 전략 ----

def test_strategy_picks_result_that_captures():
    g = YutGame(board, {"robot": ["cell_1", WAIT], "human": ["cell_4", WAIT]})
    assert choose_move(g, "robot", [DO, GEOL]) == Move(0, GEOL, "capture")


def test_strategy_enter_when_all_waiting():
    g = YutGame(board)
    assert choose_move(g, "robot", [GAE]) == Move(0, GAE, "enter")


# ---- 한 판 ----

@pytest.mark.parametrize("seed", range(30))
def test_full_game_finishes(seed):
    rng = random.Random(seed)
    flats = [throw_sticks(rng, 0.5, board.backdo) for _ in range(2000)]
    choices = [rng.randrange(8) for _ in range(2000)]
    ai = [throw_sticks(rng, 0.5, board.backdo) for _ in range(2000)]
    orch, *_, store, log = make(flats, ai=ai, choices=choices)
    winner = orch.run()
    assert winner in ("human", "robot") and store.events[-1].kind == "win"
    assert all(p == f"goal_{winner}" for p in orch.state.pieces[winner])
