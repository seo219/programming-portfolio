import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace

import cv2
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vision.detector import VisionDetector  # noqa: E402
from vision.yut_model import DEFAULT_YUT_MODEL_DIR, ModelApiYutClassifier, detections_from_result  # noqa: E402

# 폴더 이름 → 배 개수 정답 (빽도 -1)
EXPECTED = {"backdo": -1, "do": 1, "gae": 2, "gurl": 3, "yukk": 4, "mo": 0}
DATA = ROOT / "data" / "yukk_1"


def test_detections_from_result():
    result = SimpleNamespace(
        label_names=["down", "upper"], scores=[0.9, 0.7], bboxes=[[1, 2, 3, 4], [5, 6, 7, 8]]
    )
    dets = detections_from_result(result)
    assert [(d.label, d.score, d.box) for d in dets] == [
        ("down", 0.9, (1.0, 2.0, 3.0, 4.0)),
        ("upper", 0.7, (5.0, 6.0, 7.0, 8.0)),
    ]


def test_detections_from_result_length_mismatch():
    result = SimpleNamespace(label_names=["down"], scores=[0.9, 0.8], bboxes=[[0, 0, 1, 1]])
    with pytest.raises(ValueError):
        detections_from_result(result)


def test_missing_model_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        ModelApiYutClassifier(tmp_path)


@pytest.mark.parametrize("folder, expected", EXPECTED.items())
def test_real_model_read_yut(folder, expected):
    if importlib.util.find_spec("model_api") is None:
        pytest.skip("model_api(openvino-model-api)가 설치되어 있지 않습니다")
    if not (DEFAULT_YUT_MODEL_DIR / "model.xml").exists():
        pytest.skip(f"윷 모델이 없습니다: {DEFAULT_YUT_MODEL_DIR}")
    photos = sorted((DATA / folder).glob("*.jpg"))[:2]
    if len(photos) < 2:
        pytest.skip(f"테스트 사진이 부족합니다: {DATA / folder}")
    classifier = ModelApiYutClassifier()
    for photo in photos:
        frame = cv2.imread(str(photo))
        detector = VisionDetector(ROOT / "config" / "slots.json", frame_source=lambda: frame, yut_classifier=classifier)
        assert detector.read_yut().flats == expected, photo.name
