"""말 판별(색 덩어리 -> 칸 배정) 테스트. 합성 이미지로 확인하고, 사진이 있으면 스크립트와 같은 결과인지도 본다."""
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from vision.board_cells import BoardCell  # noqa: E402
from vision.board_pieces import (  # noqa: E402
    MAX_CELL_DIST_RATIO, MIN_BLOB_AREA, Blob, assign_blobs_to_cells, cell_spacing, find_piece_blobs)

RED = (0, 0, 220)    # BGR
BLUE = (220, 0, 0)
R = 28               # 반지름: 면적 약 2463px > MIN_BLOB_AREA

# 간격 160px 격자 9칸. 이름은 섞어서 쓴다 (이름을 해석하지 않는지 확인)
NAMES = ["cell_3", "diag_r1", "center", "cell_0", "diag_l2", "cell_19", "diag_r4", "cell_7", "diag_l1"]
CELLS = {n: BoardCell(160.0 + 160 * (i % 3), 120.0 + 120 * (i // 3), 40.0) for i, n in enumerate(NAMES)}
SPACING = 120.0  # 격자에서 모든 칸의 최근접 이웃은 세로로 120px


def canvas():
    return np.full((480, 640, 3), 128, np.uint8)


def draw(img, color, x, y, r=R):
    cv2.circle(img, (x, y), r, color, -1)


def read(img):
    return assign_blobs_to_cells(find_piece_blobs(img), CELLS)


def test_빨강_파랑이_가장_가까운_칸에_배정된다():
    img = canvas()
    draw(img, RED, 170, 130)    # cell_3 (160,120) 근처
    draw(img, BLUE, 470, 250)   # cell_19 (480,240) 근처
    r = read(img)
    assert r.issues == []
    assert r.state["cell_3"] == "robot"
    assert r.state["cell_19"] == "human"
    assert set(r.state) == set(NAMES)
    assert all(v is None for k, v in r.state.items() if k not in ("cell_3", "cell_19"))


def test_최소_면적보다_작은_점은_무시한다():
    img = canvas()
    draw(img, RED, 160, 120, r=15)   # 면적 약 706 < MIN_BLOB_AREA
    assert np.pi * 15 ** 2 < MIN_BLOB_AREA
    assert find_piece_blobs(img) == []
    r = read(img)
    assert r.state == {n: None for n in NAMES} and r.issues == []


def test_칸에서_먼_덩어리는_배정하지_않고_issues에_남긴다():
    img = canvas()
    draw(img, BLUE, 240, 180)   # 가장 가까운 칸들까지 (80,60)=100px
    limit = MAX_CELL_DIST_RATIO * SPACING   # 72
    assert np.hypot(80, 60) > limit
    r = read(img)
    assert all(v is None for v in r.state.values())
    assert len(r.issues) == 1 and "배정 못한" in r.issues[0] and "human" in r.issues[0]


def test_같은_칸에_다른_편이_겹치면_None과_충돌_기록():
    img = canvas()
    draw(img, RED, 132, 120)    # cell_3 중심(160,120) 양옆에 맞닿게
    draw(img, BLUE, 188, 120)
    r = read(img)
    assert r.state["cell_3"] is None
    assert len(r.issues) == 1 and "충돌" in r.issues[0] and "cell_3" in r.issues[0]


def test_같은_칸에_같은_편_둘이면_그_편으로_배정하고_issues는_비어_있다():
    img = canvas()
    draw(img, RED, 132, 120)
    draw(img, RED, 188, 120)
    r = read(img)   # 맞닿은 원은 하나로 합쳐질 수 있어, 덩어리 둘인 경우는 아래에서 직접 시험
    assert r.state["cell_3"] == "robot" and r.issues == []
    r2 = assign_blobs_to_cells([Blob("robot", 150, 120, 2000), Blob("robot", 170, 125, 2000)], CELLS)
    assert r2.state["cell_3"] == "robot" and r2.issues == []


def test_칸_이름을_해석하지_않는다():
    cells = {"cell_3": BoardCell(100, 100, 10), "diag_r1": BoardCell(200, 100, 10),
             "center": BoardCell(300, 100, 10), "zzz": BoardCell(400, 100, 10)}
    r = assign_blobs_to_cells([Blob("human", 205, 100, 2000), Blob("robot", 398, 102, 2000)], cells)
    assert r.state == {"cell_3": None, "diag_r1": "human", "center": None, "zzz": "robot"}


def test_cell_spacing은_최근접_이웃_거리의_중앙값():
    # x = 0, 10, 30, 60 -> 최근접 거리 10, 10, 20, 30 -> 중앙값 15
    cells = {n: BoardCell(float(x), 0.0, 5.0) for n, x in zip(["a", "b", "c", "d"], [0, 10, 30, 60])}
    assert cell_spacing(cells) == pytest.approx(15.0)
    # 격자: 모든 칸의 최근접은 세로 120
    assert cell_spacing(CELLS) == pytest.approx(SPACING)


def test_cell_spacing은_칸이_하나면_예외():
    with pytest.raises(ValueError):
        cell_spacing({"a": BoardCell(0, 0, 5)})


DATA = ROOT / "data" / "board"
REF = DATA / "WIN_20261103_10_50_51_Pro.jpg"
EXPECTED = {
    "horse_1.jpg": {"cell_2": "human", "cell_8": "robot", "cell_14": "robot"},
    "horse_2.jpg": {"cell_1": "robot", "cell_6": "human", "cell_23": "robot"},
    "horse_3.jpg": {"cell_9": "human", "cell_17": "human", "cell_21": "robot", "cell_25": "robot"},
}


@pytest.mark.parametrize("name", sorted(EXPECTED))
def test_실제_사진이_시험_스크립트와_같은_배정(name):
    if not REF.exists() or not (DATA / name).exists():
        pytest.skip("data/board 사진 없음")
    import board_state_test as bst
    ref_cells = json.loads((ROOT / "config" / "slots_draft_v2.json").read_text(encoding="utf-8"))
    ref_markers = bst.detect_markers(cv2.imread(str(REF)))
    img = cv2.imread(str(DATA / name))
    cells, markers, _ = bst.refit_cells(img, ref_cells, ref_markers)
    state, issues, _ = bst.board_state(img, cells, markers)
    assert {k: v for k, v in state.items() if v} == EXPECTED[name]
    assert issues == []
