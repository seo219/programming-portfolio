import json
import sys
from pathlib import Path

import cv2
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vision.detector import VisionDetector  # noqa: E402

TRAY = [0, 0, 200, 200]

# 100x100 주사위 면 안의 눈 위치 (왼쪽 위 기준)
PIP_POS = {
    1: [(50, 50)],
    2: [(25, 25), (75, 75)],
    3: [(25, 25), (50, 50), (75, 75)],
    4: [(25, 25), (75, 25), (25, 75), (75, 75)],
    5: [(25, 25), (75, 25), (50, 50), (25, 75), (75, 75)],
    6: [(25, 25), (75, 25), (25, 50), (75, 50), (25, 75), (75, 75)],
}


def make_frame(dice=None):
    frame = np.full((200, 300, 3), 90, dtype=np.uint8)
    if dice:
        cv2.rectangle(frame, (50, 50), (150, 150), (240, 240, 240), -1)
        for px, py in PIP_POS[dice]:
            cv2.circle(frame, (50 + px, 50 + py), 12, (20, 20, 20), -1)
    return frame


def detector(tmp_path, frame_fn):
    slots = tmp_path / "slots.json"
    slots.write_text(json.dumps({"tray": TRAY}), encoding="utf-8")
    return VisionDetector(slots, frame_source=frame_fn)


@pytest.mark.parametrize("value", range(1, 7))
def test_read_dice(tmp_path, value):
    result = detector(tmp_path, lambda: make_frame(dice=value)).read_dice()
    assert result.value == value
    assert result.confidence == 1.0


def with_tray_noise(frame):
    """주사위 밖 트레이 바닥에 눈처럼 보이는 어두운 원을 찍습니다."""
    for cx, cy in [(20, 20), (180, 30), (25, 180), (175, 175)]:
        cv2.circle(frame, (cx, cy), 12, (20, 20, 20), -1)
    return frame


@pytest.mark.parametrize("value", range(1, 7))
def test_read_dice_ignores_dark_spots_outside_die(tmp_path, value):
    result = detector(tmp_path, lambda: with_tray_noise(make_frame(dice=value))).read_dice()
    assert result.value == value


@pytest.mark.parametrize("value", [1, 3, 6])
def test_read_dice_tilted_die(tmp_path, value):
    def tilted():
        frame = make_frame(dice=value)
        matrix = cv2.getRotationMatrix2D((100, 100), 25, 1.0)
        return cv2.warpAffine(frame, matrix, (300, 200), borderValue=(90, 90, 90))
    assert detector(tmp_path, tilted).read_dice().value == value


def single_roi_detector(tmp_path, frame_fn, size):
    slots = tmp_path / "slots.json"
    slots.write_text(json.dumps({"tray": [0, 0, size[0], size[1]]}), encoding="utf-8")
    return VisionDetector(slots, frame_source=frame_fn)


@pytest.mark.parametrize("value", range(1, 7))
def test_read_dice_large_roi_with_glare(tmp_path, value):
    """트레이 ROI가 크고 책상에 밝은 반사광이 있어도 눈을 센다 (주사위 본체를 따로 찾지 않음)."""
    def frame():
        f = np.tile(np.linspace(80, 210, 600, dtype=np.uint8), (400, 1))  # 왼쪽 어둡고 오른쪽 밝은 배경
        f = cv2.merge([f, f, f])
        cv2.rectangle(f, (350, 150), (450, 250), (240, 240, 240), -1)
        for px, py in PIP_POS[value]:
            cv2.circle(f, (350 + px, 150 + py), 12, (20, 20, 20), -1)
        return f
    assert single_roi_detector(tmp_path, frame, (600, 400)).read_dice().value == value


@pytest.mark.parametrize("value", [1, 3, 6])
def test_read_dice_ignores_flat_side_pips(tmp_path, value):
    """주사위 옆면 눈은 비스듬해서 납작하게 보인다. 윗면 눈만 센다."""
    def frame():
        f = np.full((260, 200, 3), 90, dtype=np.uint8)
        cv2.rectangle(f, (50, 20), (150, 120), (240, 240, 240), -1)  # 윗면
        for px, py in PIP_POS[value]:
            cv2.circle(f, (50 + px, 20 + py), 12, (20, 20, 20), -1)
        cv2.rectangle(f, (50, 120), (150, 170), (225, 225, 225), -1)  # 비스듬히 보이는 옆면
        for cx in (70, 100, 130):
            cv2.ellipse(f, (cx, 145), (13, 4), 0, 0, 360, (20, 20, 20), -1)
        return f
    assert single_roi_detector(tmp_path, frame, (200, 260)).read_dice().value == value


def test_read_dice_unstable_returns_none(tmp_path):
    values = iter([1, 2, 3, 4, 5, 6, 1, 2])
    result = detector(tmp_path, lambda: make_frame(dice=next(values))).read_dice()
    assert result.value is None


def test_read_dice_no_dice_returns_none(tmp_path):
    result = detector(tmp_path, lambda: make_frame()).read_dice()
    assert result.value is None
    assert result.confidence == 0.0


def board_detector(tmp_path, frame_fn):
    """칸 좌표 파일(board_cells.json)을 tmp_path에 만들어 board_cells_path로 넘긴 판 감지기."""
    from test_vision_board_state import write_cells
    slots = tmp_path / "slots.json"
    slots.write_text(json.dumps({"tray": TRAY}), encoding="utf-8")
    return VisionDetector(slots, board_frame_source=frame_fn, board_cells_path=write_cells(tmp_path))


def test_piece_at(tmp_path):
    from test_vision_board_state import BLUE as B, RED as R, frame
    f = frame({"cell_0": R, "cell_1": B})
    d = board_detector(tmp_path, lambda: f)
    assert d.piece_at("cell_0") == "robot"
    assert d.piece_at("cell_1") == "human"


def test_piece_at_empty(tmp_path):
    from test_vision_board_state import frame
    assert board_detector(tmp_path, lambda: frame()).piece_at("cell_0") is None


def test_unmeasured_roi_raises(tmp_path):
    slots = tmp_path / "slots.json"
    slots.write_text(json.dumps({"tray": [0, 0, 0, 0]}), encoding="utf-8")
    d = VisionDetector(slots, frame_source=lambda: make_frame())
    with pytest.raises(ValueError):
        d.read_dice()
