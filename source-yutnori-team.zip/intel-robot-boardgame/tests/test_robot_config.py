"""로봇 설정 로더 테스트 (하드웨어 없이 실행). config/poses.json 형식과 미측정 처리를 확인합니다."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from robot.config import PoseNotMeasured, get_pose, load_poses, load_robot_config  # noqa: E402

J = [10.0, 20.0, 30.0, 40.0, 50.0, 60.0]


def write(tmp_path, data):
    p = tmp_path / "poses.json"
    p.write_text(json.dumps(data), encoding="utf-8")
    return p


def test_null_and_all_zero_are_unmeasured(tmp_path):
    poses = load_poses(write(tmp_path, {"_comment": "x", "a": None, "b": [0] * 6, "c": J}))
    assert set(poses) == {"c"}
    assert poses["c"].above == tuple(J) and poses["c"].grasp is None


def test_dict_form_with_grasp(tmp_path):
    poses = load_poses(write(tmp_path, {"cell_3": {"above": J, "grasp": [1, 2, 3, 4, 5, 6]}}))
    assert poses["cell_3"].grasp == (1.0, 2.0, 3.0, 4.0, 5.0, 6.0)


@pytest.mark.parametrize("bad", [[1, 2, 3], "x", [1, 2, 3, 4, 5, True], {"above": J, "extra": J}])
def test_bad_format_raises(tmp_path, bad):
    with pytest.raises(ValueError):
        load_poses(write(tmp_path, {"cell_1": bad}))


def test_get_pose_unmeasured_raises(tmp_path):
    poses = load_poses(write(tmp_path, {"cell_1": None}))
    with pytest.raises(PoseNotMeasured):
        get_pose(poses, "cell_1")


def test_repo_poses_json_has_all_slots():
    raw = json.loads((ROOT / "config" / "poses.json").read_text(encoding="utf-8"))
    expected = {"home", "tray", "drop", *(f"cell_{i}" for i in range(29)),
                *(f"{kind}_{side}" for kind in ("wait", "goal") for side in ("robot", "human"))}
    assert expected <= set(raw)
    assert not [k for k in raw if k[-2:] in ("_0", "_1") and k.startswith(("wait_", "goal_"))]  # 번호 붙은 자리는 없음
    load_poses(ROOT / "config" / "poses.json")  # 형식 오류가 없어야 함


def test_repo_robot_json_loads():
    cfg = load_robot_config(ROOT / "config" / "robot.json")
    assert {"follower", "leader", "gripper", "speed", "act"} <= set(cfg)
    assert cfg["act"]["enabled"] is False
