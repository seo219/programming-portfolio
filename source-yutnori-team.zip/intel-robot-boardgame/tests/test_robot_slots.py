"""슬롯 말 수 추적과 컨트롤러 move 흐름 테스트 (하드웨어 없이 FakeBackend로 실행)."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from robot.backend import BackendError  # noqa: E402
from robot.config import ConfigNotSet, PoseNotMeasured, RobotSettings, load_settings  # noqa: E402
from robot.controller import RobotController  # noqa: E402
from robot.fake_backend import FakeBackend  # noqa: E402
from robot.slots import SlotError, SlotTracker  # noqa: E402

DELTA = (0.0, 5.0, 0.0, 0.0, 0.0)
SETTINGS = RobotSettings(gripper_open=100.0, gripper_close=10.0, travel=1.0, approach=0.5, carry_stack=0.2, level_delta=DELTA)


def pose(base):
    """슬롯마다 구분되는 가짜 관절 값. above는 grasp보다 위(shoulder_lift가 작음)."""
    return {"above": [base, 10, 0, 0, 0, 0], "grasp": [base, 30, 0, 0, 0, 0]}


@pytest.fixture
def poses_path(tmp_path):
    names = ["cell_3", "cell_5", "wait_robot", "wait_human", "goal_robot", "goal_human"]
    data = {"home": [1, 1, 1, 1, 1, 1], **{n: pose(i + 2) for i, n in enumerate(names)}}
    p = tmp_path / "poses.json"
    p.write_text(json.dumps(data), encoding="utf-8")
    return p


def make(poses_path, tracker=None, settings=SETTINGS, backend=None):
    backend = backend or FakeBackend()
    return RobotController(poses_path, backend, settings, tracker or SlotTracker()), backend


# ---- SlotTracker ----

def test_tracker_start_and_move_rules():
    t = SlotTracker()
    assert t.snapshot() == {"wait_robot": 2, "wait_human": 2}
    assert t.pieces_to_move("wait_human") == 1  # 대기에서는 맨 위 1개
    t.apply("wait_human", "cell_3", 1)
    t.apply("wait_human", "cell_3", 1)
    assert t.count("cell_3") == 2 and t.pieces_to_move("cell_3") == 2  # 판 위에서는 전부


def test_tracker_rejects_bad_moves():
    t = SlotTracker({"cell_3": 1, "cell_5": 2, "goal_human": 1})
    with pytest.raises(SlotError):
        t.check_move("cell_9", "cell_3")  # 빈 칸
    with pytest.raises(SlotError):
        t.check_move("cell_3", "cell_5")  # 가득 참
    with pytest.raises(SlotError):
        t.check_move("goal_human", "cell_3")  # 완주 자리에서는 안 옮김
    with pytest.raises(SlotError):
        t.check_move("cell_3", "cell_3")


def test_tracker_sync():
    t = SlotTracker()
    t.sync({"cell_3": 1, "wait_robot": 0})
    assert t.snapshot() == {"cell_3": 1}


# ---- 컨트롤러 move ----

def test_move_single_piece_sequence(poses_path):
    t = SlotTracker({"cell_3": 1})
    c, b = make(poses_path, t)
    assert c.move("cell_3", "cell_5") is True
    assert b.calls == [
        ("move_to", (2, 10, 0, 0, 0), 1.0),   # cell_3 위 접근
        ("gripper", 100.0),                   # 열기
        ("move_to", (2, 30, 0, 0, 0), 0.5),   # 내려가서
        ("gripper", 10.0),                    # 집기
        ("move_to", (2, 10, 0, 0, 0), 1.0),   # 들어올리기 (1개: 이동 속도)
        ("move_to", (3, 10, 0, 0, 0), 1.0),   # cell_5 위
        ("move_to", (3, 30, 0, 0, 0), 0.5),   # 놓는 자리
        ("gripper", 100.0),
        ("move_to", (3, 10, 0, 0, 0), 0.5),
    ]
    assert t.snapshot() == {"cell_5": 1}


def test_wait_pick_takes_top_piece_one_level_higher(poses_path):
    t = SlotTracker()  # wait_human 2개
    c, b = make(poses_path, t)
    assert c.move("wait_human", "cell_3") is True
    # 위 말 1개만: 아래에 말 1개 → 집는 높이 + DELTA
    assert ("move_to", (5, 35, 0, 0, 0), 0.5) in b.calls
    assert t.snapshot() == {"wait_robot": 2, "wait_human": 1, "cell_3": 1}


def test_stack_moves_together_slowly_at_base_height(poses_path):
    t = SlotTracker({"cell_3": 2})
    c, b = make(poses_path, t)
    assert c.move("cell_3", "wait_human") is True
    assert ("move_to", (2, 30, 0, 0, 0), 0.5) in b.calls  # 쌓여 있어도 같은 높이에서 집음
    assert ("move_to", (5, 10, 0, 0, 0), 0.2) in b.calls  # 2개 들고는 carry_stack 속도
    assert t.snapshot() == {"wait_human": 2}


def test_place_on_occupied_slot_is_higher(poses_path):
    t = SlotTracker({"cell_3": 1, "cell_5": 1})
    c, b = make(poses_path, t)
    assert c.move("cell_3", "cell_5") is True
    assert ("move_to", (3, 35, 0, 0, 0), 0.5) in b.calls  # 말 1개 위에 얹음
    assert t.snapshot() == {"cell_5": 2}


@pytest.mark.parametrize("counts,src,dst", [
    ({}, "cell_3", "cell_5"),                      # 빈 칸에서 집기
    ({"cell_3": 1, "cell_5": 2}, "cell_3", "cell_5"),  # 가득 찬 칸에 놓기
    ({"goal_human": 1}, "goal_human", "cell_3"),   # 완주 자리에서 집기
])
def test_invalid_moves_return_false_without_motion(poses_path, counts, src, dst):
    c, b = make(poses_path, SlotTracker(counts))
    assert c.move(src, dst) is False
    assert b.calls == []


@pytest.mark.parametrize("fail_at", range(1, 10))
def test_backend_failure_returns_false_and_keeps_counts(poses_path, fail_at):
    t = SlotTracker({"cell_3": 1})
    c, b = make(poses_path, t, backend=FakeBackend(fail_on_call=fail_at))
    assert c.move("cell_3", "cell_5") is False
    assert t.snapshot() == {"cell_3": 1}


def test_unmeasured_pose_raises_before_motion(poses_path):
    c, b = make(poses_path, SlotTracker({"cell_3": 1}))
    with pytest.raises(PoseNotMeasured):
        c.move("cell_3", "cell_9")  # cell_9는 poses에 없음
    assert b.calls == []


def test_missing_settings_raise_before_motion(poses_path):
    c, b = make(poses_path, SlotTracker({"cell_3": 1}), settings=RobotSettings())
    with pytest.raises(ConfigNotSet):
        c.move("cell_3", "cell_5")
    c, b = make(poses_path, SlotTracker({"cell_3": 1, "cell_5": 1}), settings=RobotSettings(gripper_open=1.0, gripper_close=0.0))
    with pytest.raises(ConfigNotSet):  # 얹으려면 level_delta 필요
        c.move("cell_3", "cell_5")
    assert b.calls == []


def test_grasper_can_be_swapped(poses_path):
    """ACT 같은 다른 집기 방식을 끼워도 컨트롤러는 above 사이 이동과 말 수 기록만 맡는다."""
    log = []

    class RecordingGrasper:
        def preflight(self, pose, level):
            log.append(("preflight", level))

        def pick(self, backend, pose, level, carry_speed):
            log.append(("pick", level, carry_speed))

        def place(self, backend, pose, level):
            log.append(("place", level))

    t = SlotTracker({"cell_3": 2})
    b = FakeBackend()
    c = RobotController(poses_path, b, SETTINGS, t, grasper=RecordingGrasper())
    assert c.move("cell_3", "wait_human") is True
    assert log == [("preflight", 0), ("preflight", 0), ("pick", 0, 0.2), ("place", 0)]
    assert [x[1] for x in b.calls] == [(2, 10, 0, 0, 0), (5, 10, 0, 0, 0)]  # above 위치 둘만 컨트롤러가 이동
    assert t.snapshot() == {"wait_human": 2}


def test_home_and_no_backend(poses_path):
    c, b = make(poses_path)
    c.home()
    assert b.calls == [("move_to", (1, 1, 1, 1, 1), 1.0)]
    no_backend = RobotController(poses_path)
    with pytest.raises(NotImplementedError):
        no_backend.move("cell_3", "cell_5")


def test_load_settings_from_repo_robot_json():
    s = load_settings(ROOT / "config" / "robot.json")
    assert s == RobotSettings()  # 아직 전부 미측정(null)
