"""통합 테스트: 윷놀이 한 판 전체를 RobotController(+FakeBackend)로 돌려 슬롯 규칙과 게임 상태가 맞는지 봅니다.

게임(YutOrchestrator·DeviceWrapper)은 고치지 않고 그대로 씁니다. 로봇 쪽 해석(SlotTracker)이 게임과 어긋나면
여기서 잡힙니다. 검증:
  1. 모든 robot.move가 True (컨트롤러가 거절·실패한 이동 0번)
  2. 말을 옮기기 직전과 직후에 컨트롤러의 슬롯별 말 수 == 게임 상태
  3. 한 판이 끝났을 때도 일치
그리고 잡기(말 1개·업힌 말 2개), 업기, 대기에서 1개만 집기, 완주 자리 용량(2) 같은 경우가 실제로 나오는지 센다.
"""
import json
import random
import sys
from collections import Counter
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from common.mock import ConsoleScreen, MockNarrator, MockStore, ScriptedVision  # noqa: E402
from game.wrapper import DeviceWrapper  # noqa: E402
from game.yut_orchestrator import YutOrchestrator, slot  # noqa: E402
from game.yut_reference import YutBoard, throw_sticks  # noqa: E402
from robot.config import RobotSettings  # noqa: E402
from robot.controller import RobotController  # noqa: E402
from robot.fake_backend import FakeBackend  # noqa: E402
from robot.slots import SlotTracker, canonical_slot  # noqa: E402

BOARD_PATH = ROOT / "config" / "yut_board.json"
board = YutBoard(BOARD_PATH)
SETTINGS = RobotSettings(gripper_open=100.0, gripper_close=10.0, travel=1.0, approach=0.5, carry_stack=0.2,
                         level_delta=(0.0, 5.0, 0.0, 0.0, 0.0))  # 시험용 값 (실제 측정값 아님)


def fake_poses(tmp_path) -> Path:
    """게임이 쓰는 모든 슬롯 이름(canonical 변환 후)에 가짜 자세를 만듭니다. 실제 측정값이 아닙니다."""
    names = {canonical_slot(k) for k in board.layout} | {f"{k}_{p}" for k in ("wait", "goal") for p in ("robot", "human")}
    data = {"home": [1, 1, 1, 1, 1, 1]}  # 전부 0이면 로더가 미측정으로 보므로 0이 아닌 값
    for i, n in enumerate(sorted(names)):
        data[n] = {"above": [i + 1, 10, 0, 0, 0, 0], "grasp": [i + 1, 30, 0, 0, 0, 0]}
    p = tmp_path / "poses.json"
    p.write_text(json.dumps(data), encoding="utf-8")
    return p


def game_counts(orch) -> dict:
    """게임 상태의 슬롯별 말 수 (poses.json 이름 기준)."""
    c = Counter()
    for p in ("human", "robot"):
        for pos in orch.game.pieces[p]:
            c[canonical_slot(slot(p, pos))] += 1
    return dict(c)


class CheckedRobot:
    """RobotController를 감싸 모든 이동을 기록하고, 이동하는 말 수 같은 정보를 모읍니다."""

    def __init__(self, ctl: RobotController, stats: Counter):
        self.ctl, self.stats = ctl, stats
        self.failed: list = []

    def home(self) -> None:
        self.ctl.home()

    def move(self, src: str, dst: str) -> bool:
        t = self.ctl.tracker
        s, d = canonical_slot(src), canonical_slot(dst)
        n_src, n_dst = t.count(s), t.count(d)
        ok = self.ctl.move(src, dst)
        if not ok:
            self.failed.append((src, dst, n_src, n_dst))
            return ok
        n = n_src if not s.startswith("wait_") else 1
        self.stats["moves"] += 1
        if s.startswith("wait_") and n_src == 2:
            self.stats["take_one_from_wait_stack"] += 1  # 대기에서 위 말 1개만 집기
        if s.startswith("wait_") and n_src == 1:
            self.stats["take_last_from_wait"] += 1
        if not s.startswith("wait_") and n == 2 and not d.startswith(("goal_", "wait_")):
            self.stats["move_stack_on_board"] += 1  # 업힌 말 둘을 한 번에
        if d.startswith("wait_") and not s.startswith("wait_"):
            self.stats["capture_clear_" + ("2" if n == 2 else "1")] += 1  # 잡힌 말 치우기
        if d.startswith("goal_"):
            self.stats["goal_move_n%d" % n] += 1
            if n_dst == 1:
                self.stats["goal_second_arrival"] += 1  # 완주 자리에 이미 1개 → 용량 2
            if n_dst + n == 2:
                self.stats["goal_capacity_reached"] += 1
        if not d.startswith(("goal_", "wait_")) and n_dst == 1:
            self.stats["stack_on_board_from_" + ("wait" if s.startswith("wait_") else "cell")] += 1  # 업기
        return ok


def run_game(seed: int, tmp_path: Path):
    rng = random.Random(seed)
    flats = [throw_sticks(rng, 0.5, board.backdo) for _ in range(3000)]
    choices = [rng.randrange(8) for _ in range(3000)]
    ai = [throw_sticks(rng, 0.5, board.backdo) for _ in range(3000)]
    stats: Counter = Counter()
    ctl = RobotController(fake_poses(tmp_path), FakeBackend(), SETTINGS, SlotTracker())
    robot = CheckedRobot(ctl, stats)
    screen = ConsoleScreen(choices=choices, quiet=True)
    dev = DeviceWrapper(ScriptedVision(flats), robot, screen, ask_flats=lambda: 1)
    store = MockStore()
    orch = YutOrchestrator(board, dev, MockNarrator(), store, screen, ai_throw=lambda: ai.pop(0), verify_moves=False)

    mismatches: list = []
    real_apply = orch._apply

    def checked_apply(player, move, throw):
        before = game_counts(orch)
        if ctl.tracker.snapshot() != before:
            mismatches.append(("before", orch.state.turn, ctl.tracker.snapshot(), before))
        r = real_apply(player, move, throw)
        after = game_counts(orch)
        if ctl.tracker.snapshot() != after:
            mismatches.append(("after", orch.state.turn, ctl.tracker.snapshot(), after))
        return r

    orch._apply = checked_apply
    winner = orch.run()
    for e in store.events:
        if e.kind == "capture":
            stats["capture_%d_%s" % (e.detail["captured"], e.player)] += 1
        if e.kind == "stack":
            stats["stack_event"] += 1
        if e.kind == "move" and e.detail["yut"] == "빽도":
            stats["backdo_move"] += 1
    return winner, robot, mismatches, ctl, orch, stats


SEEDS = range(40)


@pytest.mark.parametrize("seed", SEEDS)
def test_full_game_robot_matches_game_state(seed, tmp_path):
    winner, robot, mismatches, ctl, orch, _ = run_game(seed, tmp_path)
    assert winner in ("human", "robot")
    assert robot.failed == [], f"컨트롤러가 거절한 이동: {robot.failed[:3]}"
    assert mismatches == [], f"로봇 말 수와 게임 상태가 다름: {mismatches[:3]}"
    assert ctl.tracker.snapshot() == game_counts(orch)  # 판이 끝났을 때도 일치


def test_cases_are_covered_across_seeds(tmp_path_factory):
    total: Counter = Counter()
    for seed in SEEDS:
        total.update(run_game(seed, tmp_path_factory.mktemp(f"g{seed}"))[5])
    needed = {
        "잡기 1개 (사람이)": "capture_1_human", "잡기 1개 (로봇이)": "capture_1_robot",
        "업힌 말 둘 잡기": ["capture_2_human", "capture_2_robot"],
        "잡힌 말 1개 치우기": "capture_clear_1", "잡힌 말 2개 치우기": "capture_clear_2",
        "업기 (대기→칸)": "stack_on_board_from_wait", "업기 (칸→칸)": "stack_on_board_from_cell",
        "대기 2개에서 1개만 집기": "take_one_from_wait_stack", "업힌 말 둘 한 번에 이동": "move_stack_on_board",
        "완주 자리 2번째 도착": "goal_second_arrival", "업힌 말 둘 함께 완주": "goal_move_n2",
        "빽도 이동": "backdo_move",
    }
    missing = [k for k, v in needed.items() if not any(total[x] for x in ([v] if isinstance(v, str) else v))]
    assert not missing, f"시드 {SEEDS}에서 한 번도 안 나온 경우: {missing} (전체 집계 {dict(total)})"
