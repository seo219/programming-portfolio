import json
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from vision.detector import VisionDetector  # noqa: E402
from vision.yut_logic import Detection  # noqa: E402

BOX = (0.0, 0.0, 10.0, 10.0)
FRAME = np.zeros((10, 10, 3), dtype=np.uint8)


def dets(*labels, score=0.9):
    return [Detection(label, score, BOX) for label in labels]


class FakeClassifier:
    """프레임을 부를 때마다 미리 정한 Detection 목록을 순서대로 돌려줍니다."""

    def __init__(self, outputs):
        self._outputs = iter(outputs)

    def detect(self, frame):
        return next(self._outputs)


def yut_detector(tmp_path, outputs):
    slots = tmp_path / "slots.json"
    slots.write_text(json.dumps({"tray": [0, 0, 10, 10]}), encoding="utf-8")
    return VisionDetector(slots, frame_source=lambda: FRAME, yut_classifier=FakeClassifier(outputs))


# 규칙(docs/rules.md): 배 개수 → 도1 개2 걸3 윷4 모5(배 0개), 빽도-1
@pytest.mark.parametrize(
    "labels, flats, value",
    [
        (["down", "upper", "upper", "upper"], 1, 1),
        (["down", "down", "upper", "upper"], 2, 2),
        (["down", "down", "down", "upper"], 3, 3),
        (["down", "down", "down", "down"], 4, 4),
        (["upper", "upper", "upper", "upper"], 0, 5),
        (["backdo", "upper", "upper", "upper"], -1, -1),
    ],
)
def test_read_yut_all_frames_agree(tmp_path, labels, flats, value):
    result = yut_detector(tmp_path, [dets(*labels)] * 8).read_yut()
    assert (result.flats, result.value, result.confidence) == (flats, value, 1.0)


def test_read_yut_backdo_when_marked_stick_is_only_flat(tmp_path):
    # down 0개 + backdo 1개 + upper 3개 → 평평한 면 1개지만 표시 가락이므로 빽도
    result = yut_detector(tmp_path, [dets("backdo", "upper", "upper", "upper")] * 8).read_yut()
    assert (result.flats, result.value) == (-1, -1)


def test_read_yut_majority_6_of_8_accepted(tmp_path):
    outputs = [dets("down", "down", "upper", "upper")] * 6 + [dets("down", "upper", "upper", "upper")] * 2
    result = yut_detector(tmp_path, outputs).read_yut()
    assert (result.flats, result.value, result.confidence) == (2, 2, 0.75)


def test_read_yut_majority_5_of_8_rejected(tmp_path):
    outputs = [dets("down", "down", "upper", "upper")] * 5 + [dets("down", "upper", "upper", "upper")] * 3
    result = yut_detector(tmp_path, outputs).read_yut()
    assert (result.flats, result.value, result.confidence) == (None, None, 5 / 8)


def test_read_yut_wrong_stick_count_returns_none(tmp_path):
    result = yut_detector(tmp_path, [dets("down", "upper", "upper")] * 8).read_yut()
    assert (result.flats, result.value, result.confidence) == (None, None, 0.0)


def test_read_yut_without_classifier_raises(tmp_path):
    slots = tmp_path / "slots.json"
    slots.write_text(json.dumps({"tray": [0, 0, 10, 10]}), encoding="utf-8")
    with pytest.raises(RuntimeError):
        VisionDetector(slots, frame_source=lambda: FRAME).read_yut()


def test_existing_constructor_still_works():
    d = VisionDetector(ROOT / "config" / "slots.json")
    assert d.yut_classifier is None
    assert d.board_path == ROOT / "config" / "yut_board.json"


def gray(v):
    return np.full((36, 64, 3), v, dtype=np.uint8)


class FakeClock:
    """부를 때마다 step초씩 흐르는 시계 (실제로 기다리지 않음)."""

    def __init__(self, step=0.5):
        self.t, self.step = 0.0, step

    def __call__(self):
        self.t += self.step
        return self.t


def still_detector(tmp_path, frames, classifier=None, tray=(0, 0, 64, 36)):
    slots = tmp_path / "slots.json"
    slots.write_text(json.dumps({"tray": list(tray)}), encoding="utf-8")
    it = iter(frames)
    d = VisionDetector(slots, frame_source=lambda: next(it), yut_classifier=classifier)
    d._clock = FakeClock()
    return d


def test_wait_until_still_static_frames(tmp_path):
    d = still_detector(tmp_path, [gray(100)] * 15)
    d._clock = FakeClock(step=0.1)  # 정지 10장 연속이 timeout 안에 들어오도록
    assert d._wait_until_still()


def test_wait_until_still_keeps_changing(tmp_path):
    assert not still_detector(tmp_path, [gray(v) for v in range(0, 200, 10)])._wait_until_still()


def test_wait_until_still_moves_then_stops(tmp_path):
    frames = [gray(0), gray(60), gray(120)] + [gray(200)] * 13
    d = still_detector(tmp_path, frames)
    d._clock = FakeClock(step=0.1)  # timeout 안에 움직임 3장 + 정지 10장 이상이 들어오도록 천천히 흐르는 시계
    assert d._wait_until_still()


def half_up(v):
    """gray(v)에서 절반 픽셀만 1 높인 프레임. gray(v)와의 평균 절대차가 정확히 0.5."""
    f = gray(v)
    f[:18] += 1
    return f


def rolling_then_quiet():
    """움직임(차이 3) 뒤 7프레임 잠잠한 구간(차이 0.5)이 끼고 다시 움직이는 열."""
    moving = [gray(100), gray(103), gray(106)]
    quiet = [half_up(106), gray(106), half_up(106), gray(106), half_up(106), gray(106), half_up(106)]  # 차이 0.5가 7번
    return moving + quiet


def test_wait_until_still_ignores_short_quiet_while_rolling(tmp_path):
    # 잠잠한 구간이 7프레임(< STILL_FRAMES=10)이고 이후 계속 움직이므로 멈춘 것이 아님
    frames = rolling_then_quiet() + [gray(110 + 3 * k) for k in range(40)]
    d = still_detector(tmp_path, frames)
    d._clock = FakeClock(step=0.1)
    assert not d._wait_until_still()


def test_wait_until_still_true_after_quiet_then_12_still_frames(tmp_path):
    frames = rolling_then_quiet() + [gray(130 + 3 * k) for k in range(2)] + [gray(150)] * 13
    d = still_detector(tmp_path, frames)
    d._clock = FakeClock(step=0.1)
    assert d._wait_until_still()


def test_read_yut_halves_confidence_when_not_still(tmp_path):
    # 프레임이 계속 변함(대기 약 5장 소비 후 timeout) → 이후 8장은 같은 값이라 투표는 만장일치
    frames = [gray(v) for v in range(0, 100, 20)] + [gray(0)] * 8
    d = still_detector(tmp_path, frames, FakeClassifier([dets("down", "down", "upper", "upper")] * 8))
    result = d.read_yut()
    assert (result.flats, result.value, result.confidence) == (2, 2, 0.5)


def test_last_still_info_when_still(tmp_path):
    d = still_detector(tmp_path, [gray(100)] * 15)
    d._clock = FakeClock(step=0.1)
    assert d.last_still_info is None
    assert d._wait_until_still()
    info = d.last_still_info
    assert (info.still, info.frames, info.max_diff, info.last_diff) == (True, 10, 0.0, 0.0)
    assert info.diffs == [0.0] * 10 and info.waited_sec > 0


def test_last_still_info_on_timeout(tmp_path):
    d = still_detector(tmp_path, [gray(v) for v in range(0, 200, 10)])  # 프레임마다 차이 10, 시계 step 0.5라 약 5장 후 timeout
    assert not d._wait_until_still()
    info = d.last_still_info
    assert info.still is False and info.max_diff == info.last_diff == 10.0
    assert info.frames == len(info.diffs) > 0 and set(info.diffs) == {10.0}


def with_corner(v):
    """gray(100) 바탕의 오른쪽 아래 구석(트레이 밖)만 밝기 v로 바꾼 프레임."""
    f = gray(100)
    f[18:, 32:] = v
    return f


def test_wait_until_still_ignores_motion_outside_tray_roi(tmp_path):
    # 트레이(왼쪽 위 1/4)는 그대로이고 구석에서만 밝기가 계속 변하는 열 → ROI만 보면 정지
    frames = [with_corner(v) for v in range(0, 200, 10)] + [gray(100)] * 5
    d = still_detector(tmp_path, frames, tray=(0, 0, 32, 18))
    d._clock = FakeClock(step=0.05)
    assert d._wait_until_still()


def test_wait_until_still_sees_motion_inside_tray_roi(tmp_path):
    # 같은 열이라도 ROI가 전체 화면이면 구석의 변화가 보여 멈추지 않은 것으로 판정
    frames = [with_corner(v) for v in range(0, 200, 10)]
    d = still_detector(tmp_path, frames, tray=(0, 0, 64, 36))
    assert not d._wait_until_still()


def test_wait_until_still_unmeasured_tray_uses_full_frame(tmp_path):
    frames = [gray(v) for v in range(0, 200, 10)]
    d = still_detector(tmp_path, frames, tray=(0, 0, 0, 0))
    assert not d._wait_until_still()
