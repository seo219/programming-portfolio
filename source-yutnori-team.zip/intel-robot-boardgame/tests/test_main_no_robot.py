"""--no-robot: 로봇 대신 사람이 말을 옮기고, 나머지(비전·상태 머신·중계·DB·화면)는 실제 경로로 한 판이 도는지 확인합니다.

실제 카메라·Ollama 대신 가짜를 끼우되, main.build_yut()이 만드는 연결(HandRobot, 이동 확인 켜짐)은 그대로 씁니다.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import db.store  # noqa: E402
import llm.narrator  # noqa: E402
import main  # noqa: E402
from common.mock import ConsoleScreen, HandRobot, MockNarrator, random_flats, yut_result  # noqa: E402


class SeeingVision:
    """사람이 화면 안내대로 말을 옮겼다고 보고, 게임이 기대한 판을 그대로 읽어 줍니다."""

    def __init__(self):
        self.orch = None
        self.board_reads = 0

    def read_yut(self):
        return yut_result(random_flats())

    def board_state(self):
        self.board_reads += 1
        return self.orch._expected_board()


def build(monkeypatch, tmp_path):
    vision, screen = SeeingVision(), ConsoleScreen(choices=[], quiet=True)
    monkeypatch.setattr(main, "build_vision", lambda yut: vision)
    monkeypatch.setattr(main, "build_screen", lambda ui: screen)
    monkeypatch.setattr(llm.narrator, "OllamaNarrator", MockNarrator)
    real_store = db.store.SqliteStore
    monkeypatch.setattr(db.store, "SqliteStore", lambda path: real_store(tmp_path / "games.db"))
    orch = main.build_yut(mock=False, no_robot=True)
    vision.orch = orch
    return orch, vision, screen


def test_no_robot_uses_hand_robot_and_verifies_moves(monkeypatch, tmp_path):
    orch, vision, screen = build(monkeypatch, tmp_path)
    assert isinstance(orch.dev.robot, HandRobot) and orch.verify_moves
    winner = orch.run()
    assert winner in ("human", "robot")
    moves = [h for h in screen.helps if h.startswith("[로봇 대신]")]
    assert moves and len(moves) == len(screen.helps)  # 사람에게 부탁한 것은 말 옮기기뿐 (판 불일치 없음)
    clears = [h for h in moves if "의 말을 wait_" in h]  # 잡힌 말 치우기는 이어지는 내 말 이동과 함께 확인
    assert vision.board_reads == len(moves) - len(clears)  # 말을 옮길 때마다 판 전체 확인


def test_hand_robot_move_asks_on_screen():
    screen = ConsoleScreen(quiet=True)
    assert HandRobot(screen).move("cell_3", "wait_human") is True
    assert "cell_3" in screen.helps[0] and "wait_human" in screen.helps[0]


def test_camera_indices_reach_detector(monkeypatch):
    import vision.detector

    monkeypatch.setitem(main.CAMERAS, "tray", 2)
    monkeypatch.setitem(main.CAMERAS, "board", 1)
    det = main.build_vision(yut=False)  # 카메라는 처음 읽을 때 열리므로 여기서는 열지 않음
    assert isinstance(det, vision.detector.VisionDetector)
    assert (det.camera_index, det.board_camera_index) == (2, 1)
