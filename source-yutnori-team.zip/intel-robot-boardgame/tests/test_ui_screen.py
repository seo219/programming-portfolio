"""게임 화면(pygame) 헤드리스 테스트: SDL dummy 드라이버로 창 없이 그리기·입력·닫기를 확인합니다."""
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import pygame  # noqa: E402
import pytest  # noqa: E402

from common.interfaces import GameState, YutState  # noqa: E402
from ui import yut_view  # noqa: E402
from ui.screen import GameScreen  # noqa: E402


@pytest.fixture
def screen():
    s = GameScreen(throw_seconds=0.05, hold_seconds=0)
    yield s
    s.close()


def yut_state(**kw) -> YutState:
    pieces = {"robot": ["cell_7", "cell_7"], "human": ["wait_human", "cell_12"]}
    return YutState(pieces=pieces, **kw)


def post_key(key):
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=key))


def test_board_layout_contains_all_cells():
    data = json.loads((ROOT / "config" / "yut_board.json").read_text(encoding="utf-8"))
    expected = {k for k in data["layout"] if not k.startswith("_")}
    layout = yut_view.load_layout()
    assert set(layout["cells"]) == expected
    assert len(expected) == 29
    # 모든 칸이 선으로 이어져 있고, 선의 양끝은 모두 존재하는 칸
    linked = {c for edge in layout["edges"] for c in edge}
    assert linked == expected


def test_update_draws_yut_state(screen, tmp_path):
    screen.update(yut_state(pending=[4, 5], current="robot", turn=3), "로봇 차례")
    assert not screen.closed
    pygame.image.save(screen.surface, str(tmp_path / "a.png"))
    screen.update(yut_state(winner="human"), "끝")  # 결과 화면도 깨지지 않음


def test_update_dice_game_state(screen):
    screen.update(GameState(positions={"human": 1, "robot": 2}), "주사위 골격")
    assert not screen.closed


def test_show_throw_all_results(screen):
    for flats, name in [(-1, "빽도"), (0, "모"), (1, "도"), (2, "개"), (3, "걸"), (4, "윷")]:
        screen.show_throw(flats, name)
    assert not screen.closed


def test_ask_choice_by_digit_key(screen):
    screen.update(yut_state())
    post_key(pygame.K_2)
    assert screen.ask_choice(["말1(cell_7)에 윷(4칸)", "말2(cell_7)에 윷(4칸)"]) == 1


def test_ask_choice_ignores_out_of_range_key(screen):
    screen.update(yut_state())
    post_key(pygame.K_5)  # 보기는 2개뿐이라 무시
    post_key(pygame.K_1)
    assert screen.ask_choice(["가", "나"]) == 0


def test_ask_choice_by_mouse_click(screen):
    screen.update(yut_state())
    rect = yut_view.choice_rects(3)[2]
    pygame.event.post(pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=rect.center, button=1))
    assert screen.ask_choice(["가", "나", "다"]) == 2


def test_ask_help_returns_on_enter(screen):
    post_key(pygame.K_RETURN)
    screen.ask_help("말을 옮겨 주세요")


def test_ask_help_returns_on_button_click(screen):
    btn = yut_view.YutView.help_button(size=pygame.display.get_surface().get_size())
    pygame.event.post(pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=btn.center, button=1))
    screen.ask_help("확인 버튼을 눌러 주세요")


def test_window_close_during_ask_choice_is_safe(screen):
    screen.update(yut_state())
    pygame.event.post(pygame.event.Event(pygame.QUIT))
    assert screen.ask_choice(["가", "나"]) == 0
    assert screen.closed
    # 닫힌 뒤의 호출도 예외 없이 지나감
    screen.update(yut_state(), "x")
    screen.show_throw(2, "개")
    assert screen.ask_choice(["가"]) == 0
    screen.ask_help("무시")
    screen.close()


def test_window_close_during_ask_help_is_safe(screen):
    pygame.event.post(pygame.event.Event(pygame.QUIT))
    screen.ask_help("닫기")
    assert screen.closed


def test_option_slot_parsing():
    assert yut_view.option_slot("말1(cell_7)에 윷(4칸)") == "cell_7"
    assert yut_view.option_slot("말2(wait_human)에 모(5칸)") == "wait_human"
    assert yut_view.option_slot("그냥 문구") is None


def test_korean_font_found():
    pygame.font.init()
    from ui import theme
    if theme.find_font_path() is None:
        pytest.skip("한글 폰트가 없는 환경")
    assert Path(theme.find_font_path()).exists()


def test_pending_shown_as_names():
    assert yut_view.load_yut_names() == {-1: "빽도", 1: "도", 2: "개", 3: "걸", 4: "윷", 5: "모"}


def test_show_throw_holds_result_then_skips_on_key():
    import time
    s = GameScreen(throw_seconds=0, hold_seconds=5)  # 애니메이션 없이 곧바로 결과 단계
    try:
        post_key(pygame.K_SPACE)
        start = time.monotonic()
        s.show_throw(2, "개")
        assert time.monotonic() - start < 2  # 결과가 나온 뒤 키를 누르면 5초를 안 기다림
    finally:
        s.close()


def test_show_throw_holds_when_not_skipped():
    import time
    s = GameScreen(throw_seconds=0.05, hold_seconds=0.4)
    try:
        start = time.monotonic()
        s.show_throw(3, "걸")
        assert time.monotonic() - start >= 0.4
    finally:
        s.close()


def test_ask_flats_on_screen_maps_choice_to_flats():
    from game.wrapper import FLATS_CHOICES, ask_flats_on_screen

    class Fake:
        def __init__(self, k):
            self.k, self.seen = k, None

        def ask_choice(self, options):
            self.seen = options
            return self.k

    assert [ask_flats_on_screen(Fake(k))() for k in range(6)] == [1, 2, 3, 4, 0, -1]
    f = Fake(0)
    ask_flats_on_screen(f)()
    assert f.seen == [label for label, _ in FLATS_CHOICES]
    assert ask_flats_on_screen(Fake(99))() == 1  # 범위 밖이면 첫 보기
