"""--mock --db: 하드웨어 없이 한 판을 돌려 SQLite에 기록되는지 확인합니다."""
import io
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import main  # noqa: E402
from common.mock import MockStore  # noqa: E402
from db.store import SqliteStore  # noqa: E402


def test_mock_without_db_uses_mock_store():
    assert isinstance(main.mock_store(None), MockStore)


def test_mock_yut_game_writes_sqlite(tmp_path, monkeypatch):
    monkeypatch.setattr(sys, "stdin", io.StringIO(""))  # 입력이 끝나면 사람 윷은 랜덤, 말 선택은 0번
    db = tmp_path / "mock.db"
    game = main.build_yut(mock=True, db=db)
    assert isinstance(game.store, SqliteStore)
    winner = game.run()
    game.store.close()

    conn = sqlite3.connect(db)
    (games_winner, total_turns), = conn.execute("SELECT winner, total_turns FROM games").fetchall()
    moves = conn.execute("SELECT COUNT(*) FROM turns WHERE from_pos IS NOT NULL AND to_pos IS NOT NULL").fetchone()[0]
    throws = conn.execute("SELECT COUNT(*) FROM events WHERE kind = 'throw'").fetchone()[0]
    conn.close()
    assert games_winner == winner
    assert total_turns > 0 and moves > 0 and throws > 0
