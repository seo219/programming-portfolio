"""판 칸 좌표 로더와 초안 변환 스크립트 테스트."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

import make_board_cells  # noqa: E402
from robot.slots import SLOT_ALIASES  # noqa: E402  (대조용, 비전 코드에서는 import하지 않음)
from vision.board_cells import board_cell_names, load_board_cells  # noqa: E402

DRAFT = ROOT / "config" / "slots_draft_v2.json"
BOARD = ROOT / "config" / "yut_board.json"


def expected_names():
    """기대 이름을 직접 나열: cell_0~19와 지름길 9칸."""
    return ([f"cell_{i}" for i in range(20)] + ["center"]
            + [f"diag_r{i}" for i in range(1, 5)] + [f"diag_l{i}" for i in range(1, 5)])


@pytest.fixture
def made(tmp_path):
    out = tmp_path / "board_cells.json"
    assert make_board_cells.main(["--draft", str(DRAFT), "--out", str(out)]) == 0
    return out


def _edit(made, fn):
    data = json.loads(made.read_text(encoding="utf-8"))
    fn(data["cells"])
    made.write_text(json.dumps(data), encoding="utf-8")


def test_board_cell_names_29():
    names = board_cell_names(BOARD)
    assert sorted(names) == sorted(expected_names())
    assert len(names) == 29
    assert not any(f"cell_{i}" in names for i in range(20, 29))


def test_draft_to_game_name_matches_slot_aliases():
    assert make_board_cells.DRAFT_TO_GAME_NAME == {v: k for k, v in SLOT_ALIASES.items()}


def test_convert_and_load(made):
    cells = load_board_cells(made, BOARD)
    assert len(cells) == 29
    draft = json.loads(DRAFT.read_text(encoding="utf-8"))
    assert (cells["diag_r1"].x, cells["diag_r1"].y) == (draft["cell_20"]["x"], draft["cell_20"]["y"])
    assert cells["center"].roi_r == draft["cell_22"]["roi_r"]
    assert cells["cell_7"].x == draft["cell_7"]["x"]
    assert "초안" in json.loads(made.read_text(encoding="utf-8"))["_comment"]


def test_load_missing_file(tmp_path):
    with pytest.raises(FileNotFoundError, match="make_board_cells.py"):
        load_board_cells(tmp_path / "none.json", BOARD)


def test_load_missing_cell(made):
    _edit(made, lambda c: c.pop("diag_l4"))
    with pytest.raises(ValueError, match="diag_l4"):
        load_board_cells(made, BOARD)


def test_load_unknown_draft_name(made):
    _edit(made, lambda c: c.update(cell_22=c["center"]))
    with pytest.raises(ValueError, match="cell_22.*게임 칸 이름"):
        load_board_cells(made, BOARD)


def test_load_zero_roi(made):
    _edit(made, lambda c: c["cell_3"].update(roi_r=0))
    with pytest.raises(ValueError, match="cell_3"):
        load_board_cells(made, BOARD)


def test_load_string_coordinate(made):
    _edit(made, lambda c: c["cell_4"].update(x="100"))
    with pytest.raises(ValueError, match="cell_4"):
        load_board_cells(made, BOARD)


def test_no_overwrite_without_force(made):
    made.write_text("keep", encoding="utf-8")
    assert make_board_cells.main(["--draft", str(DRAFT), "--out", str(made)]) == 1
    assert made.read_text(encoding="utf-8") == "keep"
    assert make_board_cells.main(["--draft", str(DRAFT), "--out", str(made), "--force"]) == 0
    assert len(load_board_cells(made, BOARD)) == 29
