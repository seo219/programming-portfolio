"""실제 카메라로 윷 인식(read_yut)을 사람이 눈으로 시험하는 도구입니다.

사용법 (프로젝트 .venv에서):
    python scripts/try_read_yut.py --camera 0                          # 카메라 실시간 미리보기
    python scripts/try_read_yut.py --image data/yukk_1/gae/xxx.jpg     # 사진 한 장으로 한 번 읽고 종료(창 없음)

화면 표시: 가락 박스(down 초록, backdo 빨강, upper 파랑)와 라벨·점수, 위쪽에 검출 수와 배 개수.
키: 스페이스=read_yut() 실행 후 결과 출력(+기록), o/x=직전 결과를 맞음/틀림으로 표시, q/Esc=종료,
    스페이스 결과는 data/yut_logs/yut_try_<시각>.csv(줄별 즉시 저장)와 data/yut_logs/yut_try_<시각>/NNN_<이름>.jpg(박스 그린 원본 해상도 사진),
    종료 시 요약 data/yut_logs/yut_try_<시각>.txt로 남습니다.
    c=정지 보정(2구간: 가만히 4초 -> 윷 굴림 4초, 각 구간 앞에 1초 준비. 프레임마다 평균차와 변화 픽셀 비율을
      출력하고 구간별 요약·비교와 data/yut_logs/yut_calib_*.csv·.txt 저장. 판정 로직은 바꾸지 않는 진단용).

시험 순서:
  1) c를 누르고 안내에 따라 가만히 두었다가 굴린 뒤, 두 지표 중 구분이 잘 되는 쪽과 기준값을 정합니다.
  2) 윷을 던지고 멎은 뒤 스페이스로 결과를 확인합니다. 정지 대기에 걸리면 confidence가 절반으로 줄어듭니다.
  3) 틀린 경우 사진은 따로 저장하지 않으니 필요하면 화면을 직접 캡처합니다.

노출·화이트밸런스는 아직 고정하지 않았다.
"""
import argparse
import csv
import json
import sys
import time
from collections import Counter
from datetime import datetime
from functools import lru_cache
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vision.detector import (  # noqa: E402
    STILL_DIFF_THRESH, STILL_FRAMES, STILL_SIZE, VisionDetector, YUT_BOARD_PATH)
from vision.yut_logic import flats_from_detections  # noqa: E402
from vision.yut_model import DEFAULT_YUT_MODEL_DIR, ModelApiYutClassifier  # noqa: E402

WINDOW = "try_read_yut"
SHOW_WIDTH = 960  # 화면에 보여 줄 가로 크기
CALIB_PHASE_SECONDS = 4.0  # 정지 보정 한 구간의 기록 시간
CALIB_READY_SECONDS = 1.0  # 구간 안내 후 기록 전에 주는 준비 시간
CALIB_PIXEL_SIZE = (320, 180)  # 변화 픽셀 비율을 셀 때의 그레이 크기(가락이 작아도 평균에 안 묻히게 평균차보다 크게)
CALIB_PIXEL_DIFF = 25  # 이 값(0~255)보다 크게 바뀐 픽셀을 '변화한 픽셀'로 센다. 센서 잡음(수 단계)보다 충분히 큼
CALIB_DUP_EPS = 0.005  # 평균차가 이 값 미만(소수 둘째 자리로 0.00)이면 카메라가 준 중복 프레임으로 봄
LOG_DIR = ROOT / "data" / "yut_logs"  # 정지 보정·읽기 시험 기록을 모아 두는 곳(data/는 git 제외)
CALIB_PHASES = (("가만히", "[1/2] 가만히 두세요", "[1/2] Hold still"),
                ("굴림", "[2/2] 이제 윷을 화면 안에서 굴리세요", "[2/2] Now roll the yut in view"))
# 화면에 한글을 그릴 폰트 후보(앞쪽 우선). OpenCV 기본 폰트는 한글을 못 그려 Pillow로 그린다
FONT_CANDIDATES = ("C:/Windows/Fonts/malgun.ttf", "C:/Windows/Fonts/malgunbd.ttf", "C:/Windows/Fonts/NanumGothic.ttf",
                   "C:/Windows/Fonts/gulim.ttc", "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
                   "/System/Library/Fonts/AppleSDGothicNeo.ttc")
FONT_SIZE = 24
RESULT_SECONDS = 4.0  # 스페이스 결과를 화면에 남겨 두는 시간
GREEN, RED, BLUE, WHITE, YELLOW = (0, 255, 0), (0, 0, 255), (255, 0, 0), (255, 255, 255), (0, 255, 255)
LABEL_COLORS = {"down": GREEN, "backdo": RED, "upper": BLUE}


def yut_name(flats) -> str:
    """flats를 yut_board.json의 이름으로 바꿉니다. 인식 실패면 '-'."""
    if flats is None:
        return "-"
    table = json.loads(YUT_BOARD_PATH.read_text(encoding="utf-8"))["yut"]
    return table[str(flats)][0]


def read_once(detector: VisionDetector):
    """read_yut()를 한 번 실행해 결과 한 줄을 콘솔에 출력하고 (화면용 글자, 결과, 걸린 시간)을 돌려줍니다."""
    t0 = time.perf_counter()
    result = detector.read_yut()
    elapsed = time.perf_counter() - t0
    line = (f"flats={result.flats} value={result.value} 이름={yut_name(result.flats)} "
            f"confidence={result.confidence:.2f} 걸린 시간={elapsed:.2f}초")
    print(line)
    return line, result, elapsed


def draw_boxes(frame, detections):
    """원본 해상도 프레임 복사본에 검출 박스와 라벨·점수를 그립니다."""
    shown = frame.copy()
    for d in detections:
        x1, y1, x2, y2 = (int(v) for v in d.box)
        color = LABEL_COLORS.get(d.label, WHITE)
        cv2.rectangle(shown, (x1, y1), (x2, y2), color, 3)
        cv2.putText(shown, f"{d.label} {d.score:.2f}", (x1, max(y1 - 8, 20)), cv2.FONT_HERSHEY_SIMPLEX, 1.0, color, 2)
    return shown


def draw(frame, detections):
    """검출 박스를 그린 축소 이미지와 배 개수(flats)를 돌려줍니다."""
    shown = draw_boxes(frame, detections)
    flats = flats_from_detections(detections)
    scale = SHOW_WIDTH / shown.shape[1]
    return cv2.resize(shown, None, fx=scale, fy=scale), flats


def find_font_path(candidates=FONT_CANDIDATES):
    """후보 중 실제로 있는 첫 폰트 경로. 하나도 없으면 None."""
    return next((c for c in candidates if Path(c).is_file()), None)


@lru_cache(maxsize=1)
def load_font():
    """한글 폰트를 한 번만 불러옵니다. 없으면 경고 한 줄을 내고 None."""
    path = find_font_path()
    if path is None:
        print("경고: 한글 폰트를 찾지 못해 화면 문구를 영어로 표시합니다 (FONT_CANDIDATES 참고)")
        return None
    return ImageFont.truetype(path, FONT_SIZE)


def choose_text(text: str, alt, has_font: bool) -> str:
    """폰트가 있으면 text, 없으면 대체 문구(alt, 없으면 text의 ASCII 글자만)를 고릅니다."""
    if has_font:
        return text
    return alt if alt is not None else (text.encode("ascii", "ignore").decode().strip() or "-")


def draw_texts(image, items) -> None:
    """items=[(문구, 대체 문구 또는 None, 행, 색 BGR)]를 image에 한 번에 그립니다 (Pillow 변환은 프레임당 한 번)."""
    if not items:
        return
    font = load_font()
    if font is None:
        for text, alt, row, color in items:
            cv2.putText(image, choose_text(text, alt, False), (10, 30 + 32 * row), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
        return
    canvas = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(canvas)
    for text, _, row, color in items:
        draw.text((10, 8 + 32 * row), text, font=font, fill=color[::-1])
    image[:] = cv2.cvtColor(np.asarray(canvas), cv2.COLOR_RGB2BGR)


def frame_metrics(prev, cur) -> tuple[float, float]:
    """두 프레임(BGR 또는 그레이)에서 (평균차, 변화 픽셀 비율 %)를 돌려줍니다.

    평균차는 detector와 같은 STILL_SIZE 축소 그레이의 절대차 평균, 변화 비율은 320x180 그레이에서
    절대차가 CALIB_PIXEL_DIFF를 넘는 픽셀의 비율입니다."""
    def gray(f, size):
        g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY) if f.ndim == 3 else f
        return cv2.resize(g, size, interpolation=cv2.INTER_AREA)
    mean_diff = float(cv2.absdiff(gray(cur, STILL_SIZE), gray(prev, STILL_SIZE)).mean())
    changed = cv2.absdiff(gray(cur, CALIB_PIXEL_SIZE), gray(prev, CALIB_PIXEL_SIZE)) > CALIB_PIXEL_DIFF
    return mean_diff, float(changed.mean() * 100)


def describe(values) -> str:
    """최소/평균/최대/95퍼센타일 한 줄 요약."""
    v = np.asarray(values, dtype=float)
    return f"최소 {v.min():.2f} / 평균 {v.mean():.2f} / 최대 {v.max():.2f} / 95% {np.percentile(v, 95):.2f}"


def exceed_pct(values, limit: float) -> float:
    """values 중 limit을 넘은 비율(%)."""
    return float((np.asarray(values, dtype=float) > limit).mean() * 100)


def show_guide(detector: VisionDetector, text: str, alt: str, seconds: float, sub=None) -> None:
    """미리보기가 멈추지 않게 프레임을 계속 그리며 안내 문구를 화면에 띄웁니다."""
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        frame = detector._grab()
        shown = cv2.resize(frame, None, fx=SHOW_WIDTH / frame.shape[1], fy=SHOW_WIDTH / frame.shape[1])
        draw_texts(shown, [(text, alt, 0, YELLOW)] + ([(sub[0], sub[1], 1, WHITE)] if sub else []))
        cv2.imshow(WINDOW, shown)
        cv2.waitKey(1)


def build_summary(rows, conditions) -> str:
    """구간별 요약·비교·측정 조건을 한 문자열로 만듭니다 (콘솔 출력과 txt 저장에 같이 씀).

    rows: 구간 이름 -> [(평균차, 변화 %, 중복 여부)]"""
    lines, stats = [], {}  # stats: 구간 이름 -> (평균차 목록, 변화 % 목록), 중복 프레임 제외
    for name, data in rows.items():
        valid = [r for r in data if not r[2]]
        stats[name] = ([r[0] for r in valid], [r[1] for r in valid])
        lines.append(f"\n[{name}] 프레임 {len(data)}개 (중복 {len(data) - len(valid)}개 제외)")
        if valid:
            lines.append(f"  평균차   {describe(stats[name][0])}")
            lines.append(f"  변화픽셀 {describe(stats[name][1])} (%)")
    still, roll = stats["가만히"], stats["굴림"]
    if still[0] and roll[0]:
        lines.append("\n비교 (굴림 중앙값은 참고용)")
        for i, label, unit in ((0, "평균차", ""), (1, "변화픽셀", "%")):
            limit = max(still[i])
            lines.append(f"  {label}: 가만히 최대 {limit:.2f}{unit} vs 굴림 최대 {max(roll[i]):.2f}{unit}, "
                         f"굴림 중앙값 {np.median(roll[i]):.2f}{unit}, 굴림 중 가만히 최대 초과 {exceed_pct(roll[i], limit):.1f}%")
        lines.append("구분이 잘 되는 지표와, 가만히 최대와 굴림 중앙값 사이 값을 알려 주세요.")
    else:
        lines.append("\n유효한 프레임이 부족해 비교하지 못했습니다.")
    lines.append("\n측정 조건")
    lines.extend(f"  {c}" for c in conditions)
    return "\n".join(lines)


def calibrate(detector: VisionDetector) -> None:
    """가만히 -> 굴림 2구간에서 두 지표를 기록해 비교합니다 (진단 전용, 판정 로직은 그대로)."""
    rows, size = {}, None  # rows: 구간 이름 -> [(평균차, 변화 %, 중복 여부)], size: 프레임 (가로, 세로)
    for name, guide, guide_alt in CALIB_PHASES:
        print(f"{guide} ({CALIB_PHASE_SECONDS:.0f}초)")
        show_guide(detector, guide, guide_alt, CALIB_READY_SECONDS, ("곧 기록을 시작합니다", "Recording soon"))
        rows[name], prev = [], None
        end = time.monotonic() + CALIB_PHASE_SECONDS
        while time.monotonic() < end:
            frame = detector._grab()
            size = (frame.shape[1], frame.shape[0])
            shown = cv2.resize(frame, None, fx=SHOW_WIDTH / frame.shape[1], fy=SHOW_WIDTH / frame.shape[1])
            draw_texts(shown, [(guide, guide_alt, 0, YELLOW), ("기록 중", "Recording", 1, WHITE)])
            cv2.imshow(WINDOW, shown)
            cv2.waitKey(1)
            if prev is not None:
                mean_diff, changed = frame_metrics(prev, frame)
                dup = mean_diff < CALIB_DUP_EPS
                rows[name].append((mean_diff, changed, dup))
                print(f"  평균차 {mean_diff:.2f} / 변화픽셀 {changed:.2f}%" + (" (중복 프레임)" if dup else ""))
            prev = frame

    now = datetime.now()
    conditions = [f"측정 시각: {now:%Y-%m-%d %H:%M:%S}",
                  f"카메라 번호: {detector.camera_index} / 프레임 해상도: {size[0]}x{size[1]}" if size else "카메라 번호: -",
                  f"STILL_DIFF_THRESH={STILL_DIFF_THRESH} STILL_SIZE={STILL_SIZE} STILL_FRAMES={STILL_FRAMES} "
                  f"CALIB_PIXEL_DIFF={CALIB_PIXEL_DIFF}"]
    summary = build_summary(rows, conditions)
    print(summary)  # 콘솔과 txt에 같은 문자열을 씀

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    stem = LOG_DIR / f"yut_calib_{now:%Y%m%d_%H%M%S}"
    with stem.with_suffix(".csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["phase", "mean_diff", "changed_pct", "is_duplicate"])
        for name, data in rows.items():
            writer.writerows((name, f"{m:.4f}", f"{c:.4f}", int(d)) for m, c, d in data)
    stem.with_suffix(".txt").write_text(summary + "\n", encoding="utf-8")
    print(f"저장: {stem.with_suffix('.csv')} , {stem.with_suffix('.txt')}")


TRY_FIELDS = ["seq", "time", "flats", "value", "name", "confidence", "elapsed_sec", "detections", "verdict", "image",
              "wait_sec", "still_ok", "wait_frames", "wait_max_diff", "wait_last_diff"]  # 뒤 5개는 정지 대기 진단
NAME_SLUGS = {"도": "do", "개": "gae", "걸": "gurl", "윷": "yut", "모": "mo", "빽도": "backdo", "실패": "fail"}  # 사진 파일명용(한글 피함)


def write_trials_csv(path: Path, rows) -> None:
    """시도 기록 전체를 CSV로 다시 씁니다 (줄이 몇 개 안 되고, 시도·o/x마다 불러 도중 종료에도 남게 함)."""
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=TRY_FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def build_trial_summary(rows, conditions) -> str:
    """시험 세션 기록(rows: write_trials_csv의 행 dict 목록)을 요약 문자열로 만듭니다."""
    ok = sum(r["verdict"] == "ok" for r in rows)
    wrong = sum(r["verdict"] == "wrong" for r in rows)
    confs = [float(r["confidence"]) for r in rows]
    elapsed = [float(r["elapsed_sec"]) for r in rows]
    lines = [f"총 시도 {len(rows)}회 / 맞음(o) {ok} / 틀림(x) {wrong} / 미표시 {len(rows) - ok - wrong}",
             "정답률 " + (f"{ok / (ok + wrong) * 100:.1f}% (o/(o+x))" if ok + wrong else "- (o/x 표시 없음)")]
    if rows:
        counts = Counter(r["name"] for r in rows)
        lines.append("이름별 횟수: " + ", ".join(f"{n} {c}" for n, c in counts.items()))
        lines.append(f"confidence 평균 {sum(confs) / len(confs):.2f} / 최소 {min(confs):.2f}")
        lines.append(f"평균 걸린 시간 {sum(elapsed) / len(elapsed):.2f}초")
        lines.append(f"인식 실패(None) {sum(r['flats'] in ('', None) for r in rows)}회")
        waits = [r for r in rows if r.get("wait_sec") not in (None, "")]
        if waits:
            timeouts = sum(int(r["still_ok"]) == 0 for r in waits)
            max_diffs = [float(r["wait_max_diff"]) for r in waits]
            lines.append(f"정지 대기 평균 {sum(float(r['wait_sec']) for r in waits) / len(waits):.2f}초 / "
                         f"타임아웃 {timeouts}회 ({timeouts / len(waits) * 100:.0f}%)")
            lines.append(f"대기 중 최대 diff 평균 {sum(max_diffs) / len(max_diffs):.2f} / 최대 {max(max_diffs):.2f}")
    lines.append("\n측정 조건")
    lines.extend(f"  {c}" for c in conditions)
    return "\n".join(lines)


def record_trial(detector: VisionDetector, rows, session_dir: Path, csv_path: Path):
    """스페이스 한 번 분량: 윷을 읽고 기록 한 줄을 CSV에 쓰고, 사진을 저장합니다. (화면용 글자, 해상도)를 돌려줍니다."""
    line, result, elapsed = read_once(detector)
    # read_yut 내부를 건드리지 않으려고, 읽은 직후 프레임을 다시 받아 같은 분류기로 검출해 그린다
    # (read_yut가 마지막으로 본 프레임과 미세하게 다를 수 있음)
    frame = detector._grab()
    detections = detector.yut_classifier.detect(frame)
    name = yut_name(result.flats) if result.flats is not None else "실패"
    seq = len(rows) + 1
    image = f"{seq:03d}_{NAME_SLUGS.get(name, 'fail')}.jpg"
    session_dir.mkdir(parents=True, exist_ok=True)
    info = detector.last_still_info  # read_yut 안의 정지 대기 진단 기록
    if info is not None:
        with (session_dir / f"{seq:03d}_wait.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["idx", "diff"])
            writer.writerows(enumerate(info.diffs))
        line += f" / 대기 {info.waited_sec:.1f}초"
    cv2.imwrite(str(session_dir / image), draw_boxes(frame, detections))
    rows.append({"seq": seq, "time": f"{datetime.now():%H:%M:%S}", "flats": "" if result.flats is None else result.flats,
                 "value": "" if result.value is None else result.value, "name": name,
                 "confidence": f"{result.confidence:.4f}", "elapsed_sec": f"{elapsed:.3f}",
                 "detections": " ".join(f"{d.label}:{d.score:.2f}" for d in detections), "verdict": "",
                 "image": f"{session_dir.name}/{image}",
                 **({} if info is None else {
                     "wait_sec": f"{info.waited_sec:.3f}", "still_ok": int(info.still), "wait_frames": info.frames,
                     "wait_max_diff": f"{info.max_diff:.3f}", "wait_last_diff": f"{info.last_diff:.3f}"})})
    write_trials_csv(csv_path, rows)
    return line, (frame.shape[1], frame.shape[0])


def run_image(detector: VisionDetector, frame) -> None:
    detections = detector.yut_classifier.detect(frame)
    print(f"검출 {len(detections)}개, 배 개수 {flats_from_detections(detections)}")
    read_once(detector)


def run_camera(detector: VisionDetector, model_name: str) -> None:
    try:
        detector._grab()  # private이지만 같은 패키지 도구라 직접 씀: 카메라 하나를 미리보기와 read_yut이 공유
    except RuntimeError as e:
        detector.close()
        raise SystemExit(f"카메라를 열 수 없습니다: {e}\n--camera 번호를 바꿔 보거나 다른 프로그램이 카메라를 쓰는지 확인하세요.")
    print("실시간 미리보기 시작. 스페이스=윷 읽기, o=맞음, x=틀림(직전 결과), c=정지 보정, q/Esc=종료")
    message, message_until = "", 0.0
    started = datetime.now()
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    stem = LOG_DIR / f"yut_try_{started:%Y%m%d_%H%M%S}"
    rows, size = [], None
    try:
        while True:
            frame = detector._grab()
            detections = detector.yut_classifier.detect(frame)
            shown, flats = draw(frame, detections)
            texts = [(f"detections: {len(detections)}  flats: {flats}", None, 0, YELLOW),
                     ("스페이스=읽기  o=맞음  x=틀림  c=보정  q=종료", "space=read o=ok x=wrong c=calib q=quit", 2, WHITE)]
            if time.monotonic() < message_until:
                texts.append((message, None, 1, WHITE))
            draw_texts(shown, texts)
            cv2.imshow(WINDOW, shown)
            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord("q")):
                break
            if key == ord(" "):
                message, size = record_trial(detector, rows, stem, stem.with_suffix(".csv"))
                message_until = time.monotonic() + RESULT_SECONDS
            elif key in (ord("o"), ord("x")) and rows:
                rows[-1]["verdict"] = "ok" if key == ord("o") else "wrong"
                write_trials_csv(stem.with_suffix(".csv"), rows)
                message, message_until = f"#{rows[-1]['seq']} {rows[-1]['name']}: {rows[-1]['verdict']}", time.monotonic() + RESULT_SECONDS
            elif key == ord("c"):
                calibrate(detector)
    finally:
        detector.close()
        cv2.destroyAllWindows()
        if rows:
            conditions = [f"시작 시각: {started:%Y-%m-%d %H:%M:%S}",
                          f"카메라 번호: {detector.camera_index} / 프레임 해상도: {size[0]}x{size[1]}",
                          f"STILL_DIFF_THRESH={STILL_DIFF_THRESH} STILL_SIZE={STILL_SIZE} STILL_FRAMES={STILL_FRAMES}",
                          f"모델 폴더: {model_name}"]
            summary = build_trial_summary(rows, conditions)
            print(summary)
            stem.with_suffix(".txt").write_text(summary + "\n", encoding="utf-8")
            print(f"저장: {stem.with_suffix('.csv')} , {stem.with_suffix('.txt')} , 사진 {stem}/")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("--camera", type=int, default=0)
    parser.add_argument("--model", type=Path, default=DEFAULT_YUT_MODEL_DIR, help="model.xml이 든 폴더")
    parser.add_argument("--device", default="CPU")
    parser.add_argument("--image", type=Path, help="카메라 대신 사진 한 장으로 한 번 읽고 종료")
    args = parser.parse_args()

    try:
        classifier = ModelApiYutClassifier(args.model, args.device)
    except FileNotFoundError as e:
        raise SystemExit(str(e))
    frame = None
    if args.image:
        frame = cv2.imread(str(args.image))
        if frame is None:
            raise SystemExit(f"사진을 읽을 수 없습니다: {args.image}")
    # 사진 모드는 같은 사진을 반복해 주므로 정지 대기가 바로 통과한다
    detector = VisionDetector(ROOT / "config" / "slots.json", camera_index=args.camera, yut_classifier=classifier,
                              frame_source=(lambda: frame) if frame is not None else None)
    if frame is not None:
        run_image(detector, frame)
    else:
        run_camera(detector, args.model.name)


if __name__ == "__main__":
    main()
