"""칸 이동 반복 시험 (실제 로봇 필요). 사람이 직접 실행합니다. 보고서의 합격선: 한 칸 이동 10회 중 9회 성공.

두 칸 사이로 말 하나를 왕복시키며, 이동할 때마다 사람이 성공 여부(말이 제자리에 놓였나)를 입력합니다.
컨트롤러의 True/False는 "동작이 끝까지 실행됐다"는 뜻일 뿐이라, 말이 실제로 놓였는지는 사람이 판단합니다.

  python scripts/test_robot_moves.py --src cell_0 --dst cell_1 --repeat 10
  python scripts/test_robot_moves.py --src cell_0 --dst cell_1 --check     # 로봇 없이 준비 상태만 점검

시작 전에 src 칸에 말 1개를 올려 두세요. 로봇은 먼저 home으로 갔다가 움직입니다.
"""
import argparse
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from robot.config import ConfigNotSet, PoseNotMeasured, load_robot_config, load_settings  # noqa: E402
from robot.controller import RobotController  # noqa: E402
from robot.slots import SlotTracker  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--dst", required=True)
    ap.add_argument("--repeat", type=int, default=10, help="왕복 포함 이동 횟수")
    ap.add_argument("--poses", default=str(ROOT / "config" / "poses.json"))
    ap.add_argument("--robot", default=str(ROOT / "config" / "robot.json"))
    ap.add_argument("--check", action="store_true", help="가짜 백엔드로 흐름만 점검 (로봇을 움직이지 않음)")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    cfg_path = Path(args.robot)
    settings = load_settings(cfg_path)
    tracker = SlotTracker({args.src: 1})  # src에 말 1개

    if args.check:
        from robot.fake_backend import FakeBackend
        backend = FakeBackend()
    else:
        from robot.backend_lerobot import LeRobotBackend
        backend = LeRobotBackend.from_config(load_robot_config(cfg_path))

    ctl = RobotController(Path(args.poses), backend, settings, tracker)
    try:
        if not args.check:
            input(f"\n{args.src}에 말 1개를 올리고 로봇 주변을 비웠으면 Enter (중단: Ctrl+C) ")
        ctl.home()
        ok = fail = 0
        a, b = args.src, args.dst
        for i in range(1, args.repeat + 1):
            moved = ctl.move(a, b)
            if args.check:
                print(f"[{i}] {a} → {b}: 동작 {'완료' if moved else '실패'} (점검 모드)")
                ok += moved
            else:
                ans = input(f"[{i}] {a} → {b}: 동작 {'완료' if moved else '실패'}. 말이 제자리에 놓였나요? (y/n) ").strip().lower()
                if moved and ans == "y":
                    ok += 1
                else:
                    fail += 1
                    tracker.sync({b: 1} if ans == "y" else {a: 1})  # 사람이 말을 바로잡은 위치에 기록을 맞춤
                    input("말을 현재 기록 위치에 맞게 놓고 Enter ")
            a, b = b, a  # 왕복
        ctl.home()
        total = ok + fail
        print(f"\n결과: 성공 {ok}/{total}" + (" (합격선 9/10)" if total >= 10 and ok / total >= 0.9 else ""))
    except (PoseNotMeasured, ConfigNotSet) as e:
        print(f"\n준비가 덜 됐습니다: {e}")
        sys.exit(2)
    finally:
        if hasattr(backend, "disconnect"):
            try:
                backend.disconnect()
            except Exception:
                pass


if __name__ == "__main__":
    main()
