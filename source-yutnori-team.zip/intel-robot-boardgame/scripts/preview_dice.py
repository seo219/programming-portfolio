"""카메라 화면에서 주사위 눈 인식 결과를 실시간으로 보여 줍니다 (비전 확인용).

사용법:
    python scripts/preview_dice.py                     # 카메라 0번 실시간
    python scripts/preview_dice.py --camera 1
    python scripts/preview_dice.py --image data/second/3/xxx.jpg              # 사진 한 장 확인(창)
    python scripts/preview_dice.py --image xxx.jpg --save out.jpg             # 창 없이 결과 이미지로 저장

화면 표시: 노란 사각형=tray ROI, 초록 윤곽=눈으로 인식된 점, 위쪽 글자=이번 프레임 눈 개수와
최근 8프레임 다수결 값(read_dice와 같은 규칙). 조작: s=지금 화면 저장(data/), q 또는 Esc=종료.
"""
import argparse
import json
import sys
import time
from collections import Counter, deque
from pathlib import Path

import cv2

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vision.detector import FRAMES, MIN_AGREE, VisionDetector, open_camera  # noqa: E402

WINDOW = "preview_dice"
GREEN, YELLOW, RED = (0, 255, 0), (0, 255, 255), (0, 0, 255)


def tray_roi(slots_path: Path, frame_shape) -> tuple[int, int, int, int]:
    """slots.json의 tray ROI를 프레임 안으로 잘라서 돌려줍니다. 미측정이면 전체 프레임."""
    h, w = frame_shape[:2]
    x, y, rw, rh = json.loads(slots_path.read_text(encoding="utf-8")).get("tray", [0, 0, 0, 0])
    if rw <= 0 or rh <= 0:
        return 0, 0, w, h
    x, y = min(max(x, 0), w - 1), min(max(y, 0), h - 1)
    return x, y, min(rw, w - x), min(rh, h - y)


def annotate(frame, roi, votes: deque):
    """프레임에 ROI·눈 윤곽·판독 결과를 그려 새 이미지로 돌려줍니다. (이번 프레임 눈 개수, 다수결 값)도 함께."""
    x, y, w, h = roi
    pips = VisionDetector._find_pips(frame[y:y + h, x:x + w])
    count = len(pips)
    votes.append(count if 1 <= count <= 6 else None)
    valid = [v for v in votes if v is not None]
    value, ratio = None, 0.0
    if valid:
        top, n = Counter(valid).most_common(1)[0]
        ratio = n / FRAMES
        value = top if ratio >= MIN_AGREE else None

    shown = frame.copy()
    cv2.rectangle(shown, (x, y), (x + w - 1, y + h - 1), YELLOW, 3)
    for c in pips:
        cv2.drawContours(shown, [c + [x, y]], -1, GREEN, 3)
    color = GREEN if value else RED
    cv2.putText(shown, f"pips this frame: {count}", (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.3, GREEN, 3)
    cv2.putText(shown, f"dice (last {FRAMES}): {value if value else 'None'}  conf {ratio:.2f}", (20, 100),
                cv2.FONT_HERSHEY_SIMPLEX, 1.3, color, 3)
    return shown, count, value


def show(image):
    cv2.imshow(WINDOW, cv2.resize(image, None, fx=0.5, fy=0.5) if image.shape[1] > 1400 else image)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("--camera", type=int, default=0)
    parser.add_argument("--image", type=Path, help="카메라 대신 사진 한 장으로 확인")
    parser.add_argument("--save", type=Path, help="--image와 함께 쓰면 창 없이 결과를 이 파일로 저장")
    parser.add_argument("--slots", type=Path, default=ROOT / "config" / "slots.json")
    args = parser.parse_args()
    votes: deque = deque(maxlen=FRAMES)

    if args.image:
        frame = cv2.imread(str(args.image))
        if frame is None:
            raise SystemExit(f"사진을 읽을 수 없습니다: {args.image}")
        for _ in range(FRAMES):  # 같은 사진이므로 다수결 칸을 채워 read_dice와 같은 값이 나오게 함
            shown, count, value = annotate(frame, tray_roi(args.slots, frame.shape), votes)
        print(f"이번 프레임 눈 {count}개, 판독값 {value}")
        if args.save:
            cv2.imwrite(str(args.save), shown)
            print(f"저장: {args.save}")
            return
        show(shown)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        return

    try:
        cap = open_camera(args.camera)
    except RuntimeError as e:
        raise SystemExit(str(e))
    print("실시간 미리보기 시작. s=화면 저장, q/Esc=종료")
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                raise SystemExit("카메라에서 프레임을 읽지 못했습니다")
            shown, _, _ = annotate(frame, tray_roi(args.slots, frame.shape), votes)
            show(shown)
            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord("q")):
                break
            if key == ord("s"):
                out = ROOT / "data" / f"snap_{time.strftime('%Y%m%d_%H%M%S')}.jpg"
                cv2.imwrite(str(out), frame)  # 원본 프레임 저장 (분석용)
                print(f"저장: {out}")
    finally:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
