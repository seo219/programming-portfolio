"""칸별 로봇 자세 기록 도구 (실제 로봇 필요, Windows 전용). 사람이 직접 실행합니다.

리더 팔을 움직이면 팔로워가 따라 움직입니다. 원하는 자세에서 키를 눌러 팔로워의 현재 관절값을
config/poses.json에 저장합니다. 슬롯마다 above(위 접근) → grasp(집는 자세) 순서입니다 (home은 above만).

  python scripts/record_poses.py                      # 아직 측정 안 한 자세만 순서대로
  python scripts/record_poses.py --only cell_3,wait_human   # 지정한 슬롯만 (이미 측정했어도 다시)
  python scripts/record_poses.py --redo                # 전부 다시

키: [스페이스] 저장하고 다음  [n] 건너뛰기  [b] 이전  [q] 종료

필요: config/robot.json의 follower.port, leader.port와 lerobot-calibrate로 만든 보정 파일.
안전: 팔로워가 리더 자세로 갑자기 튀지 않도록 한 번에 움직이는 각도를 제한합니다 (--max-step, 기본 10도).
"""
import argparse
import sys
import time
from datetime import datetime
from pathlib import Path

if sys.platform != "win32":
    sys.exit("이 도구는 Windows 키 입력(msvcrt)을 씁니다")
import msvcrt

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from robot.config import ConfigNotSet, load_poses, load_robot_config, require, update_pose_file  # noqa: E402

JOINTS = ("shoulder_pan", "shoulder_lift", "elbow_flex", "wrist_flex", "wrist_roll", "gripper")


def build_queue(poses_path: Path, only, redo: bool) -> list:
    import json
    dice_only = {"tray", "drop"}  # 주사위(차선책)용 자세: 윷놀이에는 필요 없어 --only로 지정할 때만 기록
    names = [k for k in json.loads(poses_path.read_text(encoding="utf-8"))
             if not k.startswith("_") and (only or k not in dice_only)]
    measured = load_poses(poses_path)
    queue = []
    for name in names:
        if only and name not in only:
            continue
        for kind in (("above",) if name == "home" else ("above", "grasp")):
            have = name in measured and (kind == "above" or measured[name].grasp is not None)
            if redo or only or not have:
                queue.append((name, kind))
    return queue


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--poses", default=str(ROOT / "config" / "poses.json"))
    ap.add_argument("--robot", default=str(ROOT / "config" / "robot.json"))
    ap.add_argument("--only", help="쉼표로 구분한 슬롯 이름")
    ap.add_argument("--redo", action="store_true")
    ap.add_argument("--max-step", type=float, default=10.0, help="한 번에 움직일 최대 각도(도)")
    args = ap.parse_args()

    poses_path = Path(args.poses)
    cfg = load_robot_config(Path(args.robot))
    f, l = cfg.get("follower", {}), cfg.get("leader", {})
    try:
        f_port, f_id = require(f.get("port"), "follower.port"), require(f.get("id"), "follower.id")
        l_port, l_id = require(l.get("port"), "leader.port"), require(l.get("id"), "leader.id")
    except ConfigNotSet as e:
        sys.exit(str(e))
    queue = build_queue(poses_path, set(args.only.split(",")) if args.only else None, args.redo)
    if not queue:
        sys.exit("기록할 자세가 없습니다 (모두 측정됨). 다시 재려면 --redo 또는 --only")

    from pathlib import Path as P
    from lerobot.robots.so_follower import SO101Follower, SO101FollowerConfig
    from lerobot.teleoperators.so_leader import SO101Leader, SO101LeaderConfig

    follower = SO101Follower(SO101FollowerConfig(port=f_port, id=f_id, max_relative_target=args.max_step,
                                                 calibration_dir=P(f["calibration_dir"]) if f.get("calibration_dir") else None))
    leader = SO101Leader(SO101LeaderConfig(port=l_port, id=l_id,
                                           calibration_dir=P(l["calibration_dir"]) if l.get("calibration_dir") else None))
    follower.connect(calibrate=False)
    leader.connect(calibrate=False)
    if not (follower.is_calibrated and leader.is_calibrated):
        follower.disconnect()
        leader.disconnect()
        sys.exit("보정이 맞지 않습니다. lerobot-calibrate로 팔로워와 리더를 먼저 보정하세요")
    meta = {"follower_id": f_id, "calibration_file": str(follower.calibration_fpath), "recorded": datetime.now().isoformat(timespec="seconds")}

    print(f"기록할 자세 {len(queue)}개. [스페이스] 저장 [n] 건너뛰기 [b] 이전 [q] 종료")
    print("리더 팔을 천천히 움직이세요. 처음에는 팔로워가 리더 쪽으로 이동합니다.")
    i, last = 0, None
    try:
        while i < len(queue):
            slot, kind = queue[i]
            if last != i:
                print(f"\n[{i + 1}/{len(queue)}] {slot} / {kind}: 자세를 맞추고 스페이스")
                last = i
            follower.send_action(leader.get_action())
            while msvcrt.kbhit():
                ch = msvcrt.getwch()
                if ch == " ":
                    obs = follower.get_observation()
                    joints = [round(float(obs[f"{n}.pos"]), 2) for n in JOINTS]
                    try:
                        update_pose_file(poses_path, slot, kind, joints, meta)
                        print(f"  저장: {slot}.{kind} = {joints}")
                        i += 1
                    except ValueError as e:
                        print(f"  저장 안 함: {e}")
                elif ch == "n":
                    i += 1
                elif ch == "b":
                    i = max(0, i - 1)
                elif ch == "q":
                    i = len(queue)
            time.sleep(1 / 30)
    finally:
        follower.disconnect()
        leader.disconnect()
    print("끝났습니다.")


if __name__ == "__main__":
    main()
