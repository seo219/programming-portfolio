"""비전 초안(slots_draft_v2.json)을 config/board_cells.json(게임 칸 이름 키)으로 변환.

사용: python scripts/make_board_cells.py [--draft PATH] [--out PATH] [--force]
카메라 위치 확정 후 사람이 실행합니다. 이미 있는 파일은 --force 없이는 덮어쓰지 않습니다.
"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# 비전 초안 이름 → 게임 칸 이름. cell_0~19는 같고 지름길 9칸만 다름 (robot을 import하지 않으려고 따로 둠)
DRAFT_TO_GAME_NAME = {
    "cell_20": "diag_r1", "cell_21": "diag_r2", "cell_22": "center", "cell_23": "diag_r3", "cell_24": "diag_r4",
    "cell_25": "diag_l1", "cell_26": "diag_l2", "cell_27": "diag_l3", "cell_28": "diag_l4",
}
COMMENT = "카메라 위치 확정 전 초안에서 변환한 값, 카메라나 판이 움직이면 다시 만들 것"


def convert(draft: dict) -> dict:
    cells = {}
    for name, v in draft.items():
        cells[DRAFT_TO_GAME_NAME.get(name, name)] = {"x": v["x"], "y": v["y"], "roi_r": v["roi_r"]}
    return {"_comment": COMMENT, "cells": cells}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--draft", type=Path, default=ROOT / "config" / "slots_draft_v2.json")
    ap.add_argument("--out", type=Path, default=ROOT / "config" / "board_cells.json")
    ap.add_argument("--force", action="store_true", help="기존 파일 덮어쓰기")
    args = ap.parse_args(argv)
    if args.out.exists() and not args.force:
        print(f"{args.out}이(가) 이미 있습니다. 덮어쓰려면 --force를 붙이세요", file=sys.stderr)
        return 1
    draft = json.loads(args.draft.read_text(encoding="utf-8"))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(convert(draft), ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print(f"{args.out}에 {len(draft)}칸을 저장했습니다")
    return 0


if __name__ == "__main__":
    sys.exit(main())
