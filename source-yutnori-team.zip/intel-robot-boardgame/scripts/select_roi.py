"""카메라 화면(또는 사진)에서 tray ROI를 마우스로 찍어 config/slots.json에 저장합니다.

사용법:
    python scripts/select_roi.py                      # 카메라 0번, tray만
    python scripts/select_roi.py --image data/board.jpg
    python scripts/select_roi.py --only tray other    # 다른 슬롯 이름을 직접 줄 수도 있음

판 칸 좌표는 이 스크립트로 찍지 않습니다. 말 없는 기준 사진에서 만든 초안을
scripts/make_board_cells.py로 config/board_cells.json(게임 칸 이름)으로 바꿔 씁니다.

조작: 드래그로 영역 선택 → 스페이스/엔터 확정, c나 Esc는 그 칸을 건너뜀(기존 값 유지).
중간에 멈추려면 터미널에서 Ctrl+C: 지금까지 찍은 것만 저장합니다.
카메라 미리보기에서는 스페이스로 촬영, Esc로 취소합니다.
"""
import argparse
import json
import sys
from pathlib import Path

import cv2

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vision.detector import open_camera  # noqa: E402  detector와 같은 해상도로 열어야 ROI 좌표가 맞음
WINDOW = "select_roi"


def capture(camera_index: int):
    """미리보기를 보여 주고 스페이스를 누른 순간의 프레임을 돌려줍니다. Esc면 None."""
    try:
        cap = open_camera(camera_index)
    except RuntimeError as e:
        raise SystemExit(str(e))
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                raise SystemExit("카메라에서 프레임을 읽지 못했습니다")
            cv2.imshow(WINDOW, frame)
            key = cv2.waitKey(1) & 0xFF
            if key == 32:
                return frame
            if key == 27:
                return None
    finally:
        cap.release()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("--image", type=Path, help="카메라 대신 쓸 사진 경로")
    parser.add_argument("--camera", type=int, default=0, help="카메라 번호 (기본 0)")
    parser.add_argument("--slots", type=Path, default=ROOT / "config" / "slots.json")
    parser.add_argument("--only", nargs="+", help="찍을 슬롯 이름 (기본 tray)")
    args = parser.parse_args()

    slots = json.loads(args.slots.read_text(encoding="utf-8"))
    names = args.only or ["tray"]

    if args.image:
        frame = cv2.imread(str(args.image))
        if frame is None:
            raise SystemExit(f"사진을 읽을 수 없습니다: {args.image}")
    else:
        frame = capture(args.camera)
        if frame is None:
            cv2.destroyAllWindows()
            raise SystemExit("촬영을 취소했습니다")

    changed = 0
    try:
        for name in names:
            shown = frame.copy()
            cv2.putText(shown, f"{name}  (Enter=OK, c/Esc=skip)", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
            x, y, w, h = (int(v) for v in cv2.selectROI(WINDOW, shown, showCrosshair=False))
            if w > 0 and h > 0:
                slots[name] = [x, y, w, h]
                changed += 1
                print(f"{name}: {slots[name]}")
            else:
                print(f"{name}: 건너뜀")
    except KeyboardInterrupt:
        print("중단: 지금까지 찍은 것만 저장합니다")
    cv2.destroyAllWindows()

    args.slots.write_text(json.dumps(slots, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"{changed}개 저장: {args.slots}")


if __name__ == "__main__":
    main()
