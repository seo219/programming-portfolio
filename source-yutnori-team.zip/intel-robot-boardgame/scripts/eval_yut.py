"""윷 모델(Geti, OpenVINO) 평가: 폴더별 정답(도·개·걸·윷·모·빽도) 사진에 돌려 정확도를 냅니다.

사용: python scripts/eval_yut.py --model models/yut/7bc45355-openvino-fp16 data/yukk_1 [data/yukk_2 ...]
- 데이터 폴더 아래에 backdo/do/gae/gurl/yukk/mo 하위 폴더가 있어야 합니다.
- 필요 패키지: openvino-model-api (requirements.txt에 있음)
- 클래스: backdo(표시된 배), down(배), upper(윗면=등). 배 개수 = down + backdo
"""
import argparse
import sys
import time
from collections import Counter
from pathlib import Path

import cv2
from model_api.models import Model

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from vision.yut_logic import DEFAULT_MIN_SCORE, Detection, flats_from_detections  # noqa: E402

# 폴더 이름 → 배(평평한 면)가 위인 가락 수. 빽도는 -1
EXPECTED = {"backdo": -1, "do": 1, "gae": 2, "gurl": 3, "yukk": 4, "mo": 0}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="model.xml이 든 폴더")
    ap.add_argument("--min-score", type=float, default=DEFAULT_MIN_SCORE, help="이 점수 미만 검출은 버림")
    ap.add_argument("data", nargs="+", type=Path)
    args = ap.parse_args()

    model = Model.create_model(str(Path(args.model) / "model.xml"))
    total = ok = none = 0
    wrong: list[tuple[str, int, int | None, dict]] = []
    times = []
    per_folder: dict[str, list[int]] = {}
    for root in args.data:
        for name, expected in EXPECTED.items():
            for path in sorted((root / name).glob("*.jpg")):
                img = cv2.cvtColor(cv2.imread(str(path)), cv2.COLOR_BGR2RGB)
                t0 = time.perf_counter()
                result = model(img)
                times.append(time.perf_counter() - t0)
                dets = [Detection(n, float(s), (0.0, 0.0, 0.0, 0.0))
                        for n, s in zip(result.label_names, result.scores)]
                counts = Counter(d.label for d in dets if d.score >= args.min_score)
                got = flats_from_detections(dets, args.min_score)
                total += 1
                per_folder.setdefault(name, [0, 0])[1] += 1
                if got == expected:
                    ok += 1
                    per_folder[name][0] += 1
                else:
                    none += got is None
                    wrong.append((f"{root.name}/{name}/{path.name}", expected, got, dict(counts)))
    print(f"전체 {ok}/{total} ({ok / max(total, 1):.1%}), 인식 실패(None) {none}장")
    for name, (good, n) in per_folder.items():
        print(f"  {name:6s} {good}/{n}")
    print(f"추론 시간 평균 {sum(times) / len(times) * 1000:.0f}ms (첫 장 포함)")
    for item in wrong[:20]:
        print("  오답", item)


if __name__ == "__main__":
    main()
