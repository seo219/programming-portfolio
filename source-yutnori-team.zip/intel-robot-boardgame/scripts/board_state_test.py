"""색으로 말을 찾아 점(cell)에 배정하는 board_state() 시험.

사용: python board_state_test.py --slots slots_draft_v2.json --ref-image 기준사진.jpg 시험사진1.jpg 시험사진2.jpg
- 기준 사진: 말 없이 찍은 사진 (slots 좌표를 만든 사진)
- 시험 사진의 카메라 위치가 기준과 조금 달라도 판의 원으로 위치를 다시 맞춘 뒤 판정합니다 (--no-refit이면 기준 좌표를 그대로 사용)
- 결과 그림은 시험 사진 이름에 _state.png를 붙여 저장합니다
"""
import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from vision.board_cells import BoardCell  # noqa: E402
from vision.board_pieces import assign_blobs_to_cells, find_piece_blobs  # noqa: E402

DICT = cv2.aruco.DICT_4X4_1000


def detect_markers(img):
    det = cv2.aruco.ArucoDetector(cv2.aruco.getPredefinedDictionary(DICT), cv2.aruco.DetectorParameters())
    corners, ids, _ = det.detectMarkers(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
    if ids is None:
        return {}
    return {int(i): c.reshape(4, 2) for c, i in zip(corners, ids.flatten())}


def find_circles(img, markers):
    """판에 인쇄된 검은 원의 중심을 찾는다 (마커 주변은 제외)."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, bw = cv2.threshold(cv2.GaussianBlur(gray, (5, 5), 0), 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    for pts in markers.values():
        c = pts.mean(axis=0)
        r = int(np.linalg.norm(pts[0] - pts[2]))
        cv2.rectangle(bw, (int(c[0] - r), int(c[1] - r)), (int(c[0] + r), int(c[1] + r)), 0, -1)
    op = cv2.morphologyEx(bw, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13)))
    n, _, stats, cent = cv2.connectedComponentsWithStats(op)
    out = []
    for j in range(1, n):
        x, y, w, h, area = stats[j]
        if 500 < area < 15000 and 0.7 < w / h < 1.4 and area > 0.42 * w * h:
            out.append((float(cent[j][0]), float(cent[j][1])))
    return out


def refit_cells(img, ref_cells, ref_markers):
    """기준 점 좌표를 이 사진의 카메라 위치에 맞게 옮긴다 (마커로 대략 맞춘 뒤 보이는 원으로 다시 맞춤)."""
    markers = detect_markers(img)
    if not all(i in markers and i in ref_markers for i in range(4)):
        raise RuntimeError(f"마커 4개를 모두 찾지 못함: {sorted(markers)}")
    names = list(ref_cells)
    ref_pts = np.array([[ref_cells[k]["x"], ref_cells[k]["y"]] for k in names], np.float32)
    src = np.concatenate([ref_markers[i] for i in range(4)]).astype(np.float32)
    dst = np.concatenate([markers[i] for i in range(4)]).astype(np.float32)
    h0, _ = cv2.findHomography(src, dst, 0)
    pred = cv2.perspectiveTransform(ref_pts.reshape(-1, 1, 2), h0).reshape(-1, 2)
    a, b = [], []
    for (x, y) in find_circles(img, markers):
        d = np.linalg.norm(pred - np.array([x, y]), axis=1)
        j = int(d.argmin())
        if d[j] < 60:
            a.append(ref_pts[j])
            b.append([x, y])
    if len(a) < 10:
        raise RuntimeError(f"맞출 원이 너무 적음: {len(a)}개")
    h, mask = cv2.findHomography(np.array(a, np.float32), np.array(b, np.float32), cv2.RANSAC, 6.0)
    pos = cv2.perspectiveTransform(ref_pts.reshape(-1, 1, 2), h).reshape(-1, 2)
    return {k: (float(p[0]), float(p[1])) for k, p in zip(names, pos)}, markers, int(mask.sum())


def px_per_mm_at(markers, y, marker_mm=30.0):
    """화면 높이 y에서 판 평면의 1mm당 픽셀 수 (위쪽/아래쪽 마커 크기를 보간한 근사값)."""
    def side(pts):
        return float(np.mean([np.linalg.norm(pts[k] - pts[(k + 1) % 4]) for k in range(4)]))
    top = [(markers[i].mean(axis=0)[1], side(markers[i])) for i in (0, 1)]
    bot = [(markers[i].mean(axis=0)[1], side(markers[i])) for i in (2, 3)]
    y_top, s_top = np.mean([t[0] for t in top]), np.mean([t[1] for t in top])
    y_bot, s_bot = np.mean([t[0] for t in bot]), np.mean([t[1] for t in bot])
    t = float(np.clip((y - y_top) / (y_bot - y_top), 0, 1))
    return (s_top + (s_bot - s_top) * t) / marker_mm


def board_state(img, cells, markers):
    """{cell 이름: 'robot' | 'human' | None}, 점검 메모, 색 덩어리를 돌려준다 (판정은 vision.board_pieces)."""
    hull = cv2.convexHull(np.array([p.mean(axis=0) for p in markers.values()], np.float32))
    blobs = find_piece_blobs(img, hull)
    reading = assign_blobs_to_cells(blobs, {k: BoardCell(x, y, 0.0) for k, (x, y) in cells.items()})
    return reading.state, reading.issues, blobs


def draw(img, cells, state, blobs):
    vis = img.copy()
    for k, (x, y) in cells.items():
        color = {"robot": (0, 0, 255), "human": (255, 80, 0), None: (0, 200, 0)}[state[k]]
        cv2.circle(vis, (int(x), int(y)), 6, color, -1)
        cv2.putText(vis, k.split("_")[1], (int(x) + 8, int(y) - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
    for b in blobs:
        cv2.circle(vis, (int(b.cx), int(b.cy)), 30, (0, 255, 255), 2)
        cv2.putText(vis, b.owner, (int(b.cx) - 30, int(b.cy) - 36), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
    return cv2.resize(vis, (1280, 720))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--slots", required=True, help="점 좌표 JSON (x, y 필드)")
    ap.add_argument("--ref-image", required=True, help="slots를 만든 기준 사진")
    ap.add_argument("--no-refit", action="store_true", help="카메라가 안 움직였을 때: 기준 좌표를 그대로 사용")
    ap.add_argument("images", nargs="+")
    args = ap.parse_args()

    ref_cells = json.loads(Path(args.slots).read_text(encoding="utf-8"))
    ref_markers = detect_markers(cv2.imread(args.ref_image))
    for path in args.images:
        img = cv2.imread(path)
        if args.no_refit:
            cells = {k: (v["x"], v["y"]) for k, v in ref_cells.items()}
            markers = detect_markers(img)
            fit = "기준 좌표 그대로"
        else:
            cells, markers, n = refit_cells(img, ref_cells, ref_markers)
            fit = f"원 {n}개로 위치 보정"
        state, issues, blobs = board_state(img, cells, markers)
        occupied = {k: v for k, v in state.items() if v}
        print(f"\n== {Path(path).name} ({fit})")
        print("말이 있는 점:", {k.split("_")[1]: v for k, v in sorted(occupied.items(), key=lambda kv: int(kv[0].split('_')[1]))})
        for b in blobs:
            print(f"  {b.owner:5s} 좌표 {b.cx:.0f},{b.cy:.0f}  면적 {b.area:.0f}px (약 {b.area / px_per_mm_at(markers, b.cy) ** 2:.0f}mm2 환산)")
        for msg in issues:
            print(f"  <-- 확인 필요: {msg}")
        out = Path(path).with_name(Path(path).stem + "_state.png")
        cv2.imwrite(str(out), draw(img, cells, state, blobs))
        print("  결과 그림:", out)


if __name__ == "__main__":
    main()
