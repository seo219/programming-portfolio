"""ArUco 마커 인식 테스트.

사진 한 장:  python aruco_test.py --image 사진.png
카메라:      python aruco_test.py --camera 0 --frames 100   (q 종료, s 현재 화면 저장)
화면 없이:   python aruco_test.py --camera 0 --frames 100 --no-gui
"""
import argparse
import sys

import cv2

DICT_NAME = "DICT_4X4_1000"  # 마커를 만든 딕셔너리와 같아야 함
EXPECTED_IDS = {0, 1, 2, 3}  # 판 모서리에 붙인 마커 ID
MODULE_COUNT = int(DICT_NAME.split("_")[1][0]) + 2  # 안쪽 격자 + 검은 테두리 양쪽 (4x4이면 6칸)
MIN_MODULE_PX = 5  # 한 칸이 이보다 작게 찍히면 불안정할 수 있음 (경험치, 시험으로 확인할 것)
PASS_RATE = 0.95  # 모든 마커가 인식된 프레임 비율의 합격선 (팀이 정해 바꿀 것)


def make_detector():
    aruco = cv2.aruco
    dictionary = aruco.getPredefinedDictionary(getattr(aruco, DICT_NAME))
    if hasattr(aruco, "ArucoDetector"):  # OpenCV 4.7 이상
        detector = aruco.ArucoDetector(dictionary, aruco.DetectorParameters())
        return lambda gray: detector.detectMarkers(gray)[:2]
    params = aruco.DetectorParameters_create()  # 구버전
    return lambda gray: aruco.detectMarkers(gray, dictionary, parameters=params)[:2]


def analyze(detect, frame):
    """프레임에서 마커를 찾아 {id: 한 변 픽셀 수}와 그리기용 값을 돌려준다."""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    corners, ids = detect(gray)
    sides = {}
    if ids is not None:
        for c, marker_id in zip(corners, ids.flatten()):
            pts = c.reshape(4, 2)
            sides[int(marker_id)] = sum(cv2.norm(pts[k] - pts[(k + 1) % 4]) for k in range(4)) / 4
    return sides, corners, ids


def draw(frame, sides, corners, ids):
    if ids is not None:
        cv2.aruco.drawDetectedMarkers(frame, corners, ids)
    missing = sorted(EXPECTED_IDS - set(sides))
    text = "OK: all markers" if not missing else f"missing ID: {missing}"
    color = (0, 200, 0) if not missing else (0, 0, 255)
    cv2.putText(frame, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
    for marker_id, side in sides.items():
        cv2.putText(frame, f"ID{marker_id}: {side / MODULE_COUNT:.1f}px/cell", (10, 60 + 25 * marker_id),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 200, 0), 2)


def run_image(detect, path):
    frame = cv2.imread(path)
    if frame is None:
        sys.exit(f"이미지를 열 수 없음: {path}")
    sides, corners, ids = analyze(detect, frame)
    print(f"사진 크기 {frame.shape[1]}x{frame.shape[0]}, 인식한 마커 {len(sides)}개")
    for marker_id in sorted(sides):
        print(f"  ID {marker_id}: 한 변 {sides[marker_id]:.1f}px, 한 칸 {sides[marker_id] / MODULE_COUNT:.1f}px")
    missing = sorted(EXPECTED_IDS - set(sides))
    extra = sorted(set(sides) - EXPECTED_IDS)
    print("없는 ID:", missing or "없음", "| 예상 밖 ID:", extra or "없음")
    draw(frame, sides, corners, ids)
    cv2.imwrite("aruco_result.png", frame)
    print("결과 그림 저장: aruco_result.png")
    return not missing


def run_camera(detect, args):
    source = int(args.camera) if str(args.camera).isdigit() else args.camera
    if isinstance(source, int) and sys.platform.startswith("win"):
        cap = cv2.VideoCapture(source, cv2.CAP_DSHOW)
    else:
        cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        sys.exit(f"카메라를 열 수 없음: {args.camera}")
    if isinstance(source, int):
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.height)
    print(f"실제 해상도 {int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))}x{int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))}")

    total = all_found = 0
    seen = {i: 0 for i in EXPECTED_IDS}
    min_cell = {i: float("inf") for i in EXPECTED_IDS}
    while total < args.frames:
        ok, frame = cap.read()
        if not ok:
            print("프레임을 읽지 못해 종료")
            break
        total += 1
        sides, corners, ids = analyze(detect, frame)
        for marker_id in EXPECTED_IDS & set(sides):
            seen[marker_id] += 1
            min_cell[marker_id] = min(min_cell[marker_id], sides[marker_id] / MODULE_COUNT)
        all_found += EXPECTED_IDS <= set(sides)
        if not args.no_gui:
            draw(frame, sides, corners, ids)
            cv2.imshow("aruco test (q: quit, s: save)", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            if key == ord("s"):
                cv2.imwrite(f"aruco_frame_{total}.png", frame)
                print("저장:", f"aruco_frame_{total}.png")
    cap.release()
    if not args.no_gui:
        cv2.destroyAllWindows()

    if total == 0:
        return False
    print(f"\n총 {total}프레임")
    for marker_id in sorted(EXPECTED_IDS):
        cell = "-" if min_cell[marker_id] == float("inf") else f"{min_cell[marker_id]:.1f}px"
        print(f"  ID {marker_id}: 인식 {seen[marker_id]}/{total} ({seen[marker_id] / total:.0%}), 가장 작았던 한 칸 {cell}")
    rate = all_found / total
    print(f"네 마커가 모두 인식된 프레임: {all_found}/{total} ({rate:.0%}), 합격선 {PASS_RATE:.0%}")
    small = [i for i in sorted(EXPECTED_IDS) if min_cell[i] < MIN_MODULE_PX]
    if small:
        print(f"주의: ID {small}는 한 칸이 {MIN_MODULE_PX}px보다 작게 찍힌 적이 있음 (마커를 키우거나 카메라를 가깝게)")
    return rate >= PASS_RATE


def main():
    parser = argparse.ArgumentParser(description="ArUco 마커 인식 테스트")
    parser.add_argument("--image", help="사진 파일 하나로 테스트")
    parser.add_argument("--camera", default="0", help="카메라 번호 또는 영상 파일 경로")
    parser.add_argument("--width", type=int, default=1280)
    parser.add_argument("--height", type=int, default=720)
    parser.add_argument("--frames", type=int, default=100, help="카메라 테스트에서 읽을 프레임 수")
    parser.add_argument("--no-gui", action="store_true", help="화면 창 없이 실행")
    args = parser.parse_args()

    if not hasattr(cv2, "aruco"):
        sys.exit("cv2.aruco가 없음: pip install opencv-contrib-python (opencv-python과 같이 설치하지 말 것)")
    detect = make_detector()
    ok = run_image(detect, args.image) if args.image else run_camera(detect, args)
    print("결과:", "통과" if ok else "확인 필요")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
