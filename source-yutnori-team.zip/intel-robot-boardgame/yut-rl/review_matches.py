"""Summarize recorded human matches and export reviewable human decisions."""
import json
from collections import Counter
from pathlib import Path
from play_web import ROOT, MODEL
from yut_rl.engine import YutBoard, YutGame
from yut_rl.game import Move, legal_moves
from yut_rl import dice, sticks, sticks_backdo
from yut_rl.bundle import sha256


def main():
    folder = ROOT / 'output/human_matches'
    output = ROOT / 'output/human_review'
    output.mkdir(parents=True, exist_ok=True)
    counts = Counter()
    flags, missed_wins, samples = [], [], []
    for path in sorted(folder.glob('*.json')):
        record = json.loads(path.read_text(encoding='utf-8'))
        backdo = record.get('rules') == sticks_backdo.RULES_ID
        dice_mode = backdo or record.get('rules') == 'uniform_d6'  # 빽도 행동 형식
        board_path = (sticks_backdo.BOARD if backdo else sticks.BOARD if record.get('rules') == sticks.RULES_ID else
                      dice.BOARD if dice_mode else MODEL.with_name('board.json'))
        if not board_path.exists() or record['board_sha256'] != sha256(board_path):
            counts['skipped_incompatible_board'] += 1
            continue
        board = (sticks_backdo.SticksBackdoBoard(board_path) if backdo else
                 dice.DiceBoard(board_path) if dice_mode else YutBoard(board_path))
        game_type = dice.DiceGame if dice_mode else YutGame
        move_type = dice.DiceMove if dice_mode else Move
        get_legal = sticks_backdo.legal_moves if backdo else dice.legal_moves if dice_mode else legal_moves
        counts['rules_' + record.get('rules', 'legacy_yut')] += 1
        counts[record['status']] += 1
        if record['winner']:
            counts['winner_' + record['winner']] += 1
        for event in record['events']:
            if event['kind'] != 'move':
                continue
            before = event['before']
            game = game_type(board, before['pieces'])
            player = event['player']
            legal = get_legal(game, player, before['pending'])
            if str(event['id']) in record['feedback']:
                flags.append(dict(match_id=record['match_id'], event=event,
                                  feedback=record['feedback'][str(event['id'])]))
            if player == 'robot':
                winning = []
                for move in legal:
                    trial = game_type(board, {p: list(v) for p, v in game.pieces.items()})
                    trial.move(player, move.piece, move.result)
                    if trial.winner() == player:
                        winning.append(move.action)
                if winning and event['action'] not in winning:
                    missed_wins.append(dict(match_id=record['match_id'], event_id=event['id'],
                                            chosen=event['action'], immediate_wins=winning))
            elif record['status'] == 'completed':
                # Training masks merge identical waiting/stacked pieces. Map the
                # human's numbered piece to the canonical legal representative.
                chosen = move_type.decode(event['action'])
                canonical = chosen if chosen.piece < 0 else next(m for m in legal if m.piece >= 0 and
                    m.result == chosen.result and game.pieces[player][m.piece] == game.pieces[player][chosen.piece])
                samples.append(dict(match_id=record['match_id'], event_id=event['id'],
                                    pieces=before['pieces'], player=player, pending=before['pending'],
                                    action=canonical.action, winner=record['winner'],
                                    model_sha256=record['model_sha256'],
                                    rules=record.get('rules', 'legacy_yut'), board_sha256=record['board_sha256'],
                                    approved_for_training=False))
    (output / 'review.json').write_text(json.dumps(dict(counts=counts, flagged_moves=flags,
        missed_immediate_wins=missed_wins), ensure_ascii=False, indent=2), encoding='utf-8')
    (output / 'human_decisions.jsonl').write_text(''.join(json.dumps(s, ensure_ascii=False)+'\n'
                                                        for s in samples), encoding='utf-8')
    summary = ('# 사람 대결 검토\n\n'
               f'- 완료 경기: {counts["completed"]}\n- 사람 승리: {counts["winner_human"]}\n'
               f'- AI 승리: {counts["winner_robot"]}\n- 검토 표시된 AI 수: {len(flags)}\n'
               f'- 즉시 승리 기회를 놓친 수: {len(missed_wins)}\n'
               f'- 완료 경기의 사람 선택: {len(samples)}\n\n'
               f'- 주사위 경기: {counts["rules_uniform_d6"]} / 과거 윷 경기: {counts["rules_legacy_yut"]}\n'
               f'- 말 2개 빽도 윷 경기(11/03 규칙): {counts["rules_" + sticks_backdo.RULES_ID]}\n'
               f'- 말 2개 빽도 없는 윷 경기(11/02 규칙): {counts["rules_sticks_2pieces_no_backdo_v1"]}\n'
               f'- 판 해시 불일치 제외: {counts["skipped_incompatible_board"]}\n\n'
               '표시는 사용자의 검토 요청이며 모델의 실수로 확정한 것이 아닙니다.\n'
               '사람의 선택도 정답으로 간주하지 않으며, 학습용 승인은 기본 false입니다.\n'
               '경기 단위로 학습/평가 데이터를 분리하고 검토한 후 추가 학습해야 합니다.\n'
               '주사위와 과거 윷 기록은 rules와 board_sha256으로 구분하며 그대로 섞어 학습하면 안 됩니다.\n'
               '현재 모델이나 보조 규칙은 자동으로 변경하지 않습니다.\n')
    (output / 'SUMMARY.md').write_text(summary, encoding='utf-8')
    print(summary)


if __name__ == '__main__':
    main()
