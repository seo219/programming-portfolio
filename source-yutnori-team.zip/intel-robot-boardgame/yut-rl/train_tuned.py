"""중간 승률 평가 없이 여러 조건을 조정한 모델을 처음부터 학습합니다."""
import argparse
import json
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
import torch
from sb3_contrib import MaskablePPO
from stable_baselines3.common.callbacks import CallbackList, CheckpointCallback
from stable_baselines3.common.logger import configure
from stable_baselines3.common.vec_env import DummyVecEnv
from yut_rl.bundle import compatibility, read_bundle, package_versions, write_json, sha256
from yut_rl.env import read_config
from yut_rl.game import DEFAULT_BOARD, ROOT
from yut_rl.tuned import MixedOpponentEnv, ExplorationSchedule, interpolate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--steps', type=int, default=10000000)
    parser.add_argument('--seed', type=int, default=43)
    parser.add_argument('--output', type=Path, default=Path('models/four_pieces_tuned_10m'))
    parser.add_argument('--config', type=Path, default=Path('config/training_tuned.json'))
    args = parser.parse_args()
    if args.output.exists() or args.steps <= 0:
        parser.error('새 출력 폴더와 양수 steps가 필요합니다.')
    cfg = read_config(args.config)
    torch.set_num_threads(cfg['torch_threads'])
    opponent_path, opponent_board, _ = read_bundle(ROOT / cfg['frozen_model'])
    if sha256(opponent_board) != sha256(DEFAULT_BOARD):
        raise ValueError('상대와 학습 환경의 윷판이 다릅니다.')
    frozen = MaskablePPO.load(opponent_path, device='cpu')
    frozen.policy.set_training_mode(False)
    env = DummyVecEnv([lambda: MixedOpponentEnv(DEFAULT_BOARD, cfg, frozen_model=frozen) for _ in range(cfg['n_envs'])])
    env.seed(args.seed)
    args.output.mkdir(parents=True)
    shutil.copyfile(DEFAULT_BOARD, args.output/'board.json')
    manifest = {'created_utc':datetime.now(timezone.utc).isoformat(), 'status':'training',
                'seed':args.seed, 'requested_steps':args.steps, 'resume_from':None,
                'config':cfg, 'packages':package_versions(), 'compatibility':compatibility(args.output/'board.json'),
                'training_source_sha256': {name:sha256(ROOT/name) for name in ['train_tuned.py','yut_rl/tuned.py']},
                'frozen_opponent_sha256':sha256(opponent_path),
                'intermediate_evaluation':False, 'note':'승패 보상과 실제 게임 규칙은 유지. 설정 조합 실험.'}
    write_json(args.output/'manifest.json', manifest)
    start_lr, end_lr = cfg['learning_rate'], cfg['learning_rate_final']
    model = MaskablePPO('MlpPolicy', env, device='cpu', seed=args.seed, verbose=0,
                       learning_rate=lambda remaining: interpolate(start_lr, end_lr, remaining),
                       gamma=cfg['gamma'], gae_lambda=cfg['gae_lambda'], n_steps=cfg['n_steps'],
                       batch_size=cfg['batch_size'], n_epochs=cfg['n_epochs'], ent_coef=cfg['ent_coef'],
                       policy_kwargs={'net_arch':cfg['net_arch']})
    model.set_logger(configure(str(args.output/'logs'), []))
    callbacks = CallbackList([
        ExplorationSchedule(cfg['ent_coef'], cfg['ent_coef_final'], args.steps),
        CheckpointCallback(save_freq=max(1,cfg['checkpoint_freq']//cfg['n_envs']), save_path=str(args.output), name_prefix='checkpoint')])
    started = time.perf_counter()
    try:
        model.learn(total_timesteps=args.steps, callback=callbacks)
        model.save(args.output/'final_model')
        manifest['status'] = 'complete'
    except KeyboardInterrupt:
        model.save(args.output/'interrupted_model')
        manifest['status'] = 'interrupted'
    except Exception:
        manifest['status'] = 'failed'
        raise
    finally:
        manifest.update(total_steps=model.num_timesteps, steps_this_run=model.num_timesteps,
                        elapsed_seconds=round(time.perf_counter()-started,3),
                        opponent_episode_counts=[e.episode_counts for e in env.envs])
        write_json(args.output/'manifest.json', manifest)
        env.close()
    print(json.dumps(manifest,ensure_ascii=False),flush=True)


if __name__ == '__main__':
    main()
