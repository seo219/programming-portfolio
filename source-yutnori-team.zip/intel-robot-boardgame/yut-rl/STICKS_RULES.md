# 현재 규칙: 실제 윷 · 편당 말 2개 · 빽도 사용 (11/03)

2026-11-03에 메인 게임과 함께 빽도를 사용하는 규칙으로 바꿨습니다. 메인 게임 규칙서는 [docs/rules.md](../docs/rules.md)입니다.
설정은 `config/yut_sticks_2pieces_backdo.json`, 규칙·웹 어댑터는 `yut_rl/sticks_backdo.py`, 학습 환경은 `yut_rl/sticks_backdo_env.py`입니다.

| 결과 | 이동 | 경우의 수 | 확률 |
|---|---|---|---|
| 빽도 | −1칸 | 1 | 6.25% |
| 도 | +1칸 | 3 | 18.75% |
| 개 | +2칸 | 6 | 37.5% |
| 걸 | +3칸 | 4 | 25% |
| 윷 | +4칸 | 1 | 6.25% |
| 모 | +5칸 | 1 | 6.25% |

- 윷가락 4개의 앞면 확률은 각각 0.5이고, 마지막 가락에 빽도 표시가 있습니다. 표시 가락 **하나만** 앞이면 빽도입니다.
- 빽도는 판 위의 말(업힌 말은 함께)을 한 칸 뒤로 옮깁니다. 뒤로 간 칸에서도 잡기·업기가 됩니다. 연결은 설정의 `backward`이며 메인 게임과 같습니다 (도 → 참먹이, 방 → `diag_l2`).
- 판 위에 말이 없어 남은 결과를 하나도 쓸 수 없으면 빽도는 무효입니다 (행동 0 "빽도 버리기"). 윷 → 빽도처럼 다른 결과가 있으면 그 결과로 말을 먼저 올린 뒤 빽도를 씁니다.
- 말은 편마다 2개, 둘 다 완주하면 승리. 잡기·업기·지름길, 윷·모·잡기 추가 던지기는 그대로입니다.
- `tests/test_sticks_backdo.py`가 메인 게임 규칙 엔진(`src/game/yut_reference.py`)과 모든 칸·결과의 이동이 같은지 확인합니다.

## 모델과 학습

관측은 131차원(말 위치 + 결과별 개수 6개 + 차례), 행동은 말 2개 × 결과 6개 + 빽도 버리기 + 대기 = 14개입니다.
행동·관측 형식이 11/02 모델과 달라서 처음부터 학습했고, 11/02 모델(`continued_4m`, `sticks_two_*`)은 이 규칙에서 쓰지 못합니다.

```powershell
.\python.ps1 train_sticks_backdo.py 42 models/sticks_backdo_10m_seed42_20261103   # 시드, 저장 폴더, [스텝 수]
.\python.ps1 evaluate.py --model models/<폴더>/final_model.zip --games 2000 --seed 32000000 --opponent rule
.\play_web.ps1                                   # 빽도 규칙 모델(play_web.py의 BACKDO_MODEL), 없으면 규칙 AI
.\play_web.ps1 --model models/<폴더>/final_model.zip
```

학습 조건은 11/02 tuned 조건(`config/training_tuned.json`: 학습률·탐색 감소, 128x128)과 같고,
빽도 규칙 모델이 아직 없어서 동결 상대 없이 규칙 0.75 · 무작위 0.25로 학습합니다.
모델 폴더의 `manifest.json`에 규칙 코드 해시가 있어, 규칙·환경 코드가 바뀌면 모델을 거부합니다.
기보는 `rules=sticks_2pieces_backdo_v1`과 `board_sha256`으로 구분합니다.

## 과거 규칙: 빽도 제외 (11/02)

도 25% / 개 37.5% / 걸 25% / 윷 6.25% / 모 6.25%, 빽도 없음. 설정 `config/yut_sticks_2pieces.json`, 어댑터 `yut_rl/sticks.py`.
`train.py`, `train_sticks_tuned.py`, `continue_sticks_plus4m.py`와 그 모델(`continued_4m`, `sticks_two_*`)은 이 규칙입니다.
웹에서 다시 두려면 `.\play_web.ps1 --rules no_backdo`(기본 모델 `continued_4m`)를 씁니다.
기보는 `rules=sticks_2pieces_no_backdo_v1`이며 새 규칙 기보와 섞어 학습하지 않습니다.
