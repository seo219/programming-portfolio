"""말 2개·빽도 규칙의 MaskablePPO 학습 환경. 로봇 편을 학습하고 상대 턴은 환경 안에서 진행합니다.

상대는 경기마다 config의 opponent_mix 비율로 고릅니다 (rule, random, frozen).
frozen은 같은 빽도 규칙으로 학습한 과거 모델입니다. opponent_mix가 없으면 config의 opponent 하나만 씁니다.
"""
import gymnasium as gym
import numpy as np
from gymnasium import spaces

from .dice import DiceGame, DiceMove
from .env import read_config
from .sticks_backdo import BOARD, SticksBackdoBoard, SticksBackdoCodec, choose_rule, legal_moves


class SticksBackdoEnv(gym.Env):
    metadata = {"render_modes": ["ansi"]}

    def __init__(self, board_path=BOARD, config=None, frozen_model=None):
        super().__init__()
        self.config = dict(read_config() if config is None else config)
        self.board = SticksBackdoBoard(board_path)
        self.codec = SticksBackdoCodec(self.board)
        self.pass_action = self.board.pieces * 6 + 1
        self.action_space = spaces.Discrete(self.pass_action + 1)
        self.observation_space = spaces.Box(0, np.inf, (self.codec.size,), dtype=np.float32)
        mix = self.config.get('opponent_mix') or {self.config['opponent']: 1.0}
        self.kinds = list(mix)
        self.weights = np.asarray(list(mix.values()), dtype=float)
        if not set(self.kinds) <= {'rule', 'random', 'frozen'} or np.any(self.weights < 0) or \
                not np.isclose(self.weights.sum(), 1):
            raise ValueError('상대는 rule·random·frozen이며 비율의 합이 1이어야 합니다.')
        if mix.get('frozen', 0) > 0 and frozen_model is None:
            raise ValueError('동결된 상대 모델이 필요합니다.')
        if self.config['max_moves'] < 1 or self.config['max_throws_per_batch'] < 1:
            raise ValueError('안전 한도는 양수여야 합니다.')
        if self.config['first_player'] not in ('robot', 'human', 'random'):
            raise ValueError('first_player는 robot, human 또는 random입니다.')
        self.frozen_model = frozen_model
        self.episode_counts = dict.fromkeys(self.kinds, 0)
        self.game = DiceGame(self.board)
        self.pending: list[int] = []
        self.current = self.first_player = self.opponent_kind = None
        self.moves = 0
        self.terminated = self.truncated = self.illegal_action = False
        self.truncation_reason = None

    def _roll(self):
        for _ in range(self.config['max_throws_per_batch']):
            throw = self.board.sample(self.np_random)
            self.pending.append(throw.value)
            if not throw.again:
                return
        self.truncated = True
        self.truncation_reason = 'throw_safety_limit'

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self.game = DiceGame(self.board)
        self.pending = []
        self.moves = 0
        self.terminated = self.truncated = self.illegal_action = False
        self.truncation_reason = None
        self.opponent_kind = (options or {}).get('opponent') or str(self.np_random.choice(self.kinds, p=self.weights))
        self.episode_counts[self.opponent_kind] = self.episode_counts.get(self.opponent_kind, 0) + 1
        first = (options or {}).get('first_player', self.config['first_player'])
        if first == 'random':
            first = 'robot' if self.np_random.integers(2) == 0 else 'human'
        if first not in ('human', 'robot'):
            raise ValueError('선공은 human 또는 robot입니다.')
        self.first_player = self.current = first
        if first == 'robot':
            self._roll()
        # 상대 선공이면 첫 step은 대기 행동입니다.
        return self._obs(), self._info()

    def _obs(self):
        return self.codec.encode(self.game, 'robot', self.pending, self.current == 'robot')

    def _info(self):
        return dict(winner='human' if self.illegal_action else self.game.winner(), moves=self.moves,
                    first_player=self.first_player, opponent=self.opponent_kind,
                    illegal_action=self.illegal_action, truncation_reason=self.truncation_reason)

    def action_masks(self):
        if self.current == 'human' or self.terminated or self.truncated:
            mask = np.zeros(self.action_space.n, dtype=bool)
            mask[self.pass_action] = True
            return mask
        return self.codec.mask(self.game, 'robot', self.pending)

    def _apply(self, player, move):
        result = self.game.move(player, move.piece, move.result)
        self.pending.remove(move.result)
        self.moves += 1
        if self.game.winner():
            self.terminated = True
        elif self.moves >= self.config['max_moves']:
            self.truncated = True
            self.truncation_reason = 'move_limit'
        elif result.captured and self.board.again_on_capture:
            self._roll()

    def _opponent_move(self):
        if self.opponent_kind == 'rule':
            return choose_rule(self.game, 'human', self.pending)
        if self.opponent_kind == 'random':
            choices = legal_moves(self.game, 'human', self.pending)
            return choices[int(self.np_random.integers(len(choices)))]
        mask = self.codec.mask(self.game, 'human', self.pending)
        action, _ = self.frozen_model.predict(self.codec.encode(self.game, 'human', self.pending),
                                              action_masks=mask, deterministic=True)
        action = int(action)
        if not 0 <= action < len(mask) or not mask[action]:
            raise ValueError('동결 모델의 불법 행동')
        return DiceMove.decode(action)

    def _opponent_turn(self):
        self.current = 'human'
        self._roll()
        while self.pending and not (self.terminated or self.truncated):
            self._apply('human', self._opponent_move())
        if not (self.terminated or self.truncated):
            self.current = 'robot'
            self._roll()

    def step(self, action):
        if self.terminated or self.truncated:
            raise RuntimeError('종료된 환경입니다. reset()을 호출하세요.')
        if not self.action_space.contains(action) or not self.action_masks()[int(action)]:
            self.illegal_action = self.terminated = True
            return self._obs(), float(self.config['loss_reward']), True, False, self._info()
        if self.current == 'human':
            self._opponent_turn()
        else:
            self._apply('robot', DiceMove.decode(int(action)))
            if not self.pending and not (self.terminated or self.truncated):
                self._opponent_turn()
        winner = self.game.winner()
        reward = self.config['win_reward'] if winner == 'robot' else (
            self.config['loss_reward'] if winner == 'human' else 0.0)
        return self._obs(), float(reward), self.terminated, self.truncated, self._info()

    def render(self):
        return f"moves={self.moves} robot={self.game.pieces['robot']} human={self.game.pieces['human']} pending={self.pending}"
