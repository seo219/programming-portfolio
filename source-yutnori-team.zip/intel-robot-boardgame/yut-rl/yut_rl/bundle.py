"""모델과 입력 형식·규칙 정보를 함께 관리합니다."""
import hashlib
import json
from importlib.metadata import version
from pathlib import Path

from .game import StateCodec


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def compatibility(board_path: Path) -> dict:
    return {"schema": StateCodec.version, "board_sha256": sha256(board_path),
            "implementation_sha256": {
                name: sha256(Path(__file__).parent / name)
                for name in ("engine.py", "game.py", "env.py")}}


def package_versions() -> dict:
    return {name: version(name) for name in (
        "numpy", "torch", "gymnasium", "stable-baselines3", "sb3-contrib")}


def read_bundle(model_path: Path) -> tuple[Path, Path, dict]:
    path = Path(model_path).resolve()
    if path.suffix != ".zip":
        path = path.with_suffix(".zip")
    if not path.is_file():
        raise FileNotFoundError(f"모델이 없습니다: {path}. train.py로 먼저 학습하세요.")
    manifest = path.parent / "manifest.json"
    board = path.parent / "board.json"
    if not manifest.is_file() or not board.is_file():
        raise ValueError("모델과 같은 폴더에 manifest.json, board.json이 필요합니다.")
    data = json.loads(manifest.read_text(encoding="utf-8"))
    if data["compatibility"] != compatibility(board):
        raise ValueError("학습 당시와 규칙 또는 입력·환경 코드가 다릅니다. 같은 버전을 쓰거나 재학습하세요.")
    return path, board, data
