"""규칙 AI 상대의 단일 에이전트 Gymnasium 환경."""
import json
from pathlib import Path

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from .engine import YutBoard, YutGame
from .game import DEFAULT_BOARD, ROOT, Move, StateCodec, choose_rule, legal_moves, move_detail


def read_config(path: Path | None = None) -> dict:
    return json.loads((path or ROOT / "config" / "training.json").read_text(encoding="utf-8"))


class YutEnv(gym.Env):
    """로봇 편을 학습합니다. 상대 턴은 환경 내부에서 진행합니다."""
    metadata = {"render_modes": ["ansi"]}

    def __init__(self, board_path: Path = DEFAULT_BOARD, config: dict | None = None,
                 render_mode: str | None = None, record_events: bool = False):
        super().__init__()
        self.config = dict(config or read_config())
        self.board_path = Path(board_path)
        data = json.loads(self.board_path.read_text(encoding="utf-8"))
        if data.get("backdo"):
            raise ValueError("이 환경은 빽도 제외 규칙입니다.")
        self.board = YutBoard(self.board_path)
        if {t.value for t in self.board.yut.values()} != {1, 2, 3, 4, 5}:
            raise ValueError("윷 결과는 1~5여야 합니다.")
        if not 0 < self.config["flat_probability"] < 1:
            raise ValueError("flat_probability는 0과 1 사이여야 합니다.")
        if self.config["max_moves"] < 1 or self.config["max_throws_per_batch"] < 1:
            raise ValueError("안전 한도는 양수여야 합니다.")
        if self.config["opponent"] not in ("rule", "random"):
            raise ValueError("opponent는 rule 또는 random입니다.")
        if self.config["first_player"] not in ("robot", "human", "random"):
            raise ValueError("first_player는 robot, human 또는 random입니다.")
        self.codec = StateCodec(self.board)
        self.pass_action = self.board.pieces * 5
        self.action_space = spaces.Discrete(self.pass_action + 1)
        self.observation_space = spaces.Box(0, np.inf, (self.codec.size,), dtype=np.float32)
        self.render_mode = render_mode
        self.record_events = record_events
        self.game = YutGame(self.board)
        self.pending: list[int] = []
        self.current = "robot"
        self.first_player = "robot"
        self.moves = 0
        self.events: list[dict] = []
        self.terminated = self.truncated = False
        self.illegal_action = False
        self.truncation_reason: str | None = None

    def _log(self, event: dict) -> None:
        if self.record_events:
            self.events.append(event)

    def _roll(self, player: str) -> None:
        for _ in range(self.config["max_throws_per_batch"]):
            flats = int(np.sum(self.np_random.random(4) < self.config["flat_probability"]))
            result = self.board.throw(flats)
            self.pending.append(result.value)
            self._log({"kind": "throw", "player": player, "value": result.value})
            if not result.again:
                return
        # 승패가 아닌 중단으로 기록해 추가 던지기 규칙을 바꾸지 않습니다.
        self.truncated = True
        self.truncation_reason = "throw_safety_limit"

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        super().reset(seed=seed)
        self.game = YutGame(self.board)
        self.pending = []
        self.moves = 0
        self.events = []
        self.terminated = self.truncated = self.illegal_action = False
        self.truncation_reason = None
        first = (options or {}).get("first_player", self.config["first_player"])
        if first == "random":
            first = "robot" if self.np_random.integers(2) == 0 else "human"
        if first not in ("human", "robot"):
            raise ValueError("선공은 human 또는 robot입니다.")
        self.first_player = self.current = first
        if first == "robot":
            self._roll("robot")
            if self.truncated:
                raise RuntimeError("초기 윷 던지기 안전 한도 초과")
        # 상대 선공이면 첫 step은 대기 행동입니다. 상대가 첫 턴에 승리해도 누락하지 않습니다.
        return self._obs(), self._info()

    def _obs(self) -> np.ndarray:
        return self.codec.encode(self.game, "robot", self.pending, self.current == "robot")

    def action_masks(self) -> np.ndarray:
        if self.terminated or self.truncated or self.current == "human":
            mask = np.zeros(self.action_space.n, dtype=bool)
            mask[self.pass_action] = True
            return mask
        return self.codec.mask(self.game, "robot", self.pending)

    def _info(self) -> dict:
        return {"winner": "human" if self.illegal_action else self.game.winner(),
                "moves": self.moves, "first_player": self.first_player,
                "illegal_action": self.illegal_action,
                "truncation_reason": self.truncation_reason}

    def _apply(self, player: str, move: Move) -> None:
        detail = move_detail(self.game, player, move)
        result = self.game.move(player, move.piece, move.result)
        self.pending.remove(move.result)
        self.moves += 1
        self._log({"kind": "move", "player": player, **detail})
        if self.game.winner() is not None:
            self.terminated = True
        elif self.moves >= self.config["max_moves"]:
            self.truncated = True
            self.truncation_reason = "move_limit"
        elif result.captured and self.board.again_on_capture:
            self._roll(player)

    def _opponent_turn(self) -> None:
        self.current = "human"
        self._roll("human")
        while self.pending and not (self.terminated or self.truncated):
            if self.config["opponent"] == "rule":
                move = choose_rule(self.game, "human", self.pending)
            else:
                options = legal_moves(self.game, "human", self.pending)
                move = options[int(self.np_random.integers(len(options)))]
            self._apply("human", move)
        if not (self.terminated or self.truncated):
            self.current = "robot"
            self._roll("robot")

    def step(self, action: int):
        if self.terminated or self.truncated:
            raise RuntimeError("종료된 환경입니다. reset()을 호출하세요.")
        if not self.action_space.contains(action) or not self.action_masks()[int(action)]:
            # check_env의 무작위 행동도 처리하되 게임 상태를 변경하지 않습니다.
            self.illegal_action = self.terminated = True
            return self._obs(), float(self.config["loss_reward"]), True, False, self._info()
        if self.current == "human":
            self._opponent_turn()
        else:
            self._apply("robot", Move.decode(int(action)))
            if not self.pending and not (self.terminated or self.truncated):
                self._opponent_turn()
        winner = self.game.winner()
        reward = self.config["win_reward"] if winner == "robot" else (
            self.config["loss_reward"] if winner == "human" else 0.0)
        return self._obs(), float(reward), self.terminated, self.truncated, self._info()

    def render(self) -> str:
        return f"moves={self.moves} robot={self.game.pieces['robot']} human={self.game.pieces['human']} pending={self.pending}"
