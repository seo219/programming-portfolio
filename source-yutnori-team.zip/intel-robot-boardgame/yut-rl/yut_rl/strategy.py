"""실제 게임에서 호출할 순수 전략 어댑터. 로봇은 제어하지 않습니다."""
from pathlib import Path

from sb3_contrib import MaskablePPO

from .bundle import read_bundle
from .engine import GOAL, WAIT, YutBoard, YutGame
from .game import Move, StateCodec, choose_rule, move_detail


def validated_game(board: YutBoard, pieces: dict[str, list[str]]) -> YutGame:
    aliases = {"wait_robot": WAIT, "wait_human": WAIT,
               "goal_robot": GOAL, "goal_human": GOAL}
    codec = StateCodec(board)
    result = {}
    for player in ("human", "robot"):
        if player not in pieces or len(pieces[player]) != board.pieces:
            raise ValueError(f"{player} 말이 정확히 {board.pieces}개 필요합니다.")
        result[player] = [aliases.get(pos, pos) for pos in pieces[player]]
        if any(pos not in codec.cell_ids for pos in result[player]):
            raise ValueError("알 수 없는 칸 이름입니다.")
    overlaps = set(result["human"]) & set(result["robot"]) - {WAIT, GOAL}
    if overlaps:
        raise ValueError(f"양쪽 말이 같은 칸에 있습니다. 판 상태를 확인하세요: {overlaps}")
    game = YutGame(board, result)
    if game.winner():
        raise ValueError("이미 종료된 게임입니다.")
    return game


class ModelStrategy:
    """저장 모델로 말과 윷 결과를 선택합니다."""
    def __init__(self, model_path: Path):
        path, board_path, self.manifest = read_bundle(model_path)
        self.board = YutBoard(board_path)
        self.codec = StateCodec(self.board)
        self.model = MaskablePPO.load(path, device="cpu")

    def choose(self, pieces: dict[str, list[str]], pending: list[int],
               player: str = "robot", fallback: bool = True) -> dict:
        if player not in ("robot", "human"):
            raise ValueError("player는 robot 또는 human입니다.")
        if not pending or any(type(value) is not int or value not in range(1, 6) for value in pending):
            raise ValueError("pending에는 1~5 정수 결과가 하나 이상 필요합니다.")
        game = validated_game(self.board, pieces)
        mask = self.codec.mask(game, player, pending)
        source, error = "model", None
        try:
            action, _ = self.model.predict(self.codec.encode(game, player, pending),
                                           action_masks=mask, deterministic=True)
            action = int(action)
            if not 0 <= action < len(mask) or not mask[action]:
                raise ValueError("모델이 허용되지 않은 행동을 반환했습니다.")
            move = Move.decode(action)
        except Exception as exc:
            if not fallback:
                raise
            move = choose_rule(game, player, pending)
            source, error = "rule_fallback", str(exc)
        detail = move_detail(game, player, move)
        # 실제 슬롯 이름으로 바꿉니다. 잡힌 말 처리는 C1에서 별도로 수행합니다.
        detail["src_slot"] = f"wait_{player}" if detail["src"] == WAIT else detail["src"]
        detail["dst_slot"] = f"goal_{player}" if detail["dst"] == GOAL else detail["dst"]
        return {**detail, "source": source, "fallback_error": error}
