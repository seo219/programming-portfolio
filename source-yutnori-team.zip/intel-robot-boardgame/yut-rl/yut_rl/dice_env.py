"""주사위·빽도 전용 MaskablePPO 학습 환경."""
import gymnasium as gym
import numpy as np
from gymnasium import spaces

from .dice import DiceBoard, DiceCodec, DiceGame, DiceMove, choose_rule, legal_moves
from .env import read_config


class DiceEnv(gym.Env):
    def __init__(self, config=None):
        super().__init__()
        self.config = dict(read_config() if config is None else config)
        self.board = DiceBoard()
        self.codec = DiceCodec(self.board)
        self.pass_action = self.board.pieces * 6 + 1
        self.action_space = spaces.Discrete(self.pass_action + 1)
        self.observation_space = spaces.Box(0, np.inf, (self.codec.size,), dtype=np.float32)
        if self.config['opponent'] not in ('rule', 'random'):
            raise ValueError('주사위 학습 상대는 rule 또는 random입니다.')
        if self.config['max_moves'] < 1 or self.config['max_throws_per_batch'] < 1:
            raise ValueError('안전 한도는 양수여야 합니다.')

    def _roll(self):
        for _ in range(self.config['max_throws_per_batch']):
            throw = self.board.sample(self.np_random)
            self.pending.append(throw.value)
            if not throw.again:
                return
        self.truncated = True

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self.game = DiceGame(self.board)
        self.pending = []
        self.moves = 0
        self.terminated = self.truncated = False
        self.current = (options or {}).get('first_player', self.config['first_player'])
        if self.current == 'random':
            self.current = 'human' if self.np_random.integers(2) else 'robot'
        if self.current not in ('human', 'robot'):
            raise ValueError('선공이 잘못되었습니다.')
        if self.current == 'robot':
            self._roll()
        return self._obs(), self._info()

    def _obs(self):
        return self.codec.encode(self.game, 'robot', self.pending, self.current == 'robot')

    def _info(self):
        return dict(winner=self.game.winner(), moves=self.moves)

    def action_masks(self):
        if self.current == 'human' or self.terminated or self.truncated:
            mask = np.zeros(self.action_space.n, dtype=bool)
            mask[self.pass_action] = True
            return mask
        return self.codec.mask(self.game, 'robot', self.pending)

    def _apply(self, player, move):
        result = self.game.move(player, move.piece, move.result)
        self.pending.remove(move.result)
        self.moves += 1
        if self.game.winner():
            self.terminated = True
        elif self.moves >= self.config['max_moves']:
            self.truncated = True
        elif result.captured and self.board.again_on_capture:
            self._roll()

    def _opponent_turn(self):
        self.current = 'human'
        self._roll()
        while self.pending and not (self.terminated or self.truncated):
            if self.config['opponent'] == 'rule':
                move = choose_rule(self.game, 'human', self.pending)
            else:
                choices = legal_moves(self.game, 'human', self.pending)
                move = choices[int(self.np_random.integers(len(choices)))]
            self._apply('human', move)
        if not (self.terminated or self.truncated):
            self.current = 'robot'
            self._roll()

    def step(self, action):
        if self.terminated or self.truncated:
            raise RuntimeError('종료된 게임입니다.')
        if not self.action_space.contains(action) or not self.action_masks()[int(action)]:
            self.terminated = True
            return self._obs(), float(self.config['loss_reward']), True, False, dict(winner='human', illegal_action=True)
        if self.current == 'human':
            self._opponent_turn()
        else:
            self._apply('robot', DiceMove.decode(int(action)))
            if not self.pending and not (self.terminated or self.truncated):
                self._opponent_turn()
        winner = self.game.winner()
        reward = self.config['win_reward'] if winner == 'robot' else self.config['loss_reward'] if winner else 0.0
        return self._obs(), float(reward), self.terminated, self.truncated, self._info()
