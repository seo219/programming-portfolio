"""말 2개와 실제 윷 확률표를 사용하는 현재 규칙."""
import json
from pathlib import Path

from .engine import YutBoard, YutGame
from .game import choose_rule, move_detail
from .strategy import ModelStrategy

BOARD = Path(__file__).resolve().parents[1] / 'config/yut_sticks_2pieces.json'
RULES_ID = 'sticks_2pieces_no_backdo_v1'


class SticksBoard(YutBoard):
    def __init__(self, path=BOARD):
        super().__init__(path)
        self.path_file = Path(path)
        data = json.loads(self.path_file.read_text(encoding='utf-8'))
        self.flat_probability = data['flat_probability']
        self.rules_id = RULES_ID
        if self.pieces != 2 or data['backdo'] or data['throw_mode'] != 'four_independent_sticks':
            raise ValueError('현재 규칙은 말 2개·윷가락 4개·빽도 제외입니다.')
        if self.flat_probability != .5:
            raise ValueError('요청된 확률표는 각 윷가락 앞면 확률 0.5입니다.')

    def sample(self, rng):
        return self.throw(sum(rng.random() < self.flat_probability for _ in range(4)))

    def path(self, pos, steps):
        if type(steps) is not int or steps not in range(1, 6):
            raise ValueError('현재 규칙은 빽도 없이 1~5칸 전진만 허용합니다.')
        return super().path(pos, steps)


class SticksRuleStrategy:
    def __init__(self):
        self.board = SticksBoard()
        self.model_path = None
        self.label = '말 2개 · 윷 규칙 AI (학습 모델 없음)'

    def choose(self, pieces, pending, player='robot', fallback=False):
        if not pending or any(type(v) is not int or v not in range(1, 6) for v in pending):
            raise ValueError('빽도 없이 도·개·걸·윷·모만 사용합니다.')
        game = YutGame(self.board, pieces)
        return dict(**move_detail(game, player, choose_rule(game, player, pending)), source='sticks_rule')


class SticksModelStrategy:
    def __init__(self, model_path):
        self.model_path = Path(model_path).resolve()
        self.legacy = ModelStrategy(self.model_path)
        self.board = SticksBoard()
        old = self.legacy.board
        if (old.pieces != self.board.pieces or old.routes != self.board.routes or
                old.route_of != self.board.route_of or old.yut != self.board.yut or
                old.again_on_capture != self.board.again_on_capture or
                self.legacy.manifest['config']['flat_probability'] != self.board.flat_probability):
            raise ValueError('모델의 말 수·이동 규칙·윷 확률이 현재 말 2개 규칙과 다릅니다.')
        self.label = '말 2개 · PPO (' + self.model_path.parent.name + ')'

    def choose(self, pieces, pending, player='robot', fallback=False):
        return self.legacy.choose(pieces, pending, player, fallback=False)
