"""기존 게임 규칙을 유지하며 학습 상대와 탐색 일정을 조정합니다."""
import numpy as np
from stable_baselines3.common.callbacks import BaseCallback
from .env import YutEnv
from .game import Move, choose_rule, legal_moves


def interpolate(start: float, end: float, remaining: float) -> float:
    return end + (start - end) * float(np.clip(remaining, 0, 1))


class ExplorationSchedule(BaseCallback):
    """추가 경기를 실행하지 않고 탐색 계수만 점차 낮춥니다."""
    def __init__(self, start: float, end: float, steps: int):
        super().__init__()
        self.start, self.end, self.steps = start, end, steps

    def _on_step(self) -> bool:
        self.model.ent_coef = interpolate(self.start, self.end, 1 - self.num_timesteps / self.steps)
        return True


class MixedOpponentEnv(YutEnv):
    """매 경기 규칙·무작위·동결된 과거 모델 중 상대를 하나 고릅니다."""
    def __init__(self, *args, frozen_model=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.frozen_model = frozen_model
        self.kinds = list(self.config['opponent_mix'])
        self.weights = np.asarray(list(self.config['opponent_mix'].values()), dtype=float)
        if not set(self.kinds) <= {'rule', 'random', 'frozen'} or np.any(self.weights < 0) or not np.isclose(self.weights.sum(), 1):
            raise ValueError('상대 비율은 음수가 아니며 합이 1이어야 합니다.')
        if self.config['opponent_mix'].get('frozen', 0) > 0 and frozen_model is None:
            raise ValueError('동결된 상대 모델이 필요합니다.')
        self.opponent_kind = 'rule'
        self.episode_counts = dict.fromkeys(self.kinds, 0)

    def reset(self, *, seed=None, options=None):
        obs, info = super().reset(seed=seed, options=options)
        self.opponent_kind = str(self.np_random.choice(self.kinds, p=self.weights))
        self.episode_counts[self.opponent_kind] += 1
        return obs, {**info, 'opponent_kind': self.opponent_kind}

    def _opponent_turn(self) -> None:
        self.current = 'human'
        self._roll('human')
        while self.pending and not (self.terminated or self.truncated):
            if self.opponent_kind == 'rule':
                move = choose_rule(self.game, 'human', self.pending)
            elif self.opponent_kind == 'random':
                options = legal_moves(self.game, 'human', self.pending)
                move = options[int(self.np_random.integers(len(options)))]
            else:
                mask = self.codec.mask(self.game, 'human', self.pending)
                action, _ = self.frozen_model.predict(self.codec.encode(self.game, 'human', self.pending),
                                                      action_masks=mask, deterministic=True)
                action = int(action)
                if not 0 <= action < len(mask) or not mask[action]:
                    raise ValueError('동결 모델의 불법 행동')
                move = Move.decode(action)
            self._apply('human', move)
        if not (self.terminated or self.truncated):
            self.current = 'robot'
            self._roll('robot')
