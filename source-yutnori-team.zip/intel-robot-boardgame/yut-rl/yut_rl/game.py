"""공통 행동 형식과 단일 대결 상태를 제공합니다."""
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np

from .engine import GOAL, WAIT, YutBoard, YutGame, other

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BOARD = ROOT / "config" / "yut_board.json"
VALUES = (1, 2, 3, 4, 5)


@dataclass(frozen=True)
class Move:
    """말 번호는 0부터, 결과는 도=1부터 모=5까지입니다."""
    piece: int
    result: int

    @property
    def action(self) -> int:
        return self.piece * len(VALUES) + self.result - 1

    @classmethod
    def decode(cls, action: int) -> "Move":
        return cls(action // len(VALUES), action % len(VALUES) + 1)


def legal_moves(game: YutGame, player: str, pending: list[int]) -> list[Move]:
    return [Move(piece, value) for piece in game.options(player)
            for value in sorted(set(pending))]


def choose_rule(game: YutGame, player: str, pending: list[int]) -> Move:
    """잡기 > 업기 > 앞선 말 > 새 말. 결과 순서도 함께 비교합니다."""
    def rank(move: Move) -> tuple:
        preview = game.preview(player, move.piece, move.result)
        src = game.pieces[player][move.piece]
        if preview.captured:
            return 0, -len(preview.captured), game.board.distance(preview.dst), move.action
        if preview.stacked > len(preview.moved):
            return 1, 0, game.board.distance(preview.dst), move.action
        if src != WAIT:
            return 2, game.board.distance(src), game.board.distance(preview.dst), move.action
        return 3, 0, game.board.distance(preview.dst), move.action

    moves = legal_moves(game, player, pending)
    if not moves:
        raise ValueError("선택 가능한 이동이 없습니다.")
    return min(moves, key=rank)


class StateCodec:
    """말별 one-hot 위치, 남은 결과별 개수, 내 차례 여부를 인코딩합니다."""
    version = "positions-onehot_pending-counts_turn_v1"

    def __init__(self, board: YutBoard):
        self.board = board
        cells = {cell for route in board.routes.values() for cell in route}
        self.cells = [WAIT, *sorted(cells - {WAIT, GOAL}), GOAL]
        self.cell_ids = {cell: i for i, cell in enumerate(self.cells)}
        self.size = 2 * board.pieces * len(self.cells) + len(VALUES) + 1

    def encode(self, game: YutGame, player: str, pending: list[int], my_turn: bool = True) -> np.ndarray:
        obs = np.zeros(self.size, dtype=np.float32)
        offset = 0
        for side in (player, other(player)):
            for pos in game.pieces[side]:
                obs[offset + self.cell_ids[pos]] = 1
                offset += len(self.cells)
        counts = Counter(pending)
        # 결과 수를 자르지 않습니다. /10은 입력 크기만 조절합니다.
        obs[offset:offset + 5] = [counts[value] / 10 for value in VALUES]
        obs[-1] = float(my_turn)
        return obs

    def mask(self, game: YutGame, player: str, pending: list[int]) -> np.ndarray:
        mask = np.zeros(self.board.pieces * 5 + 1, dtype=bool)
        for move in legal_moves(game, player, pending):
            mask[move.action] = True
        return mask


def move_detail(game: YutGame, player: str, move: Move) -> dict:
    preview = game.preview(player, move.piece, move.result)
    return {**asdict(move), "action": move.action, "src": preview.src,
            "dst": preview.dst, "moved": preview.moved, "captured": preview.captured}
