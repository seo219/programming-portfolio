"""동일 확률 주사위 6결과와 빽도. 과거 윷 모델의 규칙 코드는 보존합니다."""
import json
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np

from .engine import GOAL, WAIT, MoveResult, YutBoard, YutGame
from .game import StateCodec

BOARD = Path(__file__).resolve().parents[1] / 'config/yut_dice.json'
VALUES = (-1, 1, 2, 3, 4, 5)
NAMES = {-1: '빽도', 1: '도', 2: '개', 3: '걸', 4: '윷', 5: '모'}


class DiceBoard(YutBoard):
    """눈 1~6을 동일 확률로 뽑으며 역방향 연결은 설정에 둡니다."""
    def __init__(self, path=BOARD):
        super().__init__(path)
        self.path_file = Path(path)
        data = json.loads(self.path_file.read_text(encoding='utf-8'))
        self.backward = data['backward']
        if not data['backdo'] or data['throw_mode'] != 'uniform_d6':
            raise ValueError('빽도와 uniform_d6 규칙이 필요합니다.')
        if set(self.yut) != set(range(1, 7)) or tuple(self.yut[i].value for i in range(1, 7)) != VALUES:
            raise ValueError('주사위 눈 1~6은 빽도, 도, 개, 걸, 윷, 모여야 합니다.')
        cells = {p for route in self.routes.values() for p in route} - {WAIT, GOAL}
        if set(self.backward) != cells or any(p not in cells for p in self.backward.values()):
            raise ValueError('모든 판 위 칸의 역방향 연결이 필요합니다.')

    def sample(self, rng):
        return self.throw(min(int(rng.random() * 6) + 1, 6))

    def path(self, pos, steps):
        if steps == -1:
            if pos in (WAIT, GOAL):
                raise ValueError('대기·완주 말에는 빽도를 적용할 수 없습니다.')
            return [self.backward[pos]]
        if steps not in VALUES:
            raise ValueError('유효하지 않은 주사위 결과입니다.')
        return super().path(pos, steps)


class DiceGame(YutGame):
    def move(self, player, piece, steps):
        if piece == -1:
            if steps != -1 or any(pos not in (WAIT, GOAL) for pos in self.pieces[player]):
                raise ValueError('판 위에 말이 없을 때만 빽도를 소모합니다.')
            return MoveResult(WAIT, [WAIT], [], [], 0)
        if type(piece) is not int or not 0 <= piece < self.board.pieces:
            raise ValueError('말 번호가 잘못되었습니다.')
        return super().move(player, piece, steps)

    def preview(self, player, piece, steps):
        trial = DiceGame(self.board, {p: list(v) for p, v in self.pieces.items()})
        return trial.move(player, piece, steps)


@dataclass(frozen=True)
class DiceMove:
    """행동 0은 빽도 소모, 나머지는 말별 여섯 결과입니다."""
    piece: int
    result: int

    @property
    def action(self):
        return 0 if self.piece == -1 else 1 + self.piece * 6 + VALUES.index(self.result)

    @classmethod
    def decode(cls, action):
        if action == 0:
            return cls(-1, -1)
        if type(action) is not int or action < 0:
            raise ValueError('행동 번호가 잘못되었습니다.')
        return cls((action - 1) // 6, VALUES[(action - 1) % 6])


def legal_moves(game, player, pending):
    if any(type(v) is not int or v not in VALUES for v in pending):
        raise ValueError('주사위 결과는 -1, 1, 2, 3, 4, 5입니다.')
    moves = []
    for value in sorted(set(pending)):
        pieces = [i for i in game.options(player) if value != -1 or game.pieces[player][i] != WAIT]
        moves.extend(DiceMove(i, value) for i in pieces)
        if value == -1 and not pieces:
            moves.append(DiceMove(-1, -1))
    return moves


def detail(game, player, move):
    preview = game.preview(player, move.piece, move.result)
    return dict(**asdict(move), action=move.action, src=preview.src, dst=preview.dst,
                moved=preview.moved, captured=preview.captured)


def choose_rule(game, player, pending):
    """즉시 승리, 잡기, 업기, 완주 거리 순으로 비교하는 주사위 기준 전략."""
    def rank(move):
        if move.piece < 0:
            return (4, 0, 0, move.action)
        result = game.preview(player, move.piece, move.result)
        remaining = sum(pos != GOAL for pos in game.pieces[player])
        if result.dst == GOAL and len(result.moved) == remaining:
            return (0, 0, 0, move.action)
        return (1 if result.captured else 2 if result.stacked > len(result.moved) else 3,
                -len(result.captured), game.board.distance(result.dst), move.action)
    return min(legal_moves(game, player, pending), key=rank)


class DiceCodec(StateCodec):
    version = 'dice-six-results_backdo_v1'

    def __init__(self, board):
        super().__init__(board)
        self.size += 1

    def encode(self, game, player, pending, my_turn=True):
        # 기존 관측의 마지막 차례 비트 앞에 빽도 개수를 추가합니다.
        old = super().encode(game, player, [v for v in pending if v > 0], my_turn)
        old[-2] = pending.count(-1) / 10
        return old

    def mask(self, game, player, pending):
        mask = np.zeros(self.board.pieces * 6 + 2, dtype=bool)
        for move in legal_moves(game, player, pending):
            mask[move.action] = True
        return mask


class LegacyDiceStrategy:
    """기존 모델은 양수 결과만 선택하고 빽도만 남으면 보조 규칙을 씁니다."""
    def __init__(self, legacy, board=None):
        self.legacy = legacy
        self.board = board or DiceBoard()
        if self.board.pieces != legacy.board.pieces or self.board.routes != legacy.board.routes:
            raise ValueError('기존 모델과 주사위 판의 말 수·정방향 경로가 다릅니다.')
        self.label = '기존 PPO + 빽도 보조 규칙 (주사위 재학습 전)'
        self.model_path = None

    def choose(self, pieces, pending, player='robot', fallback=False):
        game = DiceGame(self.board, pieces)
        forwards = [v for v in pending if v > 0]
        if forwards:
            selected = self.legacy.choose(pieces, forwards, player, fallback=False)
            move = DiceMove(selected['piece'], selected['result'])
            source = 'legacy_model_forward'
        else:
            move = choose_rule(game, player, pending)
            source = 'backdo_rule'
        return dict(**detail(game, player, move), source=source)


class DiceRuleStrategy:
    def __init__(self):
        self.board = DiceBoard()
        self.label = '주사위 규칙 AI (학습 모델 아님)'
        self.model_path = None

    def choose(self, pieces, pending, player='robot', fallback=False):
        game = DiceGame(self.board, pieces)
        return dict(**detail(game, player, choose_rule(game, player, pending)), source='dice_rule')


class DiceModelStrategy:
    """새 주사위 규격으로 학습된 모델만 로드합니다."""
    def __init__(self, model_path):
        from sb3_contrib import MaskablePPO
        from .bundle import sha256
        self.model_path = Path(model_path).resolve()
        manifest = json.loads(self.model_path.with_name('manifest.json').read_text(encoding='utf-8'))
        board_path = self.model_path.with_name('board.json')
        if manifest.get('schema') != DiceCodec.version or manifest.get('board_sha256') != sha256(board_path):
            raise ValueError('주사위 모델 규격 또는 판 해시가 다릅니다.')
        if manifest['board_sha256'] != sha256(BOARD):
            raise ValueError('현재 웹 규칙과 모델의 판이 다릅니다.')
        for name in ('yut_rl/dice.py', 'yut_rl/dice_env.py'):
            if manifest.get('source_sha256', {}).get(name) != sha256(BOARD.parents[1] / name):
                raise ValueError('주사위 학습 당시와 규칙 코드가 다릅니다.')
        self.board = DiceBoard(board_path)
        self.codec = DiceCodec(self.board)
        self.model = MaskablePPO.load(self.model_path, device='cpu')
        if self.model.observation_space.shape != (self.codec.size,) or self.model.action_space.n != self.board.pieces * 6 + 2:
            raise ValueError('주사위 모델의 입출력 크기가 다릅니다.')
        self.label = '주사위 6결과 PPO 모델'

    def choose(self, pieces, pending, player='robot', fallback=False):
        game = DiceGame(self.board, pieces)
        mask = self.codec.mask(game, player, pending)
        action, _ = self.model.predict(self.codec.encode(game, player, pending), action_masks=mask, deterministic=True)
        action = int(action)
        if not 0 <= action < len(mask) or not mask[action]:
            raise ValueError('모델이 잘못된 행동을 반환했습니다.')
        return dict(**detail(game, player, DiceMove.decode(action)), source='dice_model')
