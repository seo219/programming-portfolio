"""말 2개·실제 윷 확률·빽도 규칙 (11/03). 메인 게임(src/game)의 규칙과 같습니다.

행동 인코딩과 관측은 주사위 변형(dice.py)의 빽도 형식을 그대로 씁니다.
- 행동 0: 남은 빽도 버리기(무효). 판 위에 말이 없어 남은 결과를 하나도 쓸 수 없을 때만 허용
- 행동 1 + 말 * 6 + 결과 순번: 그 말에 결과(-1, 1~5) 적용
빽도 없는 11/02 규칙(sticks.py)은 과거 모델 재현용으로 남겨 둡니다.
"""
import json
from pathlib import Path

import numpy as np

from .bundle import sha256
from .dice import VALUES, DiceCodec, DiceGame, DiceMove, detail
from .engine import GOAL, WAIT, Throw, YutBoard

ROOT = Path(__file__).resolve().parents[1]
BOARD = ROOT / 'config/yut_sticks_2pieces_backdo.json'
RULES_ID = 'sticks_2pieces_backdo_v1'
SOURCES = ('yut_rl/sticks_backdo.py', 'yut_rl/sticks_backdo_env.py', 'yut_rl/dice.py', 'yut_rl/engine.py')


class SticksBackdoBoard(YutBoard):
    def __init__(self, path=BOARD):
        super().__init__(path)
        self.path_file = Path(path)
        data = json.loads(self.path_file.read_text(encoding='utf-8'))
        self.flat_probability = data['flat_probability']
        self.rules_id = RULES_ID
        self.yut[-1] = Throw(*data['yut']['-1'])
        self.backward = {k: v for k, v in data['backward'].items() if not k.startswith('_')}
        if self.pieces != 2 or not data['backdo'] or data['throw_mode'] != 'four_sticks_marked_backdo':
            raise ValueError('현재 규칙은 말 2개·윷가락 4개·빽도 사용입니다.')
        if self.flat_probability != .5:
            raise ValueError('요청된 확률표는 각 윷가락 앞면 확률 0.5입니다.')
        if sorted(t.value for t in self.yut.values()) != sorted(VALUES):
            raise ValueError('윷 결과는 빽도, 도, 개, 걸, 윷, 모여야 합니다.')
        cells = {p for route in self.routes.values() for p in route} - {WAIT, GOAL}
        if set(self.backward) != cells or any(p not in cells for p in self.backward.values()):
            raise ValueError('모든 판 위 칸의 빽도 연결이 필요합니다.')

    def sample(self, rng) -> Throw:
        """윷가락 4개. 마지막 가락이 표시 가락이라 그것만 앞이면 빽도."""
        sticks = [rng.random() < self.flat_probability for _ in range(4)]
        return self.yut[-1 if sum(sticks) == 1 and sticks[-1] else sum(sticks)]

    def path(self, pos, steps):
        if steps == -1:
            if pos in (WAIT, GOAL):
                raise ValueError('대기·완주 말에는 빽도를 적용할 수 없습니다.')
            return [self.backward[pos]]
        if type(steps) is not int or steps not in range(1, 6):
            raise ValueError('윷 결과는 -1 또는 1~5칸입니다.')
        return super().path(pos, steps)


def legal_moves(game, player, pending):
    """적용할 수 있는 (말, 결과). 하나도 없고 빽도만 남았으면 빽도 버리기(무효) 하나."""
    if any(type(v) is not int or v not in VALUES for v in pending):
        raise ValueError('윷 결과는 -1, 1, 2, 3, 4, 5입니다.')
    moves = [DiceMove(i, value) for value in sorted(set(pending)) for i in game.options(player)
             if value != -1 or game.pieces[player][i] != WAIT]
    if not moves and pending:
        moves.append(DiceMove(-1, -1))
    return moves


def choose_rule(game, player, pending):
    """잡기 > 업기 > 앞선 말 전진 > 새 말 > 빽도(완주에서 가장 먼 말) > 빽도 버리기."""
    def rank(move):
        if move.piece < 0:
            return 5, 0, 0, move.action
        preview = game.preview(player, move.piece, move.result)
        src = game.pieces[player][move.piece]
        if preview.captured:
            return 0, -len(preview.captured), game.board.distance(preview.dst), move.action
        if preview.stacked > len(preview.moved):
            return 1, 0, game.board.distance(preview.dst), move.action
        if move.result < 0:
            return 4, -game.board.distance(src), 0, move.action
        if src != WAIT:
            return 2, game.board.distance(src), game.board.distance(preview.dst), move.action
        return 3, 0, game.board.distance(preview.dst), move.action

    moves = legal_moves(game, player, pending)
    if not moves:
        raise ValueError('선택 가능한 이동이 없습니다.')
    return min(moves, key=rank)


class SticksBackdoCodec(DiceCodec):
    """관측: 말별 위치 one-hot, 결과별 개수(도~모, 빽도), 내 차례. 행동: 말 2개 × 6결과 + 빽도 버리기 + 대기."""
    version = 'sticks-backdo_positions-onehot_pending6-counts_turn_v1'

    def mask(self, game, player, pending):
        mask = np.zeros(self.board.pieces * 6 + 2, dtype=bool)
        for move in legal_moves(game, player, pending):
            mask[move.action] = True
        return mask


def source_hashes() -> dict:
    return {name: sha256(ROOT / name) for name in SOURCES}


class SticksBackdoRuleStrategy:
    def __init__(self):
        self.board = SticksBackdoBoard()
        self.model_path = None
        self.label = '말 2개 · 빽도 · 윷 규칙 AI (학습 모델 없음)'

    def choose(self, pieces, pending, player='robot', fallback=False):
        game = DiceGame(self.board, pieces)
        return dict(**detail(game, player, choose_rule(game, player, pending)), source='sticks_backdo_rule')


def read_backdo_bundle(model_path):
    """모델 폴더의 manifest·board가 현재 규칙·코드와 같은지 확인합니다."""
    path = Path(model_path).resolve()
    manifest = json.loads(path.with_name('manifest.json').read_text(encoding='utf-8'))
    board_path = path.with_name('board.json')
    if manifest.get('schema') != SticksBackdoCodec.version or manifest.get('board_sha256') != sha256(board_path):
        raise ValueError('빽도 규칙 모델이 아니거나 판 해시가 다릅니다.')
    if manifest['board_sha256'] != sha256(BOARD):
        raise ValueError('현재 빽도 규칙과 모델의 판이 다릅니다.')
    if manifest.get('source_sha256') != source_hashes():
        raise ValueError('학습 당시와 규칙·환경 코드가 다릅니다. 같은 버전을 쓰거나 재학습하세요.')
    return path, board_path, manifest


class SticksBackdoModelStrategy:
    """빽도 규칙으로 학습한 모델만 불러옵니다. 빽도 없는 11/02 모델은 거부합니다."""
    def __init__(self, model_path):
        from sb3_contrib import MaskablePPO
        self.model_path, board_path, self.manifest = read_backdo_bundle(model_path)
        self.board = SticksBackdoBoard(board_path)
        self.codec = SticksBackdoCodec(self.board)
        self.model = MaskablePPO.load(self.model_path, device='cpu')
        if (self.model.observation_space.shape != (self.codec.size,) or
                self.model.action_space.n != self.board.pieces * 6 + 2):
            raise ValueError('빽도 규칙 모델의 입출력 크기가 다릅니다.')
        self.label = '말 2개 · 빽도 · PPO (' + self.model_path.parent.name + ')'

    def choose(self, pieces, pending, player='robot', fallback=False):
        game = DiceGame(self.board, pieces)
        mask = self.codec.mask(game, player, pending)
        action, _ = self.model.predict(self.codec.encode(game, player, pending), action_masks=mask,
                                       deterministic=True)
        action = int(action)
        if not 0 <= action < len(mask) or not mask[action]:
            raise ValueError('모델이 허용되지 않은 행동을 반환했습니다.')
        return dict(**detail(game, player, DiceMove.decode(action)), source='model')
