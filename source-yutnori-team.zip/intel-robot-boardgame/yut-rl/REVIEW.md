# 팀 검토 안내

이 폴더는 윷놀이 강화학습의 도입 여부를 논의하기 위한 독립 작업물입니다. 기존 `src/main.py`, 로봇·비전 모듈, 루트 의존성 파일은 변경하지 않았습니다. 이 브랜치를 올리는 것만으로 기존 게임에서 학습 모델을 사용하지 않습니다.

## 먼저 볼 자료

- [전체 작업 보고서 PDF](docs/yut_ai_complete_history_2026-11-01.pdf): 제작 방식, 오픈소스 역할, 전체 학습 이력, 비교 결과, 통합 계획.
- [최신 실험 결과](docs/results/four_pieces_tuned_10m/RESULT.md): 새 규칙 AI 평가 1,000판에서 55.6%. 사람 상대나 실제 로봇 성능을 검증한 수치는 아닙니다.
- [README](README.md): 설치, 학습, 평가, 추론 방법.
- `replay/yut_replay.html`: 저장된 시뮬레이션 경기 다시보기. 브라우저에서 열 수 있습니다.

## 포함·제외 범위

포함: Python 코드, 테스트, 규칙·학습 설정, 의존성 잠금 파일, 설치 스크립트, 평가 요약, 경기 다시보기, 보고서.

제외: 모델 가중치 ZIP, 체크포인트, 전체 실행 로그, 내보내기 ZIP, 가상환경, PC별 `.python-path`, 임시 파일. 저장소 AGENTS.md와 협업 규칙의 모델 커밋 제외 원칙을 따릅니다. 원본 로컬 작업 폴더 `F:/intel_pj/yut-rl`은 보존합니다.

보고서·결과 문서의 경로는 당시 로컬 실험 위치를 기록한 것입니다. 해당 모델·로그가 Git에 모두 포함됐다는 뜻은 아닙니다. 결과 요약은 `docs/results/`에 복사했습니다.

## 새 PC에서 가능한 작업

Windows에서 uv를 설치한 뒤 이 폴더에서 실행합니다.

```powershell
powershell -ExecutionPolicy Bypass -File .\setup.ps1
.\python.ps1 train.py --steps 2048 --seed 42 --output models/review_smoke
```

이는 규칙 AI를 상대로 새 모델을 만드는 짧은 동작 확인입니다. 기존 성적을 재현하는 충분한 학습량은 아닙니다. setup.ps1은 Python 3.12 계열을 요청하고 requirements.lock으로 패키지를 고정합니다. 기존 검증 환경은 Python 3.12.14 / Windows / CPU입니다.

기존 모델의 추론·이어 학습에는 해당 실험 폴더의 `final_model.zip`, `board.json`, `manifest.json`이 별도로 필요합니다. 최신 혼합 상대 학습에는 `models/four_pieces_18m/`의 상대 모델도 필요합니다. 공유 위치는 팀에서 결정해야 하며, 아직 Hugging Face Hub에 업로드하지 않았습니다.

`finish_tuned.py`와 `build_replay.py`는 과거 실험 산출물을 참조하는 작업 자동화 스크립트입니다. 필요한 모델·기록을 별도로 준비해야 같은 파이프라인을 실행할 수 있습니다. 이미 생성된 리플레이 HTML은 모델 없이 열 수 있습니다.

## 논의할 사항

1. 규칙 AI 대비 성능 향상이 프로젝트 일정과 시연 목표에 충분한가?
2. C1의 게임 상태와 전략 어댑터를 어떻게 연결하고 오류를 처리할 것인가?
3. 모델 공유 위치·버전 관리와 추가 평가 담당자를 어떻게 정할 것인가?

PR 생성·병합은 별도 결정입니다. 이 작업은 검토용 브랜치 커밋·push까지만 진행합니다.
