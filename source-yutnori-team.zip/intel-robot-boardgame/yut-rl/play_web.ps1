$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$env:PYTHONUTF8 = '1'
& "$PSScriptRoot/python.ps1" "$PSScriptRoot/play_web.py" @args
