"""본 학습 종료 후에만 최종 모델 평가·비교·기보·패키징을 실행합니다."""
import json
import subprocess
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from yut_rl.bundle import write_json
from yut_rl.game import ROOT

NAME = 'four_pieces_tuned_10m'
OUT = ROOT/'models'/NAME
STATUS = ROOT/'runs'/f'{NAME}_pipeline.json'
LOG = ROOT/'runs'/f'{NAME}_final_evaluation.log'


def phase(value: str) -> None:
    write_json(STATUS, {'phase':value,'updated_utc':datetime.now(timezone.utc).isoformat(), 'results':str(OUT/'RESULT.md')})


def run(*args: str) -> None:
    with LOG.open('a',encoding='utf-8') as log:
        subprocess.run([sys.executable,*args],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)


def main() -> None:
    if (OUT/'COMPARISON.json').exists():
        raise FileExistsError('완료된 비교 결과가 있습니다.')
    phase('waiting_for_training_completion')
    # 승률·중간 모델을 측정하지 않고 완료 상태만 확인합니다.
    while True:
        manifest=json.loads((OUT/'manifest.json').read_text(encoding='utf-8'))
        if manifest['status'] != 'training':
            break
        time.sleep(10)
    if manifest['status'] != 'complete':
        raise RuntimeError(f"학습 상태: {manifest['status']}; 최종 평가를 실행하지 않습니다.")
    assert manifest['intermediate_evaluation'] is False
    assert not (OUT/'evaluations.npz').exists() and not (OUT/'best_model.zip').exists()
    phase('final_evaluation')
    models = {
        'baseline_10m': ('기존 설정 · 누적 약 1000만', 'models/four_pieces_18m/checkpoint_10001536_steps.zip'),
        'baseline_18m': ('기존 설정 · 누적 약 1800만', 'models/four_pieces_18m/final_model.zip'),
        'tuned_10m': ('변경 설정 · 신규 약 1000만', f'models/{NAME}/final_model.zip'),
    }
    scenarios=[('rule_existing','rule',3000000),('rule_fresh','rule',6000000),('random_fresh','random',6000000)]
    reports=[]
    for key,(label,model) in models.items():
        for scenario,opponent,seed in scenarios:
            output=f'runs/{NAME}_{key}_{scenario}.json'
            args=['evaluate.py','--model',model,'--games','1000','--seed',str(seed),'--opponent',opponent,'--output',output]
            if key=='tuned_10m' and scenario=='rule_fresh':
                args+=['--trace',f'runs/{NAME}_game.json']
            run(*args)
            reports.append({'label':label,'key':key,'scenario':scenario,**json.loads((ROOT/output).read_text(encoding='utf-8'))})
    phase('writing_results')
    run('predict.py','--model',f'models/{NAME}/final_model.zip','--state','examples/state.json')
    run('build_replay.py')
    with LOG.open('a',encoding='utf-8') as log:
        subprocess.run(['node','replay/check_replay.cjs'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    write_json(OUT/'COMPARISON.json',{'training':manifest,'reports':reports})
    lookup={(r['key'],r['scenario']):r for r in reports}
    rows='\n'.join(f"| {label} | " + ' | '.join(f"{lookup[key,s]['win_rate_all_games']:.1%}" for s,_,_ in scenarios)+' |' for key,(label,_) in models.items())
    fresh=lookup['tuned_10m','rule_fresh']
    low,high=fresh['win_rate_95pct_wilson']
    violations=sum(r['illegal_actions'] for r in reports)
    truncated=sum(r['truncated'] for r in reports)
    text=f'''# 여러 학습 조건 변경: 1000만 스텝 최종 비교

완료 기록 시각(UTC): {datetime.now(timezone.utc).isoformat()}

## 실행 조건

- 기존 모델을 이어 학습하지 않고 시드 43으로 처음부터 학습했습니다.
- 요청 10,000,000 / 실제 {manifest['total_steps']:,}스텝, 학습 시간 {manifest['elapsed_seconds']/60:.1f}분 (최종 평가 제외).
- **중간 승률 평가 0회**. best 모델을 선택하지 않고 마지막 모델만 평가했습니다.
- 100만 스텝마다 남긴 체크포인트는 장애 복구용 저장이며 평가에 사용하지 않았습니다.
- 편당 말 4개, 이동·잡기·업기·지름길·추가 던지기 규칙과 승리 +1/패배 -1 보상은 유지했습니다.

| 항목 | 기존 | 이번 실험 |
|---|---|---|
| 학습 상대 | 규칙 AI만 | 경기마다 규칙 60% / 무작위 20% / 동결된 기존 1800만 모델 20% |
| 학습률 | 0.0003 고정 | 0.0003 → 0.00003 선형 감소 |
| 탐색 계수 | 0.01 고정 | 0.02 → 0.005 선형 감소 |
| 미래 보상 할인율 | 0.99 | 0.995 |
| 은닉층 | 64 → 64 | 128 → 128 |
| 환경별 경험 수집 | 256스텝 | 512스텝 |
| 배치 크기 | 64 | 128 |
| 환경 수 / 반복 업데이트 | 4 / 4회 | 동일 |

동결된 상대는 이번 학습 중 업데이트하지 않았습니다. 과거 모델을 활용한 혼합 상대 학습이며 실시간 자기 대결은 아닙니다. 여러 조건과 학습 시드가 달라졌으므로 개별 요소의 인과 효과를 구분할 수 없습니다. 또한 과거 1800만 모델을 상대에 사용했으므로 전체 사전 학습 자원까지 같은 예산의 비교는 아닙니다.

## 학습 종료 후 평가

각 셀은 1,000판(선후공 500판씩)의 승률입니다. 기존 비교 세트는 시드 3000000, 새 세트는 시드 6000000부터입니다. 같은 시드라도 행동에 따라 윷 던지기 횟수가 달라질 수 있습니다.

| 모델 | 규칙 AI · 기존 세트 | 규칙 AI · 새 세트 | 무작위 AI · 새 세트 |
|---|---:|---:|---:|
{rows}

이번 모델의 새 규칙 AI 평가 승률은 {fresh['win_rate_all_games']:.1%}, Wilson 95% 구간은 {low:.2%}~{high:.2%}입니다. 전체 평가 9,000판에서 불법 행동 {violations}회, 경기 중단 {truncated}회였습니다.

기존 약 1000만 모델은 `checkpoint_10001536_steps.zip`이며 1,800만 모델 폴더에 보관된 과거 체크포인트입니다. 새 모델과 학습량은 비슷하지만 동일한 초기 시드·연속 학습 이력은 아닙니다. 이 결과는 설정 조합의 비교이며 다른 학습 시드에서도 반복하기 전 일반적인 우수성을 단정하지 않습니다. 기존 기본 모델은 자동 교체하지 않았습니다.

## 산출물

- `final_model.zip`, `board.json`, `manifest.json`: 모델·규칙·학습 조건
- `COMPARISON.json`: 각 모델/상대/시드의 승패·신뢰구간·선후공 결과
- `replay/yut_replay.html`: 마지막 모델의 새 평가 세트 첫 경기

```powershell
.\\python.ps1 predict.py --model models/{NAME}/final_model.zip --state examples/state.json
```

실제 로봇은 실행하지 않았습니다. 다른 PC에서는 모델과 소스·규칙·메타데이터를 함께 옮기고 `setup.ps1`로 환경을 설치합니다.
'''
    (OUT/'RESULT.md').write_text(text,encoding='utf-8')
    readme=ROOT/'README.md'
    current=readme.read_text(encoding='utf-8')
    note=f'\n여러 조건 변경 실험: 신규 {manifest["total_steps"]:,}스텝 학습 후에만 평가했습니다. 새 규칙 AI 평가 세트 승률은 {fresh["win_rate_all_games"]:.1%}입니다. [설정 조합 최종 비교](models/{NAME}/RESULT.md)를 참고하세요.\n'
    readme.write_text(current.replace('\n4개 말 모델을 새로 학습할 때는',note+'\n4개 말 모델을 새로 학습할 때는',1),encoding='utf-8')
    files=set()
    for pattern in ['*.py','*.ps1','*.md','requirements*','pytest.ini','SOURCE.json','.gitignore']:
        files.update(p for p in ROOT.glob(pattern) if p.is_file())
    for directory in ['yut_rl','config','examples','tests','replay','runs']:
        files.update(p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix in {'.py','.json','.html','.cjs'} and not p.name.endswith('_pipeline.json'))
    for folder in (ROOT/'models').iterdir():
        if folder.is_dir() and 'smoke' not in folder.name:
            for filename in ['final_model.zip','best_model.zip','board.json','manifest.json','RESULT.md','COMPARISON.json']:
                if (folder/filename).is_file():files.add(folder/filename)
    files.add(ROOT/'models/four_pieces_18m/checkpoint_10001536_steps.zip')
    archive=ROOT/'exports/yut-rl-tuned-10m.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(files):z.write(p,'yut-rl/'+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    phase('complete')
    print(json.dumps({'steps':manifest['total_steps'],'fresh_rule_win_rate':fresh['win_rate_all_games'],'result':str(OUT/'RESULT.md'),'archive':str(archive)},ensure_ascii=False),flush=True)


if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        write_json(STATUS,{'phase':'failed','error':str(exc)})
        raise
