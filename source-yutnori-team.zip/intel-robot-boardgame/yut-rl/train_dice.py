"""주사위 여섯 결과로 새 모델을 학습합니다. 과거 모델을 덮어쓰지 않습니다."""
import argparse
from pathlib import Path
import shutil
import torch
from sb3_contrib import MaskablePPO
from yut_rl.bundle import sha256, write_json
from yut_rl.dice import BOARD, DiceCodec
from yut_rl.dice_env import DiceEnv


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--steps', type=int, default=1000000)
    parser.add_argument('--seed', type=int, default=43)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.steps <= 0 or args.output.exists():
        parser.error('양수 steps와 새 출력 폴더를 지정하세요.')
    torch.set_num_threads(1)
    env = DiceEnv()
    cfg = env.config
    model = MaskablePPO('MlpPolicy', env, device='cpu', seed=args.seed,
                        n_steps=cfg['n_steps'], batch_size=cfg['batch_size'],
                        n_epochs=cfg['n_epochs'], learning_rate=cfg['learning_rate'],
                        gamma=cfg['gamma'], gae_lambda=cfg['gae_lambda'], ent_coef=cfg['ent_coef'],
                        policy_kwargs=dict(net_arch=[128, 128]))
    args.output.mkdir(parents=True)
    shutil.copyfile(BOARD, args.output / 'board.json')
    manifest = dict(schema=DiceCodec.version, status='training', seed=args.seed,
                    board_sha256=sha256(BOARD), config=cfg, requested_steps=args.steps,
                    throw_distribution={name: 1 / 6 for name in ('빽도', '도', '개', '걸', '윷', '모')},
                    source_sha256={name: sha256(Path(__file__).parent / name) for name in
                                   ('yut_rl/dice.py', 'yut_rl/dice_env.py', 'train_dice.py')})
    write_json(args.output / 'manifest.json', manifest)
    try:
        model.learn(args.steps)
        model.save(args.output / 'final_model')
        manifest.update(status='complete', total_steps=model.num_timesteps)
    except BaseException:
        manifest['status'] = 'failed_or_interrupted'
        raise
    finally:
        write_json(args.output / 'manifest.json', manifest)
        env.close()
    print(f'Saved: {args.output / "final_model.zip"}; steps={model.num_timesteps}')


if __name__ == '__main__':
    main()
