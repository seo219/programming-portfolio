"""MaskablePPO 학습 실행. python train.py --steps 100000 --output models/first"""
import argparse
import json
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import torch
from sb3_contrib import MaskablePPO
from sb3_contrib.common.maskable.callbacks import MaskableEvalCallback
from stable_baselines3.common.callbacks import BaseCallback, CallbackList, CheckpointCallback
from stable_baselines3.common.logger import configure
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import DummyVecEnv

from yut_rl.bundle import compatibility, package_versions, read_bundle, write_json
from yut_rl.env import YutEnv, read_config
from yut_rl.sticks import BOARD as STICKS_BOARD, SticksBoard


class Progress(BaseCallback):
    def __init__(self, every: int = 4096):
        super().__init__()
        self.every = every
        self.last = 0
        self.started = time.perf_counter()

    def _on_step(self) -> bool:
        if self.num_timesteps - self.last >= self.every:
            self.last = self.num_timesteps
            elapsed = time.perf_counter() - self.started
            print(f"[progress] total_steps={self.num_timesteps:,} elapsed={elapsed:.1f}s", flush=True)
        return True


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--steps", type=int, default=100_000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", type=Path, default=Path("models/first"))
    parser.add_argument("--config", type=Path)
    parser.add_argument("--board", type=Path, default=STICKS_BOARD)
    parser.add_argument("--resume", type=Path, help="기존 모델을 새 출력 폴더에서 이어 학습")
    parser.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    args = parser.parse_args()
    if args.steps < 1:
        parser.error("--steps는 양수여야 합니다.")
    if args.output.exists():
        parser.error("출력 폴더가 이미 있습니다. 새 --output 이름을 지정하세요.")
    config = read_config(args.config)
    if not args.resume and args.board.resolve() == STICKS_BOARD.resolve():
        if config['flat_probability'] != SticksBoard().flat_probability:
            parser.error('현재 윷 확률표는 flat_probability=0.5를 사용합니다.')
    resume_path = None
    if args.resume:
        resume_path, args.board, previous = read_bundle(args.resume)
        if args.config and config != previous["config"]:
            parser.error("이어 학습은 원래 config를 사용합니다. --config를 제거하세요.")
        config = previous["config"]
    torch.set_num_threads(config["torch_threads"])
    # 설치 오류나 규칙 오류는 출력 폴더를 만들기 전에 확인합니다.
    probe = YutEnv(args.board, config)
    probe.close()
    args.output.mkdir(parents=True)
    shutil.copyfile(args.board, args.output / "board.json")
    manifest = {"created_utc": datetime.now(timezone.utc).isoformat(),
                "status": "training", "seed": args.seed, "requested_steps": args.steps,
                "resume_from": str(resume_path) if resume_path else None,
                "config": config, "packages": package_versions(),
                "compatibility": compatibility(args.output / "board.json"),
                "note": "승률 검증 전 학습 결과입니다. 최종 실력은 evaluate.py로 별도 측정하세요."}
    write_json(args.output / "manifest.json", manifest)
    env = DummyVecEnv([lambda: Monitor(YutEnv(args.board, config)) for _ in range(config["n_envs"])])
    env.seed(args.seed)
    eval_env = Monitor(YutEnv(args.board, {**config, "opponent": "rule", "first_player": "random"}))
    eval_env.reset(seed=args.seed + 1_000_000)
    eval_freq = max(config["eval_freq"] // config["n_envs"], 1)
    callbacks = CallbackList([
        Progress(),
        CheckpointCallback(save_freq=eval_freq, save_path=str(args.output), name_prefix="checkpoint"),
        MaskableEvalCallback(eval_env, best_model_save_path=str(args.output),
                             log_path=str(args.output), eval_freq=eval_freq,
                             n_eval_episodes=config["eval_episodes"], deterministic=True),
    ])
    if resume_path:
        model = MaskablePPO.load(resume_path, env=env, device=args.device)
        model.set_random_seed(args.seed)
    else:
        model = MaskablePPO("MlpPolicy", env, seed=args.seed, device=args.device, verbose=0,
            learning_rate=config["learning_rate"], gamma=config["gamma"],
            gae_lambda=config["gae_lambda"], n_steps=config["n_steps"],
            batch_size=config["batch_size"], n_epochs=config["n_epochs"],
            ent_coef=config["ent_coef"], policy_kwargs={"net_arch": config["net_arch"]})
    model.set_logger(configure(str(args.output / "logs"), ["csv"]))
    initial_steps = model.num_timesteps
    started = time.perf_counter()
    print(f"Training: {args.steps:,} steps, device={model.device}, output={args.output.resolve()}", flush=True)
    try:
        model.learn(total_timesteps=args.steps, callback=callbacks,
                    reset_num_timesteps=resume_path is None)
        model.save(args.output / "final_model")
        manifest["status"] = "complete"
    except KeyboardInterrupt:
        model.save(args.output / "interrupted_model")
        manifest["status"] = "interrupted"
        print("중단 시점 모델을 interrupted_model.zip에 저장했습니다.", flush=True)
    except Exception:
        manifest["status"] = "failed"
        raise
    finally:
        manifest["total_steps"] = model.num_timesteps
        manifest["steps_this_run"] = model.num_timesteps - initial_steps
        manifest["elapsed_seconds"] = round(time.perf_counter() - started, 3)
        write_json(args.output / "manifest.json", manifest)
        env.close()
        eval_env.close()
    print(json.dumps({"status": manifest["status"], "steps": manifest["steps_this_run"],
                      "elapsed_seconds": manifest["elapsed_seconds"]}), flush=True)


if __name__ == "__main__":
    main()
