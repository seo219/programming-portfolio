param()
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$pathFile = Join-Path $PSScriptRoot '.python-path'
if (-not (Test-Path -LiteralPath $pathFile)) { throw 'setup.ps1을 먼저 실행하세요.' }
$pythonPath = [System.IO.File]::ReadAllText($pathFile).Trim()
if (-not (Test-Path -LiteralPath $pythonPath)) { throw 'setup.ps1을 먼저 실행하세요.' }
$env:PYTHONUTF8 = '1'
$runName = 'models/smoke_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
& $pythonPath -m pytest tests -q
if ($LASTEXITCODE -ne 0) { throw '테스트 실패' }
& $pythonPath train.py --steps 2048 --output $runName
if ($LASTEXITCODE -ne 0) { throw '학습 실패' }
& $pythonPath evaluate.py --model "$runName/final_model.zip" --games 20 --output "$runName/evaluation.json" --trace "$runName/game.json"
if ($LASTEXITCODE -ne 0) { throw '평가 실패' }
& $pythonPath predict.py --model "$runName/final_model.zip"
if ($LASTEXITCODE -ne 0) { throw '예측 실패' }
Write-Host "동작 검증 완료: $runName (실력 검증용 학습량이 아닙니다.)"
