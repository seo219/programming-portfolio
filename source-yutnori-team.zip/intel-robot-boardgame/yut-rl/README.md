# 윷놀이 전략 모델 학습 폴더

> **2026-11-03 최신 규칙:** 웹 기본은 편당 말 2개, 실제 윷 확률표, **빽도 사용**입니다 (메인 게임 `config/yut_board.json`과 같음).
> 빽도 6.25% / 도 18.75% / 개 37.5% / 걸 25% / 윷 6.25% / 모 6.25%. 학습은 `train_sticks_backdo.py`. [현재 규칙](STICKS_RULES.md), [웹 실행](PLAY_WEB.md)을 먼저 읽으세요.
> 11/02 규칙(빽도 제외, 도 25%)과 그 모델·`train.py`·`train_sticks_tuned.py`는 과거 결과 재현용으로 남겨 두었습니다.
> 아래 성적과 말 4개 설명은 과거 실험 기록입니다. 말 4개 재현은 `--board config/yut_board.json`을 명시하세요.

> **팀 논의용 독립 학습 코드입니다.** 기존 게임 진입점과 로봇 제어에는 연결하지 않았습니다.
> 저장소 규칙에 따라 학습된 모델 ZIP·체크포인트·가상환경은 포함하지 않습니다.
> 아래 모델 경로와 성적은 로컬 실험 기록입니다. 저장소를 clone하는 것만으로 기존 모델 추론이나 이어 학습은 할 수 없습니다.
> 설치 및 기본 새 학습은 가능합니다. [팀 검토 안내](REVIEW.md)에서 포함 범위와 모델 전달 조건을 확인하세요.

현재 프로젝트의 윷놀이 규칙을 이용해 **MaskablePPO 전략 모델 하나를 학습**합니다.
카메라, 로봇, Ollama, Jev API 키가 필요하지 않습니다. 실행은 CPU를 기본으로 합니다.

**현재 기본 규칙은 편당 말 4개**입니다. 최신 모델은 `models/four_pieces_18m/final_model.zip`에 있습니다. 추가 10,000,384스텝, 누적 18,001,920스텝 학습을 완료했습니다. 규칙 AI 상대 1,000판 승률은 **50.0%**이며 이전 800만 모델은 48.8%입니다. [최신 학습 결과](docs/results/four_pieces_18m/RESULT.md)를 참고하세요. 입력은 254차원, 이동 행동 20개와 내부 대기 행동 1개입니다.

시드 비교 실험: 시드 43으로 새로 4,000,768스텝 학습했습니다. 기존 평가 세트 승률 46.5%, 추가 평가 세트 승률 51.6%입니다. [시드 비교 결과](docs/results/four_pieces_seed43_4m/RESULT.md)를 참고하세요. 기존 누적 1,800만 모델을 기본 모델로 유지합니다.

여러 조건 변경 실험: 신규 10,000,384스텝 학습 후에만 평가했습니다. 새 규칙 AI 평가 세트 승률은 55.6%입니다. [설정 조합 최종 비교](docs/results/four_pieces_tuned_10m/RESULT.md)를 참고하세요.

4개 말 모델을 새로 학습할 때는 `--resume` 없이 실행합니다. 이전 2개 말 모델은 각 폴더에 보관된 `board.json`으로만 평가·추론할 수 있습니다. 기본 `examples/state.json`은 4개 말용이므로 이전 모델에 전달할 때는 편당 2개인 별도 입력을 사용하세요.

```powershell
.\python.ps1 train.py --steps 4000000 --seed 42 --output models/four_pieces_new
```

아래 성적은 **과거 편당 말 2개 모델**의 기록이며 4개 말 모델 성능이 아닙니다. 과거 **400만 스텝 추가 학습 모델**은 `models/continued_4m/final_model.zip`에 있습니다.
누적 6,523,904스텝이며 규칙 AI 상대 1,000판 승률은 51.5%입니다. [과거 2개 말 학습 결과](docs/results/continued_4m/RESULT.md)를 참고하세요.
이전 누적 약 252만 스텝 모델(승률 52.8%)도 `models/continued_2m/final_model.zip`에 보관했습니다. 이번 추가 학습으로 뚜렷한 개선은 확인하지 못했습니다.
이전 약 52만 스텝 모델(승률 50.7%)도 `models/continued_500k/final_model.zip`에 보관했습니다.
초기 구성 검증 내역은 [VALIDATION.md](VALIDATION.md)에 별도로 기록했습니다.

## 1. 설치

이 폴더에서 PowerShell을 열고 실행합니다.

```powershell
cd F:\intel_pj\yut-rl
powershell -ExecutionPolicy Bypass -File .\setup.ps1
```

- Python 3.12 전용 환경에 `requirements.lock`을 설치하고 테스트합니다.
- F: 같은 외장 드라이브의 설치 지연을 줄이기 위해, 패키지는 기본적으로 내부 디스크의 `%LOCALAPPDATA%/yut-rl-envs/폴더별ID`에 설치합니다.
- `python.ps1`이 `.python-path`에 기록된 전용 Python을 실행합니다. 코드와 모델은 이 폴더에 남습니다.
- 기존 `intel-robot-boardgame`의 코드, 가상환경, 의존성은 변경하지 않습니다.
- `uv`가 필요합니다. 없으면 [uv 설치 안내](https://docs.astral.sh/uv/getting-started/installation/)를 따릅니다.
- 설치 파일에는 PyTorch가 포함되어 있어 다운로드와 디스크 복사에 시간이 걸릴 수 있습니다.
- 다른 PC로 옮길 때는 이 폴더를 복사하되 `.python-path`는 제외하고 설치를 다시 합니다.
- 스크립트 실행이 차단된 셸에서는 `powershell -ExecutionPolicy Bypass -File .\python.ps1 train.py ...` 형식으로 실행합니다.

## 2. 먼저 짧게 동작 확인

```powershell
powershell -ExecutionPolicy Bypass -File .\smoke.ps1
```

규칙 테스트 → 2,048 스텝 학습 → 20판 평가 → 예시 상태의 말 선택을 실행합니다.
결과는 `models/smoke_날짜_시간/`에 저장됩니다. 짧은 학습은 **실행 검증용**이며 실력을 보장하지 않습니다.

## 3. 첫 모델 학습

```powershell
.\python.ps1 train.py --steps 100000 --seed 42 --output models/first
```

`--steps`는 대결 판 수가 아니라 **학습 환경의 행동 진행 횟수**입니다.
PPO는 rollout 단위로 수집하므로 실제 스텝 수가 요청량보다 조금 커질 수 있습니다.
기본값은 환경 4개를 순차 실행하며, 신경망은 64 × 64 크기입니다.
별도 창이나 로봇을 실행하지 않습니다. 콘솔에 진행량·경과 시간이 출력됩니다.

출력 폴더가 이미 있으면 덮어쓰지 않습니다. 새 이름을 지정하세요.

```text
models/first/
  final_model.zip             최종 모델
  best_model.zip              주기 평가에서 가장 좋았던 모델 (평가 주기를 넘겼을 때)
  checkpoint_*_steps.zip      중간 체크포인트
  board.json                 학습에 사용한 윷판 규칙
  manifest.json              설정·버전·시드·소요 시간·실제 스텝 수
  evaluations.npz            주기 평가 결과 (평가 주기를 넘겼을 때)
  logs/progress.csv          학습 지표
```

중단하려면 `Ctrl+C`를 누릅니다. 정상적인 키보드 중단이면 `interrupted_model.zip`을 저장합니다.
프로세스를 강제 종료하면 마지막 주기 체크포인트까지만 남을 수 있습니다.

이어 학습할 때는 새 폴더를 사용합니다. 기존 학습 설정을 그대로 가져옵니다.

```powershell
.\python.ps1 train.py --resume models/first/final_model.zip --steps 100000 --output models/continued
```

## 4. 성능 평가

```powershell
# 규칙 AI 상대, 선후공 각각 100판
.\python.ps1 evaluate.py --model models/first/final_model.zip --games 200 --opponent rule --output runs/vs_rule.json

# 무작위 상대
.\python.ps1 evaluate.py --model models/first/final_model.zip --games 200 --opponent random --output runs/vs_random.json

# 같은 규칙 AI끼리 대결한 기준값
.\python.ps1 evaluate.py --model models/first/final_model.zip --policy rule --games 200 --output runs/rule_baseline.json

# 첫 판의 윷 결과·이동 경로를 JSON으로 기록
.\python.ps1 evaluate.py --model models/first/final_model.zip --games 20 --trace runs/game.json --output runs/quick_eval.json
```

- 평가 중 학습하지 않습니다. 모델은 합법 행동 마스크를 적용한 결정적 선택을 사용합니다.
- 평가 시드는 기본 `2000000`부터이며 학습 기본 시드 `42`, 주기 평가 시드와 분리합니다.
- 짝수 판 수만 허용합니다. 같은 시드로 선후공을 바꾸지만 전략에 따라 던지기 횟수가 달라지므로 완전히 같은 윷 수열을 보장하지는 않습니다.
- 승·패·중단·불법 행동 수, 전체 판 대비 승률, Wilson 95% 구간, 선후공별 승수, 판단 시간을 기록합니다.
- 중단된 게임을 승리로 세지 않습니다. 신뢰구간은 고정된 한 모델의 대결 변동만 나타냅니다.
- 주기 평가로 고른 `best_model.zip`도 최종 평가는 별도 시드로 수행하세요.
- 100,000 스텝은 시작값이며 충분한 학습량을 의미하지 않습니다. 기존 규칙 AI보다 강하다는 주장은 평가 결과가 있어야 합니다.

## 경기 기보 다시보기

`replay/yut_replay.html`을 더블클릭하면 브라우저에서 열립니다. 서버나 Python 실행 없이 사용할 수 있으며, HTML 파일 하나만 다른 PC에 복사해도 됩니다.

- 새 4개 말 경기와 과거 2개 말 평가 경기 선택, 이동 목록 클릭, 이전/다음 수, 자동 재생과 속도 조절을 지원합니다.
- 방향키 ← →로 이동하고 Home / End로 처음과 끝, Space로 재생과 정지를 조절합니다.
- 말 번호 1+2처럼 함께 표시된 번호는 같은 칸에 있는 말입니다. 최대 4개까지 표시합니다. 대기/완주 칸에서는 업기 의미가 아닙니다.
- 던지기는 다음 이동 기록에 함께 표시합니다. 점선은 출발·도착 연결이며 실제 경유 경로가 아닙니다.
- 기존 평가는 첫 경기만 기록했으므로 1,000판 전체 기보가 들어 있는 것은 아닙니다.
- 새 기보는 `evaluate.py --trace`로 저장한 뒤 화면의 **경기 JSON 불러오기**로 엽니다. 현재 윷판 규칙의 편당 말 4개 기록과 과거 2개 기록을 지원합니다.

새 경기 기록 예시 (학습하지 않고 평가만 실행):

```powershell
.\python.ps1 evaluate.py --model models/four_pieces_18m/final_model.zip --games 2 --seed 3000000 --trace runs/replay_new.json --output runs/replay_new_eval.json
```

화면 템플릿이나 기본 경기 기록을 변경한 경우 `.\python.ps1 build_replay.py`로 HTML을 다시 생성합니다.

## 5. 게임 상태를 주고 말 선택 받기

```powershell
.\python.ps1 predict.py --model models/first/final_model.zip --state examples/state.json
```

입력 예시는 `examples/state.json`에 있습니다.

```json
{
  "player": "robot",
  "pieces": {
    "robot": ["cell_2", "wait_robot", "wait_robot", "wait_robot"],
    "human": ["cell_4", "wait_human", "wait_human", "wait_human"]
  },
  "pending": [2, 4]
}
```

출력에는 `piece`(0부터 시작), `result`(도=1~모=5), `src_slot`, `dst_slot`,
`moved`(함께 옮길 말), `captured`(대기 칸으로 되돌릴 상대 말)가 들어 있습니다.
실제 로봇은 움직이지 않습니다.

파이썬에서 사용:

```python
from pathlib import Path
from yut_rl.strategy import ModelStrategy

strategy = ModelStrategy(Path("models/first/final_model.zip"))  # 한 번 로드
decision = strategy.choose(
    pieces={"robot": ["cell_2", "wait_robot", "wait_robot", "wait_robot"],
            "human": ["cell_4", "wait_human", "wait_human", "wait_human"]},
    pending=[2, 4],
)
print(decision)
```

이 폴더가 Python import 경로에 있어야 합니다. 기존 게임에 연결할 때 C1이 어댑터를 호출하고
선택을 다시 검증한 뒤 로봇의 `move(src, dst)`를 호출합니다.
잡힌 말 치우기, 업힌 말 집기, HOME 복귀, 비전 확인은 기존 게임·로봇 모듈 책임입니다.
`ModelStrategy.choose()`에서 추론 오류가 나면 기본적으로 규칙 AI로 전환하고 `source=rule_fallback`을 반환합니다.
모델 로드 실패나 잘못된 판 상태는 예외로 반환하므로 호출자가 규칙 AI 전환 또는 사람 확인을 처리해야 합니다.

## 학습 구조와 규칙

```text
윷놀이 규칙 스냅샷
  → Gymnasium 환경 (상태 / 행동 / 보상)
  → MaskablePPO 학습
  → 모델 ZIP + 규칙·버전 정보 저장
  → 선택 어댑터 → 기존 게임 진행 코드 → 로봇
```

- 편마다 말 4개, 빽도 제외, 잡기·업기·지름길·추가 던지기 포함.
- 규칙 코드: `yut_rl/engine.py`, 윷판: `config/yut_board.json`.
- 기존 프로젝트의 `src/game/yut_reference.py`에서 규칙 부분을 복사했습니다. 원본 위치와 해시는 `SOURCE.json`에 기록했습니다.
- **자동 동기화되지 않는 스냅샷**입니다. 팀 규칙이 바뀌면 양쪽 규칙·테스트를 맞춘 뒤 재학습해야 합니다.
- 원래 참고 시뮬레이터와 달리, 이 환경은 **말과 사용할 윷 결과를 함께 선택**합니다.
- 상대 규칙 AI도 모든 보유 결과를 비교합니다. 우선순위는 잡기 → 업기 → 앞선 말 → 새 말이며 동률이면 잡은 수·잔여 거리 등으로 결정합니다. 원본의 결과 고정 순서 전략과 동일한 기준값은 아닙니다.
- 승리 +1, 패배 -1, 나머지 0. 잡기 자체에는 별도 보상을 주지 않습니다.
- 입력: 로봇·상대 말별 칸 위치 one-hot, 보유 결과별 개수(/10, 자르지 않음), 내 차례 여부.
- 기본 행동 20개: `말 번호 × 5 + (윷 결과 - 1)`. 같은 결과가 여러 개면 한 개씩 소비합니다.
- 별도의 21번째 행동은 **상대 선공을 진행시키는 환경 내부 대기**입니다. 실제 말 선택에서는 제외합니다. 상대가 첫 턴에 승리하는 경우도 기록하기 위한 처리입니다.
- 한 step은 로봇의 선택 한 번과, 필요할 때 다음 로봇 선택 전까지의 상대 턴을 포함합니다.
- 한 판 1,000회 이동 또는 한 묶음 10,000회 던지기 한도는 오류 방지용이며 승패가 아닌 `truncated`로 기록합니다.
- 윷가락 평평한 면 확률은 임시 가정 0.5입니다. 실측값으로 바꾸려면 `config/training.json`을 수정하고 재학습합니다.

## 폴더 구성

```text
yut-rl/
  setup.ps1 / smoke.ps1      설치 / 짧은 전체 동작 확인
  python.ps1                내부 디스크의 전용 Python 실행
  train.py                  학습·이어 학습
  evaluate.py               모델·기준 전략 평가
  predict.py                외부 상태에서 말 선택
  yut_rl/
    engine.py               기존 규칙 스냅샷
    game.py                 행동 형식·상태 인코딩·규칙 전략
    env.py                  학습 환경과 상대 턴 처리
    bundle.py               규칙·코드 호환성 검증
    strategy.py             실제 게임 연결용 선택 어댑터
  config/                   윷판·학습 설정
  tests/                    규칙·전이·마스크·저장 검증
  examples/state.json       예측 입력 예시
  requirements.txt          직접 의존성
  requirements.lock         Windows / Python 3.12 설치 고정 목록
  models/                   학습 결과 (Git 제외)
  runs/                     평가·대결 기록 (Git 제외)
```

환경 설정을 바꿀 때는 `config/training.json`을 복사해 `--config`로 전달할 수 있습니다.
학습 결과를 옮길 때는 ZIP 하나만 옮기지 말고 `manifest.json`, `board.json`도 함께 옮깁니다.
규칙·인코딩·환경 파일이 학습 당시와 다르면 모델 로드를 차단합니다.

## 사용한 오픈소스

- [Gymnasium](https://github.com/Farama-Foundation/Gymnasium): 환경 인터페이스, MIT.
- [Stable-Baselines3](https://github.com/DLR-RM/stable-baselines3): 학습 실행·로그·체크포인트.
- [SB3-Contrib](https://github.com/Stable-Baselines-Team/stable-baselines3-contrib): MaskablePPO, MIT.
- [MaskablePPO 공식 예제](https://sb3-contrib.readthedocs.io/en/master/modules/ppo_mask.html): 학습·추론 마스크, 전용 평가 콜백.

Jev, 외부 Q-table 저장소, 외부 윷놀이 엔진은 포함하지 않았습니다.
학습한 정책을 평가하는 데 집중하는 최소 구성이며, 원래 게임 오케스트레이터와 실제 로봇 통합은 후속 작업입니다.
