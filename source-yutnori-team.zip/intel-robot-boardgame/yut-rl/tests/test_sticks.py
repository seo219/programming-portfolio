"""이미지의 16가지 윷 경우의 수와 말 2개 웹 규칙을 검증합니다."""
from collections import Counter
from itertools import product
import random
from types import SimpleNamespace

import pytest
from play_web import Match
from yut_rl.sticks import BOARD, RULES_ID, SticksBoard, SticksRuleStrategy, SticksModelStrategy
from yut_rl.game import Move, StateCodec, choose_rule
from yut_rl.env import YutEnv, read_config


def test_all_16_stick_combinations_match_image():
    board = SticksBoard()
    counts = Counter()
    for bits in product((.25, .75), repeat=4):
        values = iter(bits)
        counts[board.sample(SimpleNamespace(random=lambda: next(values))).name] += 1
    assert counts == {'도': 4, '개': 6, '걸': 4, '윷': 1, '모': 1}
    assert board.pieces == 2
    assert [board.throw(i).again for i in range(5)] == [True, False, False, False, True]
    with pytest.raises(ValueError):
        board.path('cell_1', -1)


def test_two_pieces_masks_finish_and_reject_third_piece():
    match = Match(SticksRuleStrategy())
    match.pending = [1]
    match.must_roll = False
    assert len(match.game.pieces['human']) == 2
    assert {m['piece'] for m in match.state()['moves']} == {0, 1}
    with pytest.raises(ValueError):
        match.act('move', Move(2, 1).action)
    match.game.pieces['human'] = ['cell_0', 'cell_0']
    match.act('move', Move(0, 1).action)
    assert match.game.winner() == 'human'
    assert match.state()['rules'] == RULES_ID


def test_training_matches_web_distribution_and_dimensions():
    env = YutEnv(BOARD, read_config())
    web = Match(SticksRuleStrategy(), rng=random.Random(9))
    assert env.codec.size == StateCodec(web.game.board).size == 130
    assert env.action_space.n == 11
    for seed in range(12):
        env.reset(seed=seed)
        while not (env.terminated or env.truncated):
            action = env.pass_action if env.current == 'human' else choose_rule(env.game, 'robot', env.pending).action
            env.step(action)
        assert env.terminated
    for _ in range(1000):
        assert web.game.board.sample(web.rng).value in (1,2,3,4,5)


def test_recording_identifies_current_rules(tmp_path):
    import json
    from yut_rl.bundle import sha256
    strategy = SticksRuleStrategy()
    strategy.record_model_hash = None
    strategy.record_board_hash = sha256(BOARD)
    match = Match(strategy, record_dir=tmp_path, rng=random.Random(1))
    match.act('roll')
    record = json.loads((tmp_path / (match.match_id + '.json')).read_text(encoding='utf-8'))
    assert record['rules'] == RULES_ID
    assert len(record['final_pieces']['human']) == 2
    assert record['board_sha256'] == sha256(BOARD)
    assert record['events'][0]['value'] in (1,2,3,4,5)


def test_local_two_piece_model_and_four_piece_rejection():
    from play_web import TWO_PIECE_MODEL, MODEL
    if not TWO_PIECE_MODEL.exists() or not MODEL.exists():
        pytest.skip('모델 가중치는 Git에 포함하지 않습니다.')
    strategy = SticksModelStrategy(TWO_PIECE_MODEL)
    for seed in range(6):
        match = Match(strategy, first='robot' if seed % 2 else 'human', rng=random.Random(seed))
        for _ in range(2000):
            if match.game.winner():
                break
            if match.current == 'robot':
                match.act('ai')
            elif match.must_roll:
                match.act('roll')
            else:
                match.act('move', choose_rule(match.game, 'human', match.pending).action)
        assert match.game.winner()
    with pytest.raises(ValueError, match='말 수'):
        SticksModelStrategy(MODEL)
