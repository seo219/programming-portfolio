"""주사위 확률·빽도 경계·기존 모델 연결·학습 환경을 검증합니다."""
import random
from types import SimpleNamespace
import numpy as np
import pytest
from stable_baselines3.common.env_checker import check_env

from play_web import Match
from yut_rl.dice import (DiceBoard, DiceGame, DiceMove, DiceCodec, DiceRuleStrategy,
                         LegacyDiceStrategy, VALUES, legal_moves, choose_rule)
from yut_rl.dice_env import DiceEnv
from yut_rl.env import read_config


def test_uniform_six_faces_and_frequencies():
    board = DiceBoard()
    assert [board.sample(SimpleNamespace(random=lambda: (i + .5) / 6)).value for i in range(6)] == list(VALUES)
    rng = random.Random(2026)
    values = [board.sample(rng).value for _ in range(60000)]
    assert all(abs(values.count(v) - 10000) < 500 for v in VALUES)
    assert [i for i in range(1, 7) if board.throw(i).again] == [5, 6]


@pytest.mark.parametrize('src,dst', [('cell_1','cell_0'), ('cell_0','cell_19'),
    ('cell_5','cell_4'), ('cell_10','cell_9'), ('cell_15','cell_14'),
    ('diag_r1','cell_5'), ('diag_r3','center'), ('center','diag_l2'), ('diag_l3','center')])
def test_backward_paths(src, dst):
    assert DiceBoard().path(src, -1) == [dst]


def test_backdo_no_wait_entry_or_finished_move():
    game = DiceGame(DiceBoard())
    assert legal_moves(game, 'human', [-1]) == [DiceMove(-1, -1)]
    result = game.move('human', -1, -1)
    assert result.moved == result.captured == []
    assert game.pieces['human'] == ['wait'] * 4
    with pytest.raises(ValueError):
        game.move('human', 0, -1)
    game.pieces['human'][0] = 'goal'
    with pytest.raises(ValueError):
        game.move('human', 0, -1)
    game.pieces['human'][1] = 'cell_1'
    assert legal_moves(game, 'human', [-1]) == [DiceMove(1, -1)]
    with pytest.raises(ValueError):
        game.move('human', -1, -1)


def test_backward_stack_capture_and_extra_roll():
    match = Match(DiceRuleStrategy())
    match.game.pieces['human'] = ['cell_2','cell_2','wait','wait']
    match.game.pieces['robot'] = ['cell_1','cell_1','wait','wait']
    match.pending = [-1, 2]
    match.must_roll = False
    match.act('move', DiceMove(0, -1).action)
    assert match.game.pieces['human'][:2] == ['cell_1','cell_1']
    assert match.game.pieces['robot'] == ['wait'] * 4
    assert match.pending == [2] and match.must_roll and match.current == 'human'


def test_backdo_discard_keeps_other_results_and_turn():
    match = Match(DiceRuleStrategy())
    match.pending = [-1, 4]
    match.must_roll = False
    match.act('move', 0)
    assert match.pending == [4] and not match.must_roll and match.current == 'human'
    assert match.events[0]['after']['pieces']['human'] == ['wait'] * 4


def test_codec_mask_and_backdo_count():
    board = DiceBoard()
    codec = DiceCodec(board)
    game = DiceGame(board)
    mask = codec.mask(game, 'human', [-1, -1, 2])
    assert np.flatnonzero(mask).tolist() == [0, DiceMove(0, 2).action]
    obs = codec.encode(game, 'human', [-1,-1,2])
    assert obs.shape == (255,)
    assert obs[-2] == np.float32(.2) and obs[-1] == 1
    for piece in range(4):
        for value in VALUES:
            move = DiceMove(piece, value)
            assert DiceMove.decode(move.action) == move


def test_legacy_adapter_does_not_send_backdo_to_old_model():
    board = DiceBoard()
    def choose(pieces, pending, player, fallback):
        assert pending == [2] and fallback is False
        return dict(piece=0, result=2)
    strategy = LegacyDiceStrategy(SimpleNamespace(board=board, choose=choose))
    pieces = DiceGame(board).pieces
    result = strategy.choose(pieces, [-1, 2])
    assert result['action'] == DiceMove(0, 2).action
    assert result['source'] == 'legacy_model_forward'
    assert strategy.choose(pieces, [-1])['source'] == 'backdo_rule'


def test_seeded_complete_dice_matches_and_env_contract():
    check_env(DiceEnv(), warn=True)
    for seed in range(12):
        traces = []
        for _ in range(2):
            env = DiceEnv()
            obs, _ = env.reset(seed=seed)
            trace = []
            while not (env.terminated or env.truncated):
                action = env.pass_action if env.current == 'human' else choose_rule(env.game, 'robot', env.pending).action
                obs, reward, _, _, info = env.step(action)
                trace.append((action, reward, obs.tolist()))
            assert env.terminated and info['winner'] in ('human', 'robot')
            traces.append(trace)
        assert traces[0] == traces[1]


def test_web_api_records_dice_moves_and_review(tmp_path):
    import json
    import threading
    import urllib.request
    import http.cookiejar
    from http.server import HTTPServer
    from play_web import make_handler
    server = HTTPServer(('127.0.0.1', 0), make_handler(DiceRuleStrategy(), tmp_path))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_port}'
    client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def post(state, **data):
        request = urllib.request.Request(base + '/api/action',
            data=json.dumps(dict(revision=state['revision'], **data)).encode(),
            headers={'Content-Type':'application/json'})
        return json.load(client.open(request, timeout=5))
    try:
        state = json.load(client.open(base + '/api/state', timeout=5))
        state = post(state, command='new', first='robot')
        for _ in range(100):
            state = post(state, command='ai')
            if state['review_events']:
                break
        event_id = state['review_events'][0]['id']
        state = post(state, command='flag', event_id=event_id, note='후진 검토')
        record = json.loads((tmp_path / (state['match_id'] + '.json')).read_text(encoding='utf-8'))
        assert record['rules'] == 'uniform_d6'
        assert record['events'][event_id]['source'] == 'dice_rule'
        assert record['feedback'][str(event_id)]['note'] == '후진 검토'
        assert record['model_sha256'] is None
    finally:
        server.shutdown()
        server.server_close()
        thread.join()
