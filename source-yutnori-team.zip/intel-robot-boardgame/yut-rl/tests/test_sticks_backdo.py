"""말 2개·빽도 규칙(11/03): 확률표, 빽도 이동·무효, 메인 게임과의 일치, 학습 환경, 웹 진행을 검증합니다."""
from collections import Counter
from itertools import product
from pathlib import Path
import random
import sys
from types import SimpleNamespace

import numpy as np
import pytest
from stable_baselines3.common.env_checker import check_env

from play_web import Match, TWO_PIECE_MODEL
from yut_rl.dice import DiceGame, DiceMove
from yut_rl.engine import GOAL, WAIT
from yut_rl.env import read_config
from yut_rl.sticks_backdo import (SticksBackdoBoard, SticksBackdoModelStrategy, SticksBackdoRuleStrategy,
                                  choose_rule, legal_moves)
from yut_rl.sticks_backdo_env import SticksBackdoEnv

board = SticksBackdoBoard()


def game(robot=(), human=()):
    return DiceGame(board, {'robot': list(robot) + [WAIT] * (2 - len(robot)),
                            'human': list(human) + [WAIT] * (2 - len(human))})


def test_all_16_stick_combinations_match_table():
    counts = Counter()
    for bits in product((.25, .75), repeat=4):
        values = iter(bits)
        counts[board.sample(SimpleNamespace(random=lambda: next(values))).name] += 1
    assert counts == {'빽도': 1, '도': 3, '개': 6, '걸': 4, '윷': 1, '모': 1}
    assert board.throw(-1).value == -1 and not board.throw(-1).again


@pytest.mark.parametrize('pos,dst', [('cell_3', 'cell_2'), ('cell_1', 'cell_0'), ('center', 'diag_l2'),
                                     ('diag_r1', 'cell_5'), ('diag_l3', 'center'), ('cell_0', 'cell_19')])
def test_backdo_path(pos, dst):
    assert board.path(pos, -1) == [dst]


def test_backdo_not_for_waiting_piece():
    with pytest.raises(ValueError):
        board.path(WAIT, -1)


def test_backdo_void_only_when_nothing_playable():
    assert legal_moves(game(), 'robot', [-1]) == [DiceMove(-1, -1)]
    assert legal_moves(game(), 'robot', [4, -1]) == [DiceMove(0, 4)]  # 윷으로 먼저 올린 뒤 빽도
    assert legal_moves(game(robot=('cell_4',)), 'robot', [-1]) == [DiceMove(0, -1)]
    g = game()
    g.move('robot', -1, -1)
    assert g.pieces['robot'] == [WAIT, WAIT]


def test_backdo_moves_stack_and_captures():
    g = game(robot=('cell_5', 'cell_5'), human=('cell_4',))
    r = g.move('robot', 0, -1)
    assert r.moved == [0, 1] and r.captured == [0] and g.pieces['robot'] == ['cell_4', 'cell_4']


def test_rule_ai_backdo_priority():
    g = game(robot=('cell_3', 'cell_12'))
    assert choose_rule(g, 'robot', [-1, 2]).result == 2  # 앞으로 가는 결과 먼저
    assert choose_rule(g, 'robot', [-1]) == DiceMove(0, -1)  # 완주에서 가장 먼 말을 뒤로
    g = game(robot=('cell_3',), human=('cell_2',))
    assert choose_rule(g, 'robot', [1, -1]) == DiceMove(0, -1)  # 빽도로 잡기


def test_matches_main_game_rules():
    """메인 게임(src/game/yut_reference.py)과 모든 칸·결과의 이동이 같아야 합니다."""
    src = Path(__file__).resolve().parents[2] / 'src'
    if not src.is_dir():
        pytest.skip('메인 저장소 src가 없습니다')
    sys.path.insert(0, str(src))
    from game.yut_reference import YutBoard as MainBoard
    main = MainBoard(src.parent / 'config/yut_board.json')
    assert main.backdo and main.pieces == board.pieces
    assert {f: (t.name, t.value, t.again) for f, t in main.yut.items()} == \
        {f: (t.name, t.value, t.again) for f, t in board.yut.items()}
    for cell in [WAIT, *board.backward]:
        for value in (-1, 1, 2, 3, 4, 5):
            if cell == WAIT and value == -1:
                continue
            assert main.path(cell, value) == board.path(cell, value), (cell, value)


def make_env(**changes):
    return SticksBackdoEnv(config={**read_config(), 'first_player': 'robot', **changes})


def test_env_api_and_random_games_finish():
    check_env(make_env(), warn=True)
    env = make_env(first_player='random', opponent_mix={'rule': .5, 'random': .5})
    rng = np.random.default_rng(0)
    for seed in range(60):
        env.reset(seed=seed)
        done = False
        while not done:
            action = int(rng.choice(np.flatnonzero(env.action_masks())))
            _, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated
        assert info['winner'] in ('robot', 'human') and not info['illegal_action']
    assert set(env.episode_counts) == {'rule', 'random'}


def test_env_observation_counts_backdo():
    env = make_env()
    env.reset(seed=0)
    env.pending = [-1, 2]
    obs = env._obs()
    assert obs[-2] == pytest.approx(.1) and obs.shape == (env.codec.size,)
    assert env.action_space.n == board.pieces * 6 + 2


def test_web_backdo_void_and_full_game():
    m = Match(SticksBackdoRuleStrategy())
    m.pending, m.must_roll = [-1], False
    assert [mv['piece'] for mv in m.state()['moves']] == [-1]
    m.act('move', 0)
    assert m.current == 'robot' and m.log[-1].endswith('빽도 소모')
    rolls = []
    for seed in range(5):
        m = Match(SticksBackdoRuleStrategy(), rng=random.Random(seed))
        while not m.game.winner():
            if m.current == 'robot':
                m.act('ai')
            elif m.must_roll:
                m.act('roll')
            else:
                m.act('move', m.available_moves()[0].action)
        assert m.state()['rules'] == 'sticks_2pieces_backdo_v1'
        rolls += [e['value'] for e in m.events if e['kind'] == 'roll']
    assert -1 in rolls


def test_old_no_backdo_model_is_rejected():
    if not TWO_PIECE_MODEL.exists():
        pytest.skip('11/02 모델이 없습니다')
    with pytest.raises(ValueError):
        SticksBackdoModelStrategy(TWO_PIECE_MODEL)
