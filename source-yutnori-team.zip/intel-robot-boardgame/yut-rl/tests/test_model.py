"""짧은 학습 후 저장·로드·합법 행동 선택을 검증합니다."""
import shutil

import numpy as np
import pytest
import torch
from sb3_contrib import MaskablePPO

from yut_rl.bundle import compatibility, read_bundle, write_json
from yut_rl.env import YutEnv, read_config
from yut_rl.game import DEFAULT_BOARD
from yut_rl.strategy import ModelStrategy


def test_training_save_load_and_adapter(tmp_path):
    torch.set_num_threads(1)
    config = read_config()
    env = YutEnv(config=config)
    model = MaskablePPO("MlpPolicy", env, n_steps=16, batch_size=16,
        n_epochs=1, device="cpu", seed=7, policy_kwargs={"net_arch": [16, 16]})
    model.learn(total_timesteps=32)
    model.save(tmp_path / "model")
    shutil.copyfile(DEFAULT_BOARD, tmp_path / "board.json")
    write_json(tmp_path / "manifest.json", {
        "compatibility": compatibility(tmp_path / "board.json"), "config": config})
    strategy = ModelStrategy(tmp_path / "model.zip")
    pieces = {"robot": ["cell_2", "wait_robot", "cell_8", "cell_12"], "human": ["cell_4", "wait_human", "wait_human", "wait_human"]}
    output = strategy.choose(pieces, [2, 4], fallback=False)
    assert output["result"] in [2, 4] and output["piece"] in [0, 1, 2, 3]
    assert output["source"] == "model"
    obs, _ = env.reset(seed=100)
    mask = env.action_masks()
    original, _ = model.predict(obs, action_masks=mask, deterministic=True)
    loaded, _ = strategy.model.predict(obs, action_masks=mask, deterministic=True)
    assert int(original) == int(loaded)
    np.testing.assert_array_equal(obs, env._obs())
    (tmp_path / "board.json").write_text("{}", encoding="utf-8")
    with pytest.raises(ValueError, match="다릅니다"):
        read_bundle(tmp_path / "model.zip")
    env.close()
