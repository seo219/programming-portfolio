import json
from types import SimpleNamespace

import pytest

from play_web import Match
from yut_rl.sticks import SticksBoard


def basic():
    """현재 웹 규칙(말 2개) 판. 학습 모델로 한 판 두는 확인은 test_sticks.py에 있습니다."""
    return Match(SimpleNamespace(board=SticksBoard()))


def test_capture_requires_roll_before_remaining_move():
    m = basic()
    m.game.pieces['human'][0] = 'cell_1'
    m.game.pieces['robot'][0] = 'cell_2'
    m.pending = [1, 2]
    m.must_roll = False
    m.act('move', 0)
    assert m.game.pieces['robot'][0] == 'wait'
    assert m.pending == [2] and m.must_roll and m.current == 'human'
    with pytest.raises(ValueError):
        m.act('move', 1)


def test_stacked_finish_ends_game():
    m = basic()
    m.game.pieces['human'] = ['cell_0'] * 2
    m.pending = [1]
    m.must_roll = False
    m.act('move', 0)
    assert m.game.winner() == 'human'
    assert m.state()['moves'] == []
    with pytest.raises(ValueError):
        m.act('roll')


def test_human_can_select_second_waiting_piece():
    m = basic()
    m.pending = [2]
    m.must_roll = False
    assert {move['piece'] for move in m.state()['moves']} == {0, 1}
    m.act('move', 6)  # 말 1에 개 (action = 말 번호 * 5 + 칸 수 - 1)
    assert m.game.pieces['human'] == ['wait', 'cell_2']


def test_recording_preserves_before_after_and_feedback(tmp_path):
    m = basic()
    m.record_dir = tmp_path
    m.strategy.record_model_hash = 'test-model'
    m.strategy.record_board_hash = 'test-board'
    m.strategy.choose = lambda *a, **k: {'action': 0}
    m.current = 'robot'
    m.pending = [1]
    m.must_roll = False
    m.act('ai')
    m.flag(0, 'Review this move')
    data = json.loads((tmp_path / (m.match_id + '.json')).read_text(encoding='utf-8'))
    assert data['events'][0]['before']['pieces']['robot'][0] == 'wait'
    assert data['events'][0]['after']['pieces']['robot'][0] == 'cell_1'
    assert data['feedback']['0']['note'] == 'Review this move'
    assert data['model_sha256'] == 'test-model'
    m.act('roll')
    with pytest.raises(ValueError):
        m.flag(1, 'Not an AI move')
    assert m.events[0]['after']['pending'] == []


def test_wrong_turn_and_illegal_action_leave_state_unchanged():
    m = basic()
    before = m.state()
    with pytest.raises(ValueError):
        m.act('ai')
    with pytest.raises(ValueError):
        m.act('move', 99)
    assert m.state() == before
