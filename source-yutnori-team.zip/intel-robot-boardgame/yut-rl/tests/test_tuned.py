"""혼합 상대가 같은 규칙과 관측 관점을 유지하는지 확인합니다."""
import numpy as np
import pytest
from yut_rl.env import read_config
from yut_rl.game import ROOT, Move, choose_rule
from yut_rl.tuned import MixedOpponentEnv, interpolate


class LegalFrozen:
    def predict(self, obs, action_masks, deterministic):
        assert obs.shape == (254,) and obs[-1] == 1
        return np.flatnonzero(action_masks)[0], None


@pytest.mark.parametrize('kind',['rule','random','frozen'])
def test_each_opponent_finishes_legal_game(kind):
    cfg = read_config(ROOT/'config/training_tuned.json')
    cfg['opponent_mix'] = {kind:1.0}
    env = MixedOpponentEnv(config=cfg, frozen_model=LegalFrozen())
    for seed in range(5):
        _, info = env.reset(seed=seed, options={'first_player':'human'})
        assert info['opponent_kind'] == kind
        done = False
        while not done:
            action = env.pass_action if env.current == 'human' else choose_rule(env.game,'robot',env.pending).action
            _,_,terminated,truncated,info = env.step(action)
            done = terminated or truncated
        assert terminated and not truncated and not info['illegal_action']


def test_schedule_endpoints():
    assert interpolate(.02,.005,1) == pytest.approx(.02)
    assert interpolate(.02,.005,0) == pytest.approx(.005)
    assert interpolate(.02,.005,-.1) == pytest.approx(.005)


def test_frozen_observes_own_pieces_first():
    class CheckFrozen:
        def predict(self, obs, action_masks, deterministic):
            np.testing.assert_array_equal(obs, env.codec.encode(env.game,'human',env.pending))
            return np.flatnonzero(action_masks)[0], None
    cfg=read_config(ROOT/'config/training_tuned.json')
    cfg['opponent_mix']={'frozen':1.0}
    env=MixedOpponentEnv(config=cfg,frozen_model=CheckFrozen())
    env.reset(seed=5,options={'first_player':'human'})
    env.step(env.pass_action)
