"""규칙 경계와 학습 전이의 의미를 검증합니다."""
import copy
from pathlib import Path

import numpy as np
import pytest
from stable_baselines3.common.env_checker import check_env

from yut_rl.engine import GOAL, WAIT, YutGame
from yut_rl.env import YutEnv, read_config
from yut_rl.game import Move, choose_rule
from yut_rl.strategy import validated_game


def make_env(**changes):
    return YutEnv(board_path=Path(__file__).parent / "fixtures/yut_board_2pieces.json", config={**read_config(), "first_player": "robot", **changes})


def state(env, robot, human, pending):
    env.reset(seed=3)
    env.game = YutGame(env.board, {"robot": list(robot), "human": list(human)})
    env.pending = list(pending)
    env.current = "robot"


@pytest.mark.parametrize("pos,value,path", [
    (WAIT, 1, ["cell_1"]),
    ("cell_3", 2, ["cell_4", "cell_5"]),
    ("cell_5", 3, ["diag_r1", "diag_r2", "center"]),
    ("center", 2, ["diag_l3", "diag_l4"]),
    ("diag_r2", 3, ["center", "diag_r3", "diag_r4"]),
    ("cell_18", 2, ["cell_19", "cell_0"]),
    ("cell_0", 1, [GOAL]),
])
def test_board_rules(pos, value, path):
    assert make_env().board.path(pos, value) == path


def test_mask_deduplicates_wait_and_disables_finished():
    env = make_env()
    state(env, [WAIT, WAIT], [WAIT, WAIT], [1, 4, 5])
    assert np.flatnonzero(env.action_masks()).tolist() == [0, 3, 4]
    env.game.pieces["robot"] = [GOAL, "cell_3"]
    assert np.flatnonzero(env.action_masks()).tolist() == [5, 8, 9]


def test_choose_result_out_of_order_and_keep_duplicates():
    env = make_env()
    state(env, [WAIT, WAIT], [WAIT, WAIT], [4, 5, 1, 5])
    _, reward, done, truncated, _ = env.step(Move(0, 5).action)
    assert env.game.pieces["robot"][0] == "cell_5"
    assert env.pending == [4, 1, 5]
    assert reward == 0 and not done and not truncated


def test_capture_stack_and_extra_throw_preserve_pending(monkeypatch):
    env = make_env()
    state(env, ["cell_2", WAIT], ["cell_4", "cell_4"], [2, 4])
    calls = []
    def roll(player):
        calls.append(player)
        env.pending.append(1)
    monkeypatch.setattr(env, "_roll", roll)
    env.step(Move(0, 2).action)
    assert env.game.pieces["human"] == [WAIT, WAIT]
    assert env.pending == [4, 1]
    assert calls == ["robot"]


def test_stacked_pieces_finish_without_extra_throw(monkeypatch):
    env = make_env()
    state(env, ["cell_0", "cell_0"], [WAIT, WAIT], [1])
    monkeypatch.setattr(env, "_roll", lambda _: pytest.fail("승리 후 던지면 안 됩니다"))
    _, reward, terminated, truncated, info = env.step(Move(0, 1).action)
    assert env.game.pieces["robot"] == [GOAL, GOAL]
    assert (reward, terminated, truncated, info["winner"]) == (1, True, False, "robot")


def test_waiting_pieces_are_not_a_stack():
    env = make_env()
    state(env, [WAIT, WAIT], [WAIT, WAIT], [1, 2])
    env.step(Move(0, 1).action)
    assert env.game.pieces["robot"] == ["cell_1", WAIT]


def test_opponent_can_win_before_learner_first_move(monkeypatch):
    env = make_env(first_player="human")
    env.reset(seed=0)
    env.game.pieces["human"] = ["cell_0", GOAL]
    monkeypatch.setattr(env, "_roll", lambda _: env.pending.append(1))
    assert np.flatnonzero(env.action_masks()).tolist() == [env.pass_action]
    _, reward, done, truncated, info = env.step(env.pass_action)
    assert (reward, done, truncated, info["winner"]) == (-1, True, False, "human")


def test_opponent_turn_returns_next_agent_state(monkeypatch):
    env = make_env()
    state(env, [WAIT, WAIT], [WAIT, WAIT], [1])
    monkeypatch.setattr(env, "_roll", lambda _: env.pending.append(2))
    obs, _, done, truncated, _ = env.step(0)
    assert env.current == "robot" and env.pending == [2]
    assert env.game.pieces["human"][0] == "cell_2"
    assert env.moves == 2 and obs[-1] == 1
    assert not done and not truncated


def test_invalid_action_never_moves_piece():
    env = make_env()
    env.reset(seed=0)
    before = copy.deepcopy(env.game.pieces)
    _, reward, done, _, info = env.step(env.pass_action)
    assert env.game.pieces == before
    assert done and reward == -1 and info["illegal_action"]


def test_limit_is_truncation_not_loss():
    env = make_env(max_moves=1)
    state(env, [WAIT, WAIT], [WAIT, WAIT], [1])
    _, reward, done, truncated, info = env.step(0)
    assert not done and truncated and reward == 0 and info["winner"] is None


def test_win_has_priority_over_limit():
    env = make_env(max_moves=1)
    state(env, ["cell_0", GOAL], [WAIT, WAIT], [1])
    _, reward, done, truncated, _ = env.step(0)
    assert done and not truncated and reward == 1


def test_pending_order_not_part_of_observation():
    env = make_env()
    state(env, [WAIT, WAIT], [WAIT, WAIT], [4, 1, 4])
    a = env._obs()
    env.pending = [4, 4, 1]
    np.testing.assert_array_equal(a, env._obs())


def test_rule_prefers_capture_over_enter():
    env = make_env()
    state(env, ["cell_2", WAIT], ["cell_4", WAIT], [4, 2])
    assert choose_rule(env.game, "robot", env.pending) == Move(0, 2)


def test_seed_reproducibility_and_complete_games():
    for seed in range(30):
        traces = []
        for _ in range(2):
            env = make_env(first_player="random")
            env.reset(seed=seed)
            trace = []
            while not (env.terminated or env.truncated):
                action = env.pass_action if env.current == "human" else choose_rule(env.game, "robot", env.pending).action
                obs, reward, _, _, info = env.step(action)
                trace.append((action, reward, obs.tolist()))
            assert env.terminated and not info["illegal_action"]
            traces.append(trace)
        assert traces[0] == traces[1]


def test_external_state_aliases_and_validation():
    board = make_env().board
    game = validated_game(board, {"robot": ["wait_robot", "cell_2"], "human": ["goal_human", "cell_4"]})
    assert game.pieces["robot"][0] == WAIT
    with pytest.raises(ValueError):
        validated_game(board, {"robot": ["cell_2", WAIT], "human": ["cell_2", WAIT]})


def test_sb3_environment_contract():
    check_env(make_env(), warn=True)
