"""편당 말 4개 입력·선택·잡기·완주와 이전 모델의 호환성을 검증합니다."""
import numpy as np
import pytest
from yut_rl.engine import YutGame, WAIT, GOAL
from yut_rl.env import YutEnv
from yut_rl.game import Move
from yut_rl.strategy import validated_game


def ready(robot, human, pending):
    env = YutEnv()
    env.reset(seed=3, options={'first_player': 'robot'})
    env.game = validated_game(env.board, {'robot': robot, 'human': human})
    env.pending = pending
    return env


def test_four_piece_dimensions_and_wait_mask():
    env = ready([WAIT]*4, [WAIT]*4, [1, 5])
    assert env.board.pieces == 4
    assert env.observation_space.shape == (254,)
    assert env.action_space.n == 21 and env.pass_action == 20
    assert np.flatnonzero(env.action_masks()).tolist() == [0, 4]
    with pytest.raises(ValueError, match='4개'):
        validated_game(env.board, {'robot':[WAIT]*2, 'human':[WAIT]*2})


@pytest.mark.parametrize('piece', [2, 3])
def test_third_and_fourth_piece_can_move(piece):
    env = ready(['cell_1','cell_6','cell_11','cell_16'], [WAIT]*4, [1, 2])
    before = env.game.pieces['robot'].copy()
    assert env.action_masks()[Move(piece, 1).action]
    obs, _, done, truncated, _ = env.step(Move(piece, 1).action)
    assert env.game.pieces['robot'][piece] != before[piece]
    assert all(env.game.pieces['robot'][i] == before[i] for i in range(4) if i != piece)
    assert obs.shape == (254,) and not done and not truncated


def test_capture_four_stack(monkeypatch):
    env = ready(['cell_2',WAIT,WAIT,WAIT], ['cell_4']*4, [2, 1])
    monkeypatch.setattr(env, '_roll', lambda _: env.pending.append(3))
    env.step(Move(0, 2).action)
    assert env.game.pieces['human'] == [WAIT]*4
    assert env.pending == [1, 3]


def test_two_finished_is_not_victory():
    env = ready(['cell_0','cell_0',WAIT,WAIT], [WAIT]*4, [1, 2])
    _, reward, done, truncated, _ = env.step(0)
    assert env.game.pieces['robot'] == [GOAL,GOAL,WAIT,WAIT]
    assert reward == 0 and not done and not truncated


def test_all_four_finish_wins(monkeypatch):
    env = ready(['cell_0']*4, [WAIT]*4, [1])
    monkeypatch.setattr(env, '_roll', lambda _: pytest.fail('승리 후 던지기'))
    _, reward, done, truncated, info = env.step(0)
    assert env.game.pieces['robot'] == [GOAL]*4
    assert (reward,done,truncated,info['winner']) == (1,True,False,'robot')
