"""실제 윷 확률표와 말 2개 규칙으로 진행하는 로컬 웹 대결. 기본은 빽도 규칙(11/03), --rules no_backdo는 11/02 규칙."""
import argparse
import json
import secrets
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import random
import hashlib
from datetime import datetime, timezone
from copy import deepcopy

from yut_rl.engine import YutGame, other
from yut_rl.game import Move, legal_moves, move_detail
from yut_rl.strategy import ModelStrategy
from yut_rl import dice
from yut_rl import sticks
from yut_rl import sticks_backdo

ROOT = Path(__file__).resolve().parent
MODEL = ROOT / 'models/four_pieces_tuned_10m/final_model.zip'
TWO_PIECE_MODEL = ROOT / 'models/continued_4m/final_model.zip'  # 11/02 빽도 없는 규칙
BACKDO_MODEL = ROOT / 'models/sticks_backdo_10m/final_model.zip'  # 11/03 빽도 규칙
NAMES = dice.NAMES


class Match:
    def __init__(self, strategy, first='human', rng=None, record_dir=None):
        self.strategy = strategy
        backdo = isinstance(strategy.board, sticks_backdo.SticksBackdoBoard)
        self.dice_mode = backdo or isinstance(strategy.board, dice.DiceBoard)  # 빽도 행동 형식
        self.move_type = dice.DiceMove if self.dice_mode else Move
        self.legal = (sticks_backdo if backdo else dice).legal_moves if self.dice_mode else legal_moves
        self.detail = dice.detail if self.dice_mode else move_detail
        self.game = (dice.DiceGame if self.dice_mode else YutGame)(strategy.board)
        self.current = first
        self.pending = []
        self.must_roll = True
        self.rng = rng or random.Random()
        self.log = []
        self.revision = 0
        self.last_throw = None
        self.record_dir = record_dir
        self.match_id = secrets.token_hex(12)
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.first = first
        self.events = []
        self.feedback = {}
        self.abandoned = False

    def save(self):
        if self.record_dir is None:
            return
        self.record_dir.mkdir(parents=True, exist_ok=True)
        record = dict(schema_version=2, match_id=self.match_id, created_at=self.created_at,
                      rules=getattr(self.game.board, 'rules_id', 'uniform_d6' if self.dice_mode else 'legacy_yut'),
                      strategy=getattr(self.strategy, 'label', '기존 PPO'),
                      model_sha256=self.strategy.record_model_hash,
                      board_sha256=self.strategy.record_board_hash,
                      first_player=self.first, events=self.events, feedback=self.feedback,
                      winner=self.game.winner(), status='completed' if self.game.winner() else
                      'abandoned' if self.abandoned else 'in_progress', final_pieces=self.game.pieces)
        path = self.record_dir / (self.match_id + '.json')
        temporary = path.with_suffix('.tmp')
        temporary.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
        temporary.replace(path)

    def flag(self, event_id, note):
        if type(event_id) is not int or not 0 <= event_id < len(self.events):
            raise ValueError('기보 번호가 잘못되었습니다.')
        event = self.events[event_id]
        if event['kind'] != 'move' or event['player'] != 'robot':
            raise ValueError('AI의 이동만 검토 대상으로 표시할 수 있습니다.')
        if not isinstance(note, str) or len(note) > 500:
            raise ValueError('메모는 500자 이내로 입력하세요.')
        self.feedback[str(event_id)] = dict(note=note, created_at=datetime.now(timezone.utc).isoformat())
        self.revision += 1
        self.save()

    def available_moves(self):
        moves = self.legal(self.game, self.current, self.pending)
        # The training action mask merges waiting pieces; humans may select any
        # numbered waiting piece in the UI without changing the game rules.
        if self.current == 'human':
            moves = [m for m in moves if m.piece < 0 or self.game.pieces['human'][m.piece] != 'wait']
            moves += [self.move_type(i, value) for i, pos in enumerate(self.game.pieces['human'])
                      if pos == 'wait' for value in sorted(set(self.pending)) if value > 0]
        return moves

    def act(self, command, action=None):
        if self.game.winner():
            raise ValueError('종료된 경기입니다. 새 대결을 시작하세요.')
        who = '나' if self.current == 'human' else 'AI'
        before = dict(pieces=deepcopy(self.game.pieces), pending=list(self.pending),
                      player=self.current, must_roll=self.must_roll)
        source = 'human'
        if command == 'ai':
            if self.current != 'robot':
                raise ValueError('AI 차례가 아닙니다.')
            if self.must_roll:
                command = 'roll'
            else:
                choice = self.strategy.choose(self.game.pieces, self.pending, fallback=False)
                command, action = 'move', choice['action']
                source = choice.get('source', 'model')
        elif self.current != 'human':
            raise ValueError('AI 차례입니다.')
        if command == 'roll':
            if not self.must_roll:
                raise ValueError('먼저 말을 이동하세요.')
            result = (self.game.board.sample(self.rng) if hasattr(self.game.board, 'sample') else
                      self.game.board.throw(sum(self.rng.random() < .5 for _ in range(4))))
            self.pending.append(result.value)
            self.must_roll = result.again
            self.last_throw = {'player': self.current, 'name': result.name, 'value': result.value}
            self.log.append(f'{who}: {result.name} ({result.value}칸)' + (' · 한 번 더!' if result.again else ''))
        elif command == 'move':
            moves = self.available_moves()
            if self.must_roll or type(action) is not int or action not in [m.action for m in moves]:
                raise ValueError('선택할 수 없는 이동입니다.')
            move = self.move_type.decode(action)
            result = self.game.move(self.current, move.piece, move.result)
            self.pending.remove(move.result)
            self.log.append(f'{who}: {move.piece + 1}번 말 · {NAMES[move.result]} → {result.dst}' +
                            (f' · {len(result.captured)}개 잡기!' if result.captured else '') +
                            (' · 완주!' if result.dst == 'goal' else ''))
            if move.piece < 0:
                self.log[-1] = f'{who}: 판 위에 말이 없어 빽도 소모'
            elif source == 'backdo_rule':
                self.log[-1] += ' · 빽도 보조 규칙'
            if not self.game.winner():
                if result.captured and self.game.board.again_on_capture:
                    self.must_roll = True
                elif not self.pending:
                    self.current = other(self.current)
                    self.must_roll = True
        else:
            raise ValueError('알 수 없는 명령입니다.')
        self.revision += 1
        event = dict(id=len(self.events), kind=command, player=before['player'], before=before,
                     after=dict(pieces=deepcopy(self.game.pieces), pending=list(self.pending),
                                player=self.current, must_roll=self.must_roll),
                     text=self.log[-1])
        if command == 'move':
            event.update(action=action, source=source)
        else:
            event.update(value=result.value)
        self.events.append(event)
        self.save()

    def state(self):
        moves = [] if self.must_roll or self.game.winner() else self.available_moves()
        return dict(pieces=self.game.pieces, current=self.current, pending=self.pending,
                    must_roll=self.must_roll, winner=self.game.winner(), revision=self.revision,
                    moves=[self.detail(self.game, self.current, m) for m in moves],
                    log=self.log, last_throw=self.last_throw, layout=self.game.board.layout,
                    match_id=self.match_id, recording=self.record_dir is not None,
                    strategy_label=getattr(self.strategy, 'label', '기존 PPO'),
                    rules=getattr(self.game.board, 'rules_id', 'uniform_d6' if self.dice_mode else 'legacy_yut'),
                    review_events=[dict(id=e['id'], flagged=str(e['id']) in self.feedback)
                                   for e in self.events if e['kind'] == 'move' and e['player'] == 'robot'])


def make_handler(strategy, record_dir=ROOT / 'output/human_matches'):
    sessions = {}
    model_path = getattr(strategy, 'model_path', None)
    if isinstance(strategy, (dice.LegacyDiceStrategy, ModelStrategy)):
        model_path = MODEL
    strategy.record_model_hash = hashlib.sha256(Path(model_path).read_bytes()).hexdigest() if model_path else None
    board_path = strategy.board.path_file if hasattr(strategy.board, 'path_file') else MODEL.with_name('board.json')
    strategy.record_board_hash = hashlib.sha256(board_path.read_bytes()).hexdigest()

    class Handler(BaseHTTPRequestHandler):
        def reply(self, data, status=200, cookie=None):
            body = json.dumps(data, ensure_ascii=False).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Cache-Control', 'no-store')
            if cookie:
                self.send_header('Set-Cookie', f'yut_session={cookie}; HttpOnly; SameSite=Strict; Path=/')
            self.end_headers()
            self.wfile.write(body)

        def session(self):
            cookie = SimpleCookie(self.headers.get('Cookie', ''))
            token = cookie['yut_session'].value if 'yut_session' in cookie else None
            fresh = token not in sessions
            if fresh:
                token = secrets.token_urlsafe(24)
                if len(sessions) >= 100:
                    sessions.pop(next(iter(sessions)))
                sessions[token] = Match(strategy, record_dir=record_dir)
            return token, sessions[token], fresh

        def do_GET(self):
            if self.path == '/api/state':
                token, match, fresh = self.session()
                self.reply(match.state(), cookie=token if fresh else None)
            elif self.path in ('/', '/index.html'):
                body = (ROOT / 'web/index.html').read_bytes()
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_error(404)

        def do_POST(self):
            if self.path != '/api/action':
                self.send_error(404)
                return
            origin = self.headers.get('Origin')
            if origin and origin != f'http://{self.headers.get("Host")}':
                self.reply({'error': '허용되지 않은 요청입니다.'}, 403)
                return
            try:
                length = int(self.headers.get('Content-Length', 0))
                if not 0 < length < 4096:
                    raise ValueError('잘못된 요청입니다.')
                data = json.loads(self.rfile.read(length))
                token, match, fresh = self.session()
                if data.get('revision') != match.revision:
                    self.reply({'error': '화면이 갱신되었습니다. 다시 선택하세요.'}, 409)
                    return
                if data.get('command') == 'new':
                    first = data.get('first', 'human')
                    if first not in ('human', 'robot'):
                        raise ValueError('잘못된 선공입니다.')
                    match.abandoned = not bool(match.game.winner())
                    match.save()
                    replacement = Match(strategy, first, record_dir=record_dir)
                    replacement.revision = match.revision + 1
                    sessions[token] = match = replacement
                elif data.get('command') == 'flag':
                    match.flag(data.get('event_id'), data.get('note', ''))
                else:
                    match.act(data.get('command'), data.get('action'))
                self.reply(match.state(), cookie=token if fresh else None)
            except (ValueError, TypeError, AttributeError) as exc:
                self.reply({'error': str(exc)}, 400)
            except Exception:
                self.reply({'error': '모델 실행 오류입니다. 서버 로그를 확인하세요.'}, 500)
                import traceback
                traceback.print_exc()

    return Handler


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--strategy', choices=['sticks', 'rule'], default='sticks')
    parser.add_argument('--rules', choices=['backdo', 'no_backdo'], default='backdo',
                        help='backdo: 11/03 빽도 규칙(기본), no_backdo: 11/02 규칙과 그 모델')
    parser.add_argument('--model', type=Path, help='고른 규칙에 호환되는 말 2개 모델 ZIP')
    args = parser.parse_args()
    if args.rules == 'backdo':
        path = args.model or BACKDO_MODEL
        model_type, rule_type = sticks_backdo.SticksBackdoModelStrategy, sticks_backdo.SticksBackdoRuleStrategy
    else:
        path = args.model or TWO_PIECE_MODEL
        model_type, rule_type = sticks.SticksModelStrategy, sticks.SticksRuleStrategy
    use_model = args.strategy == 'sticks' and (args.model or path.exists())
    strategy = model_type(path) if use_model else rule_type()
    server = HTTPServer(('127.0.0.1', args.port), make_handler(strategy))
    print(f'Yut ready: http://127.0.0.1:{args.port}', flush=True)
    server.serve_forever()
