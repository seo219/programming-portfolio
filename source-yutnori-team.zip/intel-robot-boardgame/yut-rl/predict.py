"""JSON 게임 상태로 말 선택만 실행합니다. 로봇은 움직이지 않습니다."""
import argparse
import json
import sys
from pathlib import Path

from yut_rl.strategy import ModelStrategy


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--state", type=Path, default=Path(__file__).parent / "examples/state.json")
    args = parser.parse_args()
    state = json.loads(args.state.read_text(encoding="utf-8"))
    strategy = ModelStrategy(args.model)
    print(json.dumps(strategy.choose(state["pieces"], state["pending"],
                                     state.get("player", "robot")), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
