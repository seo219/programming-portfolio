"""말 2개·빽도 규칙(11/03): tuned 조건으로 처음부터 학습한 뒤 홀드아웃으로 평가합니다.

사용법: .\\python.ps1 train_sticks_backdo.py <시드> <저장 폴더> [스텝 수, 기본 1000만]
빽도 규칙 모델이 아직 없어 동결 상대 없이 규칙 0.75·무작위 0.25로 학습합니다 (11/02 tuned의 규칙:무작위 3:1).
학습률·탐색 감소, 128x128 신경망 등 나머지는 config/training_tuned.json 그대로입니다.
"""
import json
import shutil
import sys
import time
from contextlib import redirect_stdout
from datetime import datetime, timezone
from pathlib import Path

import torch
from sb3_contrib import MaskablePPO
from stable_baselines3.common.callbacks import CallbackList, CheckpointCallback
from stable_baselines3.common.logger import configure
from stable_baselines3.common.vec_env import DummyVecEnv

from evaluate import evaluate
from yut_rl.bundle import package_versions, sha256, write_json
from yut_rl.env import read_config
from yut_rl.sticks_backdo import BOARD, RULES_ID, SticksBackdoCodec, SticksBackdoModelStrategy, source_hashes
from yut_rl.sticks_backdo_env import SticksBackdoEnv
from yut_rl.tuned import ExplorationSchedule, interpolate

ROOT = Path(__file__).resolve().parent
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 42
OUT = ROOT / (sys.argv[2] if len(sys.argv) > 2 else f'models/sticks_backdo_10m_seed{SEED}')
STEPS = int(sys.argv[3]) if len(sys.argv) > 3 else 10_000_000
HOLDOUT, GAMES = 32_000_000, 2000


def train():
    cfg = read_config(ROOT / 'config/training_tuned.json')
    cfg.pop('frozen_model', None)
    cfg['opponent_mix'] = {'rule': 0.75, 'random': 0.25}
    torch.set_num_threads(cfg['torch_threads'])
    env = DummyVecEnv([lambda: SticksBackdoEnv(BOARD, cfg) for _ in range(cfg['n_envs'])])
    env.seed(SEED)
    OUT.mkdir(parents=True)
    shutil.copyfile(BOARD, OUT / 'board.json')
    manifest = dict(schema=SticksBackdoCodec.version, rules=RULES_ID, created_utc=datetime.now(timezone.utc).isoformat(),
                    status='training', seed=SEED, requested_steps=STEPS, config=cfg, packages=package_versions(),
                    board_sha256=sha256(BOARD), source_sha256=source_hashes(),
                    throw_distribution={'빽도': .0625, '도': .1875, '개': .375, '걸': .25, '윷': .0625, '모': .0625},
                    note='말 2개·빽도 규칙 처음 학습. 동결 상대 없음.')
    write_json(OUT / 'manifest.json', manifest)
    lr0, lr1 = cfg['learning_rate'], cfg['learning_rate_final']
    model = MaskablePPO('MlpPolicy', env, device='cpu', seed=SEED, verbose=0,
                        learning_rate=lambda r: interpolate(lr0, lr1, r),
                        gamma=cfg['gamma'], gae_lambda=cfg['gae_lambda'], n_steps=cfg['n_steps'],
                        batch_size=cfg['batch_size'], n_epochs=cfg['n_epochs'], ent_coef=cfg['ent_coef'],
                        policy_kwargs={'net_arch': cfg['net_arch']})
    model.set_logger(configure(str(OUT / 'logs'), ['csv']))
    t = time.perf_counter()
    try:
        model.learn(total_timesteps=STEPS, callback=CallbackList([
            ExplorationSchedule(cfg['ent_coef'], cfg['ent_coef_final'], STEPS),
            CheckpointCallback(save_freq=max(cfg['checkpoint_freq'] // cfg['n_envs'], 1),
                               save_path=str(OUT / 'checkpoints'), name_prefix='checkpoint')]))
        model.save(OUT / 'final_model')
        manifest.update(status='complete', model_sha256=sha256(OUT / 'final_model.zip'))
    except BaseException:
        model.save(OUT / 'interrupted_model')
        manifest['status'] = 'failed_or_interrupted'
        raise
    finally:
        manifest.update(total_steps=model.num_timesteps, elapsed_seconds=round(time.perf_counter() - t, 1),
                        opponent_episode_counts=[e.episode_counts for e in env.envs])
        write_json(OUT / 'manifest.json', manifest)
        env.close()


def score(name, path, policy='model'):
    with open(OUT / 'evaluation.log', 'a', encoding='utf-8') as log, redirect_stdout(log):
        reps = {o: evaluate(path, GAMES, HOLDOUT, o, policy) for o in ('rule', 'random')}
    for r in reps.values():
        assert not r['illegal_actions'] and not r['truncated'], name
    return dict(name=name, policy=policy, model=str(path), rule=reps['rule']['win_rate_all_games'],
                random=reps['random']['win_rate_all_games'], reports=reps)


if __name__ == '__main__':
    train()
    final = OUT / 'final_model.zip'
    SticksBackdoModelStrategy(final)  # 웹에서 그대로 불러올 수 있는지 확인
    rows = [score('rule_ai_reference', final, policy='rule'), score(f'backdo_10m_seed{SEED}', final)]
    m = json.loads((OUT / 'manifest.json').read_text(encoding='utf-8'))
    write_json(OUT / 'RESULT.json', dict(rules=RULES_ID, holdout_seed=HOLDOUT, games=GAMES, results=rows))
    print(f"steps {m['total_steps']} time {m['elapsed_seconds']}s opp {m['opponent_episode_counts']}")
    for r in rows:
        print(f"{r['name']}: rule {r['rule']:.1%} random {r['random']:.1%}")
