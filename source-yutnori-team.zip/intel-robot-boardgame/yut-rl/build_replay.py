"""저장된 경기들을 서버 없이 열 수 있는 HTML 기보로 묶습니다."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    board = json.loads((ROOT / 'config/yut_board.json').read_text(encoding='utf-8'))
    games = []
    for filename, label in [
        ('four_pieces_tuned_10m_game.json', '말 4개 · 설정 변경 · 신규 1000만 스텝'),
        ('four_pieces_seed43_4m_game.json', '말 4개 · 시드 43 · 신규 400만 스텝'),
        ('four_pieces_18m_game.json', '말 4개 · 누적 1800만 스텝'),
        ('four_pieces_8m_game.json', '말 4개 · 누적 800만 스텝'),
        ('four_pieces_4m_game.json', '말 4개 · 신규 400만 스텝'),
        ('after_4m_game.json', '말 2개 · 400만 추가 학습 · 누적 약 652만'),
        ('after_2m_game.json', '말 2개 · 200만 추가 학습 · 누적 약 252만'),
        ('after_500k_game.json', '말 2개 · 50만 추가 학습 · 누적 약 52만'),
        ('verified_game.json', '말 2개 · 초기 검증 모델'),
    ]:
        path = ROOT / 'runs' / filename
        if path.exists():
            games.append({'label': label, 'trace': json.loads(path.read_text(encoding='utf-8'))})
    data = json.dumps({'board': board, 'games': games}, ensure_ascii=False).replace('<', '\\u003c')
    template = (ROOT / 'replay/template.html').read_text(encoding='utf-8')
    output = ROOT / 'replay/yut_replay.html'
    output.write_text(template.replace('__REPLAY_DATA__', data), encoding='utf-8')
    print(output)


if __name__ == '__main__':
    main()
