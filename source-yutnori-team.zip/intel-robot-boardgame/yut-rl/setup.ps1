param([string]$EnvironmentPath = '')
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$uvCommand = Get-Command uv -ErrorAction SilentlyContinue
if (-not $uvCommand) {
    throw 'uv가 필요합니다. 설치 후 다시 실행하세요: https://docs.astral.sh/uv/getting-started/installation/'
}
if (-not $EnvironmentPath) {
    $hasher = [System.Security.Cryptography.SHA256]::Create()
    try {
        $hashBytes = $hasher.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($PSScriptRoot.ToLowerInvariant()))
        $folderKey = ([BitConverter]::ToString($hashBytes)).Replace('-', '').Substring(0, 12)
    } finally { $hasher.Dispose() }
    $EnvironmentPath = Join-Path $env:LOCALAPPDATA "yut-rl-envs/$folderKey"
}
$pythonPath = Join-Path $EnvironmentPath 'Scripts/python.exe'
if (-not (Test-Path -LiteralPath $pythonPath)) {
    & uv venv --python 3.12 $EnvironmentPath
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.12 환경 생성 실패' }
}
& uv pip sync requirements.lock --python $pythonPath
if ($LASTEXITCODE -ne 0) { throw '패키지 설치 실패' }
$env:PYTHONUTF8 = '1'
& $pythonPath -m pytest tests -q
if ($LASTEXITCODE -ne 0) { throw '학습 환경 테스트 실패' }
[System.IO.File]::WriteAllText((Join-Path $PSScriptRoot '.python-path'), $pythonPath, [System.Text.UTF8Encoding]::new($false))
Write-Host "Python: $pythonPath"
Write-Host 'Ready: .\python.ps1 train.py --steps 100000 --output models/first'
