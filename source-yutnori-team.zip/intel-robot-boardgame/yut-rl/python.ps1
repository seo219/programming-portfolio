$ErrorActionPreference = 'Stop'
$pathFile = Join-Path $PSScriptRoot '.python-path'
if (-not (Test-Path -LiteralPath $pathFile)) { throw 'setup.ps1을 먼저 실행하세요.' }
$pythonPath = [System.IO.File]::ReadAllText($pathFile).Trim()
if (-not (Test-Path -LiteralPath $pythonPath)) { throw 'Python 환경이 없습니다. setup.ps1을 다시 실행하세요.' }
$env:PYTHONUTF8 = '1'
& $pythonPath @args
exit $LASTEXITCODE
