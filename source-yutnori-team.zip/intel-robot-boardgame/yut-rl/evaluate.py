"""선후공을 균등 배정해 학습 모델을 평가합니다."""
import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch
from sb3_contrib import MaskablePPO

from yut_rl import sticks_backdo
from yut_rl.bundle import read_bundle, write_json
from yut_rl.env import YutEnv
from yut_rl.game import choose_rule
from yut_rl.sticks_backdo_env import SticksBackdoEnv


def is_backdo_model(model_path: Path) -> bool:
    manifest = Path(model_path).resolve().with_name("manifest.json")
    return (manifest.is_file() and json.loads(manifest.read_text(encoding="utf-8")).get("schema")
            == sticks_backdo.SticksBackdoCodec.version)


def wilson(wins: int, games: int) -> list[float]:
    p, z = wins / games, 1.96
    denominator = 1 + z * z / games
    center = (p + z * z / (2 * games)) / denominator
    half = z * math.sqrt(p * (1 - p) / games + z * z / (4 * games * games)) / denominator
    return [round(center - half, 4), round(center + half, 4)]


def evaluate(model_path: Path, games: int, seed: int, opponent: str,
             policy: str = "model", trace_path: Path | None = None) -> dict:
    if is_backdo_model(model_path):  # 11/03 빽도 규칙 모델
        path, board, manifest = sticks_backdo.read_backdo_bundle(model_path)
        config = {**manifest["config"], "opponent": opponent, "opponent_mix": None}
        env, rule = SticksBackdoEnv(board, config), sticks_backdo.choose_rule
    else:
        path, board, manifest = read_bundle(model_path)
        config = {**manifest["config"], "opponent": opponent}
        env, rule = YutEnv(board, config, record_events=trace_path is not None), choose_rule
    torch.set_num_threads(manifest["config"]["torch_threads"])
    model = MaskablePPO.load(path, device="cpu") if policy == "model" else None
    counts = {"wins": 0, "losses": 0, "truncated": 0, "illegal_actions": 0}
    sides = {side: {"games": 0, "wins": 0} for side in ("robot", "human")}
    decisions_ms, move_counts = [], []
    for i in range(games):
        # 같은 시드로 선후공을 바꿉니다. 전략에 따라 던지는 횟수는 달라질 수 있습니다.
        episode_seed = seed + i // 2
        first = "robot" if i % 2 == 0 else "human"
        rng = np.random.default_rng(episode_seed + 10_000_000)
        obs, _ = env.reset(seed=episode_seed, options={"first_player": first})
        done = False
        while not done:
            if env.current == "human":
                action = env.pass_action
            else:
                started = time.perf_counter()
                if policy == "model":
                    action, _ = model.predict(obs, action_masks=env.action_masks(), deterministic=True)
                    action = int(action)
                elif policy == "rule":
                    action = rule(env.game, "robot", env.pending).action
                else:
                    action = int(rng.choice(np.flatnonzero(env.action_masks())))
                decisions_ms.append((time.perf_counter() - started) * 1000)
            obs, _, terminated, truncated, info = env.step(action)
            done = terminated or truncated
        sides[first]["games"] += 1
        if info["winner"] == "robot":
            counts["wins"] += 1
            sides[first]["wins"] += 1
        elif info["winner"] == "human":
            counts["losses"] += 1
        else:
            counts["truncated"] += 1
        counts["illegal_actions"] += int(info["illegal_action"])
        move_counts.append(info["moves"])
        if trace_path is not None and i == 0:
            write_json(trace_path, {"seed": episode_seed, "first_player": first,
                "events": getattr(env, "events", []), "final": env.game.pieces, "result": info})
        if (i + 1) % 100 == 0:
            print(f"[evaluation] {i + 1}/{games}", flush=True)
    env.close()
    return {"model": str(path), "policy": policy, "opponent": opponent,
            "games": games, "seed_start": seed, **counts,
            "win_rate_all_games": counts["wins"] / games,
            "win_rate_95pct_wilson": wilson(counts["wins"], games),
            "by_first_player": sides, "mean_moves": float(np.mean(move_counts)),
            "mean_decision_ms": float(np.mean(decisions_ms)) if decisions_ms else None,
            "p95_decision_ms": float(np.percentile(decisions_ms, 95)) if decisions_ms else None,
            "note": "중단은 승리로 세지 않습니다. 신뢰구간은 이 모델의 대결 변동이며 재학습 간 변동은 포함하지 않습니다."}


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--games", type=int, default=200)
    parser.add_argument("--seed", type=int, default=2_000_000)
    parser.add_argument("--opponent", choices=["rule", "random"], default="rule")
    parser.add_argument("--policy", choices=["model", "rule", "random"], default="model")
    parser.add_argument("--output", type=Path, default=Path("runs/evaluation.json"))
    parser.add_argument("--trace", type=Path, help="첫 대결의 모든 이동·윷 결과 저장")
    args = parser.parse_args()
    if args.games < 2 or args.games % 2:
        parser.error("선후공 균등 배정을 위해 --games는 2 이상의 짝수여야 합니다.")
    report = evaluate(args.model, args.games, args.seed, args.opponent, args.policy, args.trace)
    write_json(args.output, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
