# 학습 및 최종 비교 파이프라인이 끝나면 현재 PC에 완료 알림을 표시합니다.
$ErrorActionPreference = 'Stop'
$statusPath = Join-Path $PSScriptRoot 'runs\four_pieces_tuned_10m_pipeline.json'
$noticePath = Join-Path $PSScriptRoot 'runs\four_pieces_tuned_10m_notification.json'
$resultPath = Join-Path $PSScriptRoot 'models\four_pieces_tuned_10m\RESULT.md'
$archivePath = Join-Path $PSScriptRoot 'exports\yut-rl-tuned-10m.zip'

@{ state = 'waiting'; process_id = $PID; status_file = $statusPath } |
    ConvertTo-Json | Set-Content -LiteralPath $noticePath -Encoding UTF8

while ($true) {
    $pipeline = $null
    if (Test-Path -LiteralPath $statusPath) {
        try { $pipeline = Get-Content -LiteralPath $statusPath -Raw -Encoding UTF8 | ConvertFrom-Json }
        catch { $pipeline = $null } # 상태 파일을 쓰는 순간에는 다음 확인까지 기다립니다.
    }
    if ($pipeline.phase -eq 'complete' -and (Test-Path -LiteralPath $resultPath) -and (Test-Path -LiteralPath $archivePath)) {
        $noticeText = "윷놀이 1,000만 스텝 학습과 최종 비교 평가가 완료되었습니다.`r`n`r`n결과 문서:`r`n$resultPath`r`n`r`n모델 ZIP:`r`n$archivePath"
        $noticeTitle = '윷놀이 학습 완료'
        break
    }
    if ($pipeline.phase -eq 'failed') {
        $noticeText = "윷놀이 최종 비교 작업에 오류가 발생했습니다.`r`n`r`n$($pipeline.error)`r`n`r`n상태 파일:`r`n$statusPath"
        $noticeTitle = '윷놀이 작업 확인 필요'
        break
    }
    Start-Sleep -Seconds 30
}

try {
    $popup = New-Object -ComObject WScript.Shell
    @{ state = 'displaying'; process_id = $PID; result = $resultPath } |
        ConvertTo-Json | Set-Content -LiteralPath $noticePath -Encoding UTF8
    # 확인할 때까지 유지되는 완료 알림. 모델이나 로봇은 추가로 실행하지 않습니다.
    $null = $popup.Popup($noticeText, 0, $noticeTitle, 64)
    @{ state = 'acknowledged'; process_id = $PID; result = $resultPath } |
        ConvertTo-Json | Set-Content -LiteralPath $noticePath -Encoding UTF8
} catch {
    @{ state = 'notification_failed'; error = $_.Exception.Message; result = $resultPath } |
        ConvertTo-Json | Set-Content -LiteralPath $noticePath -Encoding UTF8
    throw
}
