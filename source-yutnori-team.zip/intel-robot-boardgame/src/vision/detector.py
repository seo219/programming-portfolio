"""비전 모듈 (담당: 정성욱). 카메라 화면을 읽어 게임에 필요한 값을 돌려줍니다.

- read_yut(): 던져진 윷가락의 결과 (윷 모델 + 정지 대기 + 다수결)
- board_state(): 판 위 말 위치 (판 카메라, 색 덩어리 -> 칸 배정, 칸별 다수결). piece_at()은 그 한 칸
- read_dice(): 주사위 눈 (차선책)
"""
import json
import time
from collections import Counter
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Callable, List, Optional, Protocol

import cv2
import numpy as np

from common.interfaces import DiceResult, YutResult
from vision.board_cells import CELLS_PATH, BoardCell, load_board_cells
from vision.board_pieces import BoardReading, assign_blobs_to_cells, board_region, find_piece_blobs
from vision.yut_logic import Detection, flats_from_detections, to_yut_result

FRAMES = 8  # 다수결에 쓸 프레임 수
MIN_AGREE = 0.75  # 이 비율 이상 일치해야 결과로 인정

CAMERA_SIZE = (1920, 1080)  # (가로, 세로). slots.json ROI와 눈 면적 기준이 이 해상도 기준
WARMUP_FRAMES = 10  # 노출이 안정되기 전 어두운 첫 프레임을 버림

# 판 읽기 전에 버릴 프레임 수. 로봇이 움직이는 동안 카메라 내부 버퍼에 쌓인 오래된 프레임을 비움 (시연장에서 다시 맞출 값)
BOARD_FLUSH_FRAMES = 5

# 주사위 눈 필터. 가정: 흰 주사위에 검은 눈, 카메라 고정(1920x1080 웹캠에서 눈 면적 약 250~300px, 멀리 있는 눈은 더 작음).
# 해상도나 카메라 거리를 바꾸면 PIP_AREA를 다시 맞춥니다.
PIP_AREA = (150, 2200)  # 눈 하나의 면적 범위(픽셀)
PIP_BG_KERNEL = 81  # 주변 밝기를 재는 창 크기
PIP_DARK_RATIO = 0.55  # 주변 평균 밝기의 이 비율보다 어두우면 눈 후보
PIP_RING_MIN = 150  # 눈 둘레의 최소 밝기 (흰 면 위의 점만 인정, 책상 얼룩 제외)
PIP_RING_RATIO = 1.8  # 눈 둘레가 눈 안쪽보다 이 배수 이상 밝아야 함
PIP_MIN_CIRCULARITY = 0.6
PIP_MIN_ASPECT = 0.5  # 타원 가로세로비. 옆면 눈은 비스듬해서 0.3대로 납작함
PIP_SIZE_RATIO = 0.45  # 가장 큰 눈 대비 이 비율보다 작은 눈은 옆면으로 보고 제외

YUT_BOARD_PATH = Path(__file__).resolve().parent.parent.parent / "config" / "yut_board.json"
BOARD_CELLS_PATH = CELLS_PATH  # config/board_cells.json (칸 이름 -> 화면 좌표)


class YutClassifier(Protocol):
    """윷가락 검출기. BGR 프레임에서 가락별 Detection 목록을 돌려줍니다 (실제 모델은 따로 연결)."""

    def detect(self, frame: np.ndarray) -> list[Detection]: ...

# 윷가락이 멈췄는지 보는 기준. 시연장 카메라·조명에서 다시 맞출 값 (아래는 합리적 기본값)
STILL_TIMEOUT = 3.0  # 던진 가락이 구르다 멎기까지 기다리는 최대 시간(초)
STILL_SIZE = (64, 36)  # 비교용 축소 크기. 센서 잡음을 평균내 지우고 비용을 줄임
# 2026-11-03 실측(1920x1080, 약 30fps, 표본 1회): 가만히 둔 평균차 최대 0.62, 굴리는 도중 잠잠한 구간 최대 연속 7프레임, 멎은 뒤 연속 21프레임이 0.7 미만. 다른 조명·카메라 위치에서는 scripts/try_read_yut.py의 c 모드로 다시 측정할 값
STILL_DIFF_THRESH = 0.7  # 직전 프레임과 그레이 평균 절대차(0~255)가 이 값 미만이면 정지. 가만히 최대 0.62보다 약간 위
STILL_FRAMES = 10  # 정지가 이만큼 연속돼야 멈춘 것으로 봄(약 0.33초). 도중 잠잠한 구간 최대 7프레임보다 길고 멎은 뒤 21프레임보다 짧음


@dataclass
class StillInfo:
    """_wait_until_still()의 진단 기록 (판정에는 쓰지 않음). 정지 대기가 오래 걸리는 이유를 가리는 용도."""
    waited_sec: float  # 실제 대기 시간(self._clock 기준)
    still: bool  # _wait_until_still()의 반환값과 같음
    frames: int  # 비교한 프레임 수(차이를 잰 횟수)
    max_diff: float
    last_diff: float  # 마지막으로 잰 직전 프레임과의 차이
    diffs: List[float]  # 프레임별 차이(소수 셋째 자리 반올림)


def open_camera(index: int) -> cv2.VideoCapture:
    """카메라를 CAMERA_SIZE로 열고 노출이 안정될 때까지 프레임을 버립니다. select_roi.py도 같이 씁니다."""
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        cap.release()
        raise RuntimeError(f"카메라 {index}번을 열지 못했습니다 (다른 프로그램이 쓰고 있거나 번호가 틀렸는지 확인하세요)")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAMERA_SIZE[0])
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_SIZE[1])
    for _ in range(WARMUP_FRAMES):
        cap.read()
    return cap


class VisionDetector:
    def __init__(self, slots_path: Path, camera_index: int = 0,
                 frame_source: Optional[Callable[[], np.ndarray]] = None,
                 yut_classifier: Optional[YutClassifier] = None, board_path: Optional[Path] = None,
                 *, board_camera_index: Optional[int] = None,
                 board_frame_source: Optional[Callable[[], np.ndarray]] = None,
                 board_cells_path: Optional[Path] = None):
        """frame_source가 있으면 카메라 대신 그 함수가 주는 BGR 프레임을 씁니다 (테스트용).

        camera_index/frame_source는 트레이 카메라, board_*는 판 고정 카메라용입니다.
        판 카메라 번호가 None이거나 camera_index와 같으면 트레이와 같은 캡처·프레임 소스를 공유합니다.

        yut_classifier는 read_yut()에만 필요하고, board_path 기본값은 config/yut_board.json입니다.
        board_cells_path(기본 config/board_cells.json)는 board_state()를 처음 부를 때 읽습니다.
        """
        self.slots = json.loads(Path(slots_path).read_text(encoding="utf-8"))
        self.camera_index = camera_index
        self._frame_source = frame_source
        self.board_camera_index = board_camera_index
        self._board_frame_source = board_frame_source
        self._caps: dict[int, cv2.VideoCapture] = {}  # 카메라 번호 → 캡처 (처음 쓸 때 엶)
        self.yut_classifier = yut_classifier
        self.board_path = Path(board_path) if board_path else YUT_BOARD_PATH
        self.board_cells_path = Path(board_cells_path) if board_cells_path else BOARD_CELLS_PATH
        self._board_cells: Optional[dict[str, BoardCell]] = None  # 처음 board_state()에서 읽어 캐시
        self.last_board_issues: list[str] = []  # 마지막 board_state()에서 사람이 확인해야 할 점
        self._clock: Callable[[], float] = time.monotonic  # 테스트에서 가짜 시계로 교체
        self.last_still_info: Optional[StillInfo] = None  # 마지막 _wait_until_still()의 진단 기록

    def read_yut(self) -> YutResult:
        """가락이 멈춘 뒤 FRAMES장의 배 개수를 다수결로 판정. 일치율이 낮거나 가락 수가 안 맞으면 flats=None.

        로봇이 움직이는 동안(팔이 카메라를 가림)에는 부르지 않는 것은 호출자(게임)의 책임입니다.
        """
        if self.yut_classifier is None:
            raise RuntimeError("윷 모델이 설정되지 않았습니다")
        still = self._wait_until_still()
        votes_by_flats = Counter()
        for _ in range(FRAMES):
            flats = flats_from_detections(self.yut_classifier.detect(self._grab()))
            if flats is not None:
                votes_by_flats[flats] += 1
        if not votes_by_flats:
            return YutResult(None, None, 0.0)
        flats, votes = votes_by_flats.most_common(1)[0]
        ratio = votes / FRAMES
        result = YutResult(None, None, ratio) if ratio < MIN_AGREE else to_yut_result(flats, ratio, self.board_path)
        # 못 멈췄어도 읽긴 하되(게임이 멈추면 안 됨), 구르는 중에 읽었을 수 있으니 신뢰도만 절반으로 낮춘다
        return result if still else replace(result, confidence=result.confidence / 2)

    def _wait_until_still(self, timeout: float = STILL_TIMEOUT, diff_thresh: float = STILL_DIFF_THRESH,
                          still_frames: int = STILL_FRAMES) -> bool:
        """직전 프레임과의 차이가 diff_thresh 미만인 프레임이 still_frames번 연속이면 True, timeout까지 못 멈추면 False."""
        start = self._clock()
        deadline = start + timeout
        prev, still, diffs, ok = None, 0, [], False
        while self._clock() < deadline:
            small = cv2.resize(cv2.cvtColor(self._tray_view(self._grab()), cv2.COLOR_BGR2GRAY), STILL_SIZE,
                               interpolation=cv2.INTER_AREA)
            if prev is not None:
                diff = float(cv2.absdiff(small, prev).mean())
                diffs.append(round(diff, 3))
                still = still + 1 if diff < diff_thresh else 0
                if still >= still_frames:
                    ok = True
                    break
            prev = small
        self.last_still_info = StillInfo(self._clock() - start, ok, len(diffs), max(diffs, default=0.0),
                                         diffs[-1] if diffs else 0.0, diffs)
        return ok

    def read_dice(self) -> DiceResult:
        """트레이 ROI를 FRAMES장 인식해 다수결로 판정. 일치율이 낮으면 value=None."""
        counts = []
        for _ in range(FRAMES):
            pips = self._count_pips(self._crop(self._grab(), "tray"))
            if 1 <= pips <= 6:
                counts.append(pips)
        if not counts:
            return DiceResult(None, 0.0)
        value, votes = Counter(counts).most_common(1)[0]
        ratio = votes / FRAMES
        return DiceResult(value if ratio >= MIN_AGREE else None, ratio)

    def piece_at(self, cell: str) -> Optional[str]:
        """칸 하나의 'robot' / 'human' / None. board_state()를 읽어 그 칸만 돌려줍니다."""
        cells = self._get_board_cells()
        if cell not in cells:
            raise ValueError(f"모르는 칸 이름: {cell} (가능한 칸: {', '.join(cells)})")
        return self.board_state()[cell]

    def board_state(self) -> dict[str, Optional[str]]:
        """판 위 칸 전체의 편 {"cell_3": "robot", ...}. 빈 칸은 None. 키는 게임 칸 이름 (docs/interfaces.md 1절).

        로봇이 home()한 뒤에만 부릅니다 (설계 규칙 3, 팔이 카메라를 가림). 애매한 칸은 None으로 두고
        이유를 last_board_issues에 남깁니다. 카메라 예외는 그대로 올립니다.
        """
        reading = self._read_board()
        self.last_board_issues = reading.issues
        return reading.state

    def _get_board_cells(self) -> dict[str, BoardCell]:
        if self._board_cells is None:
            self._board_cells = load_board_cells(self.board_cells_path, self.board_path)
        return self._board_cells

    def _read_board(self) -> BoardReading:
        """오래된 프레임을 버리고 FRAMES장을 읽어 칸별 다수결로 판독합니다 (애매한 칸은 None + issues)."""
        cells = self._get_board_cells()
        region = board_region(cells)
        for _ in range(BOARD_FLUSH_FRAMES):
            self._grab("board")
        readings = []
        for _ in range(FRAMES):
            blobs = find_piece_blobs(self._grab("board"), region=region)
            readings.append(assign_blobs_to_cells(blobs, cells))
        state: dict[str, Optional[str]] = {}
        issues: list[str] = []
        for name in cells:
            votes = Counter(r.state[name] for r in readings)
            owner, count = votes.most_common(1)[0]
            if count / FRAMES < MIN_AGREE:
                summary = ", ".join(f"{o or '없음'} {n}" for o, n in votes.most_common())
                issues.append(f"불안정: {name} ({summary})")
                owner = None
            state[name] = owner
        seen = Counter(i for r in readings for i in set(r.issues))  # 일시 노이즈는 빼고 절반 이상 프레임에서 반복된 것만
        issues += [i for i, n in seen.items() if n * 2 >= FRAMES]
        return BoardReading(state, issues)

    def close(self) -> None:
        for cap in self._caps.values():
            cap.release()
        self._caps.clear()

    def _grab(self, camera: str = "tray") -> np.ndarray:
        """camera는 "tray" 또는 "board". 읽기에 실패하면 그 캡처를 닫아 다음 호출에서 다시 엽니다."""
        if camera not in ("tray", "board"):
            raise ValueError(f"camera는 'tray' 또는 'board'여야 합니다: {camera!r}")
        shared = self.board_camera_index is None or self.board_camera_index == self.camera_index
        if camera == "board":
            if self._board_frame_source is not None:
                return self._board_frame_source()
            index = self.camera_index if shared else self.board_camera_index
        else:
            index = self.camera_index
        if (camera == "tray" or shared) and self._frame_source is not None:
            return self._frame_source()
        if index not in self._caps:
            self._caps[index] = open_camera(index)
        ok, frame = self._caps[index].read()
        if not ok:
            self._caps.pop(index).release()
            raise RuntimeError(f"카메라 {index}번에서 프레임을 읽지 못했습니다")
        return frame

    def _crop(self, frame: np.ndarray, name: str) -> np.ndarray:
        if name not in self.slots or name.startswith("_"):
            raise KeyError(f"slots.json에 '{name}' ROI가 없습니다")
        x, y, w, h = self.slots[name]
        if w <= 0 or h <= 0:
            raise ValueError(f"'{name}' ROI가 아직 측정되지 않았습니다 (config/slots.json)")
        return frame[y:y + h, x:x + w]

    def _tray_view(self, frame: np.ndarray) -> np.ndarray:
        """정지 판정용: 트레이 ROI만 잘라 돌려줍니다. ROI가 없거나 아직 측정 전(0)이면 전체 프레임을 씁니다.

        트레이 밖에서 손·그림자가 움직여도 정지 판정이 흔들리지 않게 하려는 것입니다.
        """
        roi = self.slots.get("tray")
        if not roi or roi[2] <= 0 or roi[3] <= 0:
            return frame
        return self._crop(frame, "tray")

    @classmethod
    def _count_pips(cls, roi: np.ndarray) -> int:
        return len(cls._find_pips(roi))

    @staticmethod
    def _find_pips(roi: np.ndarray) -> list:
        """흰 면 위의 어두운 둥근 점(윗면 눈)의 윤곽 목록을 돌려줍니다. 옆면의 납작한 눈은 제외합니다.

        주사위 본체를 따로 찾지 않아서 트레이 ROI 크기나 책상 반사광에 덜 흔들립니다.
        """
        gray = cv2.GaussianBlur(cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY), (5, 5), 0)
        background = cv2.blur(gray, (PIP_BG_KERNEL, PIP_BG_KERNEL)).astype(np.float32)
        dark = (gray.astype(np.float32) < background * PIP_DARK_RATIO).astype(np.uint8) * 255
        dark = cv2.morphologyEx(dark, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        contours, _ = cv2.findContours(dark, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        found = []  # (면적, 윤곽)
        for c in contours:
            area = cv2.contourArea(c)
            perimeter = cv2.arcLength(c, True)
            if not PIP_AREA[0] <= area <= PIP_AREA[1] or perimeter == 0 or len(c) < 5:
                continue
            if 4 * np.pi * area / perimeter ** 2 < PIP_MIN_CIRCULARITY:
                continue
            d1, d2 = cv2.fitEllipse(c)[1]
            if min(d1, d2) / max(d1, d2) < PIP_MIN_ASPECT:
                continue
            blob = np.zeros(gray.shape, np.uint8)
            cv2.drawContours(blob, [c], -1, 255, cv2.FILLED)
            ring = cv2.dilate(blob, np.ones((15, 15), np.uint8)) & ~cv2.dilate(blob, np.ones((5, 5), np.uint8))
            ring_mean, blob_mean = gray[ring > 0].mean(), gray[blob > 0].mean()
            if ring_mean >= PIP_RING_MIN and ring_mean >= blob_mean * PIP_RING_RATIO:
                found.append((area, c))
        if not found:
            return []
        biggest = max(a for a, _ in found)
        return [c for a, c in found if a >= biggest * PIP_SIZE_RATIO]
