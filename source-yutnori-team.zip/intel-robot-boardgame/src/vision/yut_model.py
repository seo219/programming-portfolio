"""Geti 윷 탐지 모델(OpenVINO, model_api)을 YutClassifier로 감싸는 모듈."""
from pathlib import Path

import cv2
import numpy as np

from vision.yut_logic import Detection

DEFAULT_YUT_MODEL_DIR = Path(__file__).resolve().parent.parent.parent / "models" / "yut" / "7bc45355-openvino-int8"


def detections_from_result(result) -> list[Detection]:
    """model_api의 DetectionResult(label_names/scores/bboxes)를 Detection 목록으로 바꿉니다."""
    labels, scores, boxes = list(result.label_names), list(result.scores), list(result.bboxes)
    if not len(labels) == len(scores) == len(boxes):
        raise ValueError(f"결과 길이가 다릅니다: label {len(labels)}, score {len(scores)}, box {len(boxes)}")
    return [
        Detection(str(label), float(score), tuple(float(v) for v in box))
        for label, score, box in zip(labels, scores, boxes)
    ]


class ModelApiYutClassifier:
    """model.xml이 든 폴더를 model_api로 불러 BGR 프레임에서 윷가락을 검출합니다."""

    def __init__(self, model_dir: Path = DEFAULT_YUT_MODEL_DIR, device: str = "CPU"):
        xml = Path(model_dir) / "model.xml"
        if not xml.exists():
            raise FileNotFoundError(f"윷 모델이 없습니다: {xml} (models/yut/ 아래에 Geti 모델을 내려받아 두세요)")
        from model_api.models import Model  # 무거워서 모델을 실제로 쓸 때만 불러옴

        self._model = Model.create_model(str(xml), device=device)

    def detect(self, frame_bgr: np.ndarray) -> list[Detection]:
        return detections_from_result(self._model(cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)))
