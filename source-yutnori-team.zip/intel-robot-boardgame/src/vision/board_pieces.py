"""판 위 말 판별 (담당: 정성욱). 색 덩어리를 찾아 가장 가까운 칸에 배정합니다.

- 칸 이름은 그대로 키로 쓰며, 이름 모양(cell_N 등)을 가정하지 않습니다.
- 카메라·모델·로봇을 import하지 않는 순수 함수입니다 (사진 한 장 + 칸 좌표 -> 결과).
"""
from dataclasses import dataclass, field
from typing import Optional

import cv2
import numpy as np

from vision.board_cells import BoardCell

# 색 범위 (OpenCV HSV: H 0~179). 시연장 조명에서 다시 측정해 맞출 것
PIECE_COLORS = {
    "robot": [((0, 130, 100), (8, 255, 255)), ((170, 130, 100), (179, 255, 255))],  # 빨강 (색상이 0 근처에서 이어짐)
    "human": [((100, 120, 50), (130, 255, 255))],                                    # 파랑
}
MIN_BLOB_AREA = 1500       # 이보다 작은 색 덩어리는 노이즈로 봄 (픽셀)
MAX_CELL_DIST_RATIO = 0.6  # 가장 가까운 칸까지 거리가 (이웃 칸 간격 x 이 값)보다 크면 배정하지 않음


@dataclass
class Blob:
    owner: str    # "robot" | "human"
    cx: float     # 중심 x (픽셀)
    cy: float     # 중심 y (픽셀)
    area: float   # 면적 (픽셀)


@dataclass
class BoardReading:
    state: dict[str, Optional[str]]                 # {칸 이름: "robot" | "human" | None}
    issues: list[str] = field(default_factory=list)  # 사람이 확인해야 할 점


def find_piece_blobs(img_bgr: np.ndarray, region: Optional[np.ndarray] = None) -> list[Blob]:
    """색 덩어리(빨강=robot, 파랑=human)를 찾는다.

    region: 판 안쪽을 나타내는 다각형 꼭짓점 (N x 2 픽셀). 주면 그 바깥의 색은 무시한다
    (판 밖의 빨강·파랑 물건을 말로 오인하지 않기 위함). 없으면 사진 전체를 본다.
    """
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    area_mask = None
    if region is not None:
        area_mask = np.zeros(img_bgr.shape[:2], np.uint8)
        cv2.fillPoly(area_mask, [np.asarray(region).astype(np.int32)], 255)
    blobs = []
    for owner, ranges in PIECE_COLORS.items():
        mask = np.zeros(img_bgr.shape[:2], np.uint8)
        for lo, hi in ranges:
            mask |= cv2.inRange(hsv, lo, hi)
        if area_mask is not None:
            mask = cv2.bitwise_and(mask, area_mask)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
        n, _, stats, cent = cv2.connectedComponentsWithStats(mask)
        for j in range(1, n):
            area = float(stats[j][4])
            if area >= MIN_BLOB_AREA:
                blobs.append(Blob(owner, float(cent[j][0]), float(cent[j][1]), area))
    return blobs


def board_region(cells: dict[str, BoardCell]) -> np.ndarray:
    """모든 칸 원(중심 ± roi_r)의 볼록 껍질 (N x 2, int32). find_piece_blobs의 region으로 넘겨 판 바깥의 색을 무시한다."""
    angles = np.linspace(0, 2 * np.pi, 16, endpoint=False)
    pts = np.array([[c.x + c.roi_r * np.cos(a), c.y + c.roi_r * np.sin(a)]
                    for c in cells.values() for a in angles], np.float32)
    return cv2.convexHull(pts).reshape(-1, 2).astype(np.int32)


def cell_spacing(cells: dict[str, BoardCell]) -> float:
    """칸마다 가장 가까운 이웃 칸까지 거리(px)의 중앙값."""
    if len(cells) < 2:
        raise ValueError("칸이 2개 이상 필요합니다")
    pts = np.array([[c.x, c.y] for c in cells.values()])
    dist = np.linalg.norm(pts[:, None, :] - pts[None, :, :], axis=2)
    np.fill_diagonal(dist, np.inf)
    return float(np.median(dist.min(axis=1)))


def assign_blobs_to_cells(blobs: list[Blob], cells: dict[str, BoardCell],
                          max_dist_ratio: float = MAX_CELL_DIST_RATIO) -> BoardReading:
    """덩어리를 가장 가까운 칸에 배정한다. 모든 칸이 결과에 들어가고 빈 칸은 None."""
    names = list(cells)
    pts = np.array([[cells[k].x, cells[k].y] for k in names])
    limit = max_dist_ratio * cell_spacing(cells)
    owners: dict[str, set[str]] = {k: set() for k in names}
    issues: list[str] = []
    for b in blobs:
        d = np.linalg.norm(pts - np.array([b.cx, b.cy]), axis=1)
        j = int(d.argmin())
        if d[j] > limit:
            issues.append(f"배정 못한 덩어리 ({b.owner}, 좌표 {b.cx:.0f},{b.cy:.0f}): 가장 가까운 칸 {names[j]}까지 {d[j]:.0f}px")
            continue
        owners[names[j]].add(b.owner)
    state: dict[str, Optional[str]] = {}
    for k in names:
        if len(owners[k]) > 1:
            # 다른 편이 겹치면 소유자를 추측하지 않고 비워 둔다
            issues.append(f"충돌: {k}에 {' / '.join(sorted(owners[k]))} 덩어리가 겹침")
            state[k] = None
        else:
            # 같은 편 덩어리가 둘 이상이어도 한 칸에 말을 업은 것일 수 있으므로 그 편으로 둔다
            state[k] = next(iter(owners[k]), None)
    return BoardReading(state, issues)
