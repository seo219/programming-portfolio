"""판 칸 좌표 읽기 (담당: 정성욱). 키는 게임 칸 이름(cell_0~19, diag_*, center)입니다.

- 좌표 파일 config/board_cells.json은 카메라 위치 확정 후 scripts/make_board_cells.py로 만듭니다.
- 비전은 로봇을 import하지 않으므로 칸 이름은 config/yut_board.json에서 읽습니다.
"""
import json
from dataclasses import dataclass
from pathlib import Path

CONFIG = Path(__file__).resolve().parents[2] / "config"
BOARD_PATH = CONFIG / "yut_board.json"
CELLS_PATH = CONFIG / "board_cells.json"

_OFF_BOARD = ("wait_", "goal_")  # 판 밖 칸 (대기·완주)


@dataclass
class BoardCell:
    x: float       # 화면 중심 x (픽셀)
    y: float       # 화면 중심 y (픽셀)
    roi_r: float   # 판정 영역 반지름 (픽셀)


def board_cell_names(board_path: Path = BOARD_PATH) -> list[str]:
    """yut_board.json의 layout에서 판 위 칸 이름만 뽑습니다 (대기·완주 제외)."""
    layout = json.loads(Path(board_path).read_text(encoding="utf-8"))["layout"]
    return [n for n in layout if not n.startswith("_") and not n.startswith(_OFF_BOARD)]


def _is_number(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def load_board_cells(path: Path = CELLS_PATH, board_path: Path = BOARD_PATH) -> dict[str, BoardCell]:
    """board_cells.json을 읽어 {칸 이름: BoardCell}로 돌려줍니다. 맞지 않으면 예외."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"{path.as_posix()}이(가) 없습니다. 카메라 위치 확정 후 scripts/make_board_cells.py로 만드세요")
    raw = json.loads(path.read_text(encoding="utf-8")).get("cells", {})
    names = board_cell_names(board_path)
    unknown = sorted(set(raw) - set(names))
    missing = [n for n in names if n not in raw]
    if unknown:
        hint = ""
        if any(n.startswith("cell_") and n[5:].isdigit() and int(n[5:]) >= 20 for n in unknown):
            hint = " (cell_20~28은 비전 초안 이름입니다. 게임 칸 이름으로 바꿔야 합니다)"
        raise ValueError(f"모르는 칸 이름: {', '.join(unknown)}{hint}")
    if missing:
        raise ValueError(f"빠진 칸: {', '.join(missing)}")
    cells = {}
    for name in names:
        v = raw[name]
        for key in ("x", "y", "roi_r"):
            if not isinstance(v, dict) or not _is_number(v.get(key)):
                raise ValueError(f"{name}.{key}이(가) 숫자가 아닙니다: {v}")
        if v["roi_r"] <= 0:
            raise ValueError(f"{name}.roi_r은 0보다 커야 합니다 (아직 측정하지 않은 값): {v['roi_r']}")
        cells[name] = BoardCell(float(v["x"]), float(v["y"]), float(v["roi_r"]))
    return cells
