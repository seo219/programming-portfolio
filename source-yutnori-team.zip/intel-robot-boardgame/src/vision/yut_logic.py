"""윷 판정 규칙. 윷가락 검출 목록 → 배(평평한 면) 개수 → YutResult. 모델·카메라 없이 동작하는 순수 함수."""
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from common.interfaces import YutResult

# 모델 내장 기본 임계값은 0.675. 윷가락 4개가 모두 잡혀야 하므로 약간 낮춰 놓고, 4개가 안 되면 None으로 재시도시킨다.
DEFAULT_MIN_SCORE = 0.5
LABELS = ("down", "backdo", "upper")  # down=배, backdo=표시된 배(빽도 가락), upper=등


@dataclass
class Detection:
    label: str  # down | backdo | upper
    score: float
    box: tuple[float, float, float, float]  # x1, y1, x2, y2


def flats_from_detections(
    dets: list[Detection], min_score: float = DEFAULT_MIN_SCORE, expected_sticks: int = 4
) -> Optional[int]:
    """배가 위인 가락 수(0~4, 빽도 -1)를 구합니다. 가락 수가 expected_sticks가 아니면 None.

    같은 가락에 박스가 겹치는 중복 검출(NMS)은 모델 쪽 책임입니다.
    """
    for d in dets:
        if d.label not in LABELS:
            raise ValueError(f"알 수 없는 label: {d.label}")
    kept = [d for d in dets if d.score >= min_score]
    if len(kept) != expected_sticks:
        return None
    backdo = sum(d.label == "backdo" for d in kept)
    flats = backdo + sum(d.label == "down" for d in kept)
    return -1 if backdo >= 1 and flats == 1 else flats


def to_yut_result(flats: Optional[int], confidence: float, board_path: Path) -> YutResult:
    """배 개수를 board_path(yut_board.json)의 "yut" 표로 YutResult로 바꿉니다. None이면 인식 실패."""
    if flats is None:
        return YutResult(None, None, confidence)
    table = json.loads(board_path.read_text(encoding="utf-8"))["yut"]
    if str(flats) not in table:
        raise ValueError(f"yut 표에 없는 flats: {flats}")
    return YutResult(flats, table[str(flats)][1], confidence)
