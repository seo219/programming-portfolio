"""윷놀이 화면 그리기. 칸은 슬롯 이름(cell_N, wait_robot...)으로만 다루고 픽셀 좌표는 이 파일 안에서만 씁니다."""
import json
import re
from pathlib import Path
from typing import Optional

import pygame

from common.interfaces import GameState, YutState
from ui import theme

BOARD_JSON = Path(__file__).resolve().parent.parent.parent / "config" / "yut_board.json"
SIDES = ("robot", "human")  # 위에서 아래 순서
BIG_CELLS = {"cell_0", "cell_5", "cell_10", "cell_15", "center"}  # 모서리·중앙은 큰 원
SLOT_RE = re.compile(r"\((\w+)\)")  # 보기 문구 "말1(cell_7)에 ..."에서 칸 이름 추출

HEADER = pygame.Rect(0, 0, 1100, 80)
BOARD_PANEL = pygame.Rect(20, 90, 640, 670)
BOARD_RECT = pygame.Rect(80, 165, 520, 520)  # 정규화 좌표 (0,0)~(1,1)이 놓이는 사각형
SIDE_PANEL = {"robot": pygame.Rect(680, 90, 400, 140), "human": pygame.Rect(680, 240, 400, 140)}
MESSAGE_RECT = pygame.Rect(680, 390, 400, 100)
CHOICE_AREA = pygame.Rect(680, 500, 400, 260)
THROW_RECT = pygame.Rect(120, 250, 560, 360)


def load_layout(path: Path = BOARD_JSON) -> dict:
    """yut_board.json에서 칸 좌표(정규화)와 길(선 연결)을 읽습니다."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    layout = {k: tuple(v) for k, v in data["layout"].items() if not k.startswith("_")}
    edges: set = set()
    for route in data["routes"].values():
        if not isinstance(route, list):
            continue
        cells = [c for c in route if c in layout]
        edges.update(tuple(sorted(pair)) for pair in zip(cells, cells[1:]))
    edges.add(("cell_0", "cell_1"))  # outer 길은 cell_1에서 시작하므로 닫는 선을 더함
    return {"cells": layout, "edges": sorted(edges)}


def load_yut_names(path: Path = BOARD_JSON) -> dict:
    """yut_board.json의 "yut" 표에서 이동 칸 수 → 이름(빽도 -1, 도 1, 개 2, 걸 3, 윷 4, 모 5)."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return {int(v[1]): v[0] for k, v in data["yut"].items() if not k.startswith("_")}


def choice_rects(n: int) -> list[pygame.Rect]:
    """보기 버튼 위치. 개수에 따라 높이를 줄여 영역에 맞춥니다."""
    if n <= 0:
        return []
    gap = 6
    h = min(44, (CHOICE_AREA.height - 28 - gap * (n - 1)) // n)
    return [pygame.Rect(CHOICE_AREA.left, CHOICE_AREA.top + 28 + i * (h + gap), CHOICE_AREA.width, h)
            for i in range(n)]


def wrap(text: str, font: pygame.font.Font, width: int) -> list[str]:
    """글자 단위 줄바꿈 (한글은 띄어쓰기가 없어도 자릅니다)."""
    lines: list[str] = []
    for para in str(text).split("\n"):
        cur = ""
        for ch in para:
            if font.size(cur + ch)[0] > width and cur:
                lines.append(cur)
                cur = ch
            else:
                cur += ch
        lines.append(cur)
    return lines


class YutView:
    def __init__(self, fonts: "theme.Fonts", board_path: Path = BOARD_JSON, show_labels: bool = True):
        self.fonts = fonts
        self.show_labels = show_labels
        layout = load_layout(board_path)
        self.yut_names = load_yut_names(board_path)  # 이동 칸 수 → 윷 이름 (모아 둔 결과를 글자로 표시)
        self.cells: dict = layout["cells"]  # 칸 이름 → 정규화 좌표
        self.edges: list = layout["edges"]

    # ---- 좌표 (ui 안에서만) ----

    def cell_px(self, cell: str) -> tuple[int, int]:
        x, y = self.cells[cell]
        return (round(BOARD_RECT.left + x * BOARD_RECT.width), round(BOARD_RECT.top + y * BOARD_RECT.height))

    def slot_px(self, slot: str, index: int = 0) -> tuple[int, int]:
        """슬롯 이름 → 중심 픽셀. wait_*/goal_*는 편 패널 안에 가로로 늘어놓습니다."""
        if slot in self.cells:
            return self.cell_px(slot)
        kind, _, side = slot.partition("_")
        panel = SIDE_PANEL.get(side)
        if panel is None or kind not in ("wait", "goal"):
            return BOARD_RECT.center
        x0 = panel.left + (73 if kind == "wait" else 253)
        return (x0 + index * 44, panel.top + 76)

    # ---- 전체 ----

    def draw(self, surface: pygame.Surface, state, message: str = "", highlight: Optional[str] = None) -> None:
        surface.fill(theme.BG)
        self.draw_header(surface, state)
        pygame.draw.rect(surface, theme.PANEL, BOARD_PANEL, border_radius=14)
        if isinstance(state, YutState):
            self.draw_board(surface)
            self.draw_side_panels(surface, state)
            self.draw_pieces(surface, state, highlight)
        elif isinstance(state, GameState):
            self.draw_dice_state(surface, state)
        else:
            self._text(surface, "대기 중...", self.fonts.large, theme.TEXT_DIM, BOARD_PANEL.center)
        self.draw_message(surface, message)
        if getattr(state, "winner", None):
            self.draw_winner(surface, state.winner)

    def draw_header(self, surface: pygame.Surface, state) -> None:
        pygame.draw.rect(surface, theme.PANEL, HEADER)
        f = self.fonts
        self._text(surface, "윷놀이: 사람 vs 로봇", f.large, theme.TEXT, (24, 40), anchor="midleft")
        cur = getattr(state, "current", None)
        if cur:
            color = theme.SIDE_COLOR.get(cur, theme.TEXT)
            self._text(surface, f"{getattr(state, 'turn', 1)}턴 · {theme.SIDE_NAME.get(cur, cur)} 차례",
                       f.large, color, (440, 28), anchor="midleft")
            if cur == "robot":
                self._text(surface, "로봇 차례: 로봇이 윷을 던지고 말을 옮깁니다. 판에 손을 대지 마세요",
                           f.small, theme.TEXT_DIM, (440, 58), anchor="midleft")
        pending = getattr(state, "pending", None)
        if pending:
            names = " · ".join(self.yut_names.get(p, str(p)) for p in pending)
            self._text(surface, "모아 둔 결과 : " + names, f.normal, theme.ACCENT, (1076, 40), anchor="midright")

    def draw_board(self, surface: pygame.Surface) -> None:
        pad = 46
        pygame.draw.rect(surface, theme.BOARD_BG, BOARD_RECT.inflate(pad * 2, pad * 2), border_radius=18)
        for a, b in self.edges:
            pygame.draw.line(surface, theme.BOARD_LINE, self.cell_px(a), self.cell_px(b), 4)
        for name in self.cells:
            r = 20 if name in BIG_CELLS else 13
            pos = self.cell_px(name)
            pygame.draw.circle(surface, theme.BOARD_BG, pos, r)
            pygame.draw.circle(surface, theme.BOARD_LINE, pos, r, 3)
            if name in BIG_CELLS:
                pygame.draw.circle(surface, theme.BOARD_LINE, pos, r - 7, 2)
            if self.show_labels:
                self._text(surface, name, self.fonts.tiny, theme.TEXT_DARK, (pos[0], pos[1] + r + 8))

    def draw_side_panels(self, surface: pygame.Surface, state: YutState) -> None:
        for side in SIDES:
            panel = SIDE_PANEL[side]
            pygame.draw.rect(surface, theme.PANEL, panel, border_radius=12)
            border = theme.ACCENT if state.current == side else theme.PANEL_LINE
            pygame.draw.rect(surface, border, panel, width=3 if state.current == side else 1, border_radius=12)
            self._text(surface, f"{theme.SIDE_NAME[side]} 말", self.fonts.normal,
                       theme.SIDE_COLOR[side], (panel.left + 16, panel.top + 20), anchor="midleft")
            for kind, label in (("wait", "wait_" + side), ("goal", "goal_" + side)):
                x = self.slot_px(label)[0] - 40
                box = pygame.Rect(x, panel.top + 46, 150, 70)
                pygame.draw.rect(surface, theme.BG, box, border_radius=8)
                pygame.draw.rect(surface, theme.PANEL_LINE, box, width=1, border_radius=8)
                self._text(surface, label, self.fonts.tiny, theme.TEXT_DIM, (box.centerx, box.bottom - 9))

    def draw_pieces(self, surface: pygame.Surface, state: YutState, highlight: Optional[str]) -> None:
        for side in SIDES:
            slots = state.pieces.get(side, [])
            by_slot: dict = {}
            for i, slot in enumerate(slots):
                by_slot.setdefault(slot, []).append(i)
            for slot, members in by_slot.items():
                if slot in self.cells:  # 판 위: 같은 칸이면 겹쳐 그려 업힌 표현
                    self._draw_stack(surface, side, slot, members, highlight)
                else:  # 대기·완주 칸: 나란히
                    for k, i in enumerate(members):
                        self._draw_piece(surface, side, i, self.slot_px(slot, k), slot == highlight)

    def _draw_stack(self, surface, side, slot, members, highlight) -> None:
        cx, cy = self.slot_px(slot)
        n = len(members)
        for k, i in enumerate(members):
            off = (k - (n - 1) / 2) * 12
            self._draw_piece(surface, side, i, (round(cx + off), round(cy + off)), False)
        if n > 1:
            self._text(surface, f"업힘 x{n}", self.fonts.small, theme.TEXT_DARK, (cx, cy - 34))
        if slot == highlight:
            pygame.draw.circle(surface, theme.HIGHLIGHT, (cx, cy), 30, 4)

    def _draw_piece(self, surface, side, index, pos, highlighted) -> None:
        pygame.draw.circle(surface, theme.TEXT_DARK, pos, 19)
        pygame.draw.circle(surface, theme.SIDE_COLOR[side], pos, 16)
        self._text(surface, str(index + 1), self.fonts.normal, theme.TEXT, pos)
        if highlighted:
            pygame.draw.circle(surface, theme.HIGHLIGHT, pos, 24, 4)

    def draw_dice_state(self, surface: pygame.Surface, state: GameState) -> None:
        """주사위 골격(차선책)은 위치 숫자만 보여 줍니다."""
        lines = [f"{theme.SIDE_NAME.get(p, p)} {pos}칸" for p, pos in state.positions.items()]
        for k, line in enumerate(lines):
            self._text(surface, line, self.fonts.huge, theme.TEXT, (BOARD_PANEL.centerx, 300 + k * 90))

    def draw_message(self, surface: pygame.Surface, message: str) -> None:
        pygame.draw.rect(surface, theme.PANEL, MESSAGE_RECT, border_radius=12)
        for k, line in enumerate(wrap(message, self.fonts.normal, MESSAGE_RECT.width - 28)[:3]):
            self._text(surface, line, self.fonts.normal, theme.TEXT,
                       (MESSAGE_RECT.left + 14, MESSAGE_RECT.top + 22 + k * 26), anchor="midleft")

    def draw_choices(self, surface: pygame.Surface, options: list[str], hover: Optional[int]) -> None:
        self._text(surface, "움직일 말을 고르세요 (버튼 또는 숫자 키)", self.fonts.small, theme.ACCENT,
                   (CHOICE_AREA.left, CHOICE_AREA.top + 10), anchor="midleft")
        for i, (rect, text) in enumerate(zip(choice_rects(len(options)), options)):
            pygame.draw.rect(surface, theme.BUTTON_HOVER if i == hover else theme.BUTTON, rect, border_radius=8)
            self._text(surface, f"{i + 1}. {text}", self.fonts.small, theme.BUTTON_TEXT,
                       (rect.left + 12, rect.centery), anchor="midleft")

    def draw_help(self, surface: pygame.Surface, message: str, hover: bool) -> None:
        shade = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 160))
        surface.blit(shade, (0, 0))
        box = pygame.Rect(0, 0, 640, 300)
        box.center = surface.get_rect().center
        pygame.draw.rect(surface, theme.PANEL, box, border_radius=16)
        pygame.draw.rect(surface, theme.HIGHLIGHT, box, width=3, border_radius=16)
        self._text(surface, "도움이 필요해요", self.fonts.large, theme.HIGHLIGHT, (box.centerx, box.top + 36))
        for k, line in enumerate(wrap(message, self.fonts.normal, box.width - 60)[:5]):
            self._text(surface, line, self.fonts.normal, theme.TEXT, (box.centerx, box.top + 90 + k * 28))
        btn = self.help_button(box)
        pygame.draw.rect(surface, theme.BUTTON_HOVER if hover else theme.BUTTON, btn, border_radius=8)
        self._text(surface, "확인 (Enter)", self.fonts.normal, theme.BUTTON_TEXT, btn.center)

    @staticmethod
    def help_button(box: Optional[pygame.Rect] = None, size=(1100, 780)) -> pygame.Rect:
        if box is None:
            box = pygame.Rect(0, 0, 640, 300)
            box.center = (size[0] // 2, size[1] // 2)
        return pygame.Rect(box.centerx - 90, box.bottom - 64, 180, 44)

    def draw_winner(self, surface: pygame.Surface, winner: str) -> None:
        shade = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 170))
        surface.blit(shade, (0, 0))
        color = theme.SIDE_COLOR.get(winner, theme.ACCENT)
        self._text(surface, "게임 끝", self.fonts.large, theme.TEXT, (surface.get_width() // 2, 300))
        self._text(surface, f"{theme.SIDE_NAME.get(winner, winner)} 승리!", self.fonts.huge, color,
                   (surface.get_width() // 2, 380))

    # ---- 글자 ----

    def _text(self, surface, text, font, color, pos, anchor="center") -> None:
        img = font.render(str(text), True, color)
        surface.blit(img, img.get_rect(**{anchor: pos}))


def option_slot(option: str) -> Optional[str]:
    """보기 문구에서 칸 이름을 뽑습니다 (예: '말1(cell_7)에 윷(4칸)' → 'cell_7')."""
    m = SLOT_RE.search(option)
    return m.group(1) if m else None
