"""화면 테마: 색, 한글 폰트, 크기. 픽셀 값은 ui 안에서만 씁니다."""
from pathlib import Path
from typing import Optional

import pygame

# ---- 색 ----
BG = (34, 30, 28)
PANEL = (52, 46, 42)
PANEL_LINE = (96, 84, 72)
BOARD_BG = (222, 190, 140)
BOARD_LINE = (110, 74, 40)
TEXT = (245, 240, 230)
TEXT_DIM = (170, 160, 148)
TEXT_DARK = (50, 36, 24)
ACCENT = (255, 214, 90)
BUTTON = (84, 110, 150)
BUTTON_HOVER = (110, 140, 190)
BUTTON_TEXT = (255, 255, 255)
HIGHLIGHT = (255, 80, 60)
SIDE_COLOR = {"robot": (214, 70, 70), "human": (64, 120, 220)}
SIDE_NAME = {"robot": "로봇", "human": "사람"}
STICK_FLAT = (240, 220, 170)
STICK_ROUND = (92, 58, 30)
STICK_MARK = (200, 40, 40)
STICK_X = (240, 220, 170)  # 둥근 면(뒤)에 그리는 X 표시

# ---- 크기 ----
WINDOW_SIZE = (1100, 780)
FPS = 60

# 한글을 지원하는 시스템 폰트 후보 (앞에서부터 탐색)
FONT_FILES = [
    r"C:\Windows\Fonts\malgun.ttf",
    r"C:\Windows\Fonts\NanumGothic.ttf",
    r"C:\Windows\Fonts\gulim.ttc",
    "/System/Library/Fonts/AppleSDGothicNeo.ttc",
    "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
]
FONT_NAMES = ["malgungothic", "nanumgothic", "applesdgothicneo", "notosanscjkkr", "notosanskr"]


def find_font_path() -> Optional[str]:
    """한글 폰트 파일 경로. 못 찾으면 None (pygame 기본 폰트, 한글이 네모로 보일 수 있음)."""
    for p in FONT_FILES:
        if Path(p).exists():
            return p
    return pygame.font.match_font(FONT_NAMES)


class Fonts:
    """크기별 폰트 모음."""

    def __init__(self) -> None:
        path = find_font_path()
        self.has_korean = path is not None

        def make(size: int) -> pygame.font.Font:
            return pygame.font.Font(path, size)

        self.tiny, self.small, self.normal = make(12), make(16), make(20)
        self.large, self.huge = make(28), make(48)
