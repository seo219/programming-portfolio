"""윷 던지기 애니메이션. 윷가락 4개가 구르다가 차례로 멈추고 결과를 보여 줍니다."""
import math

import pygame

from ui import theme

STICKS = 4
SETTLE_START = 0.45  # 전체 진행률 중 첫 가락이 멈추기 시작하는 시점
SETTLE_STEP = 0.1  # 가락마다 멈추는 간격


def flat_flags(flats: int) -> list[bool]:
    """가락별로 평평한 면이 위인지. 빽도(-1)는 표시한 첫 가락만 평평한 면(앞)입니다."""
    n = 1 if flats < 0 else max(0, min(STICKS, flats))
    return [i < n for i in range(STICKS)]


def draw_stick(surface: pygame.Surface, cx: int, cy: int, flat: bool, marked: bool,
               squash: float, length: int = 150, width: int = 34, show_x: bool = True) -> None:
    """윷가락 하나. squash(0~1)는 굴러가는 중 폭 변화를 흉내 냅니다."""
    w = max(6, int(width * squash))
    rect = pygame.Rect(0, 0, w, length)
    rect.center = (cx, cy)
    color = theme.STICK_FLAT if flat else theme.STICK_ROUND
    pygame.draw.rect(surface, color, rect, border_radius=w // 2)
    pygame.draw.rect(surface, theme.TEXT_DARK, rect, width=2, border_radius=w // 2)
    if flat:  # 평평한 면: 가로 줄무늬
        for k in range(1, 5):
            y = rect.top + k * length // 5
            pygame.draw.line(surface, (180, 150, 100), (rect.left + 4, y), (rect.right - 4, y), 1)
    elif show_x:  # 둥근 면(뒤): 작은 X를 세로로 3개 (멈춘 뒤 결과에만 표시)
        s = 5
        cx0, cy0 = rect.center
        for dy in (-length // 4, 0, length // 4):
            for a, b in (((-s, -s), (s, s)), ((-s, s), (s, -s))):
                pygame.draw.line(surface, theme.STICK_X, (cx0 + a[0], cy0 + dy + a[1]), (cx0 + b[0], cy0 + dy + b[1]), 3)
    if marked:  # 빽도 표시
        pygame.draw.circle(surface, theme.STICK_MARK, rect.center, max(4, w // 5))


def draw_throw(surface: pygame.Surface, area: pygame.Rect, progress: float, flats: int,
               name: str, fonts: "theme.Fonts") -> None:
    """progress 0~1에 맞춰 area 안에 던지기 장면을 그립니다."""
    pygame.draw.rect(surface, theme.PANEL, area, border_radius=16)
    pygame.draw.rect(surface, theme.ACCENT, area, width=3, border_radius=16)
    flags = flat_flags(flats)
    title = fonts.large.render("로봇이 윷을 던집니다", True, theme.TEXT)
    surface.blit(title, title.get_rect(midtop=(area.centerx, area.top + 18)))

    gap = area.width // (STICKS + 1)
    for i in range(STICKS):
        settle = SETTLE_START + SETTLE_STEP * i
        cx, base_y = area.left + gap * (i + 1), area.centery - 20
        if progress < settle:  # 공중에서 구르는 중
            t = progress / settle
            squash = abs(math.cos(t * math.pi * (5 + i)))
            cy = base_y - int(math.sin(t * math.pi) * 40)
            draw_stick(surface, cx, cy, flat=(squash > 0.5) == flags[i], marked=False, squash=max(0.2, squash), show_x=False)
        else:  # 바닥에 멈춤
            draw_stick(surface, cx, base_y, flags[i], marked=(flats < 0 and i == 0), squash=1.0,
                       show_x=progress >= SETTLE_START + SETTLE_STEP * (STICKS - 1))  # 결과가 나온 뒤에만 X

    if progress >= SETTLE_START + SETTLE_STEP * (STICKS - 1):
        front = "빽도(표시한 가락만 앞)" if flats < 0 else f"앞 {flats}개"
        text = fonts.huge.render(name, True, theme.ACCENT)
        surface.blit(text, text.get_rect(midbottom=(area.centerx, area.bottom - 56)))
        sub = fonts.normal.render(front, True, theme.TEXT)
        surface.blit(sub, sub.get_rect(midbottom=(area.centerx, area.bottom - 14)))
