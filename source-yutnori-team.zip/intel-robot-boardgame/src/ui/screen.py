"""게임 화면 (담당: 김민범). pygame-ce로 윷판·말·안내를 그리고 사람의 선택을 받습니다.

Screen Protocol(common.interfaces)을 구현합니다.
- update·show_throw는 그리고 바로 돌아옵니다 (게임을 막지 않음).
- ask_choice·ask_help는 사람이 응답할 때까지 이벤트 루프를 돕니다.
- 창을 닫으면 예외 없이 정리하고, 이후 호출은 화면 없이 기본값(선택 0)으로 넘어갑니다.
"""
import time
from typing import Optional

from ui import theme


class UiError(RuntimeError):
    """화면을 열 수 없을 때 (pygame 미설치, 디스플레이 없음)."""


class GameScreen:
    def __init__(self, throw_seconds: float = 3.0, show_labels: bool = True, hold_seconds: float = 1.5) -> None:
        try:
            import pygame
        except ImportError as e:
            raise UiError("pygame-ce가 설치되어 있지 않습니다. `pip install pygame-ce` 후 다시 실행하세요.") from e
        self.pg = pygame
        self.throw_seconds = throw_seconds  # 윷가락이 구르다 멈추기까지
        self.hold_seconds = hold_seconds  # 멈춘 뒤 결과를 그대로 보여 주는 시간 (클릭·키로 건너뜀)
        try:
            pygame.init()
            pygame.display.set_caption("윷놀이: 사람 vs 로봇")
            self.surface = pygame.display.set_mode(theme.WINDOW_SIZE)
            self.fonts = theme.Fonts()
        except pygame.error as e:
            pygame.quit()
            raise UiError(f"게임 창을 열 수 없습니다 (디스플레이가 없거나 pygame 오류): {e}") from e
        from ui.yut_view import YutView  # pygame이 준비된 뒤에 불러옴
        self.view = YutView(self.fonts, show_labels=show_labels)
        self.clock = pygame.time.Clock()
        self.closed = False
        self.state = None
        self.message = ""

    # ---- Screen Protocol ----

    def update(self, state, message: str = "") -> None:
        self.state, self.message = state, message
        if self.closed:
            return
        self._render()
        self.pg.display.flip()
        self._pump()

    def show_throw(self, flats: int, name: str) -> None:
        """윷가락 던지기 애니메이션(throw_seconds) 뒤 결과를 hold_seconds 동안 보여 주고 돌아옵니다.

        결과가 나온 뒤에는 마우스 클릭이나 키를 누르면 바로 넘어갑니다.
        """
        from ui import effects, yut_view
        if self.closed:
            return
        start, done_at = time.monotonic(), None
        while not self.closed:
            now = time.monotonic()
            progress = min(1.0, (now - start) / self.throw_seconds) if self.throw_seconds > 0 else 1.0
            self._render()
            effects.draw_throw(self.surface, yut_view.THROW_RECT, progress, flats, name, self.fonts)
            self.pg.display.flip()
            events = self._events()
            if progress >= 1.0:
                done_at = done_at if done_at is not None else now
                skipped = any(ev.type in (self.pg.KEYDOWN, self.pg.MOUSEBUTTONDOWN) for ev in events)
                if skipped or now - done_at >= self.hold_seconds:
                    break
            self.clock.tick(theme.FPS)

    def ask_choice(self, options: list[str]) -> int:
        """보기 버튼 클릭 또는 숫자 키(1부터)로 고른 번호를 0부터로 돌려줍니다."""
        from ui import yut_view
        if not options:
            return 0
        rects = yut_view.choice_rects(len(options))
        while not self.closed:
            hover = self._hover(rects)
            highlight = yut_view.option_slot(options[hover]) if hover is not None else None
            self._render(highlight=highlight)
            self.view.draw_choices(self.surface, options, hover)
            self.pg.display.flip()
            for ev in self._events():
                if ev.type == self.pg.KEYDOWN:
                    n = self._digit(ev.key)
                    if n is not None and 1 <= n <= len(options):
                        return n - 1
                elif ev.type == self.pg.MOUSEBUTTONDOWN and ev.button == 1:
                    for i, r in enumerate(rects):
                        if r.collidepoint(ev.pos):
                            return i
            self.clock.tick(theme.FPS)
        return 0

    def ask_help(self, message: str) -> None:
        """안내창을 띄우고 확인 버튼 또는 Enter를 누를 때까지 대기합니다."""
        from ui import yut_view
        btn = yut_view.YutView.help_button(size=theme.WINDOW_SIZE)
        while not self.closed:
            self._render()
            self.view.draw_help(self.surface, message, btn.collidepoint(self.pg.mouse.get_pos()))
            self.pg.display.flip()
            for ev in self._events():
                if ev.type == self.pg.KEYDOWN and ev.key in (self.pg.K_RETURN, self.pg.K_KP_ENTER, self.pg.K_SPACE):
                    return
                if ev.type == self.pg.MOUSEBUTTONDOWN and ev.button == 1 and btn.collidepoint(ev.pos):
                    return
            self.clock.tick(theme.FPS)

    def wait_until_closed(self) -> None:
        """게임이 끝난 뒤 결과 화면을 유지합니다. 창을 닫거나 Esc·Enter를 누르면 정리합니다."""
        while not self.closed:
            self._render()
            self.pg.display.flip()
            for ev in self._events():
                if ev.type == self.pg.KEYDOWN and ev.key in (self.pg.K_ESCAPE, self.pg.K_RETURN):
                    self.close()
            self.clock.tick(theme.FPS)

    # ---- 내부 ----

    def close(self) -> None:
        """창을 정리합니다. 여러 번 불러도 안전합니다."""
        if not self.closed:
            self.closed = True
            self.pg.quit()

    def _events(self) -> list:
        """이벤트를 가져오되, 창 닫기는 여기서 처리하고 걸러냅니다."""
        if self.closed:
            return []
        out = []
        for ev in self.pg.event.get():
            if ev.type == self.pg.QUIT:
                self.close()
                return []
            out.append(ev)
        return out

    def _pump(self) -> None:
        """update·show_throw 중에는 입력이 필요 없으니 이벤트만 비웁니다 (창이 멈춘 것처럼 보이지 않게)."""
        self._events()

    def _render(self, highlight: Optional[str] = None) -> None:
        if self.closed:
            return
        """현재 상태를 그립니다 (화면에 내보내는 flip은 호출한 쪽이 덧그린 뒤에)."""
        self.view.draw(self.surface, self.state, self.message, highlight)

    def _hover(self, rects: list) -> Optional[int]:
        pos = self.pg.mouse.get_pos()
        for i, r in enumerate(rects):
            if r.collidepoint(pos):
                return i
        return None

    def _digit(self, key: int) -> Optional[int]:
        pg = self.pg
        if pg.K_1 <= key <= pg.K_9:
            return key - pg.K_0
        if pg.K_KP1 <= key <= pg.K_KP9:
            return key - pg.K_KP1 + 1
        return None
