"""로봇 전략: 모아 둔 결과 중 어느 결과를 어느 말에 적용할지 고릅니다.

규칙서 MVP 우선순위: 잡기 → 업기 → 완주에 가장 가까운 말 전진 → 새 말 올리기.
결과가 여러 개면 모든 (말, 결과) 조합을 보고 가장 높은 우선순위를 고릅니다.
같은 우선순위라면 먼저 나온 결과를 쓰고, 빽도는 앞으로 가는 결과를 다 쓴 뒤에 씁니다.
빽도만 남으면 완주에서 가장 먼 말을 한 칸 뒤로 보냅니다.
오케스트레이터(로봇 차례)와 시뮬레이션(game/yut_reference.py의 simulate)이 같은 함수를 씁니다.
부르는 쪽은 적용할 수 있는 결과가 하나 이상 있을 때만 부릅니다 (YutGame.playable).
"""
import random
from typing import Callable

from common.interfaces import Move
from game.yut_reference import WAIT, YutGame

Strategy = Callable[[YutGame, str, list[int]], Move]


def choose_move(game: YutGame, player: str, pending: list[int]) -> Move:
    values = [v for v in dict.fromkeys(pending) if game.options(player, v)]  # 같은 값은 한 번만, 순서 유지
    tries = [(v, i, game.preview(player, i, v)) for v in values for i in game.options(player, v)]

    for reason, hit in (("capture", lambda r: r.captured),
                        ("stack", lambda r: r.stacked > len(r.moved))):
        for v, i, r in tries:
            if hit(r):
                return Move(i, v, reason)

    options = game.options(player)
    on_board = [i for i in options if game.pieces[player][i] != WAIT]
    distance = lambda i: game.board.distance(game.pieces[player][i])  # noqa: E731
    forward = [v for v in values if v > 0]
    if not forward:
        return Move(max(on_board, key=distance), values[0], "back")
    if on_board:
        return Move(min(on_board, key=distance), forward[0], "advance")
    return Move(options[0], forward[0], "enter")


def choose_random(rng: random.Random) -> Strategy:
    """시뮬레이션의 사람 쪽: 말은 무작위, 결과는 적용할 수 있는 것 중 먼저 나온 것부터."""
    def choose(game: YutGame, player: str, pending: list[int]) -> Move:
        v = next(v for v in pending if game.options(player, v))
        return Move(rng.choice(game.options(player, v)), v, "random")
    return choose
