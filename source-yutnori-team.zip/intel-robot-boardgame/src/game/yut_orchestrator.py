"""윷놀이 진행 지휘자. 하드웨어는 DeviceWrapper로, 규칙은 YutGame으로, 순서는 YutTurnMachine으로 다룹니다.

진행 방식 (11/02 결정): 사람 턴은 실제 윷을 던져 비전이 읽고, AI 턴은 UI 화면에서 윷을 시뮬레이션합니다.
말은 사람 말·로봇 말 모두 로봇팔이 옮깁니다. 사람은 화면에서 움직일 말만 고릅니다.

한 턴: 던지기 → 결과 읽기 (윷·모면 다시 던져 결과 모으기) → 말 고르기 → (잡힌 말 치우기) → 로봇 이동 → HOME
       → 비전 확인 → 이벤트 저장·중계 → 결과가 남았으면 다시 고르기, 잡았으면 한 번 더 던지기
"""
import json
import random
from pathlib import Path
from typing import Callable, Optional

from common.interfaces import Event, Move, Narrator, Screen, Store, YutState
from game.recovery import MAX_RETRY
from game.state_machine import YutTurnMachine
from game.strategy import choose_move
from game.wrapper import DeviceWrapper
from game.yut_reference import (GOAL, WAIT, MoveResult, Throw, YutBoard, YutGame, move_events, other,
                                 throw_sticks)

BOARD_CELLS_ONLY = ("cell_", "diag_", "center")  # 비전으로 확인할 수 있는 판 위 칸

# 중계 우선순위: 이동 하나에서 여러 이벤트가 나면 앞쪽 하나만 LLM에 보냅니다 (시연 PC 자원)
NARRATE_ORDER = ("win", "capture", "finish", "stack", "move", "help")


def ai_thrower(board_path: Path, rng: Optional[random.Random] = None) -> Callable[[], int]:
    """AI 턴 윷 시뮬레이션: 윷가락 4개를 config의 flat_prob로 던져 앞 개수(0~4, 빽도 -1)를 냅니다."""
    data = json.loads(Path(board_path).read_text(encoding="utf-8"))
    prob, backdo = data["ai_throw"]["flat_prob"], data["backdo"]
    rng = rng or random.Random()
    return lambda: throw_sticks(rng, prob, backdo)


def slot(player: str, pos: str) -> str:
    """규칙 엔진 위치 → 슬롯 이름 (대기·완주는 편마다 따로)."""
    if pos == WAIT:
        return f"wait_{player}"
    if pos == GOAL:
        return f"goal_{player}"
    return pos


class YutOrchestrator:
    def __init__(self, board: YutBoard, dev: DeviceWrapper, narrator: Narrator, store: Store,
                 screen: Screen, ai_throw: Callable[[], int], verify_moves: bool = True,
                 robot_strategy: Callable[[YutGame, str, list[int]], Move] = choose_move,
                 max_turns: int = 500):
        self.board, self.dev = board, dev
        self.narrator, self.store, self.screen = narrator, store, screen
        self.ai_throw = ai_throw  # AI 턴 윷 앞 개수를 내는 함수 (ai_thrower 또는 테스트용 고정값)
        self.verify_moves = verify_moves
        self.robot_strategy = robot_strategy
        self.max_turns = max_turns
        self.game = YutGame(board)
        self.state = YutState(pieces=self._slots())
        self.sm = YutTurnMachine()

    # ---- 게임 ----

    def run(self) -> str:
        self.dev.home()
        self._show("게임 시작")
        while self.state.winner is None:
            if self.state.turn > self.max_turns:
                raise RuntimeError(f"{self.max_turns}턴 안에 끝나지 않았습니다")
            self.play_turn()
        return self.state.winner

    def play_turn(self) -> None:
        player = self.state.current
        pending: list[Throw] = []
        self._throw_until_stop(player, pending)

        while pending:
            if not self.game.playable(player, [t.value for t in pending]):
                names = ", ".join(t.name for t in pending)
                pending.clear()
                self.state.pending = []
                self._show(f"{player}: 판 위에 말이 없어 {names} 무효")
                break
            self.sm.choose()
            move = self._choose(player, pending)
            throw = next(t for t in pending if t.value == move.value)
            pending.remove(throw)
            self.state.pending = [t.value for t in pending]

            result = self._apply(player, move, throw)
            self.sm.resolve()

            if self.state.winner:
                self.sm.finish()
                return
            if result.captured and self.board.again_on_capture:
                self._throw_until_stop(player, pending)  # resolving → throwing

        self.sm.next_turn()
        self.state.current = other(player)
        self.state.turn += 1
        self.state.pending = []
        self._show(f"{self.state.current} 차례")

    # ---- 던지기·인식 ----

    def _throw_until_stop(self, player: str, pending: list[Throw]) -> None:
        while True:
            t = self.board.throw(self._throw_and_read(player))
            pending.append(t)
            self.state.pending = [p.value for p in pending]
            self._record(Event(self.state.turn, player, "throw",
                               {"yut": t.name, "value": t.value, "again": t.again}), narrate=False)
            self._show(f"{player}: {t.name}" + (" · 한 번 더!" if t.again else ""))
            if not t.again:
                return

    def _throw_and_read(self, player: str) -> int:
        """앞 개수(0~4, 빽도 -1).

        AI 턴: UI가 시뮬레이션한 결과를 그대로 씁니다 (실패 없음).
        사람 턴: 실제 윷을 비전이 읽습니다. 인식 실패(낙 포함)는 다시 던지게 하고,
        MAX_RETRY번 넘게 실패하면 사람에게 입력받습니다.
        """
        if player == "robot":
            self.sm.throw()
            flats = self.ai_throw()
            self.screen.show_throw(flats, self.board.throw(flats).name)  # UI 윷 던지기 장면
            self.sm.read()
            return flats

        for attempt in range(MAX_RETRY + 1):
            self.sm.throw()
            self._show("윷을 던져 주세요" if attempt == 0 else "다시 던져 주세요 (인식 실패)")
            self.sm.read()
            flats = self.dev.read()
            if flats is not None:
                return flats
        flats = self.dev.manual_flats("윷 인식 실패: 앞 개수를 입력해 주세요 (빽도는 -1)")
        self._record(Event(self.state.turn, player, "help", {"message": "윷 인식 실패"}), narrate=False)
        return flats

    # ---- 말 고르기·이동 ----

    def _choose(self, player: str, pending: list[Throw]) -> Move:
        values = [t.value for t in pending]
        if player == "robot":
            move = self.robot_strategy(self.game, player, values)
            self._record(Event(self.state.turn, player, "decision",
                               {"piece": move.piece + 1, "reason": move.reason}), narrate=False)
            return move

        choices = [(i, t) for t in dict((t.value, t) for t in pending).values()
                   for i in self.game.options(player, t.value)]
        labels = [f"말{i + 1}({slot(player, self.game.pieces[player][i])})에 {t.name}({t.value}칸)"
                  for i, t in choices]
        k = self.screen.ask_choice(labels)
        i, t = choices[k if 0 <= k < len(choices) else 0]
        return Move(i, t.value, "human")

    def _apply(self, player: str, move: Move, throw: Throw) -> MoveResult:
        src_pos = self.game.pieces[player][move.piece]
        r = self.game.move(player, move.piece, move.value)
        src, dst = slot(player, src_pos), slot(player, r.dst)
        self.sm.move()

        # 말은 어느 편이든 로봇팔이 옮깁니다. 잡힌 말을 먼저 상대 대기 칸으로 치운 뒤 내 말을 옮깁니다
        if r.captured:
            loser = other(player)
            if not self.dev.move(dst, slot(loser, WAIT)):
                self._help(player, f"{dst}의 {loser} 말을 {slot(loser, WAIT)}로 옮겨 주세요")

        moved = self.dev.move(src, dst)
        self.sm.check()
        if moved:
            self._verify(player, src, dst)
        else:  # 재시도까지 실패: 사람이 옮겼으므로 다시 확인·재이동하지 않습니다
            self._help(player, f"{src}의 말을 {dst}로 옮겨 주세요")

        self.state.pieces = self._slots()
        self.state.winner = self.game.winner()
        self._record_move(player, move, throw, r, src)
        return r

    def _verify(self, player: str, src: str, dst: str) -> None:
        """비전으로 판 전체를 기대 상태와 비교. 옮긴 칸이 틀리면 MAX_RETRY번 다시 옮기고, 그래도 다르면 사람에게."""
        if not self.verify_moves:
            return
        diff = self._board_diff()
        for _ in range(MAX_RETRY):
            if not diff or dst not in diff:  # 옮긴 칸은 맞고 다른 칸이 다르면 다시 옮겨도 소용없음
                break
            self.sm.retry()
            self.dev.move(src, dst)
            self.sm.check()
            diff = self._board_diff()
        if diff:
            self._help(player, "판 확인이 필요합니다: " + ", ".join(
                f"{cell} (기대 {want or '빈 칸'}, 보임 {seen or '빈 칸'})" for cell, (want, seen) in diff.items()))

    def _expected_board(self) -> dict[str, str]:
        """게임 상태로 본 판 위 칸 → 편 (대기·완주 칸은 비전이 읽지 않으므로 뺌)."""
        return {pos: p for p in ("human", "robot") for pos in self.game.pieces[p]
                if pos.startswith(BOARD_CELLS_ONLY)}

    def _board_diff(self) -> dict[str, tuple[Optional[str], Optional[str]]]:
        """기대와 다른 칸 → (기대, 보임). 비전이 적지 않은 칸은 빈 칸으로 봅니다."""
        want = self._expected_board()
        seen = {c: p for c, p in self.dev.board().items() if c.startswith(BOARD_CELLS_ONLY)}
        return {c: (want.get(c), seen.get(c)) for c in sorted(set(want) | set(seen))
                if want.get(c) != seen.get(c)}

    # ---- 기록·화면 ----

    def _record_move(self, player: str, move: Move, throw: Throw, r: MoveResult, src: str) -> None:
        events = move_events(self.state.turn, player, move.piece, throw, r, src, self.game)
        for e in events:
            self.store.save(e)
        key = min(events, key=lambda e: NARRATE_ORDER.index(e.kind))
        # 중계기가 판세·위기를 계산하도록 판 상태 복사본과 로봇의 이유를 함께 넘깁니다 (docs/interfaces.md 1절)
        context = {"pieces": {p: list(v) for p, v in self.game.pieces.items()}}
        if player == "robot":
            context["reason"] = move.reason
        self._show(self._narrate(key, context))

    def _record(self, event: Event, narrate: bool = True) -> None:
        self.store.save(event)
        if narrate:
            self._show(self._narrate(event))

    def _narrate(self, event: Event, context: Optional[dict] = None) -> str:
        # 로봇이 움직이는 중에는 LLM을 부르지 않습니다 (AGENTS.md 설계 규칙 4)
        if self.dev.arm_out:
            raise RuntimeError("로봇이 HOME 밖에 있을 때 narrate()를 부를 수 없습니다")
        return self.narrator.narrate(event, context)

    def _help(self, player: str, message: str) -> None:
        self.store.save(Event(self.state.turn, player, "help", {"message": message}))
        self.screen.ask_help(message)

    def _show(self, message: str = "") -> None:
        self.screen.update(self.state, message)

    def _slots(self) -> dict:
        return {p: [slot(p, pos) for pos in self.game.pieces[p]] for p in ("human", "robot")}


__all__ = ["YutOrchestrator", "slot"]
