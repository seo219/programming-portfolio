"""비전·로봇 래퍼: 오케스트레이터는 하드웨어를 직접 부르지 않고 이 클래스를 거칩니다.

진행 방식 (11/02 결정)
- 사람 턴: 사람이 실제 윷을 던지고 비전이 읽습니다 (read).
- AI 턴: 윷은 UI 화면에서 시뮬레이션합니다. 로봇은 윷을 던지지 않습니다.
- 말 이동: 사람 말·로봇 말·잡힌 말 치우기·완주 모두 로봇팔이 옮깁니다 (move).

이 래퍼가 맡는 것
- 순서 규칙: 로봇이 움직이면 곧바로 home()을 부르고, 팔이 나가 있는 동안에는 비전 호출을 막습니다
  (AGENTS.md 설계 규칙 3). 오케스트레이터는 `arm_out`을 보고 로봇이 움직이는 중에 LLM을 부르지 않습니다(규칙 4).
- 재시도: 로봇 동작이 False를 돌려주면 최대 MAX_RETRY번 다시 시킵니다 (game/recovery.py).
- 기록: 모든 하드웨어 호출을 `log`에 남깁니다. 테스트가 호출 순서를 검사하고, 시연 중 문제를 되짚을 때 씁니다.

이 래퍼가 맡지 않는 것
- 인식 실패 시 다시 던지게 하기, 이동 확인 실패 시 다시 옮기기는 턴 상태가 바뀌는 일이라
  오케스트레이터(game/yut_orchestrator.py)가 상태 머신과 함께 처리합니다.

---- vision 담당(정성욱)에게: 실제 모듈을 붙일 때 ----
`src/vision/`의 클래스가 아래 두 함수를 가지면 그대로 꽂힙니다 (common/interfaces.py `Vision`).
- read_yut() -> YutResult            ※ 사람 턴에만 불립니다
    flats: 평평한 면이 위인 윷가락 수 0~4. 4개가 다 안 보이거나(낙 포함) 애매하면 None.
        표시한 가락 하나만 앞이면 빽도로 -1 (config/yut_board.json "backdo").
    value: config/yut_board.json "yut" 표로 바꾼 칸 수. 게임은 flats만 보므로 표시용입니다.
    confidence: 0~1. 게임은 아직 쓰지 않지만 로그·DB에 남길 수 있게 채워 주세요.
- piece_at(cell) -> "robot" | "human" | None   ※ 칸 하나만 볼 때 (단독 확인용)
    cell은 슬롯 이름("cell_3", "diag_r1", "center" 등). 업힌 말도 그 칸의 편만 알려 주면 됩니다.
- board_state() -> {"cell_3": "robot", ...}   ※ 로봇이 말을 옮길 때마다 판 전체를 기대 상태와 비교합니다 (어느 편 말이든)
    키는 게임 칸 이름(cell_0~19, diag_r1~r4, diag_l1~l4, center). 적지 않은 칸과 None은 빈 칸으로 봅니다.
    비전 초안의 cell_20~28은 robot/slots.py의 SLOT_ALIASES 대응대로 바꿔서 돌려줍니다.
- 호출 시점에는 팔이 항상 HOME에 있습니다. 비전 쪽에서 로봇을 부르거나 기다릴 필요가 없습니다.
- 하드웨어 없이 단독 확인:
      from common.mock import MockRobot, ConsoleScreen
      dev = DeviceWrapper(VisionDetector(...), MockRobot(), ConsoleScreen())
      print(dev.read(), dev.board())

---- robot 담당(신이서)에게: 실제 모듈을 붙일 때 ----
`src/robot/`의 클래스가 아래 두 함수를 가지면 그대로 꽂힙니다 (common/interfaces.py `Robot`).
- home() -> None: HOME 자세로 복귀. 이미 HOME이어도 안전하게 여러 번 불릴 수 있어야 합니다.
- move(src, dst) -> bool: src 칸의 말을 dst 칸으로. 업힌 말(끼운 말)도 한 번에 집습니다. 실패면 False.
    사람 말과 로봇 말을 모두 옮깁니다. src/dst에는 판 위 칸 외에
    wait_robot, wait_human(대기), goal_robot, goal_human(완주)도 옵니다.
    잡기: 먼저 move(그 칸, 상대 대기 칸)으로 잡힌 말을 치우고, 이어서 move(출발, 그 칸)을 부릅니다.
- 윷 던지기(throw_yut)는 쓰지 않습니다. AI 턴의 윷은 UI가 시뮬레이션합니다.
- 함수 안에서 home()을 부르지 않아도 됩니다. 래퍼가 동작마다 home()을 부릅니다.
- 관절 값·픽셀 좌표는 robot 모듈 밖으로 내보내지 않습니다 (config/poses.json 안에서만).
- 하드웨어 없이 흐름만 확인할 때는 common/mock.py의 MockRobot·ScriptedRobot을 씁니다.
  실제 팔로 단독 확인은 사람이 지켜보며 실행합니다:
      dev = DeviceWrapper(MockVision(), RobotController(...), ConsoleScreen())
      dev.move("wait_robot", "cell_1"); dev.move("cell_1", "wait_robot")
"""
from typing import Callable, Optional

from common.interfaces import Robot, Screen, Vision
from game.recovery import MAX_RETRY, with_retry


def ask_flats_keyboard() -> int:
    """인식이 끝내 실패했을 때 사람이 앞 개수를 입력합니다 (0~4, 빽도 -1)."""
    while True:
        try:
            raw = input("윷 앞 개수 (0~4, 빽도 -1): ").strip()
        except EOFError:
            return 1  # 입력이 끝난 mock 실행: 도로 진행
        if raw in {"-1", "0", "1", "2", "3", "4"}:
            return int(raw)


FLATS_CHOICES = [("도 · 앞 1개", 1), ("개 · 앞 2개", 2), ("걸 · 앞 3개", 3),
                 ("윷 · 앞 4개", 4), ("모 · 앞 0개", 0), ("빽도 · 표시한 가락만 앞", -1)]


def ask_flats_on_screen(screen: Screen) -> Callable[[], int]:
    """인식이 끝내 실패했을 때 화면 버튼(ask_choice)으로 결과를 고르게 하는 입력 함수."""
    def ask() -> int:
        k = screen.ask_choice([label for label, _ in FLATS_CHOICES])
        return FLATS_CHOICES[k if 0 <= k < len(FLATS_CHOICES) else 0][1]
    return ask


class DeviceWrapper:
    def __init__(self, vision: Vision, robot: Robot, screen: Screen,
                 ask_flats: Callable[[], int] = ask_flats_keyboard):
        self.vision, self.robot, self.screen = vision, robot, screen
        self.ask_flats = ask_flats  # 테스트에서는 정해 둔 값을 돌려주는 함수로 바꿉니다
        self.arm_out = False  # 로봇 팔이 HOME 밖에 있으면 True
        self.log: list[str] = []
        self._last_ok = False

    # ---- 로봇 ----

    def home(self) -> None:
        self.log.append("home")
        self.robot.home()
        self.arm_out = False

    def move(self, src: str, dst: str) -> bool:
        """로봇팔로 말 옮기기 (어느 편 말이든). 실패하면 재시도하고, 마지막에 항상 HOME으로."""
        def attempt() -> None:
            self.arm_out = True
            self.log.append(f"move {src} {dst}")
            self._last_ok = bool(self.robot.move(src, dst))

        ok = with_retry(attempt, lambda: self._last_ok)
        self.home()
        return ok

    # ---- 비전 (팔이 HOME일 때만) ----

    def read(self) -> Optional[int]:
        """윷 앞 개수 0~4(빽도 -1), 인식 실패면 None."""
        self._require_home("read_yut")
        result = self.vision.read_yut()
        self.log.append(f"read {result.flats}")
        return result.flats

    def check(self, player: str, cell: str) -> bool:
        """cell에 player의 말이 보이는지."""
        self._require_home("piece_at")
        seen = self.vision.piece_at(cell)
        self.log.append(f"check {cell} {seen}")
        return seen == player

    def board(self) -> dict[str, Optional[str]]:
        """판 위 칸 전체의 편 (빈 칸은 None이거나 빠짐)."""
        self._require_home("board_state")
        seen = self.vision.board_state()
        self.log.append(f"board {len([c for c, p in seen.items() if p])}")
        return seen

    def _require_home(self, name: str) -> None:
        if self.arm_out:
            raise RuntimeError(f"로봇 팔이 HOME 밖에 있어 {name}()을 부를 수 없습니다 (home() 먼저)")

    # ---- 사람 도움 ----

    def manual_flats(self, reason: str) -> int:
        self.screen.ask_help(reason)
        flats = self.ask_flats()
        self.log.append(f"manual {flats}")
        return flats


__all__ = ["DeviceWrapper", "MAX_RETRY", "ask_flats_keyboard", "ask_flats_on_screen"]
