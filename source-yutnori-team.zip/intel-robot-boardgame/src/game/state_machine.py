"""한 턴의 상태 흐름. 잘못된 순서의 호출은 transitions가 예외(MachineError)로 막습니다."""
from transitions import Machine

# ---- 윷놀이 ----
#
#  idle ─throw→ throwing ─read→ reading ─┬─throw→ throwing   (윷·모·낙: 다시 던짐)
#                                        ├─next_turn→ idle   (판 위에 말이 없어 빽도 무효)
#                                        └─choose→ choosing ─move→ moving ─check→ checking
#  checking ─retry→ moving                 (이동 확인 실패: 다시 옮김)
#  checking ─resolve→ resolving ─┬─choose→ choosing   (모아 둔 결과가 남음)
#                                ├─throw→ throwing    (잡아서 한 번 더)
#                                ├─next_turn→ idle
#                                └─finish→ end
YUT_STATES = ["idle", "throwing", "reading", "choosing", "moving", "checking", "resolving", "end"]

YUT_TRANSITIONS = [
    {"trigger": "throw", "source": ["idle", "reading", "resolving"], "dest": "throwing"},
    {"trigger": "read", "source": "throwing", "dest": "reading"},
    {"trigger": "choose", "source": ["reading", "resolving"], "dest": "choosing"},
    {"trigger": "move", "source": "choosing", "dest": "moving"},
    {"trigger": "check", "source": "moving", "dest": "checking"},
    {"trigger": "retry", "source": "checking", "dest": "moving"},
    {"trigger": "resolve", "source": "checking", "dest": "resolving"},
    {"trigger": "next_turn", "source": ["reading", "resolving"], "dest": "idle"},
    {"trigger": "finish", "source": "resolving", "dest": "end"},
]


class YutTurnMachine:
    """윷놀이 한 턴. 오케스트레이터가 단계마다 trigger를 불러 순서를 검증합니다."""

    def __init__(self):
        Machine(model=self, states=YUT_STATES, transitions=YUT_TRANSITIONS, initial="idle")


# ---- 주사위 게임 (차선책) ----

STATES = ["idle", "rolling", "reading", "moving", "checking", "event", "end"]

TRANSITIONS = [
    {"trigger": "roll", "source": "idle", "dest": "rolling"},
    {"trigger": "read", "source": "rolling", "dest": "reading"},
    {"trigger": "reroll", "source": "reading", "dest": "rolling"},
    {"trigger": "move", "source": "reading", "dest": "moving"},
    {"trigger": "check", "source": "moving", "dest": "checking"},
    {"trigger": "retry", "source": "checking", "dest": "moving"},
    {"trigger": "do_event", "source": "checking", "dest": "event"},
    {"trigger": "next_turn", "source": "event", "dest": "idle"},
    {"trigger": "finish", "source": "event", "dest": "end"},
]


class TurnMachine:
    def __init__(self):
        Machine(model=self, states=STATES, transitions=TRANSITIONS, initial="idle")
