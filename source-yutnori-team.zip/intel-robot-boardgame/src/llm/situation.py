"""중계에 덧붙일 판 상황 (담당: 김관영). 계산은 코드가 하고 LLM은 말로 바꾸기만 합니다.

오케스트레이터가 narrate(event, context)로 넘긴 context에서 판세·위기·로봇의 생각을 뽑습니다.
- context["pieces"]: 규칙 엔진 위치 복사본 {"human": ["wait", "cell_3"], "robot": [...]} (대기 "wait", 완주 "goal")
- context["reason"]: 로봇이 이번 말을 고른 이유 (game/strategy.py의 Move.reason, 로봇 이동에만)
규칙 엔진은 복사한 판에서 preview()·distance()만 써서 실제 게임 상태를 바꾸지 않습니다.
한 번에 덧붙이는 상황은 하나뿐입니다 (역전 > 위기 > 로봇의 생각 > 판세). 중계 문장을 짧게 두기 위해서입니다.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from common.interfaces import Event
from game.yut_reference import GOAL, YutBoard, YutGame, other
from llm.templates import REASON_TEXT, player_name

BOARD_PATH = Path(__file__).resolve().parents[2] / "config" / "yut_board.json"
NOTE_KINDS = {"move", "capture", "stack", "finish"}  # 상황을 덧붙이는 이벤트 (승리·도움 요청은 장면만)
STANDING_KINDS = {"capture", "finish"}  # 판세는 판이 크게 바뀐 이벤트에서만
LEAD_MIN = 3  # 역전으로 볼 직전 차이 (칸). 초반에 한두 칸씩 앞서거니 뒤서거니 하는 것은 역전으로 치지 않음


@dataclass
class Note:
    kind: str  # lead_change | danger | reason | standing
    facts: str  # LLM 프롬프트에 덧붙이는 사실
    text: str  # LLM이 실패했을 때 템플릿 뒤에 붙이는 문장


def load_board(path: Path = BOARD_PATH) -> Optional[YutBoard]:
    try:
        return YutBoard(path)
    except (OSError, ValueError, KeyError):
        return None


def standing(board: YutBoard, pieces: dict) -> dict:
    """편마다 완주한 말 수와 완주까지 남은 거리 합."""
    return {p: {"finished": sum(pos == GOAL for pos in pieces[p]),
                "remaining": sum(board.distance(pos) for pos in pieces[p])}
            for p in ("human", "robot")}


def leader(stand: dict) -> Optional[str]:
    """남은 거리가 적은 편. 같으면 None."""
    h, r = stand["human"]["remaining"], stand["robot"]["remaining"]
    return None if h == r else ("human" if h < r else "robot")


def danger(board: YutBoard, pieces: dict, victim: str) -> list[str]:
    """상대가 던지면 victim의 판 위 말을 잡을 수 있는 윷 이름 (도·개·걸 …, 칸 수 순)."""
    hunter = other(victim)
    game = YutGame(board, {p: list(v) for p, v in pieces.items()})
    names = []
    for t in sorted({t.value: t for t in board.yut.values()}.values(), key=lambda t: t.value):
        if t.value < 0 and not board.backdo:
            continue
        if any(game.preview(hunter, i, t.value).captured for i in game.options(hunter, t.value)):
            names.append(t.name)
    return names


class Situation:
    """경기 중 상황을 고릅니다. 역전을 알아채려고 직전 판세를, 반복을 피하려고 직전에 말한 상황을 기억합니다."""

    def __init__(self, board: Optional[YutBoard]):
        self.board = board
        self.last_gap = 0  # 직전 판세: 로봇 남은 거리 - 사람 남은 거리 (양수면 사람이 앞섬)
        self.last_kind = ""  # 직전에 덧붙인 상황 종류

    def note(self, event: Event, context: Optional[dict]) -> Optional[Note]:
        if self.board is None or not context or "pieces" not in context:
            return None
        pieces = context["pieces"]
        stand = standing(self.board, pieces)
        gap = stand["robot"]["remaining"] - stand["human"]["remaining"]
        before, self.last_gap = self.last_gap, gap
        if event.kind not in NOTE_KINDS:
            return None

        who = event.player
        ahead = gap > 0 if who == "human" else gap < 0
        was_behind = before <= -LEAD_MIN if who == "human" else before >= LEAD_MIN
        candidates = []
        if ahead and was_behind:
            candidates.append(self._lead_change(who, stand))
        names = danger(self.board, pieces, who)
        if names:
            candidates.append(self._danger(who, names))
        reason = context.get("reason")
        if who == "robot" and reason in REASON_TEXT:
            candidates.append(self._reason(reason))
        lead = leader(stand)
        if event.kind in STANDING_KINDS and lead is not None:
            candidates.append(self._standing(lead, stand))

        # 역전은 늘 말하고, 나머지는 직전과 같은 종류를 건너뜁니다 (매 턴 같은 말 반복 방지)
        note = next((n for n in candidates if n.kind == "lead_change" or n.kind != self.last_kind), None)
        self.last_kind = note.kind if note else ""
        return note

    @staticmethod
    def _lead_change(who: str, stand: dict) -> Note:
        gap = stand[other(who)]["remaining"] - stand[who]["remaining"]
        name = player_name(who)
        return Note("lead_change", f"[상황] 역전: 이번 이동으로 {name}이 완주까지 남은 거리에서 {gap}칸 앞서게 됨.",
                    f"역전입니다! {name}이 {gap}칸 앞서 나갑니다!")

    @staticmethod
    def _danger(who: str, names: list[str]) -> Note:
        name, rival = player_name(who), player_name(other(who))
        yuts = f"'{names[0]}'만" if len(names) == 1 else "·".join(f"'{n}'" for n in names) + " 중 하나만"
        return Note("danger", f"[상황] 위기: {rival}이 {yuts} 던져도 {name}의 말을 잡을 수 있음.",
                    f"그런데 {rival}이 {names[0]}만 나와도 {name} 말이 잡혀요!")

    @staticmethod
    def _reason(reason: str) -> Note:
        # 중계기는 text를 LLM 문장 뒤에 그대로 붙입니다 (LLM에 맡기면 3인칭으로 바뀜, llm/narrator.py)
        said = f"저는 {REASON_TEXT[reason]} 이 말을 골랐어요"
        return Note("reason", f"[상황] 로봇의 속마음: {said}.", f"로봇: {said}!")

    @staticmethod
    def _standing(lead: str, stand: dict) -> Note:
        h, r = stand["human"], stand["robot"]
        gap = abs(h["remaining"] - r["remaining"])
        name = player_name(lead)
        return Note("standing",
                    f"[상황] 판세: 완주까지 남은 거리 사람 {h['remaining']}칸, 로봇 {r['remaining']}칸. "
                    f"{name}이 {gap}칸 앞섬.",
                    f"지금은 {name}이 {gap}칸 앞서 있습니다.")
