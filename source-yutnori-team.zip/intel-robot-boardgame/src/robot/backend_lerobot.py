"""LeRobot SO-101 백엔드 (담당: 신이서). Backend 인터페이스를 LeRobot 0.6.1의 SO101Follower로 구현합니다.

LeRobot의 send_action()은 목표만 보내고 도착을 기다리지 않으므로, 이 모듈이 목표까지 조금씩 보내며
도착(허용 오차 안)을 확인합니다. 도착하지 못하면 BackendError입니다.
- 각도는 도(degree), 그리퍼는 0~100 (LeRobot 기본 설정 use_degrees=True).
- 연결할 때 보정(calibration)이 안 맞으면 LeRobot은 input()으로 멈추므로 calibrate=False로 연결하고,
  보정이 안 맞으면 BackendError를 냅니다. 보정은 lerobot-calibrate로 따로 합니다.
- lerobot은 연결할 때만 불러옵니다 (lerobot이 없는 PC에서도 이 모듈을 import하고 테스트할 수 있게).
"""
import math
import time
from pathlib import Path
from typing import Optional

from .backend import BackendError
from .config import ARM_JOINTS, require

ARM = ("shoulder_pan", "shoulder_lift", "elbow_flex", "wrist_flex", "wrist_roll")
assert len(ARM) == ARM_JOINTS

# robot.json의 motion 값이 null일 때 쓰는 시작값. 시험으로 맞춘 값이 아닙니다 (실제 로봇에서 조정할 것)
DEFAULT_TOLERANCE_DEG = 2.0
DEFAULT_TIMEOUT_S = 10.0
DEFAULT_GRIPPER_SETTLE_S = 0.6
DEFAULT_RATE_HZ = 30.0
DEFAULT_SPEED_DPS = 30.0


class LeRobotBackend:
    def __init__(self, robot, *, tolerance_deg: float = DEFAULT_TOLERANCE_DEG, timeout_s: float = DEFAULT_TIMEOUT_S,
                 gripper_settle_s: float = DEFAULT_GRIPPER_SETTLE_S, rate_hz: float = DEFAULT_RATE_HZ,
                 default_speed: float = DEFAULT_SPEED_DPS, sleep=time.sleep, clock=time.monotonic):
        """robot: get_observation()/send_action()/disconnect()를 가진 연결된 SO101Follower (테스트에서는 가짜)."""
        self.robot = robot
        self.tolerance, self.timeout, self.gripper_settle = tolerance_deg, timeout_s, gripper_settle_s
        self.rate, self.default_speed = rate_hz, default_speed
        self._sleep, self._clock = sleep, clock

    @classmethod
    def from_config(cls, cfg: dict) -> "LeRobotBackend":
        """config/robot.json(load_robot_config 결과)로 SO101Follower를 연결해 백엔드를 만듭니다."""
        f = cfg.get("follower", {})
        port, robot_id = require(f.get("port"), "follower.port"), require(f.get("id"), "follower.id")  # 비었으면 lerobot을 불러오기 전에 알림
        from lerobot.robots.so_follower import SO101Follower, SO101FollowerConfig  # 늦게 불러옴
        calib = f.get("calibration_dir")
        robot = SO101Follower(SO101FollowerConfig(port=port, id=robot_id, max_relative_target=f.get("max_relative_target"),
                                                  calibration_dir=Path(calib) if calib else None))
        try:
            robot.connect(calibrate=False)  # 보정이 안 맞아도 input()으로 멈추지 않음
        except Exception as e:
            raise BackendError(f"로봇 연결 실패 ({port}): {e}") from e
        if not robot.is_calibrated:
            robot.disconnect()
            raise BackendError(f"보정이 맞지 않습니다 (id={robot_id}, 보정 파일: {robot.calibration_fpath}). lerobot-calibrate를 먼저 하세요")
        m = cfg.get("motion", {})
        return cls(robot,
                   tolerance_deg=m.get("tolerance_deg") or DEFAULT_TOLERANCE_DEG, timeout_s=m.get("timeout_s") or DEFAULT_TIMEOUT_S,
                   gripper_settle_s=m.get("gripper_settle_s") or DEFAULT_GRIPPER_SETTLE_S, rate_hz=m.get("rate_hz") or DEFAULT_RATE_HZ,
                   default_speed=(cfg.get("speed", {}).get("travel") or DEFAULT_SPEED_DPS))

    # ---- Backend 인터페이스 ----

    def move_to(self, joints: tuple, speed: Optional[float] = None) -> None:
        goal = tuple(float(j) for j in joints)
        if len(goal) != ARM_JOINTS:
            raise ValueError(f"팔 관절 {ARM_JOINTS}개가 필요합니다: {joints!r}")
        speed = speed or self.default_speed
        try:
            start = self._present()
            steps = max(1, math.ceil(max(abs(g - s) for g, s in zip(goal, start)) / speed * self.rate))
            for i in range(1, steps + 1):  # 가장 먼 관절이 speed(도/초)로 움직이도록 직선 보간
                self._send({f"{n}.pos": s + (g - s) * i / steps for n, s, g in zip(ARM, start, goal)})
                self._sleep(1.0 / self.rate)
            deadline = self._clock() + self.timeout
            while True:  # 도착 확인
                err = max(abs(p - g) for p, g in zip(self._present(), goal))
                if err <= self.tolerance:
                    return
                if self._clock() > deadline:
                    raise BackendError(f"목표에 도달하지 못했습니다 (남은 오차 {err:.1f}도, 제한 {self.timeout}초)")
                self._send({f"{n}.pos": g for n, g in zip(ARM, goal)})
                self._sleep(1.0 / self.rate)
        except BackendError:
            raise
        except Exception as e:
            raise BackendError(f"로봇 이동 중 오류: {e}") from e

    def set_gripper(self, value: float) -> None:
        if not 0.0 <= value <= 100.0:
            raise ValueError(f"그리퍼 값은 0~100이어야 합니다: {value}")
        try:
            self._send({"gripper.pos": float(value)})
            self._sleep(self.gripper_settle)  # 말을 잡으면 목표까지 못 닫히므로 도착을 확인하지 않고 잠시 기다림
        except Exception as e:
            raise BackendError(f"그리퍼 동작 오류: {e}") from e

    def gripper_position(self) -> float:
        """그리퍼의 현재 위치(0~100, 클수록 열림). 말을 잡았는지 확인하는 데 씁니다."""
        try:
            return float(self.robot.get_observation()["gripper.pos"])
        except Exception as e:
            raise BackendError(f"그리퍼 위치를 읽지 못했습니다: {e}") from e

    def disconnect(self) -> None:
        self.robot.disconnect()

    # ---- 내부 ----

    def _present(self) -> tuple:
        obs = self.robot.get_observation()
        return tuple(float(obs[f"{n}.pos"]) for n in ARM)

    def _send(self, action: dict) -> None:
        self.robot.send_action(action)
