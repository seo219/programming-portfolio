"""집기·놓기 방식 (담당: 신이서). 컨트롤러는 칸 위 접근까지 하고, 칸 위에서 말을 집고 놓는 일은 Grasper가 합니다.

- pick: 시작은 출발 칸의 above 자세, 끝은 말을 든 채 같은 above 자세.
- place: 시작은 말을 든 채 도착 칸의 above 자세, 끝은 말을 놓고 같은 above 자세.
- level: 집는/놓는 말 아래에 쌓인 말 수 (높이 보정에 씀).
ScriptGrasper는 측정한 grasp 자세로 내려가는 방식(MVP). ACT 정책은 pick만 바꿔 끼웁니다 (6단계).
"""
from typing import Optional, Protocol

from .backend import Backend, BackendError
from .config import ARM_JOINTS, PoseNotMeasured, RobotSettings, SlotPose, require


def arm_pose(joints: tuple, level: int = 0, delta: Optional[tuple] = None) -> tuple:
    """관절 자세에서 팔 관절 5개만 꺼내고, 아래에 말이 level개 쌓였으면 delta x level만큼 올립니다."""
    arm = tuple(joints[:ARM_JOINTS])
    if level == 0:
        return arm
    delta = require(delta, "stack.level_delta")
    return tuple(a + level * d for a, d in zip(arm, delta))


class Grasper(Protocol):
    def preflight(self, pose: SlotPose, level: int) -> None:
        """움직이기 전에 필요한 자세·설정이 있는지 확인. 없으면 PoseNotMeasured/ConfigNotSet."""
        ...

    def pick(self, backend: Backend, pose: SlotPose, level: int, carry_speed: Optional[float]) -> None: ...

    def place(self, backend: Backend, pose: SlotPose, level: int) -> None: ...


class ScriptGrasper:
    def __init__(self, settings: RobotSettings):
        self.s = settings

    def preflight(self, pose: SlotPose, level: int) -> None:
        if pose.grasp is None:
            raise PoseNotMeasured("grasp 자세가 없습니다 (config/poses.json)")
        require(self.s.gripper_open, "gripper.open")
        require(self.s.gripper_close, "gripper.close")
        arm_pose(pose.grasp, level, self.s.level_delta)  # level_delta 필요 여부 확인

    def pick(self, backend: Backend, pose: SlotPose, level: int, carry_speed: Optional[float]) -> None:
        s = self.s
        backend.set_gripper(s.gripper_open)
        backend.move_to(arm_pose(pose.grasp, level, s.level_delta), s.approach)
        backend.set_gripper(s.gripper_close)
        self._check_holding(backend)
        backend.move_to(arm_pose(pose.above), carry_speed)

    def _check_holding(self, backend: Backend) -> None:
        """그리퍼를 닫은 뒤 말을 잡았는지 확인합니다. 허공을 잡았으면 BackendError.

        값은 0(닫힘)~100(열림)이라 말을 잡으면 말 폭에서 멈춰 값이 holding_min 이상이고, 허공이면 close까지 닫혀 작습니다.
        holding_min이 없거나 백엔드가 gripper_position()을 지원하지 않으면 건너뜁니다.
        """
        hold = self.s.gripper_holding_min
        read = getattr(backend, "gripper_position", None)
        if hold is None or read is None:
            return
        pos = read()
        if pos < hold:
            raise BackendError(f"말을 잡지 못했습니다 (그리퍼 {pos:.1f} < 기준 {hold:.1f})")

    def place(self, backend: Backend, pose: SlotPose, level: int) -> None:
        s = self.s
        backend.move_to(arm_pose(pose.grasp, level, s.level_delta), s.approach)
        backend.set_gripper(s.gripper_open)
        backend.move_to(arm_pose(pose.above), s.approach)
