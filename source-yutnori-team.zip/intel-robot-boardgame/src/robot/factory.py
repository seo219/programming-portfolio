"""로봇 컨트롤러 만들기 (담당: 신이서). config/robot.json과 config/poses.json으로 실제 백엔드를 연결합니다.

main.py의 hardware()에서 `RobotController(ROOT / "config" / "poses.json")` 대신 한 줄로 씁니다
(src/main.py는 김동현 담당이라 여기서는 고치지 않음):

    from robot.factory import build_controller
    robot = build_controller(ROOT)

- robot.json의 follower.port·id가 비어 있으면 ConfigNotSet을 냅니다 (로봇을 연결하기 전에 알림).
- 백엔드 연결 실패나 보정 불일치는 BackendError입니다.
- lerobot은 LeRobotBackend.from_config() 안에서만 불러오므로, 이 모듈은 lerobot 없이도 import됩니다.
"""
from pathlib import Path
from typing import Callable, Optional

from .backend import Backend
from .backend_lerobot import LeRobotBackend
from .config import load_robot_config, load_settings
from .controller import RobotController


def build_controller(root: Path, poses_path: Optional[Path] = None, robot_path: Optional[Path] = None,
                     backend_factory: Optional[Callable[[dict], Backend]] = None) -> RobotController:
    """root(저장소 폴더)의 config로 RobotController를 만들어 돌려줍니다.

    backend_factory: robot.json 내용(dict)을 받아 Backend를 돌려주는 함수. 테스트에서 FakeBackend를 끼울 때 씁니다.
    """
    root = Path(root)
    poses_path = Path(poses_path) if poses_path else root / "config" / "poses.json"
    robot_path = Path(robot_path) if robot_path else root / "config" / "robot.json"
    cfg = load_robot_config(robot_path)
    settings = load_settings(robot_path)
    backend = (backend_factory or LeRobotBackend.from_config)(cfg)
    return RobotController(poses_path, backend, settings)
