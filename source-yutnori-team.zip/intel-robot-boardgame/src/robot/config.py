"""로봇 설정 읽기 (담당: 신이서). config/poses.json, config/robot.json을 검사해서 돌려줍니다.

관절 값은 이 모듈과 robot 폴더 안에서만 씁니다 (설계 규칙 1).
미측정(null, 옛 형식의 전부 0)인 자세를 쓰려 하면 PoseNotMeasured를 냅니다.
"""
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

JOINT_COUNT = 6  # shoulder_pan, shoulder_lift, elbow_flex, wrist_flex, wrist_roll, gripper


class PoseNotMeasured(LookupError):
    """슬롯의 자세가 없거나 아직 측정하지 않았을 때."""


@dataclass(frozen=True)
class SlotPose:
    above: tuple  # 칸 위 접근 자세 (관절 6개)
    grasp: Optional[tuple] = None  # 집는 자세. 없으면 None (집기 방식이 정함)


def _joints(value, where: str) -> Optional[tuple]:
    """6개 숫자 → tuple. null이거나 전부 0(옛 자리표시)이면 None, 그 밖의 잘못된 형식은 오류."""
    if value is None:
        return None
    if not isinstance(value, list) or len(value) != JOINT_COUNT or not all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in value):
        raise ValueError(f"{where}: 숫자 {JOINT_COUNT}개 목록이어야 합니다: {value!r}")
    if all(v == 0 for v in value):
        return None
    return tuple(float(v) for v in value)


def load_poses(path: Path) -> dict:
    """{슬롯 이름: SlotPose}. 측정되지 않은 슬롯은 결과에 넣지 않습니다."""
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    poses = {}
    for name, value in raw.items():
        if name.startswith("_"):
            continue
        if isinstance(value, dict):
            unknown = set(value) - {"above", "grasp"}
            if unknown:
                raise ValueError(f"{name}: 알 수 없는 키 {sorted(unknown)}")
            above = _joints(value.get("above"), f"{name}.above")
            grasp = _joints(value.get("grasp"), f"{name}.grasp")
        else:
            above, grasp = _joints(value, name), None
        if above is not None:
            poses[name] = SlotPose(above, grasp)
    return poses


def get_pose(poses: dict, slot: str) -> SlotPose:
    try:
        return poses[slot]
    except KeyError:
        raise PoseNotMeasured(f"{slot}: 측정된 자세가 없습니다 (config/poses.json)") from None


def load_robot_config(path: Path) -> dict:
    """config/robot.json을 읽어 돌려줍니다. 값이 null인 항목은 미정입니다."""
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    return {k: v for k, v in raw.items() if not k.startswith("_")}


def update_pose_file(path: Path, slot: str, kind: str, joints, meta: Optional[dict] = None) -> None:
    """측정한 관절 6개를 poses.json에 저장합니다. kind는 "above" 또는 "grasp".

    home은 위 접근 자세만 있으므로 6개 목록으로, 나머지 슬롯은 {"above", "grasp"} 사전으로 저장합니다.
    다른 슬롯과 _로 시작하는 항목은 그대로 두고, meta가 있으면 "_calibration"에 적어 어느 보정으로 쟀는지 남깁니다.
    """
    import os
    import tempfile
    if kind not in ("above", "grasp"):
        raise ValueError(f"kind는 above 또는 grasp: {kind!r}")
    if kind == "grasp" and slot == "home":
        raise ValueError("home에는 grasp 자세가 없습니다")
    values = _joints(list(joints), f"{slot}.{kind}")
    if values is None:
        raise ValueError(f"{slot}.{kind}: 전부 0인 자세는 저장하지 않습니다 (미측정과 구분되지 않음)")
    path = Path(path)
    raw = json.loads(path.read_text(encoding="utf-8"))
    if slot not in raw:
        raise KeyError(f"{slot}: config/poses.json에 없는 슬롯입니다")
    cur = raw[slot]
    if slot == "home":
        raw[slot] = list(values)
    else:
        entry = cur if isinstance(cur, dict) else {"above": cur, "grasp": None}
        raw[slot] = {"above": entry.get("above"), "grasp": entry.get("grasp"), kind: list(values)}
    if meta is not None:
        raw["_calibration"] = meta
    lines = [f'  {json.dumps(k, ensure_ascii=False)}: {json.dumps(v, ensure_ascii=False)}' for k, v in raw.items()]
    text = "{\n" + ",\n".join(lines) + "\n}\n"
    json.loads(text)  # 쓰기 전에 형식 검증
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    os.replace(tmp, path)


class ConfigNotSet(LookupError):
    """config/robot.json에서 동작에 필요한 값이 아직 null일 때."""


ARM_JOINTS = 5  # 팔 관절 수. 자세 6개 중 앞 5개가 팔이고 마지막(그리퍼)은 robot.json 값으로 따로 움직임


@dataclass(frozen=True)
class RobotSettings:
    gripper_open: Optional[float] = None
    gripper_close: Optional[float] = None
    # 말을 잡았을 때 그리퍼 위치(0 닫힘 ~ 100 열림)의 하한. 닫은 뒤 읽은 값이 이보다 작으면 말 폭만큼 못 막힌 것(허공)으로 봄.
    # gripper_close < gripper_holding_min < (말 폭에서 멈추는 값) 이어야 하며, None이면 확인하지 않음
    gripper_holding_min: Optional[float] = None
    travel: Optional[float] = None  # 칸 사이 이동 속도
    approach: Optional[float] = None  # 내려가기·올라가기 속도
    carry_stack: Optional[float] = None  # 말 2개를 들고 이동할 때 속도
    level_delta: Optional[tuple] = None  # 말 1개 높이만큼 쌓였을 때 팔 관절 변화량 (ARM_JOINTS개)


def require(value, name: str):
    if value is None:
        raise ConfigNotSet(f"config/robot.json의 {name} 값이 없습니다 (측정 후 입력)")
    return value


def load_settings(path: Path) -> RobotSettings:
    cfg = load_robot_config(path)
    delta = cfg.get("stack", {}).get("level_delta")
    if delta is not None:
        if not isinstance(delta, list) or len(delta) != ARM_JOINTS or not all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in delta):
            raise ValueError(f"stack.level_delta: 숫자 {ARM_JOINTS}개 목록이어야 합니다: {delta!r}")
        delta = tuple(float(v) for v in delta)
    grip, speed = cfg.get("gripper", {}), cfg.get("speed", {})
    g_open, g_close, hold = grip.get("open"), grip.get("close"), grip.get("holding_min")
    if hold is not None:
        if g_close is not None and hold <= g_close:
            raise ValueError(f"gripper.holding_min({hold})은 gripper.close({g_close})보다 커야 합니다 (값이 클수록 열림)")
        if g_open is not None and hold >= g_open:
            raise ValueError(f"gripper.holding_min({hold})은 gripper.open({g_open})보다 작아야 합니다")
    return RobotSettings(g_open, g_close, hold, speed.get("travel"), speed.get("approach"),
                         speed.get("carry_stack"), delta)
