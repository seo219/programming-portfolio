"""로봇 하드웨어 접근 약속 (담당: 신이서). 컨트롤러는 이 인터페이스만 부르고, 실제 구현은 따로 둡니다.

팔 관절은 5개(shoulder_pan ~ wrist_roll)이고 그리퍼는 따로 움직입니다.
"""
from typing import Optional, Protocol


class BackendError(RuntimeError):
    """하드웨어 동작 실패 (통신 끊김, 모터 과부하, 목표 도달 못함 등). 컨트롤러는 move()에서 False로 바꿉니다."""


class Backend(Protocol):
    def move_to(self, joints: tuple, speed: Optional[float] = None) -> None:
        """팔 관절 5개를 목표로 옮기고 도착할 때까지 기다림. speed가 None이면 백엔드 기본 속도."""
        ...

    def set_gripper(self, value: float) -> None:
        """그리퍼를 value로 움직이고 기다림."""
        ...

    def gripper_position(self) -> float:
        """(선택) 그리퍼의 현재 위치. 값이 클수록 열림(0 닫힘 ~ 100 열림, LeRobot 기준).

        말을 집은 뒤 허공을 잡았는지 확인하는 데 씁니다 (ScriptGrasper). 없는 백엔드는 확인을 건너뜁니다.
        """
        ...
