"""로봇 모듈 (담당: 신이서). 슬롯 이름으로 받은 명령을 SO-101 동작으로 바꿉니다.

move(src, dst) 흐름: src 위 접근 → (Grasper) 집기 → dst 위 접근 → (Grasper) 놓기.
- 집는 말 수: 출발지가 wait_*이면 맨 위 1개, 판 위 칸이면 쌓인 말 전부 (슬롯 규칙은 slots.py).
- 집는 높이: 집으려는 말 아래에 쌓인 말 수 x level_delta 만큼 올림. 놓는 높이: dst에 이미 있는 말 수 x level_delta.
- 자세·설정 값이 비어 있으면 움직이기 전에 PoseNotMeasured/ConfigNotSet을 냅니다 (준비 문제라 재시도하지 않음).
- 하드웨어 동작이 실패하면 False를 돌려줍니다 (재시도·ask_help는 game/recovery.py가 처리).
- 집기·놓기 방식은 Grasper로 바꿔 끼웁니다 (기본 ScriptGrasper, ACT는 6단계).
"""
import logging
from pathlib import Path
from typing import Optional

from .backend import Backend, BackendError
from .config import RobotSettings, get_pose, load_poses, require
from .grasp import Grasper, ScriptGrasper, arm_pose
from .slots import SlotError, SlotTracker, canonical_slot

log = logging.getLogger("robot")


class RobotController:
    def __init__(self, poses_path: Path, backend: Optional[Backend] = None,
                 settings: Optional[RobotSettings] = None, tracker: Optional[SlotTracker] = None,
                 grasper: Optional[Grasper] = None):
        self.poses = load_poses(Path(poses_path))  # {슬롯: SlotPose}, 미측정 슬롯은 없음
        self.backend = backend
        self.settings = settings or RobotSettings()
        self.tracker = tracker or SlotTracker()
        self.grasper = grasper or ScriptGrasper(self.settings)

    def _need_backend(self) -> Backend:
        if self.backend is None:
            raise NotImplementedError("로봇 백엔드가 연결되지 않았습니다")
        return self.backend

    def home(self) -> None:
        """HOME 자세로 복귀. 비전 인식 전에 항상 호출됨."""
        backend = self._need_backend()
        pose = get_pose(self.poses, "home")
        backend.move_to(arm_pose(pose.above), self.settings.travel)

    def roll_dice(self) -> bool:
        """트레이 모서리에서 주사위를 집어 투하 위치에서 떨어뜨림. (차선책, 미구현)"""
        raise NotImplementedError

    def move(self, src: str, dst: str) -> bool:
        """src 칸 위로 이동 → 집기 → dst 칸 위로 이동 → 놓기."""
        backend = self._need_backend()
        src, dst = canonical_slot(src), canonical_slot(dst)  # 게임 이름(diag_r1 등) → poses.json 이름
        try:
            n = self.tracker.check_move(src, dst)
        except SlotError as e:
            log.warning("move 거절: %s", e)
            return False
        pick_level = self.tracker.count(src) - n  # 집는 말 아래에 남는 말 수
        place_level = self.tracker.count(dst)  # 놓을 곳에 이미 있는 말 수

        # 움직이기 전에 필요한 자세와 설정을 모두 확인합니다
        src_pose, dst_pose = get_pose(self.poses, src), get_pose(self.poses, dst)
        self.grasper.preflight(src_pose, pick_level)
        self.grasper.preflight(dst_pose, place_level)
        carry = require(self.settings.carry_stack, "speed.carry_stack") if n > 1 else self.settings.travel

        try:
            backend.move_to(arm_pose(src_pose.above), self.settings.travel)
            self.grasper.pick(backend, src_pose, pick_level, carry)
            backend.move_to(arm_pose(dst_pose.above), carry)
            self.grasper.place(backend, dst_pose, place_level)
        except BackendError as e:
            log.error("move %s → %s 실패: %s", src, dst, e)
            return False  # 말 수 기록은 그대로 둠: 사람이 확인한 뒤 tracker.sync()로 맞춥니다
        self.tracker.apply(src, dst, n)
        return True
