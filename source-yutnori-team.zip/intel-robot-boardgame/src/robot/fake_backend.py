"""하드웨어 없는 가짜 백엔드 (담당: 신이서). 테스트와 모의 실행용이며, 불러진 동작을 calls에 기록합니다."""
from typing import Optional

from .backend import BackendError


class FakeBackend:
    def __init__(self, fail_on_call: Optional[int] = None, holding_at: Optional[float] = None):
        self.calls: list = []  # ("move_to", joints, speed) | ("gripper", value)
        self.fail_on_call = fail_on_call  # n번째(1부터) 호출에서 BackendError를 냄
        # 말을 잡은 상황: 그리퍼를 닫아도 holding_at(말 폭에 해당하는 값)까지만 닫힘. None이면 허공이라 목표까지 다 닫힘
        self.holding_at = holding_at
        self._gripper = 100.0

    def _record(self, call: tuple) -> None:
        self.calls.append(call)
        if self.fail_on_call == len(self.calls):
            raise BackendError(f"가짜 실패: {call}")

    def move_to(self, joints: tuple, speed: Optional[float] = None) -> None:
        self._record(("move_to", tuple(joints), speed))

    def set_gripper(self, value: float) -> None:
        self._record(("gripper", value))
        self._gripper = max(value, self.holding_at) if self.holding_at is not None else value

    def gripper_position(self) -> float:
        return self._gripper
