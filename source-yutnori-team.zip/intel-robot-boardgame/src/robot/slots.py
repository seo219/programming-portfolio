"""슬롯별 말 수 추적 (담당: 신이서). 컨트롤러가 집는 말 수와 놓는 높이를 정하는 데 씁니다.

- 칸 하나에 말은 최대 capacity개(편마다 말 수)까지 자석으로 쌓입니다.
- 출발지가 wait_*이면 맨 위 말 1개만, 판 위 칸이면 쌓인 말 전부를 옮깁니다 (업힌 말은 한 번에).
- 편은 구분하지 않고 개수만 셉니다. 누구의 말인지는 게임 로직이 압니다.
"""
from typing import Optional

WAIT, GOAL = "wait_", "goal_"

# 게임(config/yut_board.json)의 칸 이름 → poses.json·비전 문서(docs/vision-yut-handoff.md 2.3장)의 번호 이름.
# cell_0~19는 두 쪽이 같고, 지름길 9칸만 이름이 다릅니다. 팀이 한 가지 이름으로 합의하면 이 표는 지울 수 있습니다.
SLOT_ALIASES = {
    "diag_r1": "cell_20", "diag_r2": "cell_21", "center": "cell_22", "diag_r3": "cell_23", "diag_r4": "cell_24",
    "diag_l1": "cell_25", "diag_l2": "cell_26", "diag_l3": "cell_27", "diag_l4": "cell_28",
}


def canonical_slot(name: str) -> str:
    """게임이 쓰는 칸 이름을 poses.json 이름으로 바꿉니다 (같은 이름이면 그대로)."""
    return SLOT_ALIASES.get(name, name)


class SlotError(ValueError):
    """말 수 기록과 맞지 않는 이동 (빈 칸에서 집기, 가득 찬 칸에 놓기 등)."""


class SlotTracker:
    def __init__(self, initial: Optional[dict] = None, capacity: int = 2):
        self.capacity = capacity
        # 시작 상태: 모든 말이 편마다 대기 자리에 있음 (게임 규칙 엔진의 시작과 같음)
        start = initial if initial is not None else {"wait_robot": capacity, "wait_human": capacity}
        self._n = {canonical_slot(k): v for k, v in start.items()}  # 칸 이름은 poses.json 이름으로 통일해 저장

    def count(self, slot: str) -> int:
        return self._n.get(canonical_slot(slot), 0)

    def snapshot(self) -> dict:
        return {k: v for k, v in self._n.items() if v}

    def sync(self, counts: dict) -> None:
        """사람이 직접 말을 옮겼을 때 등, 실제 상태에 맞춰 기록을 통째로 바꿉니다."""
        merged: dict = {}
        for k, v in counts.items():
            merged[canonical_slot(k)] = merged.get(canonical_slot(k), 0) + v
        self._n = {k: v for k, v in merged.items() if v}

    def pieces_to_move(self, src: str) -> int:
        n = self.count(src)
        if src.startswith(GOAL):
            raise SlotError(f"{src}에서는 말을 옮기지 않습니다")
        if n == 0:
            raise SlotError(f"{src}에 말이 없습니다")
        return 1 if src.startswith(WAIT) else n

    def check_move(self, src: str, dst: str) -> int:
        """옮길 말 수를 돌려주고, 맞지 않으면 SlotError."""
        if canonical_slot(src) == canonical_slot(dst):
            raise SlotError(f"출발지와 목적지가 같습니다: {src}")
        n = self.pieces_to_move(src)
        if self.count(dst) + n > self.capacity:
            raise SlotError(f"{dst}에 말 {n}개를 놓을 수 없습니다 (현재 {self.count(dst)}개, 최대 {self.capacity}개)")
        return n

    def apply(self, src: str, dst: str, n: int) -> None:
        src, dst = canonical_slot(src), canonical_slot(dst)
        self._n[src] = self.count(src) - n
        self._n[dst] = self.count(dst) + n
        self._n = {k: v for k, v in self._n.items() if v}
