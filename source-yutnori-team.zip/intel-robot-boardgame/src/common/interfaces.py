"""모듈 간 약속. 바꿀 때는 팀 전원에게 먼저 알립니다 (docs/interfaces.md).

윷놀이(본 계획)와 주사위 게임(차선책 골격)의 함수가 함께 있습니다.
Protocol은 형식 검사용이라, 각 모듈은 자기 게임에 필요한 함수만 구현해도 실행됩니다.
"""
from dataclasses import dataclass, field
from typing import Optional, Protocol, Union


# ---- 윷놀이 ----

@dataclass
class YutResult:
    flats: Optional[int]  # 평평한 면이 위인 윷가락 수 0~4, 표시한 가락 하나만 앞이면 -1(빽도), 애매하면 None
    value: Optional[int]  # 이동 칸 수 (빽도-1 도1 개2 걸3 윷4 모5), 인식 실패면 None
    confidence: float


@dataclass
class YutState:
    """화면·DB에 넘기는 윷놀이 상태. 말 위치는 슬롯 이름입니다."""
    pieces: dict  # {"robot": ["wait_robot", "cell_7", ...], "human": [...]} 편마다 pieces_per_side개, 업힘 = 같은 칸
    current: str = "human"
    turn: int = 1
    pending: list = field(default_factory=list)  # 아직 적용하지 않은 결과 칸 수, 예: [4, 5, 1]
    winner: Optional[str] = None


@dataclass
class Move:
    """말 하나(업힌 말 포함)에 결과 하나를 적용하는 선택."""
    piece: int  # 말 번호 0부터 (pieces_per_side-1까지)
    value: int  # 적용할 결과 칸 수 (pending 중 하나)
    reason: str = ""  # 로봇 전략의 이유: capture | stack | advance | enter | back | human


# ---- 주사위 게임 (차선책) ----

@dataclass
class DiceResult:
    value: Optional[int]  # 1~6, 확신이 없으면 None
    confidence: float


@dataclass
class GameState:
    positions: dict  # {"human": 0, "robot": 0}
    current: str = "human"
    turn: int = 1
    winner: Optional[str] = None


# ---- 공통 ----

@dataclass
class Event:
    turn: int
    player: str  # "human" | "robot"
    kind: str  # 윷놀이: throw | move | capture | stack | finish | win | help | decision
    detail: dict = field(default_factory=dict)


class Vision(Protocol):
    def read_yut(self) -> YutResult: ...  # 윷놀이: 사람 턴의 실제 윷
    def read_dice(self) -> DiceResult: ...  # 주사위 (차선책)
    def piece_at(self, cell: str) -> Optional[str]: ...  # "robot" | "human" | None
    def board_state(self) -> dict[str, Optional[str]]: ...  # 윷놀이: 판 위 칸 전체 {"cell_3": "robot", ...}, 빈 칸은 None


class Robot(Protocol):
    def home(self) -> None: ...
    def roll_dice(self) -> bool: ...  # 주사위 (차선책)
    def move(self, src: str, dst: str) -> bool: ...  # 윷놀이: 사람·로봇 말 모두 옮김, 업힌 말도 한 번에


class Narrator(Protocol):
    # context (윷놀이, 선택): {"pieces": 규칙 엔진 위치 복사본, "reason": 로봇의 Move.reason}. 판세·위기 중계에 씀
    def narrate(self, event: Event, context: Optional[dict] = None) -> str: ...


class Store(Protocol):
    def save(self, event: Event) -> None: ...


class Screen(Protocol):
    def update(self, state: Union[YutState, GameState], message: str = "") -> None: ...
    def ask_help(self, message: str) -> None: ...
    def ask_choice(self, options: list[str]) -> int: ...  # 윷놀이: 사람이 고른 보기 번호 (0부터)
    def show_throw(self, flats: int, name: str) -> None: ...  # 윷놀이: AI 턴 윷 던지기 장면 (앞 개수, 빽도 -1, "윷")
