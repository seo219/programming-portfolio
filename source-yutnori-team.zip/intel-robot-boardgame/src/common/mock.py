"""하드웨어 없이 개발·테스트할 때 쓰는 가짜 구현.

- MockVision / MockRobot / ConsoleScreen: `python src/main.py --mock`에서 키보드로 한 판을 진행합니다.
- HandRobot: 로봇 대신 사람이 말을 옮깁니다 (`python src/main.py --no-robot`). 비전·중계·DB·화면은 실제 모듈.
- ScriptedVision / ScriptedRobot: 정해 둔 결과를 차례로 내놓아 테스트에서 턴 흐름을 재현합니다
  (tests/test_yut_turn.py). 실패(None, False)도 끼워 넣어 재시도·도움 요청을 확인할 수 있습니다.
"""
import json
import random
from pathlib import Path
from typing import Optional

from common.interfaces import DiceResult, Event, GameState, Screen, YutResult, YutState

BOARD = Path(__file__).resolve().parents[2] / "config" / "yut_board.json"
_BOARD_DATA = json.loads(BOARD.read_text(encoding="utf-8"))
YUT_VALUES = {int(k): v[1] for k, v in _BOARD_DATA["yut"].items() if not k.startswith("_")}  # 앞 개수 → 칸 수
FLAT_PROB = _BOARD_DATA["ai_throw"]["flat_prob"]  # 엔터=랜덤일 때도 AI 턴과 같은 확률
BACKDO = _BOARD_DATA["backdo"]


def random_flats() -> int:
    """윷가락 4개 던지기. 마지막 가락이 표시 가락이라 그것만 앞이면 빽도(-1)."""
    sticks = [random.random() < FLAT_PROB for _ in range(4)]
    return -1 if BACKDO and sum(sticks) == 1 and sticks[-1] else sum(sticks)


def yut_result(flats: Optional[int], confidence: float = 1.0) -> YutResult:
    """앞 개수로 YutResult를 만듭니다. None이면 인식 실패."""
    if flats is None:
        return YutResult(None, None, 0.0)
    return YutResult(flats, YUT_VALUES[flats], confidence)


def _input(prompt: str) -> str:
    """입력이 끝났으면(EOF) 빈 문자열. `printf ... | python src/main.py --mock`이 끝까지 돌게 합니다."""
    try:
        return input(prompt)
    except EOFError:
        return ""


class MockVision:
    def __init__(self, ask_human: bool = True):
        self.ask_human = ask_human

    def read_yut(self) -> YutResult:
        if self.ask_human:
            raw = _input("윷 앞 개수 입력 (0~4, 빽도 -1, 엔터=랜덤): ").strip()
            if raw.lstrip("-").isdigit() and int(raw) in YUT_VALUES:
                return yut_result(int(raw))
        return yut_result(random_flats())

    def read_dice(self) -> DiceResult:
        if self.ask_human:
            raw = _input("주사위 눈 입력 (1~6, 엔터=랜덤): ").strip()
            if raw.isdigit() and 1 <= int(raw) <= 6:
                return DiceResult(int(raw), 1.0)
        return DiceResult(random.randint(1, 6), 1.0)

    def piece_at(self, cell: str) -> Optional[str]:
        return None  # mock에서는 이동 확인을 끄고(verify_moves=False) 씁니다

    def board_state(self) -> dict[str, Optional[str]]:
        return {}  # piece_at과 같이 mock에서는 쓰지 않습니다


class MockRobot:
    def home(self) -> None:
        print("[robot] HOME")

    def roll_dice(self) -> bool:
        print("[robot] 주사위 굴리기")
        return True

    def move(self, src: str, dst: str) -> bool:
        print(f"[robot] {src} → {dst}")
        return True


class HandRobot:
    """로봇 대신 사람이 말을 옮깁니다. 화면에 옮길 칸을 띄우고, 사람이 옮긴 뒤 확인을 누르면 성공으로 봅니다.

    이동 확인은 실제 비전(board_state)이 하므로, 잘못 옮기면 게임이 다시 옮겨 달라고 하거나 ask_help로 알립니다.
    """

    def __init__(self, screen: Screen):
        self.screen = screen

    def home(self) -> None:
        pass  # 팔이 없으므로 카메라를 가리지 않음. 확인을 누르기 전에 손을 판에서 치워 주세요

    def roll_dice(self) -> bool:
        return False  # 윷놀이에서는 부르지 않습니다

    def move(self, src: str, dst: str) -> bool:
        self.screen.ask_help(f"[로봇 대신] {src}의 말을 {dst}로 옮기고, 손을 치운 뒤 확인을 눌러 주세요")
        return True


class ScriptedVision:
    """flats 목록을 차례로 읽어 줍니다. None은 인식 실패. 다 쓰면 fallback 값을 계속 냅니다.

    board: piece_at()·board_state()가 볼 칸 → 편 사전. 테스트가 실제 판처럼 채우거나 비워 둡니다.
    """

    def __init__(self, flats: list[Optional[int]], fallback: int = 1, log: Optional[list] = None):
        self.flats, self.fallback = list(flats), fallback
        self.board: dict[str, str] = {}
        self.log = log if log is not None else []

    def read_yut(self) -> YutResult:
        self.log.append("vision.read_yut")
        return yut_result(self.flats.pop(0) if self.flats else self.fallback)

    def piece_at(self, cell: str) -> Optional[str]:
        self.log.append(f"vision.piece_at {cell}")
        return self.board.get(cell)

    def board_state(self) -> dict[str, Optional[str]]:
        self.log.append("vision.board_state")
        return dict(self.board)


class ScriptedRobot:
    """호출을 log에 남기고, fails에 적은 횟수만큼 처음 동작을 실패로 돌려줍니다."""

    def __init__(self, log: Optional[list] = None, move_fails: int = 0):
        self.log = log if log is not None else []
        self.move_fails = move_fails

    def home(self) -> None:
        self.log.append("robot.home")

    def move(self, src: str, dst: str) -> bool:
        self.log.append(f"robot.move {src} {dst}")
        if self.move_fails:
            self.move_fails -= 1
            return False
        return True


class MockNarrator:
    def __init__(self):
        self.contexts: list[Optional[dict]] = []  # 테스트용: 받은 context

    def narrate(self, event: Event, context: Optional[dict] = None) -> str:
        self.contexts.append(context)
        return f"{event.turn}턴 {event.player} {event.kind}: {event.detail}"


class MockStore:
    def __init__(self):
        self.events: list[Event] = []

    def save(self, event: Event) -> None:
        self.events.append(event)


class ConsoleScreen:
    def __init__(self, choices: Optional[list[int]] = None, quiet: bool = False):
        self.choices = choices  # 테스트용: 정해 둔 선택 번호. None이면 키보드
        self.quiet = quiet
        self.helps: list[str] = []
        self.throws: list[tuple[int, str]] = []

    def update(self, state, message: str = "") -> None:
        if self.quiet:
            return
        if isinstance(state, YutState):
            pieces = " · ".join(f"{p} {state.pieces[p]}" for p in ("human", "robot"))
            print(f"[screen] {state.turn}턴 {state.current} 남은결과{state.pending} | {pieces} | {message}")
        elif isinstance(state, GameState):
            print(f"[screen] 사람 {state.positions['human']}칸 · 로봇 {state.positions['robot']}칸 {message}")

    def ask_help(self, message: str) -> None:
        self.helps.append(message)
        if not self.quiet:
            _input(f"[도움 요청] {message} (처리 후 엔터) ")

    def show_throw(self, flats: int, name: str) -> None:
        self.throws.append((flats, name))
        if not self.quiet:
            print(f"[screen] AI 윷 던지기 → 앞 {flats}개: {name}")

    def ask_choice(self, options: list[str]) -> int:
        if self.choices is not None:
            return self.choices.pop(0) if self.choices else 0
        for i, text in enumerate(options):
            print(f"  {i}: {text}")
        raw = _input("움직일 말 번호 (엔터=0): ").strip()
        return int(raw) if raw.isdigit() and int(raw) < len(options) else 0
