"""실행 진입점: python src/main.py [--mock | --no-robot] [--db [PATH]] [--game yut|dice] [--ui]"""
import argparse
from pathlib import Path
from typing import Optional

from common.mock import ConsoleScreen, HandRobot, MockNarrator, MockRobot, MockStore, MockVision
from game.orchestrator import Orchestrator
from game.rules import Rules
from game.wrapper import DeviceWrapper, ask_flats_on_screen
from game.yut_orchestrator import YutOrchestrator, ai_thrower
from game.yut_reference import YutBoard

ROOT = Path(__file__).resolve().parent.parent
MOCK_DB = ROOT / "data" / "mock_games.db"  # --mock 기록은 실제 시연 기록(games.db)과 나눕니다


CAMERAS = {"tray": 0, "board": None}  # 카메라 번호. --tray-cam·--board-cam으로 바꿈 (board None = 트레이와 같은 카메라)


def build_vision(yut: bool):
    """실제 비전. 윷놀이만 윷 모델을 불러오고, 주사위 골격은 모델 없이 만듭니다. --mock이 아닐 때만 부릅니다."""
    from vision.detector import VisionDetector

    classifier = None
    if yut:
        from vision.yut_model import ModelApiYutClassifier

        try:
            classifier = ModelApiYutClassifier()
        except FileNotFoundError as e:
            raise SystemExit(f"{e}\n모델은 Hugging Face에서 받아 models/yut/<이름>/model.xml 위치에 두세요.")
    return VisionDetector(ROOT / "config" / "slots.json", camera_index=CAMERAS["tray"], yut_classifier=classifier,
                          board_camera_index=CAMERAS["board"])


def hardware(yut: bool, hand_robot: Optional[HandRobot] = None):
    """실제 모듈 (vision·robot·llm·db). --mock이 아닐 때만 import합니다. hand_robot이 있으면 로봇 대신 씁니다."""
    from db.store import SqliteStore
    from llm.narrator import OllamaNarrator

    if hand_robot is None:
        from robot.factory import build_controller
        robot = build_controller(ROOT)
    else:
        robot = hand_robot
    return (build_vision(yut), robot, OllamaNarrator(), SqliteStore(ROOT / "data" / "games.db"))


def mock_store(db: Optional[Path]):
    """--mock에서 --db를 주면 실제 SQLite에 기록합니다 (DB → LLM 흐름을 하드웨어 없이 확인)."""
    if db is None:
        return MockStore()
    from db.store import SqliteStore
    return SqliteStore(db)


def build_screen(ui: bool):
    """--ui면 pygame 게임 화면, 아니면 콘솔 화면."""
    if not ui:
        return ConsoleScreen()
    from ui.screen import GameScreen, UiError

    try:
        return GameScreen()
    except UiError as e:
        raise SystemExit(f"--ui 실행 실패: {e}")


def build_yut(mock: bool, db: Optional[Path] = None, ui: bool = False, no_robot: bool = False) -> YutOrchestrator:
    path = ROOT / "config" / "yut_board.json"
    board, ai_throw = YutBoard(path), ai_thrower(path)
    screen = build_screen(ui)
    # --ui면 인식 실패 때 윷 결과를 화면 버튼으로 입력받고, 아니면 키보드로 입력받습니다
    flats_kw = {"ask_flats": ask_flats_on_screen(screen)} if ui else {}
    if mock:
        dev = DeviceWrapper(MockVision(), MockRobot(), screen, **flats_kw)
        return YutOrchestrator(board, dev, MockNarrator(), mock_store(db), screen, ai_throw, verify_moves=False)
    # --no-robot: 말은 사람이 옮기고 비전·상태 머신·중계·DB·화면은 실제로 돌립니다
    vision, robot, narrator, store = hardware(yut=True, hand_robot=HandRobot(screen) if no_robot else None)
    return YutOrchestrator(board, DeviceWrapper(vision, robot, screen, **flats_kw), narrator, store, screen, ai_throw)


def build_dice(mock: bool, db: Optional[Path] = None, ui: bool = False) -> Orchestrator:
    """차선책(주사위 골격). Day 6에 돌 vs 인간으로 바꿀 때 씁니다."""
    rules = Rules(ROOT / "config" / "rules.json")
    screen = build_screen(ui)
    if mock:
        return Orchestrator(rules, MockVision(), MockRobot(), MockNarrator(), mock_store(db),
                            screen, verify_moves=False)
    vision, robot, narrator, store = hardware(yut=False)
    return Orchestrator(rules, vision, robot, narrator, store, screen)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mock", action="store_true", help="비전·로봇 없이 키보드로 진행")
    parser.add_argument("--game", choices=["yut", "dice"], default="yut", help="윷놀이(기본) / 주사위 골격")
    parser.add_argument("--db", nargs="?", const=MOCK_DB, type=Path, default=None, metavar="PATH",
                        help=f"--mock에서도 SQLite에 기록 (경로 생략 시 {MOCK_DB.relative_to(ROOT)})")
    parser.add_argument("--ui", action="store_true", help="콘솔 대신 pygame 게임 화면 사용")
    parser.add_argument("--no-robot", action="store_true",
                        help="로봇 없이 실물 시험: 말은 사람이 옮기고 비전·중계·DB·화면은 실제 모듈 (윷놀이)")
    parser.add_argument("--tray-cam", type=int, default=0, metavar="N", help="트레이(윷) 카메라 번호 (기본 0)")
    parser.add_argument("--board-cam", type=int, default=None, metavar="N", help="판 카메라 번호 (생략 시 트레이와 같은 카메라)")
    args = parser.parse_args()
    CAMERAS.update(tray=args.tray_cam, board=args.board_cam)
    if args.db is not None and not args.mock:
        parser.error("--db는 --mock과 함께 씁니다 (실제 실행은 항상 data/games.db에 기록)")
    if args.no_robot and (args.mock or args.game != "yut"):
        parser.error("--no-robot은 --mock 없이 윷놀이(--game yut)에서만 씁니다")
    if args.game == "yut":
        game = build_yut(args.mock, args.db, args.ui, args.no_robot)
    else:
        game = build_dice(args.mock, args.db, args.ui)
    print(f"승자: {game.run()}")
    if args.ui:
        game.screen.wait_until_closed()  # 결과 화면을 창을 닫을 때까지 유지
