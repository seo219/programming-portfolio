# SO-101 URDF

- 출처: https://github.com/TheRobotStudio/SO-ARM100 (`Simulation/SO101/`)
- 고정한 커밋: `a758567c3978dfeefe282ede0500085a48fe8f78` (2026-10-06)
- 라이선스: Apache-2.0
- 파일: `so101_new_calib.urdf` + `assets/*.stl` 13개 (URDF가 `assets/<이름>.stl`로 참조하므로 폴더 구조를 바꾸지 않습니다)
- 새 보정(new calib) 기준입니다. 관절 0점이 가동 범위 중간입니다. 원본 README에 따르면 이 URDF는 LeRobot의 그리퍼 매핑(선형 0~100)을 반영하지 않습니다.
- ikpy 등 역기구학에 쓰는 용도입니다. LeRobot의 관절값과 URDF 각도를 쓰기 전에 단위(도/라디안)와 0점이 맞는지 실제 로봇으로 확인해야 합니다.
