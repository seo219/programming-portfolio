@echo off
set "DISCORD_STATE_DIR=%USERPROFILE%\.claude\channels\discord02"
set "PLUGIN=%USERPROFILE%\.claude\plugins\cache\claude-plugins-official\discord\0.0.4"
bun run --cwd "%PLUGIN%" --shell=bun --silent start
