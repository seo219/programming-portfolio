package POLITECH;

import javax.swing.JFrame;

public class Swing01 {

	public static void main(String[] args) {
		JFrame fw1 = new JFrame();
		JFrame fw2 = new JFrame();
		
		fw1.setTitle("나의 첫 번째 윈도우");
		fw1.setSize(300,200);
		fw1.setVisible(true);
		
		fw2.setTitle("나의 두 번째 윈도우");
		fw2.setSize(300,200);
		fw2.setVisible(true);
	}

}
