package POLITECH;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Swing02 extends JFrame{

	public Swing02(String string) {
		setSize(600,400);
		setTitle("나의 두 번째 윈도우");
		setVisible(true);
		
	}
	
	void decorate() {
		JButton btn = new JButton("나의 첫 버튼");
		add(btn);
		setVisible(true);
	}

	public static void main(String[] args) {
//		JFrame.setDefaultLookAndFeelDecorated(true);
		Swing02 f = new Swing02("안녕하세요.");
		f.decorate();
		
	}

}
