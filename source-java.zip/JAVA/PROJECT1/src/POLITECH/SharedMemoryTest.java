//package POLITECH;
//
//import java.util.Scanner;
//
//class SharesMemory{
//	int x = 5;
//	Boolean isQuit = false;
//}
//
//class PlusThread extends Thread{
//	SharesMemory shmem;
//	public void run() {
//		while(!shmem.isQuit) {
//			System.out.println("x = " + shmem.x);
//			try {
//				Thread.sleep(200);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//			shmem.x++;
//		}
//	}
//}
//
//class MinusThread extends Thread{
//	SharesMemory shmem;
//	public void run() {
//		Scanner sc = new Scanner(System.in);
//		while(shmem.x != 0) {
//			sc.nextLine();
//			shmem.x--;
//		}
//		System.out.println("x가 0입니다. 당신이 이겼습니다.");
//		shmem.isQuit = true;
//	}
//}
//
//public class SharedMemoryTest {
//
//	public static void main(String[] args) {
//		SharesMemory shobj = new SharesMemory();
//		
//		PlusThread pt = new PlusThread();
//		MinusThread mt = new MinusThread();
//		
//		pt.shmem = shobj;
//		mt.shmem = shobj;
//		
//		pt.start();
//		mt.start();
//	}
//}
//
