package POLITECH;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

class ImageWin extends JFrame {
	
	ImageWin(){
		setSize(400,200);
		setTitle("이미지 처리");
		
		ImageIcon img = new ImageIcon("f:/해변.jpg");
		JLabel lb = new JLabel(img);
		add(lb);
		
		setVisible(true);
	}
}

public class Swing08 {

	public static void main(String[] args) {
		ImageWin iw = new ImageWin();

	}

}
