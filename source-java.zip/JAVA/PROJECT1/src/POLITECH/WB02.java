package POLITECH;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseEvent;

public class WB02 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JTextField fName;
	private JLabel lblOutput;
	private JLabel lblPos;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WB02 frame = new WB02();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WB02() {
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JButton btn1 = new JButton("확인");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = fName.getText();
				lblOutput.setText(name + "님 환영합니다.");
				
			}
		});
		btn1.setFont(new Font("굴림", Font.PLAIN, 12));
		btn1.setBounds(325, 10, 97, 23);
		getContentPane().add(btn1);
		
		fName = new JTextField();
		fName.setBounds(12, 11, 301, 21);
		getContentPane().add(fName);
		fName.setColumns(10);
		
		lblOutput = new JLabel("환영 메세지 출력 란");
		lblOutput.setBounds(12, 42, 410, 23);
		getContentPane().add(lblOutput);
		
		lblPos = new JLabel("(0, 0)");
		this.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				lblPos.setText("(" + e.getX() + ", " + e.getY() + ")");
			}
		});
		lblPos.setFont(new Font("굴림", Font.BOLD, 15));
		lblPos.setBounds(12, 75, 410, 23);
		getContentPane().add(lblPos);

	}
}
