package POLITECH;

class my1{
	int x;
	void doit(){
		System.out.println(x);
	}
}

public class test1 {

	public static void main(String[] args) {
		my1 m = new my1();
		m.x = 3;
		m.doit();
		
		Plus p = new Plus();
		System.out.println(p.doit());
		
		System.out.println("안녕하세요.");
	}

}
