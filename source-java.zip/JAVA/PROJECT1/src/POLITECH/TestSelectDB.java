package POLITECH;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
 
public class TestSelectDB {
	public static void main(String[] args) {
 
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection conn = DriverManager.getConnection(
								 "jdbc:sqlserver://127.0.0.1:1433;"
								+"databaseName = CONFIGURE_LOCALLY;"
								+"user=mduser;"
								+"password=CONFIGURE_LOCALLY;"
								+"encrypt=true;"
								+"trustServerCertificate=true;");
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery("SELECT * FROM BOOK");
 
			while(rset.next()) {
				System.out.println(rset.getInt(1)+" "+
						rset.getString(2)+" "+
						rset.getString(3)+" "+
						rset.getInt(4));
				}
			rset.close();
			stmt.close();
			conn.close();
		}catch(Exception e) {}
	}
}