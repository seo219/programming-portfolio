package POLITECH;

import java.util.Scanner;

public class Project03 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String name;
		int age;
		
		System.out.print("이름:");
		name = sc.nextLine();
		System.out.print("나이:");
		age = sc.nextInt();
		
		System.out.println("================회원 정보================");
		System.out.println("이름: " + name);
		System.out.println(name + "님의 나이는 " + age + "세 입니다.");
		System.out.println("=======================================");
		
	}
	

}
