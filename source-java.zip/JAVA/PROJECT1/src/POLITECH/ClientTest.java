package POLITECH;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientTest {

	public static void main(String[] args) {
		Socket socket = null;
		
		try {
			socket = new Socket("127.0.0.1",5050);
		
			BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintWriter writer = new PrintWriter(socket.getOutputStream());
		
			writer.println("안녕하세요~");
			writer.flush();
		
		} catch (Exception e) {
			System.out.println(e);
		}
		
		finally {
			
			try {
				socket.close();
			} catch (IOException e) {
				System.out.println(e);
			}
		} 
	}

}
