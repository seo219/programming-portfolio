package POLITECH;

public class SingleThread {

	public static void main(String[] args) {
		// task1
		
		int i, sum = 0;
		
		for (i = 1; i <= 100; i++) {
			sum = sum + i;
		}
		System.out.println("1부터 100까지의 값은 " + sum + "입니다.");
		
		// task2
		
		i =0;
		while(true) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			i++;
			if (i == 10) {
				System.out.println("10초");
				break;
			} else {
				System.out.print(i + "초 ");
			}
		}
		
		// task3
		
		char alp;
		
		for (alp = 'A'; alp <= 'Z'; alp++) {
			System.out.print(alp + " ");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}

}
