package POLITECH;

public class Test2 {

	public static void main(String[] args) {
		my1 m = new my1();
		m.x = 3;
		m.doit();
		System.out.println("test2");
	}

}
