package POLITECH;

import javax.swing.JButton;
import javax.swing.JFrame;

class NullWin extends JFrame {
	
	JButton btn1;
	
	NullWin () {
		setSize(300, 200);
		setTitle("배치관리자가 없는 윈도우");
		
		setLayout(null);
		
		btn1 = new JButton("OK");
		
		btn1.setSize(100, 30);
		btn1.setLocation(50, 100);
		
		add(btn1);
		
		setVisible(true);
		
	}
}

public class Swing05 {

	public static void main(String[] args) {
		NullWin win = new NullWin();

	}

}
