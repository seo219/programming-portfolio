package POLITECH;
import java.io.*;

public class Project01 {

	public static void main(String[] args) {
		
//		try {
//			
//			FileWriter fw = new FileWriter("test.txt");
//			fw.write("my file...");
//			fw.close();
//		} catch(IOException e) {
//			System.out.println(e);
//		}
		
		try {
			int i;
			char c;
			
			FileReader fr = new FileReader("test.txt");
			
			while((i = fr.read()) != -1) {
				c = (char)i;
				System.out.print(c);
			}
			
			fr.close();
		} catch(IOException e) {
			System.out.println(e);
		}
		

	}

}
