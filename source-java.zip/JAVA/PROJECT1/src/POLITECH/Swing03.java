package POLITECH;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

class BorderWin extends JFrame {
	JButton btn1, btn2, btn3, btn4, btn5;
	
	BorderWin(String title) {
		setSize(300, 200);
		setTitle("Border Layout Window");
		
		setLayout(new BorderLayout(30, 20));
		btn1 = new JButton("북");
		btn2 = new JButton("남");
		btn3 = new JButton("서");
		btn4 = new JButton("동");
		btn5 = new JButton("중앙");
		
		add(btn1, "North");
		add(btn2, "South");
		add(btn3, "West");
		add(btn4, "East");
		add(btn5, "Center");
		
		setVisible(true);
		
	}
	
}

public class Swing03 {

	public static void main(String[] args) {
		BorderWin win = new BorderWin("");

	}

}
