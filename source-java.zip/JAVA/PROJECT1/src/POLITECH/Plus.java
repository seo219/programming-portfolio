package POLITECH;

public class Plus {
	public int doit() {
		return 10;
	}
}
