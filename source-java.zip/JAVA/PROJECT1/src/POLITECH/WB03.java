package POLITECH;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class WB03 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	int m_data;
	int m_predata;
	int m_flag;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WB03 frame = new WB03();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WB03() {
		setTitle("계산기");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 311, 402);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblData = new JLabel("0");
		lblData.setFont(new Font("맑은 고딕", Font.BOLD, 50));
		lblData.setBounds(12, 10, 276, 60);
		contentPane.add(lblData);
		
		JButton btn7 = new JButton("7");
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_data = m_data * 10 + 7;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btn7.setBounds(12, 89, 60, 60);
		contentPane.add(btn7);
		
		JButton btn8 = new JButton("8");
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_data = m_data * 10 + 8;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btn8.setBounds(84, 89, 60, 60);
		contentPane.add(btn8);
		
		JButton btn9 = new JButton("9");
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_data = m_data * 10 + 9;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btn9.setBounds(156, 89, 60, 60);
		contentPane.add(btn9);
		
		JButton btnP = new JButton("+");
		btnP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_predata = m_data;
				m_data = 0;
				m_flag = 1;
				lblData.setText(Integer.toString(m_data));
				
			}
		});
		btnP.setBounds(228, 89, 60, 60);
		contentPane.add(btnP);
		
		JButton btn4 = new JButton("4");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_data = m_data * 10 + 4;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btn4.setBounds(12, 159, 60, 60);
		contentPane.add(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_data = m_data * 10 + 5;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btn5.setBounds(84, 159, 60, 60);
		contentPane.add(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_data = m_data * 10 + 6;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btn6.setBounds(156, 159, 60, 60);
		contentPane.add(btn6);
		
		JButton btnM = new JButton("-");
		btnM.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_predata = m_data;
				m_data = 0;
				m_flag = 2;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btnM.setBounds(228, 159, 60, 60);
		contentPane.add(btnM);
		
		JButton btn1 = new JButton("1");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_data = m_data * 10 + 1;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btn1.setBounds(12, 229, 60, 60);
		contentPane.add(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_data = m_data * 10 + 2;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btn2.setBounds(84, 229, 60, 60);
		contentPane.add(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_data = m_data * 10 + 3;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btn3.setBounds(156, 229, 60, 60);
		contentPane.add(btn3);
		
		JButton btnX = new JButton("X");
		btnX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_predata = m_data;
				m_data = 0;
				m_flag = 3;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btnX.setBounds(228, 229, 60, 60);
		contentPane.add(btnX);
		
		JButton btnC = new JButton("C");
		btnC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_data = 0;
				m_predata = 0;
				m_flag = 0;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btnC.setBounds(12, 299, 60, 60);
		contentPane.add(btnC);
		
		JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_data = m_data * 10 +0;
				lblData.setText(Integer.toString(m_data));
			}
		});
		btn0.setBounds(84, 299, 60, 60);
		contentPane.add(btn0);
		
		JButton btnE = new JButton("=");
		btnE.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switch(m_flag) {
				case 1: m_data = m_predata + m_data; break;
				case 2: m_data = m_predata - m_data; break;
				case 3: m_data = m_predata * m_data; break;
				}
				lblData.setText(Integer.toString(m_data));
				m_data = 0;
			}
		});
		btnE.setBounds(156, 299, 60, 60);
		contentPane.add(btnE);
		
		JButton btnD = new JButton("/");
		btnD.setBounds(228, 299, 60, 60);
		contentPane.add(btnD);
	}
}
