package POLITECH;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class WB04 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextArea taDB;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) throws ClassNotFoundException {
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WB04 frame = new WB04();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WB04() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnConnect = new JButton("접속");
		btnConnect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection conn = DriverManager.getConnection(
							"jdbc:sqlserver://127.0.0.1:1433;"
									+"databaseName = CONFIGURE_LOCALLY;"
									+"user=mduser;"
									+"password=CONFIGURE_LOCALLY;"
									+"encrypt=true;"
									+"trustServerCertificate=true;");
					Statement stmt = conn.createStatement();
					ResultSet rset = stmt.executeQuery("SELECT * FROM BOOK");
					while(rset.next()) {
						taDB.append(Integer.toString(rset.getInt(1)));
						taDB.append("   ");
						taDB.append(rset.getString(2));
						taDB.append("   ");
						taDB.append(rset.getString(3));
						taDB.append("   ");
						taDB.append(Integer.toString(rset.getInt(4)));
						taDB.append("\n");
					}
					rset.close();
					stmt.close();
					conn.close();
				}catch(Exception e1) {}
			}
		});
		btnConnect.setBounds(12, 10, 97, 23);
		contentPane.add(btnConnect);
		
		taDB = new JTextArea();
		taDB.setEditable(false);
		taDB.setBounds(12, 43, 410, 208);
		contentPane.add(taDB);
	}
}
