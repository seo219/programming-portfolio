package POLITECH;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

class ButtonActionWin extends JFrame implements ActionListener{
	
	JButton btn1 = new JButton("OK");
	JButton btn2 = new JButton("Cancel");
	JLabel lb1 = new JLabel("버튼을 누르면 메세지가 출력됩니다.");
	
	ButtonActionWin() {	
		setSize(300,130);
		setTitle("버튼 이벤트 테스트 프로그램");
		
		designWin();
		
		setVisible(true);
		
	}
	
	void designWin() {
		JPanel p = new JPanel(new GridLayout(0,2));
		
		p.add(btn1);
		p.add(btn2);
		
		add(p,BorderLayout.CENTER);
		add(lb1,BorderLayout.SOUTH);
		
		btn1.addActionListener(this);
		btn2.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent evt) {
		
		String strCmd = evt.getActionCommand();
		
		if(strCmd.equals("OK")) {
			lb1.setText("OK버튼이 눌러졌습니다.");
		}
		
		if (strCmd.equals("Cancel")){
			lb1.setText("Cancel버튼이 눌러졌습니다.");
		}
		
	}
	
}

public class Swing07 {

	public static void main(String[] args) {
		ButtonActionWin win = new ButtonActionWin();
		

	}

}
