package POLITECH;

import java.awt.GridLayout;
import java.util.Date;

import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

class TestComp extends JFrame {
	TestComp() {
		setSize(600, 200);
		setTitle("입력 컴포넌트 테스트");
		setVisible(true);
		
	}
	
	void Decorate() {
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		JPanel p3 = new JPanel();
		
		p1.setLayout(new GridLayout(0, 1, 20, 5));
		p2.setLayout(new GridLayout(0, 1, 20, 5));
		p3.setLayout(new GridLayout(0, 2, 20, 5));
		
		JLabel l1 = new JLabel("이름 :");
		JLabel l2 = new JLabel("암호 :");
		JLabel l3 = new JLabel("생일 :");
		
		p1.add(l1);
		p1.add(l2);
		p1.add(l3);
		
		JTextField tf = new JTextField();
		tf.setText("홍길동");
		
		JPasswordField pwd = new JPasswordField();
		pwd.setEchoChar('*');
		
		JFormattedTextField date = new JFormattedTextField();
		date.setValue(new Date());
		
		p2.add(tf);
		p2.add(pwd);
		p2.add(date);
		
		JLabel l4 = new JLabel("메모 :");
		JTextArea ta = new JTextArea(5, 30);
		
		p3.add(l4);
		p3.add(ta);
		
		add(p1, "West");
		add(p2, "Center");
		add(p3, "South");
		
		setVisible(true);
		
	}
	
}

public class Swing06 {

	public static void main(String[] args) {
		TestComp f = new TestComp();
		f.Decorate();
	}

}
