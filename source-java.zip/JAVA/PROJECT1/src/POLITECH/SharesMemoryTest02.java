package POLITECH;

import java.util.Scanner;

class SharesMemory{
	int x = 5;
	Boolean isQuit = false;
	String word = "hello";
}

class PlusThread extends Thread{
	SharesMemory shmem;
	public void run() {
		while(!shmem.isQuit) {
			System.out.println("x = " + shmem.x);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			shmem.x++;
		}
	}
}

class MinusThread extends Thread{
	SharesMemory shmem;
	public void run() {
		Scanner sc = new Scanner(System.in);
		String pword;
		while(shmem.x != 0) {
			pword = sc.nextLine();
			if (pword .equals("hello")) {
				shmem.x--;
			}
		}
		System.out.println("x가 0입니다. 당신이 이겼습니다.");
		shmem.isQuit = true;
	}
}

public class SharesMemoryTest02 {

	public static void main(String[] args) {
		SharesMemory shobj = new SharesMemory();
		
		PlusThread pt = new PlusThread();
		MinusThread mt = new MinusThread();
		
		pt.shmem = shobj;
		mt.shmem = shobj;
		
		pt.start();
		mt.start();
	}
}

