package POLITECH;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseEvent;

public class WB01 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField fName;
	private JLabel lblOutput;
	private JLabel lblPos;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WB01 frame = new WB01();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public WB01() {
		setTitle("WindowBuilder_Test01");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				lblPos.setText("(" + e.getX() + ", " + e.getY() + ")");
			}
		});
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton Bnt1 = new JButton("설정");
		Bnt1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = fName.getText();
				lblOutput.setText(name + "님 환영합니다.");
			}
		});
		Bnt1.setBounds(342, 9, 80, 23);
		Bnt1.setFont(new Font("한컴산뜻돋움", Font.BOLD, 11));
		contentPane.add(Bnt1);

		fName = new JTextField();
		fName.setBounds(12, 10, 318, 21);
		contentPane.add(fName);
		fName.setColumns(10);

		lblOutput = new JLabel("환영 메세지 출력 란");
		lblOutput.setBounds(12, 41, 410, 21);
		contentPane.add(lblOutput);

		lblPos = new JLabel("(0, 0)");
		lblPos.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		lblPos.setBounds(12, 72, 410, 23);
		contentPane.add(lblPos);
	}
}
