package POLITECH;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

class GridWin extends JFrame {	
	GridWin(String title) {
		setSize(300, 200);
		setTitle("전화기 버튼 윈도우");
		
		setLayout(new GridLayout(4, 3, 10, 10));
		
		add(new JButton("1"));
		add(new JButton("2"));
		add(new JButton("3"));
		add(new JButton("4"));
		add(new JButton("5"));
		add(new JButton("6"));
		add(new JButton("7"));
		add(new JButton("8"));
		add(new JButton("9"));
		add(new JButton("*"));
		add(new JButton("0"));
		add(new JButton("#"));
		
		setVisible(true);
	}
}

public class Swing04 {

	public static void main(String[] args) {
		GridWin win = new GridWin("");
		
	}

}
