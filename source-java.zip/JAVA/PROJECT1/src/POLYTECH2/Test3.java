package POLYTECH2;

import POLITECH.*;

public class Test3 {

	public static void main(String[] args) {
		
		Plus p = new Plus();
		System.out.println(p.doit());
		
		System.out.println("test3");

	}

}
