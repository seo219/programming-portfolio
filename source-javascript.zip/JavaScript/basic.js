// 함수 선언문
function add(a, b){
    let sum = a + b;
    return sum;
}

function add2(a, b){
    return a + b;
}

console.log(add(1, 2));
console.log(add2(1, 2));

// 함수 표현식
const mul = function(a, b){
    return a * b;
}

console.log(mul(3, 1));