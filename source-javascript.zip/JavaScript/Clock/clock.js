// ================== 디지털 시계 (확장판) ==================
// 요구사항
// 1) 초 이하의 시간(밀리초) 표기 + '밀리초 숨기기' 버튼
// 2) 24시간/12시간 전환 버튼
// 3) 다른 나라 시간 표시 + 서울과의 시차 안내
// 4) '수정된 부분'에 대해 주석으로 상세 설명
//
// 이 파일은 원본 clock.js의 구조를 보존하면서 기능을 확장했습니다.
// (원본에는 12시간제 고정, 초까지만 표기, 윤년 체크만 존재)  [변경/추가 설명은 각 블록의 주석 참고]
//
// 원본의 getDayName, isLeapYear는 유지하여 호환성을 확보했습니다.
// ============================================================

function isLeapYear(year) {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}

// 요일 한국어 표기 (원본 유지)
function getDayName(dayIndex) {
  const days = ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'];
  return days[dayIndex];
}

// -------------------- [추가] 전역 상태 --------------------
// 24시간제/밀리초 표시 여부와 타임존 목록을 한 곳에서 관리합니다.
const state = {
  use24h: false,            // [추가] 24시간제 토글 상태 (기본: 12시간제)
  showMillis: true,         // [추가] 밀리초 표시 토글 상태 (기본: 보이기)
  timezones: new Set([      // [추가] 표시할 타임존 목록 (중복 방지용 Set)
    'Asia/Seoul',           // 기준(서울) 포함
    'America/New_York',
    'Europe/London',
  ]),
};

// 업데이트 주기 관리용
let tickerId = null;        // [추가] setInterval id 저장

// -------------------- [추가] DOM 참조 --------------------
const elClock = document.getElementById('clock');
const elDate = document.getElementById('date');
const elToggle24h = document.getElementById('toggle-24h');
const elToggleMs = document.getElementById('toggle-ms');
const elTzInput = document.getElementById('tz-input');
const elTzAdd = document.getElementById('btn-add-tz');
const elTzList = document.getElementById('tz-list-view');

// -------------------- [추가] 유틸: 0채우기 --------------------
const pad2 = (n) => String(n).padStart(2, '0');
const pad3 = (n) => String(n).padStart(3, '0');

// -------------------- [추가] 특정 타임존의 Date 객체 구하기 --------------------
// JS의 Date는 내부적으로 UTC 타임스탬프만 가지므로,
// Intl API를 사용해 '문자열'로 포맷하거나, 동일 타임스탬프 기준으로 표기만 변환합니다.
// 여기서는 현재 시각(now)을 기준으로, 표기는 Intl에서 타임존을 지정해 변환합니다.
function formatDateTime(now, timeZone, use24h, showMillis) {
  // 시간 구성 요소를 parts로 안전하게 뽑아옵니다.
  // (브라우저 호환성 상 formatToParts 사용)
  const parts = new Intl.DateTimeFormat('ko-KR', {
    timeZone,
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    weekday: 'long',
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric',
    hour12: !use24h,
  }).formatToParts(now);

  const getPart = (type) => parts.find((p) => p.type === type)?.value;
  // Intl은 밀리초를 직접 제공하지 않으므로, 원시 now에서 가져오되 문자열로 붙입니다.
  const ms = now.getMilliseconds();

  const year = getPart('year');
  const month = getPart('month');
  const day = getPart('day');
  const weekday = getPart('weekday');

  let hour = getPart('hour');
  const minute = getPart('minute');
  const second = getPart('second');
  const dayPeriod = getPart('dayPeriod'); // 오전/오후 (12시간제일 때만 존재)

  // 일부 브라우저에서 'hour'가 1자리일 수 있어 보정
  hour = pad2(hour);

  // 시간 문자열 만들기
  let timeStr = '';
  if (use24h) {
    timeStr = `${hour}:${minute}:${second}`;
  } else {
    // 12시간제: Intl이 이미 1~12 범위로 반환하므로 그대로 사용
    timeStr = `${dayPeriod ? dayPeriod + ' ' : ''}${hour}:${minute}:${second}`;
  }
  if (showMillis) {
    timeStr += `.${pad3(ms)}`;
  }

  // 날짜 문자열
  const dateStr = `${year}년 ${month}월 ${day}일 (${weekday})`;
  return { timeStr, dateStr };
}

// -------------------- [추가] 타임존 오프셋(분) 계산 --------------------
// Seoul 기준 시차 표기를 위해, 주어진 timeZone의 오프셋(분)을 계산합니다.
// 최신 브라우저는 timeZoneName: 'shortOffset'/'longOffset'를 지원하므로 이를 파싱합니다.
function getTimeZoneOffsetMinutes(timeZone, now = new Date()) {
  // 예시 출력: 'GMT+9', 'UTC+09:00' 등
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone,
    timeZoneName: 'shortOffset',
    hour: '2-digit',
  });
  const str = fmt.format(now); // 예: "10 GMT+9"
  const match = str.match(/GMT([+-])(\d{1,2})(?::(\d{2}))?/)
             || str.match(/UTC([+-])(\d{1,2})(?::(\d{2}))?/);
  if (!match) return null;

  const sign = match[1] === '-' ? -1 : 1;
  const h = parseInt(match[2], 10) || 0;
  const m = parseInt(match[3] || '0', 10);
  return sign * (h * 60 + m);
}

// -------------------- [추가] 로컬(서울) 기준 시차 문자열 만들기 --------------------
function formatOffsetDiff(targetTz, now = new Date()) {
  const seoulTz = 'Asia/Seoul';
  const a = getTimeZoneOffsetMinutes(seoulTz, now);
  const b = getTimeZoneOffsetMinutes(targetTz, now);
  if (a == null || b == null) return '시차: 계산 불가';
  const diff = b - a; // target - seoul (분)
  const sign = diff === 0 ? '' : diff > 0 ? '+' : '-';
  const abs = Math.abs(diff);
  const h = Math.floor(abs / 60);
  const m = abs % 60;
  return `시차: ${sign}${h}시간${m ? ' ' + m + '분' : ''} (서울 기준)`;
}

// -------------------- [변경] 기존 updateClock 확장 --------------------
// 원본은 12시간제 고정 + 초단위 갱신.
// 여기서는 (1) 24시간/12시간 토글, (2) 밀리초 표시, (3) 다른 나라 시간 리스트 갱신까지 담당합니다.
function updateClock() {
  const now = new Date();

  // 1) 로컬(기기 설정 타임존) 시각 표시
  const { timeStr, dateStr } = formatDateTime(
    now,
    Intl.DateTimeFormat().resolvedOptions().timeZone, // 현재 브라우저 타임존
    state.use24h,
    state.showMillis
  );
  elClock.textContent = timeStr;
  elDate.textContent = dateStr;

  // 2) 타임존 리스트 갱신
  renderTimezoneList(now);
}

// -------------------- [추가] 타임존 리스트 렌더링 --------------------
function renderTimezoneList(now) {
  const list = Array.from(state.timezones);
  elTzList.innerHTML = '';
  list.forEach((tz) => {
    const { timeStr, dateStr } = formatDateTime(now, tz, state.use24h, state.showMillis);
    const li = document.createElement('li');
    li.className = 'tz-item';

    const main = document.createElement('div');
    main.className = 'tz-main';

    const title = document.createElement('div');
    title.className = 'tz-title';
    const nameEl = document.createElement('span');
    nameEl.textContent = tz;
    const offsetEl = document.createElement('span');
    offsetEl.className = 'tz-offset';
    offsetEl.textContent = formatOffsetDiff(tz, now);

    title.appendChild(nameEl);
    title.appendChild(offsetEl);

    const timeEl = document.createElement('div');
    timeEl.className = 'tz-time';
    timeEl.textContent = timeStr;

    const dateEl = document.createElement('div');
    dateEl.className = 'tz-date';
    dateEl.textContent = dateStr;

    main.appendChild(title);
    main.appendChild(timeEl);
    main.appendChild(dateEl);

    const removeBtn = document.createElement('button');
    removeBtn.className = 'tz-remove';
    removeBtn.setAttribute('aria-label', `${tz} 제거`);
    removeBtn.textContent = '×';
    removeBtn.addEventListener('click', () => {
      state.timezones.delete(tz);
      renderTimezoneList(now);
    });

    li.appendChild(main);
    li.appendChild(removeBtn);
    elTzList.appendChild(li);
  });
}

// -------------------- [추가] 타임존 유효성 검사 --------------------
function isValidTimeZone(tz) {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: tz }).format();
    return true;
  } catch {
    return false;
  }
}

// -------------------- [추가] 이벤트 바인딩 --------------------
elToggle24h?.addEventListener('change', (e) => {
  state.use24h = e.target.checked;
  updateClock();       // 즉시 반영
});

elToggleMs?.addEventListener('change', (e) => {
  state.showMillis = e.target.checked;
  startTicker();       // 갱신 주기를 재설정 (밀리초 on이면 더 빠르게)
});

elTzAdd?.addEventListener('click', () => {
  const tz = (elTzInput.value || '').trim();
  if (!tz) return;
  if (!isValidTimeZone(tz)) {
    alert('유효한 IANA 타임존이 아닙니다. 예: America/New_York, Europe/London');
    return;
  }
  state.timezones.add(tz);
  elTzInput.value = '';
  updateClock();
});

// -------------------- [추가] 갱신 주기 관리 --------------------
// 밀리초를 표시할 때는 더 촘촘히(약 30~50ms), 숨길 때는 1초 간격으로 업데이트합니다.
function startTicker() {
  if (tickerId) clearInterval(tickerId);
  const interval = state.showMillis ? 33 : 1000; // 30fps 느낌
  tickerId = setInterval(updateClock, interval);
  updateClock(); // 즉시 1회 갱신
}

// 초기 구동
startTicker();
