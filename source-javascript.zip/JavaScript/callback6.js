// 쇼핑몰 시나리오, 콜백 지옥

// 3개의 함수 필요
// 3개의 함수 모두 네트워크 통신 필요 => 비동기 함수
// 3개의 함수가 순서대로 연동

// 1. 로그인
function login(username, callback) {
    setTimeout(() => {
        callback(username);
    }, 1000);
}

login('seo', (username) => {
    console.log(`${username}님 안녕하세요.`);

});

// 2. 장바구니 넣기
function addToCart(product, callback) {
        setTimeout(() => {
            callback(product);
    }, 1000);
}

addToCart('snack', (product) => {
    console.log(`${product}를 장바구니에 담았습니다.`);

});

// 3. 결제
function payment(cardNum, product, callback) {
        setTimeout(() => {
            callback(cardNum, product);
    }, 1000);
}

payment('0000111122223333', 'snack', (cardNum, product) => {
    console.log(`${cardNum}번호인 카드로 ${product}를(을) 결제하셨습니다.`);
});


login('seo', (username) => {
    console.log(`${username}님 안녕하세요.`);
    addToCart('snack', (product) => {
        console.log(`${product}를 장바구니에 담았습니다.`);
        payment('0000111122223333', 'snack', (cardNum, product) => {
            console.log(`${cardNum.slice(0,6)}카드로 ${product}를(을) 결제하셨습니다.`);
        });
    });
});

// 콜백 지옥 해결 : promise
// 유튜브 별코딩 비동기시리즈 4편 ㅊㅊ