const add = (a, b) => a + b;
const mul = (a, b) => a * b;

function calc(a, b, callback) {
    let result = callback(a, b);
    console.log(result);
    return result;
}

calc(1, 2, add);
calc(1, 2, mul);