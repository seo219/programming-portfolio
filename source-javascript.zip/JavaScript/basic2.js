//console.log(mul(3, 1)); 출력 안됨 -> 호이스팅 불가능
console.log(add2(1, 2)); // 출력 됨 -> 호이스팅 가능

// 함수 선언문
function add(a, b){
    let sum = a + b;
    return sum;
}

function add2(a, b){
    return a + b;
}

// console.log(add(1, 2));
// console.log(add2(1, 2));

// 함수 표현식
// 호이스팅이 안됨
const mul = function(a, b){
    return a * b;
}

// console.log(mul(3, 1));