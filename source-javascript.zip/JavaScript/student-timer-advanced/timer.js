// ===================== Theme Toggle =====================
const root = document.body;
const themeToggleBtn = document.getElementById('themeToggle');

const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'light' || savedTheme === 'dark') {
  root.setAttribute('data-theme', savedTheme);
} else {
  root.setAttribute('data-theme', 'dark'); // 기본 다크
}

if (themeToggleBtn) {
  themeToggleBtn.addEventListener('click', () => {
    const current = root.getAttribute('data-theme');
    const next = current === 'light' ? 'dark' : 'light';
    root.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
  });
}

// ===================== 공용 엘리먼트 =====================
const progressBar = document.getElementById('progressBar');
const timerDisplay = document.querySelector('#timerDisplay');
const hourInput = document.querySelector('#hourInput');
const minInput  = document.querySelector('#minInput');
const secInput  = document.querySelector('#secInput');

// 타이머 버튼
const startButton  = document.querySelector('.startBtn');
const pauseButton  = document.querySelector('.pauseBtn');
const resumeButton = document.querySelector('.resumeBtn');
const resetButton  = document.querySelector('.resetBtn');

// 스톱워치 버튼
const swStartButton  = document.querySelector('.swStartBtn');
const swPauseButton  = document.querySelector('.swPauseBtn');
const swResumeButton = document.querySelector('.swResumeBtn');
const swResetButton  = document.querySelector('.swResetBtn');
const swRecordButton = document.querySelector('.swRecordBtn');
const recordDisplay  = document.querySelector('#recordDisplay');

// ===================== 타이머 상태 =====================
let totalMiliSecond = 0;
let remainMiliSecond = 0;
let intervalID;
let isPause = false;

// ===================== 스톱워치 상태 =====================
let swTotalMiliSecond = 0;
let swIntervalID;
let swIsPause = false;
let swRecords = [];

// ===================== 버튼 상태 제어 =====================
// 타이머 상태: 'idle' | 'running' | 'paused' | 'finished' | 'locked'
function setTimerButtons(state) {
  // 기본값
  let start = true, pause = true, resume = true, reset = true;

  switch (state) {
    case 'idle': // 아무것도 안 돌 때
      start = false; pause = true; resume = true; reset = true;
      break;
    case 'running': // 실행 중
      start = true;  pause = false; resume = true;  reset = false;
      break;
    case 'paused': // 일시정지
      start = true;  pause = true;  resume = false; reset = false;
      break;
    case 'finished': // 종료됨
      start = false; pause = true;  resume = true;  reset = false;
      break;
    case 'locked': // 스톱워치가 실행 중이라 타이머 잠금
      start = true;  pause = true;  resume = true;  reset = true;
      break;
  }

  if (startButton)  startButton.disabled  = start;
  if (pauseButton)  pauseButton.disabled  = pause;
  if (resumeButton) resumeButton.disabled = resume;
  if (resetButton)  resetButton.disabled  = reset;
}

// 스톱워치 상태: 'idle' | 'running' | 'paused' | 'locked'
function setStopwatchButtons(state) {
  let start = true, pause = true, resume = true, reset = true, record = true;

  switch (state) {
    case 'idle':
      start = false; pause = true;  resume = true;  reset = true;  record = true;
      break;
    case 'running':
      start = true;  pause = false; resume = true;  reset = false; record = false;
      break;
    case 'paused':
      start = true;  pause = true;  resume = false; reset = false; record = false;
      break;
    case 'locked': // 타이머가 실행 중이라 스톱워치 잠금
      start = true;  pause = true;  resume = true;  reset = true;  record = true;
      break;
  }

  if (swStartButton)  swStartButton.disabled  = start;
  if (swPauseButton)  swPauseButton.disabled  = pause;
  if (swResumeButton) swResumeButton.disabled = resume;
  if (swResetButton)  swResetButton.disabled  = reset;
  if (swRecordButton) swRecordButton.disabled = record;
}

// 초기 버튼 상태
setTimerButtons('idle');
setStopwatchButtons('idle');

// ===================== 이벤트 바인딩 =====================
if (startButton)  startButton.addEventListener('click', startTimer);
if (pauseButton)  pauseButton.addEventListener('click', pauseTimer);
if (resumeButton) resumeButton.addEventListener('click', resumeTimer);
if (resetButton)  resetButton.addEventListener('click', resetTimer);

if (swStartButton)  swStartButton.addEventListener('click', startStopWatch);
if (swPauseButton)  swPauseButton.addEventListener('click', pauseStopWatch);
if (swResumeButton) swResumeButton.addEventListener('click', resumeStopWatch);
if (swResetButton)  swResetButton.addEventListener('click', resetStopWatch);
if (swRecordButton) swRecordButton.addEventListener('click', recordTime);

// 입력에서 Enter로 타이머 시작 + 음수 방지
[hourInput, minInput, secInput].forEach(el => {
  if (!el) return;
  el.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') startTimer();
    if (e.key === '-') e.preventDefault();
  });
});

// ===================== 타이머 =====================
function startTimer() {
  clearInterval(intervalID);
  isPause = false;

  const hour = parseInt(hourInput?.value) || 0;
  const min  = parseInt(minInput?.value)  || 0;
  const sec  = parseInt(secInput?.value)  || 0;

  // 유효성 검사
  if (hour < 0 || min < 0 || sec < 0 || (hour === 0 && min === 0 && sec === 0)) {
    alert('유효한 시간을 입력하세요.');
    resetTimer(); // 안전 초기화
    return;
  }

  totalMiliSecond  = ((hour * 3600) + (min * 60) + sec) * 1000;
  remainMiliSecond = totalMiliSecond;

  if (progressBar) progressBar.style.width = '100%';
  updateDisplay();

  // 타이머 시작 → 버튼 상태
  setTimerButtons('running');
  // 스톱워치 잠금
  setStopwatchButtons('locked');

  intervalID = setInterval(() => {
    if (!isPause) {
      remainMiliSecond -= 10;
      updateDisplay();
    }
    if (remainMiliSecond <= 0) {
      clearInterval(intervalID);
      playEndSound();
      if (timerDisplay) timerDisplay.textContent = '시간 종료';
      if (progressBar) progressBar.style.width = '0%';

      // 종료 → 버튼 상태
      setTimerButtons('finished');
      setStopwatchButtons('idle'); // 잠금 해제(대기)
    }
  }, 10);
}

function pauseTimer() {
  isPause = true;
  setTimerButtons('paused');
}

function resumeTimer() {
  if (remainMiliSecond > 0) {
    isPause = false;
    setTimerButtons('running');
  }
}

function resetTimer() {
  clearInterval(intervalID);
  totalMiliSecond = 0;
  remainMiliSecond = 0;
  isPause = false;

  if (timerDisplay) timerDisplay.textContent = '00:00:00.00';
  if (hourInput) hourInput.value = '';
  if (minInput)  minInput.value  = '';
  if (secInput)  secInput.value  = '';
  if (progressBar) progressBar.style.width = '0%';

  // 리셋 → 버튼 상태
  setTimerButtons('idle');
  setStopwatchButtons('idle'); // 스톱워치 잠금 해제
}

function updateDisplay() {
  const h  = Math.floor(remainMiliSecond / 3600000);
  const m  = Math.floor((remainMiliSecond % 3600000) / 60000);
  const s  = Math.floor((remainMiliSecond % 60000) / 1000);
  const cs = Math.floor((remainMiliSecond % 1000) / 10);

  if (timerDisplay) {
    timerDisplay.textContent =
      `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${String(cs).padStart(2,'0')}`;
  }

  if (progressBar) {
    if (totalMiliSecond > 0) {
      const ratio = Math.max(0, remainMiliSecond) / totalMiliSecond;
      progressBar.style.width = `${(ratio * 100).toFixed(2)}%`;
    } else {
      progressBar.style.width = '0%';
    }
  }
}

function playEndSound() {
  const audio = document.querySelector('#endSound');
  if (audio) audio.play().catch(() => {/* 자동재생 차단 시 무시 */});
}

// ===================== 스톱워치 =====================
function startStopWatch() {
  clearInterval(swIntervalID);
  swIsPause = false;

  // 스톱워치 시작 → 버튼 상태
  setStopwatchButtons('running');
  // 타이머 잠금
  setTimerButtons('locked');

  swIntervalID = setInterval(() => {
    if (!swIsPause) {
      swTotalMiliSecond += 10;
      swUpdateDisplay();
    }
  }, 10);
}

function pauseStopWatch() {
  swIsPause = true;
  setStopwatchButtons('paused');
}

function resumeStopWatch() {
  swIsPause = false;
  setStopwatchButtons('running');
}

function resetStopWatch() {
  clearInterval(swIntervalID);
  swTotalMiliSecond = 0;
  swIsPause = false;
  swRecords = [];

  if (timerDisplay) timerDisplay.textContent = '00:00:00.00';
  if (recordDisplay) recordDisplay.textContent = '저장된 기록이 없습니다.';

  // 리셋 → 버튼 상태
  setStopwatchButtons('idle');
  setTimerButtons('idle'); // 타이머 잠금 해제
}

function recordTime() {
  if (swIntervalID == null) return; // 실행 전 기록 방지
  if (swRecords.length >= 5) swRecords.shift();

  const h  = Math.floor(swTotalMiliSecond / 3600000);
  const m  = Math.floor((swTotalMiliSecond % 3600000) / 60000);
  const s  = Math.floor((swTotalMiliSecond % 60000) / 1000);
  const cs = Math.floor((swTotalMiliSecond % 1000) / 10);

  const timeRecord = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${String(cs).padStart(2,'0')}`;
  swRecords.push(timeRecord);
  updateRecordDisplay();
}

function updateRecordDisplay() {
  if (!recordDisplay) return;
  if (swRecords.length === 0) {
    recordDisplay.textContent = '저장된 기록이 없습니다.';
  } else {
    recordDisplay.innerHTML = swRecords.map(r => `<p>${r}</p>`).join('');
  }
}

function swUpdateDisplay() {
  const h  = Math.floor(swTotalMiliSecond / 3600000);
  const m  = Math.floor((swTotalMiliSecond % 3600000) / 60000);
  const s  = Math.floor((swTotalMiliSecond % 60000) / 1000);
  const cs = Math.floor((swTotalMiliSecond % 1000) / 10);

  if (timerDisplay) {
    timerDisplay.textContent =
      `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${String(cs).padStart(2,'0')}`;
  }
}
