// 비동기
// console.log('작업1');

// setTimeout(() => {
//     console.log('작업2');
// }, 3000)

console.log('시작');

setTimeout(() => {
    console.log('작업2');
}, 3000)

console.log('작업1');

