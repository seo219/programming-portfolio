const pad2 = (n) => String(n).padStart(2, '0');
const pad3 = (n) => String(n).padStart(3, '0');
const dayNames = ['일요일','월요일','화요일','수요일','목요일','금요일','토요일'];

let use24h = false;
let showMillis = true;

const elLocalClock = document.getElementById('localClock');
const elLocalDate  = document.getElementById('localDate');
const elLocalTz    = document.getElementById('localTzLabel');

const elOtherClock = document.getElementById('otherClock');
const elOtherDate  = document.getElementById('otherDate');
const elOffsetMeta = document.getElementById('offsetMeta');
const elTzSelect   = document.getElementById('tzSelect');

const btnFormat  = document.getElementById('toggleFormat');
const btnMillis  = document.getElementById('toggleMillis');

function tzOffsetMinutes(date, timeZone) {
  const dtf = new Intl.DateTimeFormat('en-GB', {
    timeZone,
    hour12: false,
    year:'numeric', month:'2-digit', day:'2-digit',
    hour:'2-digit', minute:'2-digit', second:'2-digit'
  });
  const parts = dtf.formatToParts(date);
  const get = (t) => +parts.find(p => p.type === t).value;
  const y = get('year'), m = get('month'), d = get('day');
  const hh = get('hour'), mm = get('minute'), ss = get('second');
  const ms = date.getMilliseconds();
  const asUTC = Date.UTC(y, m - 1, d, hh, mm, ss, ms);
  return (asUTC - date.getTime()) / 60000;
}

function offsetStrFromMinutes(mins) {
  const sign = mins >= 0 ? '+' : '-';
  const abs = Math.abs(mins);
  const h = Math.floor(abs / 60), m = abs % 60;
  return `UTC${sign}${pad2(h)}:${pad2(m)}`;
}

function formatTimeParts(date, timeZone, use24) {
  const dtf = new Intl.DateTimeFormat('ko-KR', {
    timeZone,
    hour12: !use24,
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
  const parts = dtf.formatToParts(date);
  const get = (t) => parts.find(p => p.type === t)?.value ?? '';
  return {
    ampm: (!use24 ? (get('dayPeriod') ? get('dayPeriod') + ' ' : '') : ''),
    hh: get('hour'),
    mm: get('minute'),
    ss: get('second')
  };
}

function formatDateLine(date, timeZone) {
  const dtf = new Intl.DateTimeFormat('ko-KR', {
    timeZone,
    year:'numeric', month:'2-digit', day:'2-digit', weekday:'long'
  });
  const parts = dtf.formatToParts(date);
  const map = Object.fromEntries(parts.map(p => [p.type, p.value]));
  return `${map.year}년 ${map.month}월 ${map.day}일 (${map.weekday})`;
}

let rafId = null;
function render(now = new Date()) {
  const localTz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Local';
  const localOffsetMin = -now.getTimezoneOffset();
  elLocalTz.textContent = `${localTz} · ${offsetStrFromMinutes(localOffsetMin)}`;

  const lp = formatTimeParts(now, localTz, use24h);
  const millis = pad3(now.getMilliseconds());
  let localTimeStr = `${lp.ampm}${lp.hh}:${lp.mm}:${lp.ss}`;
  if (showMillis)  localTimeStr += `.${millis}`;
  elLocalClock.textContent = localTimeStr;
  elLocalDate.textContent  = formatDateLine(now, localTz);

  const tz = elTzSelect.value;
  const op = formatTimeParts(now, tz, use24h);
  let otherTimeStr = `${op.ampm}${op.hh}:${op.mm}:${op.ss}`;
  if (showMillis)  otherTimeStr += `.${millis}`;
  elOtherClock.textContent = otherTimeStr;
  elOtherDate.textContent  = formatDateLine(now, tz);

  const otherOffsetMin = tzOffsetMinutes(now, tz);
  const seoulOffsetMin = tzOffsetMinutes(now, 'Asia/Seoul');
  const diffHours = (otherOffsetMin - seoulOffsetMin) / 60;
  const sign = diffHours >= 0 ? '+' : '−';
  const diffStr = Number.isInteger(diffHours) ? `${sign}${Math.abs(diffHours)}` : `${sign}${Math.abs(diffHours).toFixed(1)}`;
  elOffsetMeta.textContent = `${offsetStrFromMinutes(otherOffsetMin)} · 서울 대비 ${diffStr}시간`;
}

function loop() {
  render(new Date());
  rafId = requestAnimationFrame(loop);
}

btnFormat.addEventListener('click', () => {
  use24h = !use24h;
  btnFormat.setAttribute('aria-pressed', String(use24h));
  btnFormat.textContent = use24h ? '12시간' : '24시간';
});

btnMillis.addEventListener('click', () => {
  showMillis = !showMillis;
  btnMillis.setAttribute('aria-pressed', String(showMillis));
  btnMillis.textContent = showMillis ? '밀리초 숨기기' : '밀리초 보이기';
});

elTzSelect.addEventListener('change', () => render(new Date()));

document.addEventListener('visibilitychange', () => {
  if (document.hidden) cancelAnimationFrame(rafId);
  else loop();
});

loop();
