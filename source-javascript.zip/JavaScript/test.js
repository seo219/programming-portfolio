// const PI = 3.14;
// //PI = 3.15;

// const user = {name : "김성곤"}
// console.log(user);
// user.name = "홍길동";
// console.log(user);

// var name = "김철수";
// var name = "김안돼";

// console.log(name);

// let age = 20;
// //let age = 30;

// // new는 객체로 변환
// let d1 = Date();
// console.log(typeof d1, d1);
// let d2 = new Date();
// console.log(typeof d2, d2);


// querySlecetor("css 선택자") : 태그, .(클래스), #(아이디), ul>li 등
// querySlecetorAll("css 선택자")
// getElementByID("id")
// getElementsByClassName("class")
// getElementsByTagName("tag")
// querySlecetor("css 선택자") :
// querySlecetorAll("css 선택자") : 