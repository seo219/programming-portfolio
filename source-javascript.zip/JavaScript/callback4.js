// function main(param) {
//     param();
// };

// main(() => {});

function main(x) {
    x();
}

function sayHi() {
    console.log('Hi');
}

main(sayHi);