const mul = (a, b) => {
    return a * b;
}

console.log(mul(3, 1));

const mul1 = (a, b) => a * b;

console.log(mul1(3, 1));

function square(x) {
    return x*x;
}

const square = function(x){
    return x*x;
}

const square = (x) => x*x;

const square = x => x*x;

function greet(){
    return "hello";
}

const greet = () => "hello";
