// 동기 비동기
// console.log('작업1');
// console.log('작업2');
// console.log('작업3');

console.log('작업1');
print();
console.log('작업3');

function print() {
    console.log('작업2');
}