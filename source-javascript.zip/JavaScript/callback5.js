// function getData() {
//     setTimeout(() => {
//         console.log('서버에서 데이터를 받아왔어요...');

//     }, 2000);
// };

// getData(() => {
//     console.log('후처리');
// });


function getData(callback) {
    setTimeout(() => {
        console.log('서버에서 데이터를 받아왔어요...');
        callback();

    }, 2000);

};

getData(() => {
    console.log('후처리');
});

