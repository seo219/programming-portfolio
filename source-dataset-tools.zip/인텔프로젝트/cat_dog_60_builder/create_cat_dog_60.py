"""TensorFlow Cats and Dogs에서 고양이/개 사진 30장씩 저용량 JPG ZIP 만들기.

사용법:
    python -m pip install Pillow
    python create_cat_dog_60.py

선택 옵션:
    python create_cat_dog_60.py --size 128 --quality 65
"""

import argparse
import io
import random
import tempfile
import urllib.request
import zipfile
from pathlib import Path

from PIL import Image, ImageOps, UnidentifiedImageError

DATASET_URL = "https://storage.googleapis.com/mledu-datasets/cats_and_dogs_filtered.zip"


def download_archive(destination):
    req = urllib.request.Request(DATASET_URL, headers={"User-Agent": "Mozilla/5.0"})
    print("원본 사진 데이터 다운로드 중 (약 65MB, 다운로드 후 원본 자동 삭제)...")
    with urllib.request.urlopen(req, timeout=90) as response, open(destination, "wb") as out:
        while True:
            block = response.read(1024 * 1024)
            if not block:
                break
            out.write(block)
    print("다운로드 완료")


def create_dataset(src, output_path, image_size=96, quality=60, seed=2026):
    rng = random.Random(seed)
    with zipfile.ZipFile(src) as original:
        members = original.namelist()
        counts = {}
        with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_STORED) as output:
            for folder, original_folder in (("cat", "cats"), ("dog", "dogs")):
                candidates = [name for name in members if "/train/" in name.replace("\\", "/")
                              and f"/{original_folder}/" in name.replace("\\", "/")
                              and name.lower().endswith((".jpg", ".jpeg"))]
                rng.shuffle(candidates)
                used = 0
                for path in candidates:
                    try:
                        with Image.open(io.BytesIO(original.read(path))) as img:
                            img = ImageOps.exif_transpose(img).convert("RGB")
                            # 원본 비율을 유지하며 여백으로 정사각형 크기 통일
                            img = ImageOps.pad(img, (image_size, image_size), method=Image.Resampling.LANCZOS,
                                               color=(127, 127, 127))
                            buf = io.BytesIO()
                            img.save(buf, format="JPEG", quality=quality,
                                     optimize=True, subsampling=2)
                        output.writestr(f"{folder}/{folder}_{used+1:02d}.jpg", buf.getvalue())
                        used += 1
                        if used == 30:
                            break
                    except (OSError, ValueError, UnidentifiedImageError):
                        continue
                if used != 30:
                    raise RuntimeError(f"{folder} 사진이 {used}장밖에 준비되지 않았습니다.")
                counts[folder] = used

            readme = (
                "Cats vs Dogs 학습용 미니 데이터셋\n"
                "=================================\n"
                "cat/: 고양이 30장\n"
                "dog/: 개 30장\n"
                f"각 이미지: {image_size}x{image_size} 픽셀, RGB JPG, quality={quality}\n"
                "출처: TensorFlow 교육용 Cats and Dogs Filtered 데이터셋\n"
                f"원본 다운로드 URL: {DATASET_URL}\n"
                "용도: 학습 코드 실행 연습/소규모 프로토타입\n"
                "주의: 60장만으로는 실제 모델 성능을 신뢰하기 어렵습니다.\n"
                "데이터의 원래 라이선스와 사용 조건을 확인하세요.\n"
            )
            output.writestr("README.txt", readme.encode("utf-8-sig"))
    return counts


def main():
    parser = argparse.ArgumentParser(description="고양이/개 사진 각 30장 저용량 ZIP 생성")
    parser.add_argument("--size", type=int, default=96, help="정사각형 이미지 한 변 크기 (기본 96)")
    parser.add_argument("--quality", type=int, default=60, help="JPG 압축 품질 (기본 60)")
    parser.add_argument("--output", default="cats_dogs_60_small.zip", help="저장할 ZIP 파일 이름")
    args = parser.parse_args()
    if not 32 <= args.size <= 1024:
        parser.error("size는 32~1024 사이로 설정하세요")
    if not 30 <= args.quality <= 95:
        parser.error("quality는 30~95 사이로 설정하세요")

    output_path = Path(args.output).resolve()
    try:
        with tempfile.TemporaryDirectory() as temp:
            original_zip = Path(temp) / "cats_and_dogs_filtered.zip"
            download_archive(original_zip)
            counts = create_dataset(original_zip, output_path, args.size, args.quality)
        print(f"완료: {output_path}")
        print(f"고양이 {counts['cat']}장 + 개 {counts['dog']}장 = 60장")
        print(f"ZIP 크기: {output_path.stat().st_size / 1024:.1f} KB")
    except Exception as exc:
        if output_path.exists():
            output_path.unlink()
        print(f"생성 실패: {exc}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
