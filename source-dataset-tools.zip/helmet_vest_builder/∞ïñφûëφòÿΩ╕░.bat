@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Pillow 설치 확인 중...
py -m pip install Pillow
if errorlevel 1 (
  echo Pillow 설치 실패. 파이썬 설치 및 인터넷을 확인하세요.
  pause
  exit /b 1
)
py make_helmet_vest_60.py
pause
