"""Create a small, correctly annotated helmet/vest object-detection dataset.

Source: Atharion PPE v1.0 public, 1,130 images, mixed AGPL-3.0/CC-BY-4.0.
Output: 60 distinct real photos, YOLO detection labels, split train/val/test.
"""
import csv
import hashlib
import io
import random
import sys
import zipfile
from pathlib import Path, PurePosixPath
from urllib.request import Request, urlopen

try:
    from PIL import Image, ImageDraw
except ImportError:
    sys.exit("Pillow가 필요합니다. 먼저 실행하세요: py -m pip install pillow")

BASE = Path(__file__).resolve().parent
SOURCE_FILENAME = "atharion-v1.0-public.zip"
SOURCE_ARCHIVE = BASE / SOURCE_FILENAME
OUTPUT_ROOT = BASE / "helmet_vest_60_yolo"
OUTPUT_ZIP = BASE / "helmet_vest_60_yolo.zip"
SOURCE_URL = (
    "https://github.com/atharion-team/ppe-dataset-v1/"
    "releases/download/v1.0/atharion-v1.0-public.zip"
)
EXPECTED_SHA256 = "CONFIGURE_LOCALLY"
SPLITS = {"train": 24, "val": 3, "test": 3}
SOURCE_SPLIT = {"train": "train", "val": "valid", "test": "test"}
SIZE = 512  # maximum long side in px; preserve aspect and normalized box coordinates
JPG_QUALITY = 66


def file_sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def download_source():
    if SOURCE_ARCHIVE.is_file():
        print("원본 압축파일 확인:", SOURCE_ARCHIVE.name)
    else:
        print("원본 데이터셋 다운로드 시작 (약 94 MB, 인터넷 연결 필요)")
        print(SOURCE_URL)
        temp = SOURCE_ARCHIVE.with_suffix(".partial")
        req = Request(SOURCE_URL, headers={"User-Agent": "Mozilla/5.0 (education-dataset-builder)"})
        try:
            with urlopen(req, timeout=90) as src, temp.open("wb") as dest:
                n = 0
                while True:
                    chunk = src.read(1024 * 1024)
                    if not chunk:
                        break
                    dest.write(chunk)
                    n += len(chunk)
                    if n % (20 * 1024 * 1024) < len(chunk):
                        print(f"  {n // 1048576} MiB 수신")
            temp.replace(SOURCE_ARCHIVE)
        except Exception as exc:
            temp.unlink(missing_ok=True)
            sys.exit(
                "자동 다운로드 실패: " + str(exc) + "\n"
                "아래 주소에서 원본 ZIP을 내려받아 이 스크립트와 같은 폴더에 저장한 뒤 재실행하세요.\n"
                + SOURCE_URL
            )
    digest = file_sha256(SOURCE_ARCHIVE)
    if digest != EXPECTED_SHA256:
        sys.exit("원본 데이터셋 SHA256이 공개된 값과 다릅니다. 잘못된 파일 또는 불완전한 다운로드일 수 있습니다.\n"
                 f"실제: {digest}\n예상: {EXPECTED_SHA256}")
    print("원본 무결성 검사 통과")


def parse_box_lines(text):
    """Return remapped classes: 1 Hardhat -> 0 helmet, 2 Vest -> 1 vest."""
    kept = []
    cats = set()
    for line in text.splitlines():
        parts = line.split()
        if len(parts) != 5:
            continue
        try:
            cls = int(parts[0]); xywh = [float(s) for s in parts[1:]]
        except ValueError:
            continue
        if cls not in (1, 2) or not all(0 <= x <= 1 for x in xywh):
            continue
        if xywh[2] <= 0 or xywh[3] <= 0:
            continue
        new_class = 0 if cls == 1 else 1
        cats.add(new_class)
        kept.append((new_class, xywh))
    return kept, cats


def find_candidates(z):
    paths = set(z.namelist())
    candidates = {split: [] for split in SOURCE_SPLIT.values()}
    for path in sorted(paths):
        if not path.lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
            continue
        p = PurePosixPath(path)
        parts = p.parts
        if "images" not in parts:
            continue
        index = parts.index("images")
        if index == 0 or parts[index - 1] not in candidates:
            continue
        original_split = parts[index - 1]
        label_parts = list(parts)
        label_parts[index] = "labels"
        label_file = str(PurePosixPath(*label_parts).with_suffix(".txt"))
        if label_file not in paths:
            continue
        try:
            boxes, cats = parse_box_lines(z.read(label_file).decode("utf-8-sig"))
        except Exception:
            continue
        if cats:
            candidates[original_split].append({"image": path, "label": label_file, "boxes": boxes, "cats": cats})
    print("클래스 라벨이 있는 이미지 수:", {k: len(v) for k, v in candidates.items()})
    return candidates


def pick_images(candidates):
    """Separate, unique source images in two primary groups; honor original source splits."""
    randomizer = random.Random(20261019)
    chosen = []
    used = set()
    for split, count in SPLITS.items():
        pool = list(candidates[SOURCE_SPLIT[split]])
        randomizer.shuffle(pool)
        for target in (0, 1):
            # Prefer images labeled with this only target, then mixed-label images.
            preferred = [r for r in pool if r["cats"] == {target} and r["image"] not in used]
            mixed = [r for r in pool if target in r["cats"] and r["image"] not in used and r["cats"] != {target}]
            subset = (preferred + mixed)[:count]
            if len(subset) != count:
                raise RuntimeError(f"{split} 의 {['helmet','vest'][target]} 이미지 부족: {len(subset)} / {count}")
            for r in subset:
                used.add(r["image"])
                chosen.append({**r, "target": target, "split": split})
    if len(chosen) != 60 or len(used) != 60:
        raise RuntimeError("중복 없이 60장을 선택하지 못했습니다.")
    return chosen


def encode_jpg(data):
    with Image.open(io.BytesIO(data)) as loaded:
        rgb = loaded.convert("RGB")
        rgb.thumbnail((SIZE, SIZE), Image.Resampling.LANCZOS)
        output = io.BytesIO()
        rgb.save(output, "JPEG", quality=JPG_QUALITY, optimize=True, progressive=True)
        return output.getvalue(), rgb.size


def build():
    download_source()
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    manifest = []
    preview = []
    saved = set()
    with zipfile.ZipFile(SOURCE_ARCHIVE) as src:
        candidates = find_candidates(src)
        choices = pick_images(candidates)
        for split in SPLITS:
            (OUTPUT_ROOT / "images" / split).mkdir(parents=True, exist_ok=True)
            (OUTPUT_ROOT / "labels" / split).mkdir(parents=True, exist_ok=True)
        cnt = {(split, target): 0 for split in SPLITS for target in (0, 1)}
        for row in choices:
            raw = src.read(row["image"])
            h = hashlib.sha256(raw).hexdigest()
            if h in saved:
                raise RuntimeError("원본 이미지 내용이 중복됩니다. 선정 로직을 수정하세요: " + row["image"])
            saved.add(h)
            jpg, (width, height) = encode_jpg(raw)
            split, target = row["split"], row["target"]
            cnt[split, target] += 1
            main_class = ("helmet", "vest")[target]
            name = f"{main_class}_{split}_{cnt[split, target]:02d}"
            image_name = f"images/{split}/{name}.jpg"
            label_name = f"labels/{split}/{name}.txt"
            (OUTPUT_ROOT / image_name).write_bytes(jpg)
            label_data = "\n".join(f"{cls} " + " ".join(f"{v:.6f}" for v in box) for cls, box in row["boxes"]) + "\n"
            (OUTPUT_ROOT / label_name).write_text(label_data, encoding="utf-8")
            manifest.append({"image": image_name, "label": label_name, "primary_category": main_class,
                             "source_image": row["image"], "source_label": row["label"], "source_split": SOURCE_SPLIT[split],
                             "boxes_helmet": sum(t == 0 for t, _ in row["boxes"]),
                             "boxes_vest": sum(t == 1 for t, _ in row["boxes"]),
                             "width": width, "height": height})
            if len(preview) < 12 and (split == "train") and (cnt[split, target] <= 6):
                preview.append((jpg, row["boxes"], name))
        for info in src.infolist():
            if PurePosixPath(info.filename).name in ("NOTICE.md", "LICENSE"):
                dst = OUTPUT_ROOT / PurePosixPath(info.filename).name
                if not dst.exists():
                    dst.write_bytes(src.read(info))
    (OUTPUT_ROOT / "data.yaml").write_text(
        "# YOLO object detection dataset: 60 real images, helmet and safety vest\n"
        "path: .\ntrain: images/train\nval: images/val\ntest: images/test\nnc: 2\n"
        "names:\n  0: helmet\n  1: vest\n", encoding="utf-8"
    )
    with (OUTPUT_ROOT / "image_manifest.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=manifest[0].keys())
        writer.writeheader(); writer.writerows(manifest)
    readme = """HELMET + VEST YOLO DETECTION SAMPLE (60 real photographs)
=========================================================
- 30 images primarily selected for helmet, 30 for safety vest; 60 distinct files.
- The photo may contain BOTH classes; all annotated helmet and vest boxes are preserved.
- Labels use YOLO: class_id center_x center_y width height (normalized 0...1).
- Class 0 = helmet; class 1 = vest.
- 48 train, 6 val, 6 test (24/3/3 for each primary group), honoring source splits.
- Images are resized to maximum 512px (aspect ratio maintained), JPG quality 66.
- 'image_manifest.csv' gives original paths and annotation counts.

SOURCE AND LICENCES
Atharion PPE Dataset v1.0 public: https://github.com/atharion-team/ppe-dataset-v1
Upstream sources are Ultralytics Construction-PPE (AGPL-3.0)
and Roboflow Construction Site Safety v28 (CC BY 4.0).
Follow the applicable terms; source project NOTICE.md is included when present.

TRAIN (optional)
  pip install ultralytics
  yolo detect train model=yolo11n.pt data=data.yaml epochs=40 imgsz=512
Train from inside 'helmet_vest_60_yolo' directory (or provide absolute path to data.yaml).
This is a tiny educational sample; expect limited accuracy and test performance.
"""
    (OUTPUT_ROOT / "README.txt").write_text(readme, encoding="utf-8")
    # Preview grid with both types of boxes to help verify images and label conversion
    tile_w, tile_h = 240, 205
    canvas = Image.new("RGB", (4 * tile_w, 3 * tile_h), "#F8FAFC")
    d = ImageDraw.Draw(canvas)
    for i, (jpg, boxes, name) in enumerate(preview):
        col, row = i % 4, i // 4
        with Image.open(io.BytesIO(jpg)) as im:
            im.thumbnail((tile_w - 12, tile_h - 34))
            ox = col * tile_w + (tile_w - im.width) // 2
            oy = row * tile_h + 4
            canvas.paste(im, (ox, oy))
            for cls, (cx, cy, w, h) in boxes:
                color = "#EF4444" if cls == 0 else "#22C55E"
                left = ox + (cx - w / 2) * im.width
                top = oy + (cy - h / 2) * im.height
                right = ox + (cx + w / 2) * im.width
                bottom = oy + (cy + h / 2) * im.height
                d.rectangle((left, top, right, bottom), outline=color, width=2)
        d.text((col * tile_w + 5, row * tile_h + tile_h - 23), name, fill="#0F172A")
    d.text((5, 0), "red: helmet | green: vest", fill="#0F172A")
    canvas.save(OUTPUT_ROOT / "preview.jpg", quality=78, optimize=True)
    with zipfile.ZipFile(OUTPUT_ZIP, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=5) as z:
        for file in sorted(OUTPUT_ROOT.rglob("*")):
            if file.is_file():
                z.write(file, arcname=str(file.relative_to(OUTPUT_ROOT.parent)))
    print("\n완료:", OUTPUT_ZIP)
    print("사진", len(manifest), "장 / 각 클래스 주제 사진 30장")
    print("학습/검증/테스트:", {k: sum(a["source_split"] == SOURCE_SPLIT[k] for a in manifest) for k in SPLITS})
    print("박스 수:", {c: sum(a[f"boxes_{c}"] for a in manifest) for c in ("helmet", "vest")})
    print("압축 파일 크기:", f"{OUTPUT_ZIP.stat().st_size / (1024*1024):.2f} MiB")


if __name__ == "__main__":
    build()
