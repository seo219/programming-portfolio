"""하드웨어 없이 게임 API의 동작 순서와 실패 잠금을 확인합니다."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import robot_api
from test_slot_robot import FakeBus, fixture


class Bus(FakeBus):
    def connect(self):
        self.connected = True

    def disconnect(self, disable):
        self.connected = False


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        cfg, poses = fixture()
        root = Path(self.tmp.name)
        for name, data in [('config', cfg), ('poses', poses)]:
            (root / (name + '.json')).write_text(json.dumps(data), encoding='utf-8')
        self.bus = Bus()
        self.robot = robot_api.SlotRobot(root/'config.json', root/'poses.json', bus_factory=lambda _: self.bus)
        self.fingerprint = patch('robot_api.motion.fingerprint', return_value={})
        self.fingerprint.start()
        self.addCleanup(self.fingerprint.stop)
        self.addCleanup(self.robot.close)

    def test_plan_does_not_connect(self):
        self.assertEqual(self.robot.plan(0, 1)[-2:], [('arm', 'home'), ('grip', 'close')])
        self.assertIsNone(self.robot._bus)

    def test_success_checks_grasp_before_lift_and_returns_home(self):
        self.robot.cfg['approach_ticks_s'] = 60
        self.robot.connect()
        with patch('robot_api.motion.Controller') as cls:
            ctl = cls.return_value
            ctl.grip.side_effect = lambda mode: self.bus.positions.update(gripper=1080 if mode == 'close' else 1200)
            self.assertTrue(self.robot.move(0, 1))
            self.assertEqual(ctl.move.call_args.args[0], self.robot.poses['poses']['home'])
            self.assertEqual([c.kwargs['speed_ticks_s'] for c in ctl.move.call_args_list],
                             [300, 60, 300, 300, 300, 60, 300, 300])
            self.assertEqual(ctl.method_calls[-2][0], 'move')
            self.assertEqual(ctl.method_calls[-1][0], 'grip')
            self.assertEqual(ctl.method_calls[-1].args, ('close',))
            self.robot.home()

    def test_home_failure_does_not_close_gripper(self):
        self.robot.connect()
        with patch('robot_api.motion.Controller') as cls:
            ctl = cls.return_value
            ctl.grip.side_effect = lambda mode: self.bus.positions.update(gripper=1080 if mode == 'close' else 1200)
            calls = 0
            def move(target, **kwargs):
                nonlocal calls
                calls += 1
                if calls == 8:  # 마지막 HOME 이동
                    raise RuntimeError('home timeout')
            ctl.move.side_effect = move
            self.assertFalse(self.robot.move(0, 1))
            self.assertEqual([c.args for c in ctl.grip.call_args_list], [('open',), ('close',), ('open',)])

    def test_empty_grasp_stops_and_locks_retry(self):
        self.robot.connect()
        with patch('robot_api.motion.Controller') as cls:
            ctl = cls.return_value
            self.assertFalse(self.robot.move('cell_0', 'cell_1'))
            self.assertEqual(ctl.move.call_count, 2)  # 출발 위/집는 자세까지만
            ctl.hold.assert_called_once()
            with self.assertRaises(RuntimeError):
                self.robot.move(0, 1)
            with self.assertRaises(RuntimeError):
                self.robot.home()

    def test_wrong_start_rejected_before_prepare(self):
        self.bus.positions['elbow_flex'] = 1200
        with self.assertRaises(RuntimeError):
            self.robot.connect()
        self.assertFalse(self.bus.connected)

    def test_slot_names(self):
        self.assertEqual(robot_api.slot('center'), 'cell_22')
        self.assertEqual(robot_api.slot('wait_human'), 'wait_human')
        for invalid in (True, -1, 29, 'cell_29'):
            with self.assertRaises(ValueError):
                robot_api.slot(invalid)


if __name__ == '__main__':
    unittest.main()
