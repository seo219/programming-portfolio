"""CLI bridge example; invoking this function executes real motion.
Run from a serialized game command queue only. Initial operator confirmation remains.
"""
from pathlib import Path
import subprocess
import sys


def move_piece(source_cell: int, destination_cell: int):
    for cell in (source_cell, destination_cell):
        if type(cell) is not int or not 0 <= cell <= 28:
            raise ValueError('cell must be an integer from 0 to 28')
    script = Path(__file__).with_name('slot_robot.py')
    subprocess.run([
        sys.executable, str(script), 'move',
        '--src', f'cell_{source_cell}', '--dst', f'cell_{destination_cell}',
        '--execute', '--auto',
    ], check=True)
    # Caller must verify actual placement before committing game state.
