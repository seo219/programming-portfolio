import copy
import unittest
import slot_robot as s


def fixture():
    cfg={'units':'raw_encoder','port':'fake','calibration':{},
         'limits':{k:[0,4095] for k in s.NAMES},'speed_ticks_s':300,
         'gripper_speed_ticks_s':300,'hz':50,'tolerance_ticks':2,
         'following_error_ticks':150,'timeout_s':0.1,'gripper_settle_s':0.001,
         'start_tolerance_ticks':40,'gripper':{'open':1200,'close':1000,'holding_range':[1050,1100]},
         'home_to_slot':{'cell_0':['cell_0.above']},
         'slot_to_home':{'cell_1':['home']},'routes':{'cell_0->cell_1':['home','cell_1.above']}}
    poses={'units':'raw_encoder','port':'fake','calibration':{},'poses':{
        k:{joint:1000 for joint in s.ARM}
        for k in ['home','cell_0.above','cell_0.grasp','cell_1.above','cell_1.grasp']}}
    return cfg,poses


class FakeBus:
    def __init__(self,stuck=False):
        self.positions={k:1000 for k in s.NAMES}; self.writes=[]; self.stuck=stuck
    def sync_read(self,*args,**kwargs): return dict(self.positions)
    def sync_write(self,register,values,**kwargs):
        self.writes.append(dict(values))
        if not self.stuck: self.positions.update(values)


class Tests(unittest.TestCase):
    def test_pick_sequence_checks_before_lift(self):
        cfg,p=fixture(); a=s.plan(cfg,p,'cell_0','cell_1',True)
        check=a.index(('check','holding'))
        self.assertEqual(a[check-1],('grip','close'))
        self.assertEqual(a[check+1],('arm','cell_0.above'))
        self.assertEqual(a[-2:], [('arm','home'), ('grip','close')])
    def test_missing_pose_rejected(self):
        c,p=fixture(); del p['poses']['cell_1.grasp']
        with self.assertRaises(ValueError): s.plan(c,p,'cell_0','cell_1')
    def test_missing_route_rejected(self):
        c,p=fixture(); c['routes']={}
        with self.assertRaises(ValueError): s.plan(c,p,'cell_0','cell_1')
    def test_units_and_calibration_rejected(self):
        for field,value in [('units','degrees'),('calibration',{'changed':1}),('port','other')]:
            c,p=fixture(); p[field]=value
            with self.assertRaises(ValueError): s.plan(c,p,'cell_0','cell_1')
    def test_nonfinite_and_out_of_bounds(self):
        for v in [float('nan'),float('inf'),True,-1,4096]:
            c,p=fixture(); p['poses']['home']['elbow_flex']=v
            with self.assertRaises(ValueError): s.plan(c,p,'cell_0','cell_1')
    def test_auto_requires_grasp_measurement(self):
        c,p=fixture(); c['gripper']['holding_range']=None
        s.plan(c,p,'cell_0','cell_1')
        with self.assertRaises(ValueError): s.plan(c,p,'cell_0','cell_1',True)
    def test_arm_move_preserves_gripper_and_slew(self):
        c,_=fixture(); b=FakeBus(); b.positions['gripper']=1080
        s.Controller(b,c).move({k:1010 for k in s.ARM})
        self.assertEqual(b.positions['gripper'],1080)
        self.assertTrue(all('gripper' not in v for v in b.writes))
        self.assertEqual(b.positions['elbow_flex'],1010)
    def test_obstruction_stops_before_next_segment(self):
        c,_=fixture(); c['following_error_ticks']=2; b=FakeBus(stuck=True)
        with self.assertRaises(RuntimeError): s.Controller(b,c).move({k:1020 for k in s.ARM})
    def test_empty_grasp_cannot_pass_holding_range(self):
        c,p=fixture(); c['gripper']['holding_range']=[990,1100]
        with self.assertRaises(ValueError): s.plan(c,p,'cell_0','cell_1',True)


if __name__=='__main__': unittest.main()
