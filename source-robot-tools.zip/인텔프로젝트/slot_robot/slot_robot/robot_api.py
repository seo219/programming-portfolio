"""게임에서 호출하는 SO-101 말 이동 API. 관절값은 raw_encoder만 사용합니다."""
import threading
from pathlib import Path

import slot_robot as motion

ALIASES = {
    'diag_r1': 'cell_20', 'diag_r2': 'cell_21', 'center': 'cell_22',
    'diag_r3': 'cell_23', 'diag_r4': 'cell_24', 'diag_l1': 'cell_25',
    'diag_l2': 'cell_26', 'diag_l3': 'cell_27', 'diag_l4': 'cell_28',
}


def slot(value):
    """정수 칸 번호 또는 게임의 슬롯 이름을 받습니다."""
    if type(value) is int and 0 <= value <= 28:
        return f'cell_{value}'
    if isinstance(value, str):
        value = ALIASES.get(value, value)
        allowed = {f'cell_{i}' for i in range(29)} | {
            'wait_robot', 'wait_human', 'goal_robot', 'goal_human'}
        if value in allowed:
            return value
    raise ValueError(f'알 수 없는 슬롯: {value!r}')


class SlotRobot:
    """한 프로세스에서 한 인스턴스만 사용. 실패하면 닫고 실제 위치 확인 후 재연결합니다.

    move의 True는 동작 완료를 뜻합니다. 실제 배치 확인은 카메라/호출자가 합니다.
    쌓인 말의 높이 처리는 지원하지 않습니다. 각 이동은 말 하나, 빈 목적지 기준입니다.
    """
    def __init__(self, config=None, poses=None, *, bus_factory=None):
        root = Path(__file__).resolve().parent
        self.cfg = motion.load(config or root / 'config.json')
        self.poses = motion.load(poses or root / 'poses.json')
        self._factory = bus_factory or motion.make_bus
        self._bus = None
        self._lock = threading.Lock()
        self._fault = False
        self.last_error = None

    def plan(self, src, dst):
        """연결 없이 필요한 자세·경로·잡힘 설정을 검사합니다."""
        return motion.plan(self.cfg, self.poses, slot(src), slot(dst), automatic=True)

    def _at_home(self):
        target = self.poses['poses'].get('home')
        motion.validate_pose(target, self.cfg)
        current = motion.read(self._bus)
        if any(abs(current[k] - target[k]) > self.cfg['start_tolerance_ticks'] for k in motion.ARM):
            raise RuntimeError('저장한 home 자세가 아닙니다. 실제 팔 위치를 확인하세요.')

    def connect(self):
        """설정·보정·home 확인 후 연결. 토크 활성화는 move에서 수행합니다."""
        with self._lock:
            if self._bus is not None:
                raise RuntimeError('이미 연결되어 있습니다.')
            if self._fault:
                raise RuntimeError('실패한 인스턴스는 재사용할 수 없습니다. 위치 확인 후 새로 만드세요.')
            motion.validate_config(self.cfg)
            if (self.poses.get('units') != self.cfg['units'] or
                    self.poses.get('port') != self.cfg['port'] or
                    self.poses.get('calibration') != self.cfg['calibration']):
                raise ValueError('자세 파일의 단위/포트/보정 정보가 설정과 다릅니다.')
            motion.validate_pose(self.poses['poses'].get('home'), self.cfg)
            bus = self._factory(self.cfg['port'])
            try:
                bus.connect()
                self._bus = bus
                if motion.fingerprint(bus) != self.cfg['calibration']:
                    raise ValueError('로봇 보정값이 바뀌었습니다. 자세를 다시 측정하세요.')
                self._at_home()
            except BaseException:
                self._bus = None
                bus.disconnect(False)
                raise

    def move(self, src, dst):
        """출발→집기→잡힘 확인→운반→놓기→home→빈 그리퍼 닫기. 실패 후 자동 재시도 금지."""
        if not self._lock.acquire(blocking=False):
            raise RuntimeError('다른 로봇 명령이 실행 중입니다.')
        moving = False
        try:
            if self._bus is None or self._fault:
                raise RuntimeError('연결되지 않았거나 이전 동작 실패로 잠겼습니다.')
            actions = self.plan(src, dst)
            self._at_home()
            controller = motion.Controller(self._bus, self.cfg)
            moving = True
            controller.prepare()
            for kind, name in actions:
                if kind == 'arm':
                    speed = self.cfg.get('approach_ticks_s', self.cfg['speed_ticks_s']) if name.endswith('.grasp') else self.cfg['speed_ticks_s']
                    controller.move(self.poses['poses'][name], speed_ticks_s=speed)
                elif kind == 'grip':
                    controller.grip(name)
                else:
                    lo, hi = self.cfg['gripper']['holding_range']
                    if not lo <= motion.read(self._bus)['gripper'] <= hi:
                        raise RuntimeError('잡힘 확인 실패. 들어 올리기 전에 중단했습니다.')
            self.last_error = None
            return True
        except BaseException as exc:
            self.last_error = str(exc)
            if moving:
                self._fault = True
                try:
                    controller.hold()
                except Exception:
                    pass
            if not isinstance(exc, Exception):
                raise
            if not moving:
                raise
            return False
        finally:
            self._lock.release()

    def home(self):
        """정상 move가 이미 복귀했는지 확인. 실패 후 임의의 복귀 경로는 실행하지 않습니다."""
        with self._lock:
            if self._bus is None or self._fault:
                raise RuntimeError('연결/동작 상태를 확인하세요. 실패 후 home 자동 이동은 금지됩니다.')
            self._at_home()

    def close(self):
        """토크를 유지한 채 통신 연결만 종료합니다. 팔을 지지한 뒤 전원을 끄세요."""
        with self._lock:
            if self._bus is not None:
                bus, self._bus = self._bus, None
                bus.disconnect(False)

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *_):
        self.close()
