# SO-101 칸 지정 이동 — 학습 없는 독립 실행 코드

대상: 현재 Ubuntu의 LeRobot v0.6.1, SO-101 팔로워, STS3215 ID 1~6.
`slot_robot.py`는 원시 엔코더값으로 자세를 저장·재생합니다. 기존 게임 저장소의 poses.json/robot.json과 호환 형식이 아닙니다. 기존 파일에 덮어쓰지 마세요.
기존 저장소는 GitHub 접근이 되지 않아 수정하지 않았습니다. 실제 로봇 시험 전입니다.

## 네가 직접 할 것

1. 팔로워 USB by-id 확인. ttyACM0/1이나 보드 시리얼만 보고 리더/팔로워를 추측하지 않기.
2. 보드·로봇 고정, 그리퍼가 모든 칸에 닿는지 확인. 종이를 평평하게 고정.
3. 기존 SO-101 보정 완료. 측정 후에는 보정/호밍 오프셋 변경 금지. 바꾸면 다시 측정.
4. 같은 팔로워에서 home, cell_0.above/grasp, cell_1.above/grasp 5개부터 저장.
5. 그리퍼 open/close/holding 값과 기계적으로 허용되는 관절별 범위 측정.
6. 시작→출발 칸, 출발→도착 칸, 도착→home의 모든 이동 구간을 저속으로 검증.
7. 첫 두 칸이 되면 cell_0~cell_28 및 대기/회수 4자리의 above/grasp를 추가. home 포함 총 67개.

이번 버전은 말 1개 이동용입니다. 업힌 말은 별도 높이 자세를 측정한 뒤 확장하세요.
좌표 JSON은 칸 인식용이며 이 제어기는 칸 이름을 받아 관절 자세를 사용합니다. URDF/IK/모델/카메라가 없어도 동작합니다.

## 준비

압축을 풀어 `slot_robot` 폴더를 Windows 다운로드 폴더에 놓았다면 Ubuntu에서:

```bash
cp -r /mnt/c/Users/user/Downloads/slot_robot ~/slot_robot
cd ~/lerobot
source .venv/bin/activate
cd ~/slot_robot
ls -l /dev/serial/by-id/
```

실제 압축 해제 경로에 맞춰 cp 경로를 변경합니다. 폴더가 이미 있으면 별도 새 폴더를 사용하세요.
Studio의 로봇 원격조작/녹화/추론, 이전 모터 조회 스크립트를 종료합니다. 학습만 하는 것은 계속 가능하지만 다른 프로세스가 같은 시리얼 포트를 열면 안 됩니다.
설치/추가 패키지는 이미 만든 LeRobot 가상환경을 사용합니다.

## 1. 초기화 (실제 팔로워 by-id를 넣기)

```bash
python slot_robot.py init --port /dev/serial/by-id/실제_팔로워_장치이름
python slot_robot.py read
```

init은 설정·빈 자세 파일을 생성하고 현재 모터 보정값을 기록합니다. 보정값/ID/PID를 쓰지 않습니다.
read는 0.2초마다 6개 위치를 출력. Ctrl+C 종료.
config.json의 limits는 처음 null입니다. 자동 이동은 측정 범위를 넣기 전까지 금지됩니다.

## 2. 팔로워를 손으로 지지하며 자세 저장

로봇을 잡아 지지하고 실행합니다. `--release`는 모든 모터 토크를 해제합니다. 팔이 떨어질 수 있으며 끝난 후에도 토크는 꺼진 상태입니다.

```bash
python slot_robot.py teach home cell_0.above cell_0.grasp cell_1.above cell_1.grasp --release
```

확인에 y 입력 → 팔로워를 직접 해당 위치로 옮기고 ENTER 저장. 리더 암은 사용하지 않습니다.
- home: 보드/카메라를 가리지 않는 안정된 대기 자세.
- above: 말과 주변 말을 지나갈 충분한 높이의 접근 자세.
- grasp: 그리퍼가 말의 옆면을 잡는 높이. 책상을 누르지 않도록.
- 팔 5개 값만 저장합니다. 그리퍼는 별도 제어해 이동 중 열리지 않게 합니다.
- `poses.json` 자동 저장, 기존 값 변경 시 .bak 생성.
- 일부 자세만 다시 저장: `python slot_robot.py teach cell_1.grasp --release`
- 기록 종료/중단 시 팔을 받쳐 내려놓습니다. 끝났다고 자동으로 토크를 켜지 않습니다.

보드/베이스 위치가 바뀌면 저장 자세를 다시 측정해야 합니다.

## 3. 그리퍼 값 측정

토크 해제 상태에서 팔을 지지합니다. 집게도 무리하게 힘주지 말고 위치를 맞춥니다. 아래 명령 자체는 읽기만 합니다.

```bash
python slot_robot.py grip-sample open
python slot_robot.py grip-sample close
python slot_robot.py grip-sample holding
```

- open: 이웃 말에 닿지 않으면서 말을 집을 만큼 열린 상태.
- close: 말 없는 상태의 무리 없는 닫힌 위치.
- holding: 실제 말을 잡는 폭의 위치. 단순 손으로 맞춘 폭만으로 안정적인 집기라고 판단하지 말고 실제 구동 후 재확인.
- 원시값이므로 open이 close보다 큰지 작은지 고정 가정하지 않습니다.
- holding 명령은 config.gripper.samples에 표본만 추가합니다. 반복 표본으로 실제 잡힘 범위를 판단한 뒤 holding_range에 [작은값, 큰값] 입력. 빈 상태 close값은 포함하면 안 됩니다.
- holding_range=null이면 단계별 실행 시 사람이 잡힘을 확인합니다. --auto는 범위 측정 전 금지됩니다.
- 위치 기반 판정은 힘/말 존재 센서가 아닙니다. 끼임도 잡힘으로 오인할 수 있습니다.

## 4. config.json 직접 편집

```bash
nano config.json
```

limits의 6개 null을 각각 실제 측정한 원시값 범위 [최솟값, 최댓값]으로 바꿉니다. 0~4095 전체를 무조건 넣지 마세요. 저장한 자세와 경로가 기구 끝/책상 충돌 범위에 들어가지 않게 좁혀 설정합니다.
calibration 항목은 수정하지 않습니다. 펌웨어 관절 범위가 안전한 외부 충돌 범위를 보장하지 않습니다.

첫 두 칸용 경로 설정 예시(관절값은 예시 없음):

```json
"home_to_slot": {
  "cell_0": ["cell_0.above"],
  "cell_1": ["cell_1.above"]
},
"slot_to_home": {
  "cell_0": ["home"],
  "cell_1": ["home"]
},
"routes": {
  "cell_0->cell_1": ["home", "cell_1.above"],
  "cell_1->cell_0": ["home", "cell_0.above"]
}
```

이 예시는 home을 운반 중간 자세로 쓸 수 있을 때만 사용합니다. 아니라면 `clearance_left` 같은 자세를 teach로 추가 저장하고 경로 목록에 넣습니다. home→above 직행도 팔 전체에 충돌이 없는지 검증해야 합니다.
각 방향은 별도 경로입니다. 로봇은 보드 선을 따라갈 필요는 없습니다.

초기 설정 속도 80 ticks/s, 20Hz, 도착오차 20 ticks 등은 소프트웨어 시작값이며 하드웨어에서 검증된 값이 아닙니다. 원시값 단위이므로 도/초와 다릅니다.
속도 제한은 관절 명령 보간 제한입니다. TCP 직선이동/충돌회피/안전 인증이 아닙니다.
모터 PID·전류·토크 한도는 기존 설정을 유지합니다. 특히 그리퍼 압력과 온도는 실제 말로 확인하세요.

## 5. 연결 없이 사전 검사

```bash
python slot_robot.py move --src cell_0 --dst cell_1
```

기본은 계획 출력만 합니다. 누락/단위/범위/경로 오류는 실제 모터 연결 전에 거부합니다.
역방향도 확인:
```bash
python slot_robot.py move --src cell_1 --dst cell_0
```

## 6. 최초 이동 — 각 구간 y 확인

팔을 지지한 상태로 수동으로 **저장한 home**에 맞춥니다. 그리퍼는 비어 있어야 합니다. 해당 출발 칸에 말 하나를 둡니다.

```bash
python slot_robot.py move --src cell_0 --dst cell_1 --execute
```

실제 로봇이 움직입니다. 초기 확인 후 현재 위치를 목표값으로 맞추고 토크를 켭니다.
각 구간마다 y 입력. 잡은 직후 들어 올리기 전에도 눈으로 확인합니다.
순서: 열기 → 출발 위 → 집기 → 닫기 → 잡힘 확인 → 상승 → 경로 → 목적지 위 → 내려놓기 → 열기 → 상승 → home.

끝 자세뿐 아니라 보간 중간의 팔/손목/말 모두 충돌하지 않는지 확인합니다. 정확한 칸 위치는 poses 재측정으로 조정합니다.
시험 때마다 실제 성공 여부를 기록합니다. 로봇이 계획을 끝냈다는 로그는 시각적 놓기 성공을 보장하지 않습니다.

## 7. 검증 후 자동 실행 / 게임 연결

holding_range를 실제로 측정하고 전체 경로를 확인한 뒤에만:

```bash
python slot_robot.py move --src cell_0 --dst cell_1 --execute --auto
```

초기 시작 확인은 남아 있으며 이후 구간은 자동입니다. 충돌과 낙하 검출은 없습니다.
게임 프로그램은 같은 CLI에 칸 번호를 넣으면 됩니다. `game_bridge.py` 예시 참고. 동시에 2개 명령을 실행하면 안 됩니다. 결과 코드가 0이어도 카메라/사람의 놓기 확인 후 게임 상태를 확정해야 합니다.

## 중지·종료

Ctrl+C/오류 시 후속 경로·home 복귀·그리퍼 열기를 하지 않고, 가능한 경우 현재 읽은 위치로 hold를 요청합니다. 토크를 유지해 팔 낙하를 줄입니다.
통신 단절/모터 내부 명령이 이미 실행 중이면 정지를 보장할 수 없습니다. Ctrl+C는 하드웨어 비상정지가 아닙니다. 필요 시 팔을 안전하게 받친 뒤 전원을 차단할 수 있도록 준비하세요.
모든 정상 실행이 끝난 뒤도 토크 유지. 팔을 받쳐 안전한 위치에 놓고 전원을 끕니다.

## 검증 범위

LeRobot v0.6.1 공식 MotorsBus API로 작성. 모의 버스 단위 시험과 Python 문법 검사를 수행. 실제 장비에서 이동/집기/경로 검증은 아직 하지 않았습니다.
근거 API: https://github.com/huggingface/lerobot/blob/v0.6.1/src/lerobot/motors/motors_bus.py
기존 프로젝트 config/poses.json에 합치는 작업은 현재 저장소 코드를 확인한 후 별도로 해야 합니다.
