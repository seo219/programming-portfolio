"""SO-101 measured-pose controller. LeRobot v0.6.1. Raw encoder units only."""
import argparse
from dataclasses import asdict
import json
import math
from pathlib import Path
import time

ARM = ('shoulder_pan', 'shoulder_lift', 'elbow_flex', 'wrist_flex', 'wrist_roll')
NAMES = ARM + ('gripper',)
ROOT = Path(__file__).resolve().parent


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, data):
    path = Path(path)
    if path.exists():
        backup = path.with_suffix(path.suffix + '.bak')
        backup.write_bytes(path.read_bytes())
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(path)


def number(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def validate_config(cfg):
    if cfg.get('units') != 'raw_encoder':
        raise ValueError('This tool accepts raw_encoder units ONLY.')
    for name in NAMES:
        bounds = cfg['limits'].get(name)
        if not isinstance(bounds, list) or len(bounds) != 2 or not all(number(v) for v in bounds):
            raise ValueError('Measure and enter limits for ' + name)
        if not 0 <= bounds[0] < bounds[1] <= 4095:
            raise ValueError('Invalid raw bounds: ' + name)
    for key in ('speed_ticks_s', 'gripper_speed_ticks_s', 'hz', 'tolerance_ticks',
                'following_error_ticks', 'timeout_s', 'gripper_settle_s', 'start_tolerance_ticks'):
        if not number(cfg[key]) or cfg[key] <= 0:
            raise ValueError('Invalid positive setting: ' + key)
    if cfg['hz'] > 50 or cfg['speed_ticks_s'] > 300 or cfg['gripper_speed_ticks_s'] > 300:
        raise ValueError('Initial tool caps: 50 Hz, 300 ticks/s. Validate hardware before changing code caps.')
    approach = cfg.get('approach_ticks_s', cfg['speed_ticks_s'])
    if not number(approach) or not 0 < approach <= 300:
        raise ValueError('Invalid approach_ticks_s: expected 0 < speed <= 300.')


def validate_pose(pose, cfg, keys=ARM):
    if not isinstance(pose, dict) or set(pose) != set(keys):
        raise ValueError('Expected exact joints: ' + ', '.join(keys))
    for key, val in pose.items():
        if not number(val) or not cfg['limits'][key][0] <= val <= cfg['limits'][key][1]:
            raise ValueError('Out-of-limit or invalid target: ' + key)


def plan(cfg, poses, src, dst, automatic=False):
    validate_config(cfg)
    if poses.get('units') != 'raw_encoder' or poses.get('port') != cfg['port']:
        raise ValueError('Pose units/port differ from configuration; do not mix robots.')
    if poses.get('calibration') != cfg['calibration']:
        raise ValueError('Pose calibration fingerprint mismatch.')
    if src == dst:
        raise ValueError('Source and destination must differ.')
    route_key = src + '->' + dst
    routes = cfg['routes']
    if route_key not in routes or not isinstance(routes[route_key], list) or not routes[route_key]:
        raise ValueError('Define a measured clearance route in config.routes: ' + route_key)
    if not isinstance(cfg['home_to_slot'].get(src), list) or not cfg['home_to_slot'][src]:
        raise ValueError('Define home_to_slot route ending at source.above: ' + src)
    if not isinstance(cfg['slot_to_home'].get(dst), list) or not cfg['slot_to_home'][dst]:
        raise ValueError('Define slot_to_home route ending at home: ' + dst)
    incoming = cfg['home_to_slot'][src]
    outgoing = cfg['slot_to_home'][dst]
    carry = routes[route_key]
    if incoming[-1] != src + '.above' or carry[-1] != dst + '.above' or outgoing[-1] != 'home':
        raise ValueError('Route endpoints must be source.above, destination.above, and home.')
    for key in ('open', 'close'):
        validate_pose({'gripper': cfg['gripper'][key]}, cfg, ('gripper',))
    holding = cfg['gripper'].get('holding_range')
    if holding is not None:
        if not isinstance(holding, list) or len(holding) != 2 or not all(number(v) for v in holding):
            raise ValueError('holding_range must be [measured_min, measured_max] or null.')
        lo, hi = holding
        if not cfg['limits']['gripper'][0] <= lo < hi <= cfg['limits']['gripper'][1]:
            raise ValueError('Invalid holding_range.')
        if lo <= cfg['gripper']['close'] <= hi:
            raise ValueError('Empty close value must not pass holding_range.')
    if automatic and holding is None:
        raise ValueError('--auto requires a measured holding_range. Use step mode first.')
    actions = [('grip', 'open')]
    actions += [('arm', name) for name in incoming]
    actions += [('arm', src + '.grasp'), ('grip', 'close'), ('check', 'holding'), ('arm', src + '.above')]
    actions += [('arm', name) for name in carry]
    actions += [('arm', dst + '.grasp'), ('grip', 'open'), ('arm', dst + '.above')]
    actions += [('arm', name) for name in outgoing]
    actions += [('grip', 'close')]  # HOME 도착 후 빈 그리퍼 접기. 잡힘 확인은 하지 않음.
    for kind, name in actions:
        if kind == 'arm':
            if name not in poses['poses']:
                raise ValueError('Unmeasured pose: ' + name)
            validate_pose(poses['poses'][name], cfg)
    return actions


def make_bus(port):
    from lerobot.motors import Motor, MotorNormMode
    from lerobot.motors.feetech import FeetechMotorsBus
    return FeetechMotorsBus(port=port, motors={
        name: Motor(i, 'sts3215', MotorNormMode.RANGE_M100_100)
        for i, name in enumerate(NAMES, 1)
    })


def fingerprint(bus):
    return {name: asdict(cal) for name, cal in bus.read_calibration().items()}


def read(bus):
    values = bus.sync_read('Present_Position', normalize=False)
    if set(values) != set(NAMES) or not all(number(v) and 0 <= v <= 4095 for v in values.values()):
        raise ValueError('Invalid feedback; stop. Check position mode/phase/calibration.')
    return values


def yes(message):
    if input(message + ' [y/N] ').strip().lower() != 'y':
        raise RuntimeError('Cancelled; no subsequent movement.')


class Controller:
    def __init__(self, bus, cfg):
        self.bus, self.cfg = bus, cfg

    def hold(self):
        # Best effort only; a failed USB connection cannot guarantee a physical stop.
        self.bus.sync_write('Goal_Position', read(self.bus), normalize=False)

    def prepare(self):
        for name in NAMES:
            if self.bus.read('Operating_Mode', name, normalize=False) != 0:
                raise ValueError('Position mode 0 required: ' + name)
        current = read(self.bus)
        validate_pose(current, self.cfg, NAMES)
        self.bus.sync_write('Goal_Position', current, normalize=False)
        self.bus.enable_torque()

    def move(self, target, speed_ticks_s=None):
        cfg = self.cfg
        start = read(self.bus)
        keys = tuple(target)
        validate_pose(target, cfg, keys)
        speed = cfg['gripper_speed_ticks_s'] if keys == ('gripper',) else cfg['speed_ticks_s']
        if speed_ticks_s is not None:
            if not number(speed_ticks_s) or not 0 < speed_ticks_s <= 300:
                raise ValueError('Invalid movement speed.')
            speed = speed_ticks_s
        duration = max(abs(target[k] - start[k]) for k in keys) / speed
        begin = time.monotonic()
        previous = {k: start[k] for k in keys}
        while True:
            now = time.monotonic()
            actual = read(self.bus)
            if any(abs(actual[k] - previous[k]) > cfg['following_error_ticks'] for k in keys):
                raise RuntimeError('Tracking error. Check obstruction/grasp/torque; not a collision detector.')
            ratio = min(1.0, (now - begin) / max(duration, 0.001))
            command = {k: round(start[k] + (target[k] - start[k]) * ratio) for k in keys}
            self.bus.sync_write('Goal_Position', command, normalize=False)
            previous = command
            if ratio >= 1:
                break
            time.sleep(1 / cfg['hz'])
        deadline = time.monotonic() + cfg['timeout_s']
        while time.monotonic() < deadline:
            actual = read(self.bus)
            if all(abs(actual[k] - target[k]) <= cfg['tolerance_ticks'] for k in keys):
                return
            time.sleep(1 / cfg['hz'])
        raise RuntimeError('Target timeout; execution halted.')

    def grip(self, mode):
        if mode == 'close':
            # A held piece prevents reaching the empty-close target. Ramp and stop
            # after contact inferred from measured position; operator verifies in step mode.
            current = read(self.bus)['gripper']
            target = self.cfg['gripper']['close']
            speed = self.cfg['gripper_speed_ticks_s']
            count = max(1, math.ceil(abs(target-current) / speed * self.cfg['hz']))
            last_actual = current
            stalled_since = None
            for i in range(1, count + 1):
                command = round(current + (target-current) * i/count)
                self.bus.write('Goal_Position', 'gripper', command, normalize=False)
                time.sleep(1/self.cfg['hz'])
                actual = read(self.bus)['gripper']
                if abs(actual-last_actual) <= 2 and abs(command-actual) > 20:
                    stalled_since = stalled_since or time.monotonic()
                else:
                    stalled_since = None
                last_actual = actual
                if (abs(command-actual) > self.cfg['following_error_ticks']
                        or (stalled_since is not None and time.monotonic()-stalled_since > 0.25)):
                    self.bus.write('Goal_Position', 'gripper', actual, normalize=False)
                    break
        else:
            self.move({'gripper': self.cfg['gripper']['open']})
        time.sleep(self.cfg['gripper_settle_s'])


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config', default=str(ROOT/'config.json'))
    ap.add_argument('--poses', default=str(ROOT/'poses.json'))
    sub = ap.add_subparsers(dest='command', required=True)
    p = sub.add_parser('init'); p.add_argument('--port', required=True)
    sub.add_parser('read')
    p = sub.add_parser('home')
    p.add_argument('--execute', action='store_true')
    p.add_argument('--recover-start', action='store_true', help='Allow current feedback outside trial limits for this return only')
    p = sub.add_parser('teach'); p.add_argument('names', nargs='+'); p.add_argument('--release', action='store_true')
    p = sub.add_parser('grip-sample'); p.add_argument('label', choices=['open', 'close', 'holding'])
    p = sub.add_parser('move'); p.add_argument('--src', required=True); p.add_argument('--dst', required=True)
    p.add_argument('--execute', action='store_true'); p.add_argument('--auto', action='store_true')
    args = ap.parse_args()
    if args.command == 'init':
        if Path(args.config).exists() or Path(args.poses).exists():
            raise ValueError('Config/poses already exist; initialization will not overwrite them.')
        bus = make_bus(args.port); bus.connect()
        try:
            calibration = fingerprint(bus)
            print('Current raw positions:', read(bus))
            cfg = {'units':'raw_encoder', 'port':args.port, 'calibration':calibration,
                   'limits':dict.fromkeys(NAMES), 'speed_ticks_s':80, 'gripper_speed_ticks_s':80,
                   'hz':20, 'tolerance_ticks':20, 'following_error_ticks':150, 'timeout_s':10,
                   'gripper_settle_s':0.6, 'start_tolerance_ticks':40,
                   'gripper':{'open':None, 'close':None, 'holding_range':None, 'samples':[]},
                   'home_to_slot':{}, 'slot_to_home':{}, 'routes':{}}
            save(args.config, cfg)
            save(args.poses, {'units':'raw_encoder','port':args.port,'calibration':calibration,'poses':{}})
        finally:
            bus.disconnect(False)
        return
    cfg, poses = load(args.config), load(args.poses)
    actions = None
    if args.command == 'home':
        validate_config(cfg)
        if (poses.get('units') != cfg['units'] or poses.get('port') != cfg['port']
                or poses.get('calibration') != cfg['calibration']):
            raise ValueError('Pose units/port/calibration mismatch.')
        validate_pose(poses['poses'].get('home'), cfg)
        validate_pose({'gripper': cfg['gripper']['close']}, cfg, ('gripper',))
        print('HOME target:', poses['poses']['home'])
        if not args.execute:
            print('PLAN ONLY. Return HOME, then close gripper. Add --execute to move.')
            return
    if args.command == 'move':
        actions = plan(cfg, poses, args.src, args.dst, args.auto)
        for i, action in enumerate(actions, 1): print(i, *action)
        if not args.execute:
            print('PLAN ONLY. No robot connection or motion. Add --execute for step mode.')
            return
    bus = make_bus(cfg['port']); bus.connect()
    controller = Controller(bus, cfg)
    moving = False
    try:
        if fingerprint(bus) != cfg['calibration']:
            raise ValueError('Hardware calibration changed. Remeasure; do not reuse old raw poses.')
        if args.command == 'read':
            while True:
                print(read(bus), flush=True); time.sleep(0.2)
        elif args.command == 'home':
            current = read(bus)
            print('Current positions:', current)
            if args.recover_start:
                # Only permit the measured starting position in addition to existing limits.
                # Stored settings and target limits are not changed.
                import copy
                recovery = copy.deepcopy(cfg)
                for key in NAMES:
                    lo, hi = recovery['limits'][key]
                    recovery['limits'][key] = [min(lo, current[key]), max(hi, current[key])]
                controller = Controller(bus, recovery)
            else:
                validate_pose(current, cfg, NAMES)
            yes('Direct return to HOME, then CLOSE gripper. Verify EMPTY gripper, entire path and hands clear. Execute?')
            moving = True
            controller.prepare()
            controller.move(poses['poses']['home'])
            controller.grip('close')
            print('HOME reached.')
        elif args.command == 'teach':
            if args.release:
                yes('Support the arm. Disable torque on ALL joints for hand teaching?')
                bus.disable_torque()
                print('Torque OFF; support the arm throughout. It stays OFF after exit.')
            for name in args.names:
                if name in poses['poses']:
                    yes('Overwrite measured pose ' + name + '?')
                input('Place supported follower at ' + name + '; press ENTER to save: ')
                values = read(bus)
                poses['poses'][name] = {k:values[k] for k in ARM}
                save(args.poses, poses)
                print(name, poses['poses'][name])
        elif args.command == 'grip-sample':
            input('Set gripper to '+args.label+' physically/using existing control, then ENTER (this command only reads): ')
            value = read(bus)['gripper']
            if args.label in ('open','close'):
                cfg['gripper'][args.label] = value
            else:
                cfg['gripper']['samples'].append(value)
            save(args.config,cfg)
            print('Saved raw gripper sample:', value)
        else:
            current = read(bus)
            home = poses['poses'].get('home')
            validate_pose(home, cfg)
            if any(abs(current[k]-home[k]) > cfg['start_tolerance_ticks'] for k in ARM):
                raise ValueError('Arm must already be at measured home. Position it by teaching first.')
            yes('Verify EMPTY gripper, clear path, one piece only, correct follower and fixed board. Enable motion?')
            moving = True
            controller.prepare()
            for kind,name in actions:
                print(kind,name)
                if kind != 'check' and not args.auto:
                    yes('Execute this segment?')
                if kind == 'arm':
                    speed = cfg.get('approach_ticks_s', cfg['speed_ticks_s']) if name.endswith('.grasp') else cfg['speed_ticks_s']
                    controller.move(poses['poses'][name], speed_ticks_s=speed)
                elif kind == 'grip': controller.grip(name)
                else:
                    holding = cfg['gripper']['holding_range']
                    measured = read(bus)['gripper']
                    if holding is not None and not holding[0] <= measured <= holding[1]:
                        raise RuntimeError('Grasp position outside measured holding range; stopped before lift.')
                    if not args.auto: yes('Visually confirm piece is securely gripped?')
            print('Motion sequence completed. Verify placement externally; not automatically vision-verified.')
    finally:
        if moving:
            try: controller.hold()
            except Exception as exc: print('Hold failed:',exc)
            print('Torque remains enabled. Support arm before powering off. Ctrl+C is not a hardware emergency stop.')
        bus.disconnect(False)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nInterrupted. No automatic return-home or release.')
    except Exception as exc:
        raise SystemExit('ERROR: ' + str(exc))
