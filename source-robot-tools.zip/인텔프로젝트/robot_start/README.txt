내일 실행 순서
1. 오늘 사용한 Windows 계정(user)으로 로그인합니다.
2. 로봇 2대 USB와 전원, 카메라 USB를 연결합니다. 로봇을 작업대에 고정합니다.
3. ZIP 압축을 풀고 start_robot.bat를 우클릭 -> 관리자 권한으로 실행합니다.
   다른 관리자 계정의 자격증명을 사용하면 기존 WSL 환경이 보이지 않을 수 있습니다.
4. Docker 시작이 끝날 때까지 기다립니다. 카메라 송신 창은 켜둡니다.
5. Studio에서 기존 프로젝트를 엽니다.

이 파일은 오늘 설치한 환경을 다시 실행합니다. 새 PC 설치용이 아닙니다.
필수 기존 파일: C:\Users\LOCAL_USER\camera-relay\windows_camera_http.py
필수 기존 환경: camera-relay 가상환경, Ubuntu-24.04, Studio 저장소, Docker Desktop, usbipd.
로봇 VID:PID 1a86:55d3 장치만 찾아 연결합니다. 카메라는 WSL에 연결하지 않습니다.
로봇 USB 연결에 실패하면 케이블/전원을 확인하세요. 장치가 없으면 목록에 표시되지 않습니다.
로봇 포트 번호가 바뀔 수 있으므로 Studio의 리더/팔로워 연결을 확인하세요.
이 실행기는 로봇 동작/녹화/훈련을 시작하지 않습니다.

Studio 카메라 주소: http://host.docker.internal:8081/stream
카메라가 안 나오면 Windows 카메라 앱과 이전 ZMQ 송신기를 닫으세요.
포트 8081이 이미 사용 중이면 기존 프로세스를 유지하므로 실제 영상인지 확인하세요.
IP Camera 메뉴가 숨겨졌으면 Studio 개발자 도구 Console에서:
localStorage.setItem('physicalai:featureFlags:ipcam', 'true'); location.reload();

종료 순서
Studio 녹화/동작을 먼저 종료하고 로봇을 안정된 자세로 둡니다.
Ubuntu에서:
cd ~/physical-ai-studio/application/docker
docker compose stop
카메라 송신 창에서 Ctrl+C로 종료합니다. 이후 Windows를 종료합니다.
docker compose down -v는 데이터 삭제 명령이므로 사용하지 마세요.

검증 범위: 실행 파일 내용과 기존 환경/명령의 일치 여부를 검토했습니다.
실제 Windows PC에서의 자동 실행은 아직 시험하지 않았습니다.
