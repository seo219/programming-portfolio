$ErrorActionPreference = 'Stop'
try {
    Write-Host '[1/5] Starting Docker Desktop...'
    $dockerApp = "$env:ProgramFiles\Docker\Docker\Docker Desktop.exe"
    if (-not (Test-Path $dockerApp)) { throw 'Docker Desktop not found.' }
    Start-Process $dockerApp
    wsl.exe -d Ubuntu-24.04 -- true
    $ready = $false
    for ($i=0; $i -lt 60; $i++) {
        wsl.exe -d Ubuntu-24.04 -- docker info *> $null
        if ($LASTEXITCODE -eq 0) { $ready=$true; break }
        Start-Sleep -Seconds 2
    }
    if (-not $ready) { throw 'Docker not ready. Open Docker Desktop and retry.' }

    Write-Host '[2/5] Connecting robot USB boards (camera stays on Windows)...'
    $lines = usbipd.exe list
    foreach ($line in $lines) {
        if ($line -match '^\s*(\d+-\d+)\s+1a86:55d3\s+') {
            $bus = $Matches[1]
            if ($line -notmatch '\bAttached\s*$') {
                if ($line -match 'Not shared\s*$') {
                    usbipd.exe bind --busid $bus
                    if ($LASTEXITCODE -ne 0) { throw "USB bind failed: $bus. Run BAT as administrator using the same Windows account." }
                }
                usbipd.exe attach --wsl Ubuntu-24.04 --busid $bus
                if ($LASTEXITCODE -ne 0) { throw "USB attach failed: $bus" }
            }
        }
    }
    usbipd.exe list

    Write-Host '[3/5] Starting Windows camera HTTP sender...'
    $python = "$env:USERPROFILE\camera-relay\Scripts\python.exe"
    $sender = "$env:USERPROFILE\camera-relay\windows_camera_http.py"
    if (-not (Test-Path $python)) { throw "Missing: $python" }
    if (-not (Test-Path $sender)) { throw "Missing: $sender" }
    $listener = Get-NetTCPConnection -LocalPort 8081 -State Listen -ErrorAction SilentlyContinue
    if ($listener) {
        Write-Host 'Port 8081 already in use; keeping existing process. Verify camera stream.'
    } else {
        Start-Process -FilePath $python -ArgumentList ('"' + $sender + '"')
    }
    $cameraReady=$false
    for ($i=0; $i -lt 30; $i++) {
        try {
            $request=[System.Net.HttpWebRequest]::Create('http://localhost:8081/stream')
            $request.Timeout=2000
            $response=$request.GetResponse()
            $stream=$response.GetResponseStream()
            $stream.ReadTimeout=2000
            $buffer=New-Object byte[] 1024
            $count=$stream.Read($buffer,0,$buffer.Length)
            $stream.Dispose(); $response.Dispose()
            if ($count -gt 0) { $cameraReady=$true; break }
        } catch { Start-Sleep -Seconds 1 }
    }
    if (-not $cameraReady) { throw 'No camera stream. Close Windows Camera/ZMQ sender; verify USB camera is NOT attached to WSL.' }

    Write-Host '[4/5] Starting Studio...'
    wsl.exe -d Ubuntu-24.04 -- bash -lc 'cd ~/physical-ai-studio/application/docker && docker compose up -d'
    if ($LASTEXITCODE -ne 0) { throw 'Studio startup failed.' }
    $healthy=$false
    for ($i=0; $i -lt 60; $i++) {
        try {
            $result=Invoke-WebRequest -UseBasicParsing -Uri 'http://localhost:7860/api/health' -TimeoutSec 2
            if ($result.StatusCode -eq 200) { $healthy=$true; break }
        } catch {}
        Start-Sleep -Seconds 2
    }
    if (-not $healthy) { throw 'Studio health timeout. Run docker compose logs --tail=80 in Ubuntu.' }
    Write-Host '[5/5] Opening Studio. No robot motion is started.'
    Start-Process 'http://localhost:7860'
    Write-Host 'READY. Keep the camera sender window open. Stream URL: http://host.docker.internal:8081/stream'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
