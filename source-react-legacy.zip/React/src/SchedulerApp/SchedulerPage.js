import { useState, useEffect } from "react";
import FixedSchedule from "../inputpage/FixedSchedule";
import TodoList from "../inputpage/TodoList";
import List from "../listpage/List";
import { generateSchedule } from "../../api/gptScheduler";

const SchedulerPage = () => {
  const [fixedData, setFixedData] = useState(null);
  const [todoData, setTodoData] = useState(null);
  const [generatedTasks, setGeneratedTasks] = useState([]);

  useEffect(() => {
    if (fixedData && todoData) {
      const formattedTodos = todoData.map(item => ({
        ...item,
        dueDate: item.dueDate ? item.dueDate.toISOString() : null,
      }));

      (async () => {
        const gptText = await generateSchedule({ fixedData, todoData: formattedTodos });
        const parsed = parseSchedule(gptText);
        console.log("GPT 응답:", gptText);
        setGeneratedTasks(parsed);
      })();
    }
  }, [fixedData, todoData]);

  const parseSchedule = (text) => text
    .split("\n")
    .map(line => {
      const [time, task] = line.split(" - ");
      return { time: time?.trim(), task: task?.trim() };
    })
    .filter(item => item.time && item.task);

  return (
    <>
      <FixedSchedule onChange={setFixedData} />
      <TodoList onChange={setTodoData} />
      <List scheduleData={generatedTasks} />
    </>
  );
};

export default SchedulerPage;
