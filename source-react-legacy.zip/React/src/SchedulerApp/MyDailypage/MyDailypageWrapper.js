import React, { useState, useEffect } from "react"; 

import MyInput from "./MyInputpage/MyInput"; 

import MyInputHeader from "./MyInputpage/MyInputHeader"; 

import MyOutput from "./MyOutputpage/MyOutput"; 

import MyOutputHeader from "./MyOutputpage/MyOutputHeader"; 

import { generateSimpleSchedule } from "../../api/gptScheduler"; 

import { loadDailyData, saveDailyData } from "../../firebase/firestoreService"; 

import { auth } from "../../firebase/firebase"; 

 

const MyDailypageWrapper = ({ 

  currentDate, 

  setCurrentDate, 

  interest, 

  setInterest, 

  mood, 

  setMood, 

  generatedTasksMap, 

  setGeneratedTasksMap, 

  isGeneratedMap, 

  setIsGeneratedMap, 

}) => { 

  const currentKey = currentDate.toISOString().split("T")[0]; 

 

  const isGenerated = !!isGeneratedMap?.[currentKey]; 

  const generatedTasks = generatedTasksMap?.[currentKey] ?? []; 

 

  useEffect(() => { 

    const user = auth.currentUser; 

    if (!user) { 

      setIsGeneratedMap((prev) => ({ ...prev, [currentKey]: false })); 

      setGeneratedTasksMap((prev) => ({ ...prev, [currentKey]: [] })); 

      setInterest(""); 

      setMood(""); 

      return; 

    } 

 

    loadDailyData(user.uid, currentKey) 

      .then((data) => { 

        if (data) { 

          const hasTasks = data.generatedTasks && data.generatedTasks.length > 0; 

          setIsGeneratedMap((prev) => ({ ...prev, [currentKey]: hasTasks })); 

          setGeneratedTasksMap((prev) => ({ ...prev, [currentKey]: data.generatedTasks || [] })); 

          setInterest(data.interest || ""); 

          setMood(data.mood || ""); 

        } else { 

          setIsGeneratedMap((prev) => ({ ...prev, [currentKey]: false })); 

          setGeneratedTasksMap((prev) => ({ ...prev, [currentKey]: [] })); 

          setInterest(""); // 스케줄이 없을 때만 초기화 

          setMood("");     // 스케줄이 없을 때만 초기화 

        } 

      }) 

      .catch((error) => { 

        console.error("Firebase 데이터 로드 실패:", error); 

        setIsGeneratedMap((prev) => ({ ...prev, [currentKey]: false })); 

        setGeneratedTasksMap((prev) => ({ ...prev, [currentKey]: [] })); 

        setInterest(""); 

        setMood(""); 

      }); 

  }, [currentDate, currentKey, setInterest, setMood, setIsGeneratedMap, setGeneratedTasksMap]); 

 

  const handleGenerate = async () => { 

    if (!interest || !mood) { 

      alert("관심 분야와 기분을 모두 선택해주세요."); 

      return; 

    } 

 

    try { 

      const gptText = await generateSimpleSchedule({ interest, mood }); 

      const parsed = gptText 

        .split("\n") 

        .map((line) => { 

          const [time, task] = line.split(" - "); 

          return { time: time?.trim(), task: task?.trim() }; 

        }) 

        .filter((item) => item.time && item.task); 

 

      const user = auth.currentUser; 

      if (user) { 

        await saveDailyData(user.uid, currentKey, { 

          interest: interest, 

          mood: mood, 

          generatedTasks: parsed, 

        }); 

        console.log("Firebase에 데이터 저장 성공:", currentKey); 

      } 

 

      setGeneratedTasksMap((prev) => ({ ...prev, [currentKey]: parsed })); 

      setIsGeneratedMap((prev) => ({ ...prev, [currentKey]: true })); 

    } catch (error) { 

      console.error("일정 생성 실패:", error); 

      alert("일정 생성 중 오류가 발생했습니다."); 

    } 

  }; 

 

  // ✅ 변경 지점: handleBack 함수에서 setInterest와 setMood 호출 제거 

  const handleBack = () => { 

    setIsGeneratedMap((prev) => ({ ...prev, [currentKey]: false })); 

    // setInterest(""); // 이 줄을 제거 

    // setMood("");     // 이 줄을 제거 

  }; 

 

  return ( 

    <> 

      {!isGenerated ? ( 

        <> 

          <MyInputHeader currentDate={currentDate} setCurrentDate={setCurrentDate} /> 

          <MyInput 

            interest={interest} 

            setInterest={setInterest} 

            mood={mood} 

            setMood={setMood} 

          /> 

          <div style={{ textAlign: "center", marginTop: "20px" }}> 

            <button onClick={handleGenerate} style={{ padding: "10px 20px", fontSize: "16px" }}> 

              입력 완료 

            </button> 

          </div> 

        </> 

      ) : ( 

        <> 

          <MyOutputHeader currentDate={currentDate} setCurrentDate={setCurrentDate} /> 

          <MyOutput scheduleData={generatedTasks} currentDate={currentDate} /> 

          <div style={{ textAlign: "center", marginTop: "20px" }}> 

            <button onClick={handleBack} style={{ padding: "10px 20px", fontSize: "16px" }}> 

              다시 입력하기 

            </button> 

          </div> 

        </> 

      )} 

    </> 

  ); 

}; 

 

export default MyDailypageWrapper; 