import React from "react";
import "./MyInput.css";

const MyInput = ({ interest, setInterest, mood, setMood }) => {
  const interestOptions = ["운동", "음악", "미술", "영화/드라마", "독서"];
  const moodOptions = [
    { label: "😞 피곤함", value: "bad" },
    { label: "😐 평범함", value: "neutral" },
    { label: "😊 행복함", value: "happy" },
  ];

  return (
    <div className="TodayOptions">
      <h3>🎯 오늘의 관심 분야</h3>
      <div className="row-interest-options">
        {interestOptions.map(item => (
          <label key={item} className="interest-label">
            <input type="radio" name="interest" value={item} checked={interest === item} onChange={() => setInterest(item)} />
            <span className="custom-radio"></span>
            {item}
          </label>
        ))}
      </div>

      <h3>🌈 오늘의 기분</h3>
      <div className="row-mood-options">
        {moodOptions.map(item => (
          <label key={item.value} className={`mood-circle ${mood === item.value ? "selected" : ""}`}>
            <input type="radio" name="mood" value={item.value} checked={mood === item.value} onChange={() => setMood(item.value)} />
            <span className="emoji">{item.label.split(" ")[0]}</span>
            <span className="mood-text">{item.label.split(" ")[1]}</span>
          </label>
        ))}
      </div>
    </div>
  );
};

export default MyInput;
