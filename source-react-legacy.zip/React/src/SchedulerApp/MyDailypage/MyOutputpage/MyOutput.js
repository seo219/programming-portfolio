import React, { useEffect, useState } from "react";
import "./MyOutput.css";

const MyOutput = ({ scheduleData = [] }) => {
  const [checkStates, setCheckStates] = useState([]);

  useEffect(() => {
    setCheckStates(scheduleData.map((item) => item.isChecked || false));
  }, [scheduleData]);

  const handleCheckboxChange = (index) => {
    setCheckStates((prevStates) => {
      const newStates = [...prevStates];
      newStates[index] = !newStates[index];
      return newStates;
    });
  };

  const toMinutes = (t = "00:00") => {
    const [h, m] = t.split(":").map(Number);
    return h * 60 + m;
  };

  const sorted = [...scheduleData].sort((a, b) => {
    if (a.task.includes("기상")) return -1;
    if (b.task.includes("기상")) return 1;
    if (a.task.includes("취침")) return 1;
    if (b.task.includes("취침")) return -1;
    return toMinutes(a.time) - toMinutes(b.time);
  });

  return (
    <div>
      <table className="schedule-table">
        <tbody>
          {sorted.map((item, index) => (
            <tr key={index}>
              <td>{item.time}</td>
              <td>{item.task}</td>
              <td>
                <input
                  type="checkbox"
                  checked={checkStates[index] || false}
                  onChange={() => handleCheckboxChange(index)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MyOutput;
