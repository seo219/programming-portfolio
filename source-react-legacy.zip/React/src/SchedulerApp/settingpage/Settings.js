import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { signOut, sendPasswordResetEmail, deleteUser } from 'firebase/auth';
import { auth, db } from '../../firebase/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import './Settings.css';

const FONT_FAMILIES = [
  'Noto Sans KR',
  'Nanum Gothic',
  'Nanum Myeongjo',
  'Jua',
  'Gothic A1',
  'Spoqa Han Sans',
  'Maplestory OTF',
  'Pretendard',
];

const FONT_SIZES = [12, 14, 16, 18, 20, 24];

export default function Settings() {
  const navigate = useNavigate();
  const [fontFamily, setFontFamily] = useState(FONT_FAMILIES[0]);
  const [fontSize, setFontSize] = useState(FONT_SIZES[2]);
  const [theme, setTheme] = useState('light');
  const [showFontModal, setShowFontModal] = useState(false);
  const [showThemeModal, setShowThemeModal] = useState(false);

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;
    (async () => {
      const ref = doc(db, 'users', user.uid, 'settings', 'appearance');
      const snap = await getDoc(ref);
      if (snap.exists()) {
        const data = snap.data();
        data.fontFamily && setFontFamily(data.fontFamily);
        data.fontSize && setFontSize(data.fontSize);
        data.theme && setTheme(data.theme);
        applyAppearance(data);
      }
    })();
  }, []);

  const applyAppearance = ({ fontFamily, fontSize, theme }) => {
    document.documentElement.style.setProperty('--app-font-family', fontFamily);
    document.documentElement.style.setProperty('--app-font-size', `${fontSize}px`);
    document.documentElement.setAttribute('data-theme', theme);
  };

  const saveAppearance = async () => {
    const user = auth.currentUser;
    if (!user) return alert('로그인된 사용자가 아닙니다.');
    const ref = doc(db, 'users', user.uid, 'settings', 'appearance');
    const payload = { fontFamily, fontSize, theme };
    try {
      await setDoc(ref, payload, { merge: true });
      applyAppearance(payload);
      setShowFontModal(false);
      setShowThemeModal(false);
      alert('디자인 설정이 저장되었습니다.');
    } catch (error) {
      console.error('디자인 설정 저장 실패:', error);
      alert('디자인 설정 저장 중 오류가 발생했습니다.');
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error('로그아웃 실패:', error);
      alert('로그아웃 중 오류가 발생했습니다.');
    }
  };

  const handlePasswordReset = async () => {
    const user = auth.currentUser;
    if (!user?.email) return alert('로그인된 사용자 정보가 없습니다.');
    try {
      await sendPasswordResetEmail(auth, user.email);
      alert('비밀번호 재설정 이메일을 발송했습니다.');
    } catch (error) {
      console.error('비밀번호 재설정 실패:', error);
      alert('비밀번호 재설정 중 오류가 발생했습니다.');
    }
  };

  const handleDeleteAccount = async () => {
    if (!window.confirm('정말 계정을 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.')) return;
    try {
      await deleteUser(auth.currentUser);
      alert('계정이 삭제되었습니다.');
      navigate('/signup');
    } catch (error) {
      console.error('계정 삭제 실패:', error);
      alert('계정 삭제 중 오류가 발생했습니다.');
    }
  };

  return (
    <div className="settings-container">
      <h1 className="settings-main-title">설정</h1>
      <div className="settings-line" />

      <div className="settings-section" style={{ marginBottom: '60px' }}>
        <div className="settings-header">
          <span className="settings-title">👤 계정 설정</span>
        </div>
        <ul className="settings-list" style={{ gap: '12px' }}>
          <li className="settings-item" onClick={handleLogout}>로그아웃</li>
          <li className="settings-item" onClick={handleDeleteAccount}>계정 삭제</li>
          <li className="settings-item" onClick={handlePasswordReset}>비밀번호 재설정</li>
        </ul>
      </div>

      <div className="settings-section">
        <div className="settings-header">
          <span className="settings-title">🎨 디자인</span>
        </div>
        <ul className="settings-list" style={{ gap: '12px' }}>
          <li className="settings-item" onClick={() => setShowFontModal(true)}>
            글꼴 변경: {fontFamily}, {fontSize}px
          </li>
          <li className="settings-item" onClick={() => setShowThemeModal(true)}>
            테마 색상: {theme === 'light' ? '기본(라이트)' : '다크'}
          </li>
        </ul>

        {showFontModal && (
          <div className="modal-backdrop">
            <div className="modal">
              <h4>글꼴 설정</h4>
              <label>폰트 가족</label>
              <select value={fontFamily} onChange={e => setFontFamily(e.target.value)}>
                {FONT_FAMILIES.map(f => (<option key={f}>{f}</option>))}
              </select>
              <label>폰트 크기</label>
              <select value={fontSize} onChange={e => setFontSize(Number(e.target.value))}>
                {FONT_SIZES.map(s => (<option key={s}>{s}</option>))}
              </select>
              <div className="font-preview" style={{ fontFamily, fontSize: `${fontSize}px`, marginTop: '16px', padding: '12px' }}>
                가나다라마바사아자차카타파하
              </div>
              <div className="modal-actions">
                <button onClick={saveAppearance}>저장</button>
                <button onClick={() => setShowFontModal(false)}>취소</button>
              </div>
            </div>
          </div>
        )}

        {showThemeModal && (
          <div className="modal-backdrop">
            <div className="modal">
              <h4>테마 색상</h4>
              <select value={theme} onChange={e => setTheme(e.target.value)}>
                <option value="light">기본(라이트)</option>
                <option value="dark">다크</option>
              </select>
              <div className="modal-actions">
                <button onClick={saveAppearance}>저장</button>
                <button onClick={() => setShowThemeModal(false)}>취소</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}