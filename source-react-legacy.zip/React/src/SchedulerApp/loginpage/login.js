import React, { useState } from 'react';
import './login.css';

const LoginPage = ({ onLogin, onRegister }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    if (!email || !password) return alert('이메일과 비밀번호를 모두 입력해주세요.');
    const success = await onLogin(email, password);
    if (!success) alert('올바르지 않은 이메일 또는 비밀번호입니다.');
  };

  const handleRegister = async () => {
    if (!email || !password) return alert('이메일과 비밀번호를 모두 입력해주세요.');
    await onRegister(email, password);
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <input type="email" className="input-field" placeholder="이메일을 입력하시오." value={email} onChange={e => setEmail(e.target.value)} />
        <input type="password" className="input-field" placeholder="비밀번호를 입력하시오." value={password} onChange={e => setPassword(e.target.value)} />
        <button className="login-btn" onClick={handleLogin}>로그인</button>
        <button className="signup-btn" onClick={handleRegister}>회원가입</button>
      </div>
    </div>
  );
};

export default LoginPage;
