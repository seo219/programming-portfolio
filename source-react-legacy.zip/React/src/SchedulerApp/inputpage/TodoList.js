import React, { useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import "./TodoList.css";

const TodoList = ({ items, setItems }) => {
  const [activeDatePickerId, setActiveDatePickerId] = useState(null);

  const handleAddItem = () => {
    const newItem = { id: Date.now(), text: "", dueDate: null };
    setItems([...items, newItem]);
  };

  const handleDeleteItem = (id) => {
    if (items.length === 1) return;
    setItems(items.filter(item => item.id !== id));
    if (activeDatePickerId === id) setActiveDatePickerId(null);
  };

  const handleChangeItem = (id, value) => {
    setItems(items.map(item => (item.id === id ? { ...item, text: value } : item)));
  };

  const handleToggleDatePicker = (id) => {
    setActiveDatePickerId(activeDatePickerId === id ? null : id);
  };

  const handleDateChange = (id, date) => {
    setItems(items.map(item => (item.id === id ? { ...item, dueDate: date } : item)));
    setActiveDatePickerId(null);
  };

  const activeItem = items.find(item => item.id === activeDatePickerId);

  return (
    <div className="TodoList">
      <div className="todo-header">
        <h3>✅ 할 일 목록</h3>
        <button className="add-btn" onClick={handleAddItem}>＋</button>
      </div>

      {items.map(item => (
        <div className="todo-item" key={item.id}>
          <input placeholder="제목 입력" value={item.text} onChange={e => handleChangeItem(item.id, e.target.value)} />
          <button className="date-btn" onClick={() => handleToggleDatePicker(item.id)}>마감일</button>
          <button className="todo-delete-btn" onClick={() => handleDeleteItem(item.id)}>삭제</button>
        </div>
      ))}

      {activeItem && (
        <DatePicker
          selected={activeItem.dueDate}
          onChange={date => handleDateChange(activeItem.id, date)}
          inline
        />
      )}
    </div>
  );
};

export default TodoList;
