import "./Header.css";

const Header = ({ currentDate, setCurrentDate }) => {
  const gotoPreviousDate = () => {
    const prevDate = new Date(currentDate);
    prevDate.setDate(prevDate.getDate() - 1);
    setCurrentDate(prevDate);
  };

  const gotoNextDate = () => {
    const nextDate = new Date(currentDate);
    nextDate.setDate(nextDate.getDate() + 1);
    setCurrentDate(nextDate);
  };

  return (
    <div className="Header">
      <button className="nav-button" onClick={gotoPreviousDate}>◀</button>
      <h3 className="date">
        {currentDate.toLocaleDateString('ko-KR', {
          year: 'numeric', month: 'long', day: 'numeric'
        })}
      </h3>
      <button className="nav-button" onClick={gotoNextDate}>▶</button>
    </div>
  );
};

export default Header;
