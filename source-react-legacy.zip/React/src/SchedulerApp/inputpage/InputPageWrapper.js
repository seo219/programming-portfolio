import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import FixedSchedule from "./FixedSchedule";
import TodoList from "./TodoList";
import Header from "./Header";
import List from "../listpage/List";
import { generateSchedule } from "../../api/gptScheduler";
import { saveDailyData, loadDailyData } from "../../firebase/firestoreService";
import { auth } from "../../firebase/firebase";

const InputPageWrapper = ({ currentDate, setCurrentDate }) => {
  const location = useLocation();
  const [generatedTasksMap, setGeneratedTasksMap] = useState({});
  const [isGenerated, setIsGenerated] = useState(false);
  const [fixedDataMap, setFixedDataMap] = useState({});
  const [todoDataMap, setTodoDataMap] = useState({});

  const yyyy = currentDate.getFullYear();
  const mm = String(currentDate.getMonth() + 1).padStart(2, "0");
  const dd = String(currentDate.getDate()).padStart(2, "0");
  const currentKey = `${yyyy}-${mm}-${dd}`;

  useEffect(() => {
    if (location.state?.fromDate) setCurrentDate(new Date(location.state.fromDate));
  }, [location.state, setCurrentDate]);

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;
    loadDailyData(user.uid, currentKey).then((data) => {
      if (data) {
        setFixedDataMap((prev) => ({
          ...prev,
          [currentKey]: {
            schedules: data.schedules || [{ text: "", time: "", endTime: "" }],
            sleepTime: data.sleepTime || {},
            meals: data.meals || {},
          },
        }));
        setTodoDataMap((prev) => ({
          ...prev,
          [currentKey]: data.todos || [{ text: "", dueDate: null }],
        }));
        setGeneratedTasksMap((prev) => ({
          ...prev,
          [currentKey]: data.generatedTasks ?? [],
        }));
        setIsGenerated(location.state?.forceInput ? false : !!data.generatedTasks);
      }
    });
  }, [currentDate, currentKey, location.state]);

  useEffect(() => {
    if (!location.state?.forceInput) setIsGenerated(!!generatedTasksMap[currentKey]);
    setFixedDataMap((prev) => {
      if (!prev[currentKey]) {
        return {
          ...prev,
          [currentKey]: {
            schedules: [{ text: "", time: "", endTime: "" }],
            sleepTime: {},
            meals: {},
          },
        };
      }
      return prev;
    });
    setTodoDataMap((prev) => {
      if (!prev[currentKey]) {
        return {
          ...prev,
          [currentKey]: [{ text: "", dueDate: null }],
        };
      }
      return prev;
    });
  }, [currentDate, currentKey, generatedTasksMap, location.state]);

  const handleGenerate = async () => {
    const fixedData = fixedDataMap[currentKey];
    const todoData = todoDataMap[currentKey];
    const formattedTodos = todoData.map((item) => {
      let dueDateISO = null;
      if (item.dueDate) {
        try {
          const parsedDate = new Date(item.dueDate);
          if (!isNaN(parsedDate.getTime())) dueDateISO = parsedDate.toISOString();
        } catch (e) {
          console.warn("Invalid dueDate detected:", item.dueDate);
        }
      }
      return { task: item.text, dueDate: dueDateISO };
    });
    try {
      const gptText = await generateSchedule({ fixedData, todoData: formattedTodos });
      const parsed = parseSchedule(gptText);
      setGeneratedTasksMap((prevMap) => ({ ...prevMap, [currentKey]: parsed }));
      const user = auth.currentUser;
      if (user) {
        await saveDailyData(user.uid, currentKey, {
          schedules: fixedData.schedules,
          sleepTime: fixedData.sleepTime,
          meals: fixedData.meals,
          todos: todoData,
          generatedTasks: parsed,
        });
      }
      setIsGenerated(true);
    } catch (error) {
      console.error("일정 생성 실패:", error);
      alert("일정 생성 중 오류가 발생했습니다.");
    }
  };

  const parseSchedule = (text) => {
    return text
      .split("\n")
      .map((line) => {
        const [timeRaw, taskRaw] = line.split(" - ");
        if (!timeRaw || !taskRaw) return null;
        const time = timeRaw.trim();
        const task = taskRaw.trim();
        let category = "todo";
        if (/기상|취침/.test(task)) category = "sleep";
        else if (/식사|아침|점심|저녁/.test(task)) category = "meal";
        else {
          const fixedTitles = fixedDataMap[currentKey]?.schedules.map((s) => s.text) || [];
          if (fixedTitles.includes(task)) category = "fixed";
        }
        return { time, task, category, isChecked: false };
      })
      .filter(Boolean);
  };

  const handleBackToInput = () => setIsGenerated(false);

  const fixedData = fixedDataMap[currentKey] || {
    schedules: [{ text: "", time: "", endTime: "" }],
    sleepTime: {},
    meals: {},
  };

  const todoData = todoDataMap[currentKey] || [{ text: "", dueDate: null }];

  return (
    <>
      <Header currentDate={currentDate} setCurrentDate={setCurrentDate} />
      {!isGenerated ? (
        <>
          <FixedSchedule
            schedules={fixedData.schedules}
            setSchedules={(schedules) => setFixedDataMap((prev) => ({ ...prev, [currentKey]: { ...prev[currentKey], schedules } }))}
            sleepTime={fixedData.sleepTime}
            setSleepTime={(sleepTime) => setFixedDataMap((prev) => ({ ...prev, [currentKey]: { ...prev[currentKey], sleepTime } }))}
            meals={fixedData.meals}
            setMeals={(meals) => setFixedDataMap((prev) => ({ ...prev, [currentKey]: { ...prev[currentKey], meals } }))}
          />
          <TodoList
            items={todoData}
            setItems={(items) => setTodoDataMap((prev) => ({ ...prev, [currentKey]: items }))}
          />
          <div style={{ marginTop: "20px", textAlign: "center" }}>
            <button onClick={handleGenerate} style={{ padding: "10px 20px", fontSize: "16px" }}>입력 완료</button>
          </div>
        </>
      ) : (
        <>
          <List scheduleData={generatedTasksMap?.[currentKey] || []} />
          <div style={{ marginTop: "20px", textAlign: "center" }}>
            <button onClick={handleBackToInput} style={{ padding: "10px 20px", fontSize: "16px" }}>다시 입력하기</button>
          </div>
        </>
      )}
    </>
  );
};

export default InputPageWrapper;