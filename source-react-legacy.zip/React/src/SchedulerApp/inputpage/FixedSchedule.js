import React from "react";
import "./FixedSchedule.css";

const FixedSchedule = ({ schedules, setSchedules, sleepTime, setSleepTime, meals, setMeals }) => {
  const handleAdd = () => setSchedules([...schedules, { text: "", time: "", endTime: "" }]);
  const handleDelete = (index) => {
    if (schedules.length === 1) return;
    setSchedules(schedules.filter((_, i) => i !== index));
  };
  const handleChange = (index, field, value) => {
    const newSchedules = [...schedules];
    newSchedules[index][field] = value;
    setSchedules(newSchedules);
  };

  return (
    <div className="FixedSchedule">
      <h3>🌙 수면 시간</h3>
      <div className="row">
        <h4>기상 시간</h4>
        <input type="time" value={sleepTime.wakeUp} onChange={e => setSleepTime({ ...sleepTime, wakeUp: e.target.value })} />
      </div>
      <div className="row">
        <h4>취침 시간</h4>
        <input type="time" value={sleepTime.bedTime} onChange={e => setSleepTime({ ...sleepTime, bedTime: e.target.value })} />
      </div>

      <h3>🍽️ 식사 시간</h3>
      <div className="row">
        <h4>아침 식사</h4>
        <input type="time" value={meals.breakfast} onChange={e => setMeals({ ...meals, breakfast: e.target.value })} />
      </div>
      <div className="row">
        <h4>점심 식사</h4>
        <input type="time" value={meals.lunch} onChange={e => setMeals({ ...meals, lunch: e.target.value })} />
      </div>
      <div className="row">
        <h4>저녁 식사</h4>
        <input type="time" value={meals.dinner} onChange={e => setMeals({ ...meals, dinner: e.target.value })} />
      </div>

      <div className="schedule-header">
        <h3>📅 고정 스케줄</h3>
        <button className="add-btn" onClick={handleAdd}>＋</button>
      </div>

      {schedules.map((item, index) => (
        <div className="schedule-row" key={index}>
          <input type="text" className="title-input" placeholder="제목 입력" value={item.text} onChange={e => handleChange(index, "text", e.target.value)} />
          <div className="time-row">
            <input type="time" className="start-time" value={item.time} onChange={e => handleChange(index, "time", e.target.value)} />
            <span className="time-separator">~</span>
            <input type="time" className="end-time" value={item.endTime} onChange={e => handleChange(index, "endTime", e.target.value)} />
            <button className="delete-btn" onClick={() => handleDelete(index)}>삭제</button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default FixedSchedule;
