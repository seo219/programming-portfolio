import React from "react";
import { useNavigate } from "react-router-dom";
import { auth } from "../../firebase/firebase";
import { saveDailyData } from "../../firebase/firestoreService";
import "./CalendarList.css";

export default function CalendarList({ selectedDate, schedules = [], setSchedules }) {
  const navigate = useNavigate();
  if (!selectedDate) {
    return (
      <div className="calendar-list-wrapper">
        <h2>날짜를 선택해주세요.</h2>
      </div>
    );
  }

  const dateStr = `${selectedDate.getFullYear()}년 ${selectedDate.getMonth() + 1}월 ${selectedDate.getDate()}일`;
  const toMinutes = (t = "00:00") => {
    const [h, m] = t.split(":").map(Number);
    return h * 60 + m;
  };
  const getTime = (item) => item.time || item.startAt || "";

  const sorted = Array.isArray(schedules)
    ? [...schedules].sort((a, b) => {
        if (a.task.includes("취침")) return 1;
        if (b.task.includes("취침")) return -1;
        return toMinutes(getTime(a)) - toMinutes(getTime(b));
      })
    : [];

  const handleCheckboxChangeByTask = (targetTask, targetTime) => {
    const newList = schedules.map((item) =>
      item.task === targetTask && item.time === targetTime ? { ...item, isChecked: !item.isChecked } : item
    );
    setSchedules(newList);
    const user = auth.currentUser;
    if (user) {
      const yyyy = selectedDate.getFullYear();
      const mm = String(selectedDate.getMonth() + 1).padStart(2, "0");
      const dd = String(selectedDate.getDate()).padStart(2, "0");
      const dateKey = `${yyyy}-${mm}-${dd}`;
      saveDailyData(user.uid, dateKey, { generatedTasks: newList });
    }
  };

  return (
    <div className="calendar-list-wrapper">
      <h2>{dateStr}</h2>
      {sorted.length === 0 ? (
        <>
          <p>해당 날짜에 스케줄이 없습니다.</p>
          <div className="button-group">
            <button onClick={() => navigate("/input")}>고정 스케줄 입력</button>
            <button onClick={() => navigate("/input")}>스케줄링 받기</button>
          </div>
        </>
      ) : (
        <>
          <ul className="schedule-list">
            {sorted.map((it) => {
              const t = it.task || "";
              let cls = "task";
              if (["기상", "취침"].some((w) => t.includes(w))) cls = "sleep";
              else if (["아침", "점심", "저녁", "식사", "밥"].some((w) => t.includes(w))) cls = "meal";
              return (
                <li key={`${it.time}-${it.task}`} className={`schedule-item ${cls}`}>
                  <span className="time">{getTime(it)}</span>
                  <span className="task">{it.task}</span>
                  <input
                    type="checkbox"
                    checked={!!it.isChecked}
                    onChange={(e) => {
                      e.stopPropagation();
                      handleCheckboxChangeByTask(it.task, getTime(it));
                    }}
                  />
                </li>
              );
            })}
          </ul>
          <button
            onClick={() =>
              navigate("/input", {
                state: { fromDate: selectedDate, forceInput: true },
              })
            }
          >
            다시 입력하기
          </button>
        </>
      )}
    </div>
  );
}
