import React, { useState, useEffect, useRef } from "react";
import { auth } from "../../firebase/firebase";
import { loadDailyData } from "../../firebase/firestoreService";
import "./CalendarHeader.css";
import MyCalendar from "./Calendar";
import CalendarList from "./CalendarList";

export default function CalendarHeader({ currentDate, setCurrentDate }) {
  const [selectedDate, setSelectedDate] = useState(currentDate || new Date());
  const [year, setYear] = useState(selectedDate.getFullYear());
  const [month, setMonth] = useState(selectedDate.getMonth() + 1);
  const [showYearDropdown, setShowYearDropdown] = useState(false);
  const [showMonthDropdown, setShowMonthDropdown] = useState(false);
  const [schedules, setSchedules] = useState([]);
  const yearRef = useRef();
  const monthRef = useRef();

  const fetchSchedules = (date) => {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const dd = String(date.getDate()).padStart(2, "0");
    const key = `${yyyy}-${mm}-${dd}`;
    const user = auth.currentUser;
    if (!user) return setSchedules([]);
    loadDailyData(user.uid, key).then((data) => {
      setSchedules(Array.isArray(data?.generatedTasks) ? data.generatedTasks : []);
    });
  };

  useEffect(() => {
    fetchSchedules(selectedDate);
  }, [selectedDate]);

  useEffect(() => {
    const handleClick = (e) => {
      if (yearRef.current && !yearRef.current.contains(e.target)) setShowYearDropdown(false);
      if (monthRef.current && !monthRef.current.contains(e.target)) setShowMonthDropdown(false);
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const onDateClick = (date) => {
    setSelectedDate(date);
    setCurrentDate(date);
  };

  return (
    <div className="calendar-header-container">
      <div className="year-section" ref={yearRef}>
        <button className="year-button" onClick={() => setShowYearDropdown((v) => !v)}>
          {year}년 ▾
        </button>
        {showYearDropdown && (
          <ul className="year-dropdown">
            {Array.from({ length: 21 }, (_, i) => year - 10 + i).map((y) => (
              <li key={y} onClick={() => { setYear(y); setShowYearDropdown(false); }}>{y}년</li>
            ))}
          </ul>
        )}
      </div>

      <div className="month-section" ref={monthRef}>
        <button className="month-button" onClick={() => setShowMonthDropdown((v) => !v)}>
          {month}월 ▾
        </button>
        {showMonthDropdown && (
          <ul className="month-dropdown">
            {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
              <li key={m} onClick={() => { setMonth(m); setShowMonthDropdown(false); }}>{m}월</li>
            ))}
          </ul>
        )}
      </div>

      <MyCalendar year={year} month={month} value={selectedDate} onClickDay={onDateClick} />
      <CalendarList selectedDate={selectedDate} schedules={schedules} setSchedules={setSchedules} />
    </div>
  );
}
