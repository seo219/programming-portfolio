import React from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import "./Calendar.css";

const MyCalendar = ({ year, month, onClickDay, value }) => {
  const dateValue = value || new Date(year, month - 1, 1);

  return (
    <div className="calendar-wrapper">
      <Calendar
        activeStartDate={new Date(year, month - 1, 1)}
        value={dateValue}
        showNavigation={false}
        onClickDay={onClickDay}
        tileClassName={({ date: tileDate, view }) => {
          if (view === "month") {
            const day = tileDate.getDay();
            if (day === 6) return "saturday";
            if (day === 0) return "sunday";
          }
          return null;
        }}
      />
    </div>
  );
};

export default MyCalendar;
