// src/SchedulerApp/navigationbar/NavBar.js
import { NavLink } from "react-router-dom";
import "./NavBar.css";

const NavBar = () => (
  <nav className="nav-bar">
    <NavLink to="/Calendar">📅</NavLink>
    <NavLink to="/input">📝</NavLink>
    <NavLink to="/daily">✔️</NavLink>
    <NavLink to="/setting">⚙️</NavLink>
  </nav>
);

export default NavBar;
