import React from "react";
import { Outlet, useLocation } from "react-router-dom";
import NavBar from "./NavBar";

const Layout = () => {
  const location = useLocation();
  const hideNavRoutes = ["/login", "/register"];
  const showNavBar = !hideNavRoutes.includes(location.pathname);

  return (
    <div className="App">
      <Outlet />
      {showNavBar && <NavBar />}
    </div>
  );
};

export default Layout;
