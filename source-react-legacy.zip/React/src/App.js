import React, { useEffect, useState } from "react"; 

import { BrowserRouter as Router, useLocation, Navigate, useNavigate } from "react-router-dom"; 

import { signInWithEmailAndPassword, createUserWithEmailAndPassword, onAuthStateChanged } from "firebase/auth"; 

 

import { auth } from "./firebase/firebase"; 

 

import LoginPage from "./SchedulerApp/loginpage/login"; 

import ListHeader from "./SchedulerApp/listpage/ListHeader"; 

import List from "./SchedulerApp/listpage/List"; 

import NavBar from "./SchedulerApp/navigationbar/NavBar"; 

import InputPageWrapper from "./SchedulerApp/inputpage/InputPageWrapper"; 

import MyDailypageWrapper from "./SchedulerApp/MyDailypage/MyDailypageWrapper"; 

import CalendarHeader from "./SchedulerApp/calendarpage/CalendarHeader"; 

import Settings from "./SchedulerApp/settingpage/Settings"; 

 

import "./App.css"; 

 

function App() { 

  return ( 

    <Router> 

      <AppInner /> 

    </Router> 

  ); 

} 

 

function AppInner() { 

  const navigate = useNavigate(); 

  const { pathname: path } = useLocation(); 

 

  const [isLoggedIn, setIsLoggedIn] = useState(false); 

  const [authChecked, setAuthChecked] = useState(false); 

 

  const [currentDate, setCurrentDate] = useState(new Date()); 

 

  const [interest, setInterest] = useState(""); 

  const [mood, setMood] = useState(""); 

  const [generatedTasksMap, setGeneratedTasksMap] = useState({}); // 날짜별 생성된 일정 저장 

 

  // ✅ 추가: MyDailypageWrapper의 isGeneratedMap 상태를 AppInner로 끌어올림 

  const [isGeneratedMap, setIsGeneratedMap] = useState({}); 

 

 

  // 인증 상태 변화 감지 및 로그인 상태 업데이트 

  useEffect(() => { 

    const unsub = onAuthStateChanged(auth, (user) => { 

      setIsLoggedIn(!!user); 

      setAuthChecked(true); 

    }); 

    return () => unsub(); 

  }, []); 

 

  // 로그인 처리 함수 

  const handleLogin = async (email, password) => { 

    try { 

      await signInWithEmailAndPassword(auth, email, password); 

      navigate("/Calendar"); 

      return true; 

    } catch (error) { 

      console.error("로그인 실패:", error); 

      alert("로그인 실패: 이메일 또는 비밀번호를 확인해주세요."); 

      return false; 

    } 

  }; 

 

  // 회원가입 처리 함수 

  const handleRegister = async (email, password) => { 

    try { 

      await createUserWithEmailAndPassword(auth, email, password); 

      alert("✅ 회원가입 성공! 자동으로 로그인됩니다."); 

      navigate("/Calendar"); 

      return true; 

    } catch (error) { 

      console.error("회원가입 실패:", error); 

      alert("❌ 회원가입 실패: " + error.message); 

      return false; 

    } 

  }; 

 

  if (!authChecked) return null; 

 

  if (!isLoggedIn) { 

    return <LoginPage onLogin={handleLogin} onRegister={handleRegister} />; 

  } 

 

  if (["/", "/login", "/signup"].includes(path)) { 

    return <Navigate to="/Calendar" replace />; 

  } 

 

  return ( 

    <div className="App"> 

      {path === "/input" && ( 

        <InputPageWrapper 

          currentDate={currentDate} 

          setCurrentDate={setCurrentDate} 

        /> 

      )} 

 

      {path === "/list" && ( 

        <> 

          <ListHeader currentDate={currentDate} setCurrentDate={setCurrentDate} /> 

          <List scheduleData={generatedTasksMap[currentDate.toISOString().split("T")[0]] || []} /> 

        </> 

      )} 

 

      {path === "/daily" && ( 

        <MyDailypageWrapper 

          currentDate={currentDate} 

          setCurrentDate={setCurrentDate} 

          interest={interest} 

          setInterest={setInterest} 

          mood={mood} 

          setMood={setMood} 

          generatedTasksMap={generatedTasksMap} 

          setGeneratedTasksMap={setGeneratedTasksMap} 

          // ✅ 추가: isGeneratedMap과 setIsGeneratedMap을 props로 전달 

          isGeneratedMap={isGeneratedMap} 

          setIsGeneratedMap={setIsGeneratedMap} 

        /> 

      )} 

 

      {path === "/Calendar" && ( 

        <CalendarHeader 

          currentDate={currentDate} 

          setCurrentDate={setCurrentDate} 

        /> 

      )} 

 

      {path === "/setting" && <Settings />} 

 

      <NavBar /> 

    </div> 

  ); 

} 

 

export default App; 