import { doc, getDoc, setDoc } from "firebase/firestore";
import { db } from "./firebase";

export async function saveDailyData(userId, dateKey, data) {
  const ref = doc(db, "users", userId, "dailySchedules", dateKey);
  await setDoc(ref, data, { merge: true });
}

export async function loadDailyData(userId, dateKey) {
  const ref = doc(db, "users", userId, "dailySchedules", dateKey);
  const snap = await getDoc(ref);
  return snap.exists() ? snap.data() : null;
}
