import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "CONFIGURE_LOCALLY",
  authDomain: "test-qwerasdf.firebaseapp.com",
  projectId: "test-qwerasdf",
  storageBucket: "test-qwerasdf.firebasestorage.app",
  messagingSenderId: "71411477085",
  appId: "1:71411477085:web:fc92183ddd579be27ffbb4",
  measurementId: "G-2PBBN32DXZ"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);