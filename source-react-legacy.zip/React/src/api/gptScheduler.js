import { OpenAI } from "openai";

const openai = new OpenAI({
  apiKey: process.env.REACT_APP_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true,
});

export async function generateSchedule({ fixedData, todoData }) {
  const prompt = makePrompt(fixedData, todoData);
  const res = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
  });
  return res.choices[0]?.message?.content || "";
}

export async function generateSimpleSchedule({ interest, mood }) {
  const prompt = makeSimplePrompt(interest, mood);
  const res = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
  });
  return res.choices[0]?.message?.content || "";
}

function makePrompt(fixedData, todoData) {
  const { wakeUp, bedTime } = fixedData.sleepTime || {};
  const { breakfast, lunch, dinner } = fixedData.meals || {};
  const schedules = fixedData.schedules || [];

  const fixedText = schedules
    .filter((s) => s.time && s.endTime && s.text)
    .map((s) => `${s.time}~${s.endTime} ${s.text}`)
    .join("\n");

  const todoText = [...todoData]
    .sort((a, b) => {
      const dateA = a.dueDate ? new Date(a.dueDate) : new Date("9999-12-31");
      const dateB = b.dueDate ? new Date(b.dueDate) : new Date("9999-12-31");
      return dateA - dateB;
    })
    .map((t) => `- ${t.task}`)
    .join("\n");

  return `
너는 스마트한 하루 일정 비서야.

[기상 시간] ${wakeUp || "없음"}
[취침 시간] ${bedTime || "없음"}

[식사 시간]
아침: ${breakfast || "없음"}
점심: ${lunch || "없음"}
저녁: ${dinner || "없음"}

[고정 일정]
${fixedText || "- 없음"}
(각 고정 일정은 시작시간~끝나는시간 형식으로 되어 있으며, 이 시간 범위에는 다른 일정을 배치하지 마.)

[해야 할 일]
${todoText || "- 없음"}

⏰다음 조건을 모두 만족하도록 하루 일정을 생성해줘:
1. 기상시간은 무조건 가장 먼저 나오게 하고, 취침시간은 무조건 가장 마지막에 나오도록 해. 두 시간 사이에 모든 일정을 배치해.
2. 해야 할 일 목록은 하교하기 이후의 시간부터 취침시간 전까지의 빈 시간 안에, 중복 없이, 마감일과 중요도에 따라 우선순위를 고려해 하나씩 적절한 시간을 정해서 넣어.
3. 모든 일정은 시간(HH:MM) 기준으로 오름차순 정렬되어야 해.
4. 각 일정은 "HH:MM - 할 일" 형식으로 출력하고, 절대 숫자 목록(예: 1. 2. 3.) 형식은 사용하지 마.
5. 아무것도 입력이 되지 않았으면 아무것도 출력하지 마.
6. 하루 일과의 흐름을 고려해서, 가능한 한 자연스러운 시간대에 할 일을 배치해. 아침엔 가벼운 준비, 점심 이후엔 집중적인 활동, 저녁엔 정리/리뷰 중심.
7. 고정 일정이 끝난 직후 비는 시간에는 우선순위 높은 할 일을 먼저 배치해.
8. 할 일은 최대한 분산해서 배치하고, 하루에 너무 밀집되지 않도록 해.
`;
}

function makeSimplePrompt(interest, mood) {
  return `
너는 사용자의 관심사와 기분을 바탕으로 하루 일정을 만들어주는 비서야.

[관심 분야]: ${interest || "없음"}
[기분]: ${mood || "보통"}

⏰ 아래 조건에 따라 일정을 만들어줘:
1. 하루 일정을 08:00부터 22:00 사이에 생성해.
2. 관심 분야와 관련된 활동을 반드시 포함해.
3. 일정은 시간(HH:MM) 기준으로 오름차순으로 정렬해.
4. 각 일정은 "HH:MM - 할 일" 형식으로 출력하고, 설명이나 인삿말 없이 출력해.
5. 숫자 목록(1. 2. 3.)이나 문단 형식은 사용하지 마.
6. 가능한 한 현실적인 일정으로 구성해.
7. 기상 시간은 기본 09:00, 취침 시간은 기본 22:30으로 하되, 기분에 따라 아래와 같이 조정해:
   - 피곤함인 경우:
     • 기상 시간을 10:00으로 하고, 취침 시간을 22:00으로 설정해.
     • 활동 사이사이에 충분한 휴식 시간을 넣고, 가벼운 활동(스트레칭, 산책 등) 위주로 구성해.
   - 행복한 경우:
     • 기상 시간을 08:00으로 하고, 취침 시간을 23:00으로 설정해.
     • 에너지가 넘치는 활동(운동, 친구와 짧은 만남 등)을 넣고, 여유롭게 즐길 수 있는 여가 시간(카페, 산책, 독서 등)을 추가해.
   - 평범한 경우:
     • 기상 시간 09:00, 취침 시간 22:30을 유지.
     • 활동과 휴식이 균형 잡히도록 구성해.
8. 일정에는 아래 예시처럼 “HH:MM - 할 일” 형식만 쓰고, 추가 설명은 괄호 안에서 간단히 해도 되지만, 인삿말 형태는 쓰지 마.
9. 기상 직후에는 가벼운 스트레칭이나 간단한 아침 준비를 넣고, 취침 직전에는 릴렉스할 수 있는 활동(가벼운 독서나 명상)을 넣어.
10. 예시 출력 형식을 참고해 출력해:
08:00 - 기상 및 가벼운 스트레칭
08:30 - 아침식사
...
`;
}


export { makeSimplePrompt };
